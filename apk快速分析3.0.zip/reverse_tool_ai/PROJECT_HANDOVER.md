# 智能逆向助手 - 项目交接文档

> **版本**: 2.0.0  
> **生成日期**: 2026-07-24  
> **项目名称**: reverse_tool_ai (智能逆向助手)  
> **应用包名**: com.revtool.reverse_tool_ai

---

## 一、项目概述

「智能逆向助手」是一款 Android 端 APK/SO 逆向分析工具箱，使用 Flutter 开发，**所有核心解析逻辑均为纯 Dart 实现，不依赖任何外部原生库或命令行工具**（如 apktool、jadx 等）。用户在手机上选择 APK 或 SO 文件后，应用即可在本地完成解析，无需联网。

### 核心能力

| 分析维度 | 功能说明 |
|---------|---------|
| APK 基本信息解析 | 包名、版本号、主 Activity、SDK 版本、文件大小分类统计 |
| AndroidManifest 解析 | 二进制 XML 结构化解析 + 回退原始字节扫描，支持 XML 重建、组件详情、Deep Link 提取 |
| DEX 文件分析 | 类名提取、方法/字段解析、字符串提取、DEX 指令反汇编（smali 级） |
| SO/ELF 文件分析 | ELF 头解析、节区表、符号表（dynsym/symtab）、导入导出分析、JNI 方法定位 |
| 签名检测 | V1/V2/V3 签名方案检测、证书信息（主题/签发者/序列号/算法/指纹） |
| 安全评估 | debuggable/allowBackup 检测、导出组件风险、明文流量、SDK 版本风险 |
| 混淆检测 | 短名比例、平均熵值、单字符类名比例，输出混淆等级 |
| 第三方 SDK 识别 | 扫描 DEX 类名/字符串，识别 100+ 常见 Android SDK（广告/统计/推送/社交/支付/地图/安全/框架） |
| 加壳/加固检测 | 识别 360 加固、腾讯乐固、梆梆、爱加密等常见壳方案 |
| 权限风险分类 | 按 Android 官方保护级别分类（普通/危险/签名），附带中文说明 |
| 敏感 API 检测 | 60+ 敏感 API 关键词扫描（命令执行、反射、动态加载、隐私获取等） |
| 逆向关键词检测 | VIP/Pro/Premium/订阅/广告去除等关键词扫描，辅助逆向分析 |
| URL/IP 提取 | 从 DEX 字符串中提取 HTTP/HTTPS URL 和 IP 地址 |
| 文件结构树 | APK 内文件树展示，含压缩/未压缩大小 |
| 哈希计算 | MD5/SHA1/SHA256 文件指纹 |
| 报告导出 | 纯文本报告 + JSON 格式导出 |
| 内存管理 | LRU 缓存、内存追踪、主动 GC，防止大文件 OOM |

---

## 二、项目结构

```
reverse_tool_ai/
├── lib/                          # 35 个 Dart 文件，约 12,465 行代码
│   ├── main.dart                 # 应用入口，MultiProvider + MaterialApp
│   ├── core/                     # 核心解析引擎（纯 Dart，无第三方依赖）
│   │   ├── apk_analyzer.dart     # APK 主分析器（1786 行）— ZIP 解析、DEX 解析、综合报告
│   │   ├── manifest_parser.dart  # AndroidManifest 二进制 XML 解析器（908 行）— 结构化 + 回退
│   │   ├── dex_disassembler.dart # DEX 指令反汇编器（933 行）— Dalvik 字节码 → smali
│   │   ├── so_analyzer.dart      # ELF/SO 文件解析器（1029 行）— ELF 头/节区/符号表
│   │   ├── apk_signer.dart       # APK 签名块检测
│   │   ├── cert_parser.dart      # X.509 证书解析
│   │   ├── sdk_detector.dart     # 第三方 SDK 识别（244 行）
│   │   ├── packer_detector.dart  # 加壳/加固检测（465 行）
│   │   ├── permission_classifier.dart  # 权限风险分类（308 行）
│   │   ├── res_analyzer.dart     # 资源文件分析
│   │   ├── smali_patcher.dart    # Smali 补丁工具（框架）
│   │   └── memory_manager.dart   # 内存管理器（LRU 缓存 + GC）
│   ├── models/                   # 数据模型
│   │   ├── apk_info.dart         # APK 信息模型（248 行）— 15+ 数据类
│   │   ├── dex_class.dart        # DEX 类/方法/字段模型
│   │   ├── so_symbol.dart        # ELF 符号模型（360 行）
│   │   └── smali_method.dart     # Smali 方法模型
│   ├── providers/                # 状态管理（Provider 模式）
│   │   ├── app_state_provider.dart    # 全局应用状态
│   │   ├── apk_analysis_provider.dart # APK 分析状态（379 行）
│   │   ├── so_analysis_provider.dart  # SO 分析状态
│   │   └── smali_patch_provider.dart  # Smali 补丁状态
│   ├── services/                 # 服务层
│   │   ├── file_picker_service.dart   # 文件选择服务
│   │   ├── cache_service.dart         # 缓存服务
│   │   ├── export_service.dart        # 导出服务
│   │   ├── storage_service.dart       # 存储服务
│   │   └── upload_service.dart        # 上传服务
│   ├── ui/
│   │   └── home_page.dart        # 主界面（2969 行）— 14 个 Tab 页
│   ├── widgets/                  # UI 组件
│   │   ├── info_card.dart        # 信息卡片
│   │   ├── log_panel.dart        # 日志面板
│   │   ├── tree_panel.dart       # 文件树面板
│   │   ├── result_panels.dart    # 分析结果面板
│   │   └── so_analysis_panels.dart  # SO 分析面板
│   └── utils/                    # 工具类
│       ├── hex_utils.dart        # 十六进制/字节读取工具
│       ├── string_utils.dart     # 字符串工具（熵值计算、可打印判断等）
│       └── crypto_utils.dart     # 加解密工具（Base64/Hex/XOR/ROT13/URL decode）
├── android/                      # Android 原生配置
│   ├── app/build.gradle          # 应用级 Gradle 配置
│   ├── build.gradle              # 项目级 Gradle 配置
│   ├── settings.gradle           # Gradle 设置（含 Flutter 插件加载）
│   ├── gradle.properties         # Gradle 属性（JVM 参数、代理配置）
│   └── app/src/main/AndroidManifest.xml  # 应用清单
├── pubspec.yaml                  # Flutter 项目配置
└── pubspec.lock                  # 依赖锁定文件
```

---

## 三、开发环境

### 3.1 基础环境

| 组件 | 版本 | 路径 |
|------|------|------|
| OS | Linux x86_64 | - |
| Java | OpenJDK 17.0.19 | /usr/lib/jvm/java-17-openjdk-amd64 |
| Flutter | 3.44.8 (stable) | /opt/flutter |
| Dart | 3.12.2 (stable) | 随 Flutter |
| Gradle | 8.7 | 项目内 wrapper |
| AGP (Android Gradle Plugin) | 8.6.0 | 项目级 build.gradle |
| Kotlin | 2.0.20 (项目) / 1.9.22 (工具链) | - |
| Android SDK | API 34/35/36 | /opt/android-sdk |
| NDK | 28.2.13676358 | /opt/android-sdk/ndk |
| CMake | 3.22.1 | /opt/android-sdk/cmake |

### 3.2 依赖库

```yaml
# pubspec.yaml
dependencies:
  flutter: { sdk: flutter }
  provider: ^6.1.2          # 状态管理
  file_picker: ^8.0.0       # 文件选择器
  path_provider: ^2.1.3     # 路径获取
  path: ^1.9.0              # 路径处理
  http: ^1.2.1              # HTTP 请求
  url_launcher: ^6.2.5      # URL 打开
  crypto: ^3.0.3            # 哈希计算 (MD5/SHA1/SHA256)
```

### 3.3 APK 信息

| 属性 | 值 |
|------|-----|
| 包名 | com.revtool.reverse_tool_ai |
| 应用名 | 智能逆向助手 |
| 版本 | 2.0.0 (versionCode 1) |
| 最低 SDK | 24 (Android 7.0) |
| 目标 SDK | 34 (Android 14) |
| 编译 SDK | 36 |
| APK 大小 | 约 20 MB |
| 架构 | arm64-v8a |

---

## 四、构建问题与解决方案（重要！）

本项目在构建过程中遇到了多个棘手问题，以下为完整记录，供接手者参考。

### 4.1 Gradle 代理缺失导致下载超时

**问题现象**: Gradle 构建卡在 "Running Gradle task 'assembleRelease'..." 无任何输出，最终超时。

**根因分析**: 系统环境变量中设置了 `HTTP_PROXY=http://127.0.0.1:18080`，但 Gradle **不会自动读取系统环境变量中的代理配置**。Gradle 的 HTTP 客户端直接发起网络请求，在受限网络环境中无法连接到 `maven.aliyun.com`，导致连接超时（30秒）后重试另一个 IP，再次超时，无限循环。

**解决方案**: 在 `android/gradle.properties` 中**显式配置代理**:

```properties
# gradle.properties 追加以下内容
systemProp.http.proxyHost=127.0.0.1
systemProp.http.proxyPort=18080
systemProp.https.proxyHost=127.0.0.1
systemProp.https.proxyPort=18080
```

**排查技巧**: 
1. 运行 `curl -s --connect-timeout 5 https://maven.aliyun.com` 验证网络连通性
2. 检查 `echo $HTTP_PROXY` 确认代理地址
3. 运行 `./gradlew --debug assembleRelease 2>&1 | tail -80` 查看 Gradle 网络日志，搜索 "Connect to" 和 "timed out" 关键词
4. 查看 `/root/.gradle/daemon/8.7/daemon-*.out.log` 中的连接日志

---

### 4.2 Flutter 工具链 Kotlin 版本不兼容

**问题现象**: Gradle 构建过程中，编译 Flutter Gradle 插件（`packages/flutter_tools/gradle`）时，卡在下载 `org.jetbrains.kotlin:kotlin-gradle-plugin:2.0.0`，长时间无响应。

**根因分析**: Flutter 3.44.8 的工具链默认使用 Kotlin 2.2.20（`kotlin("jvm") version "2.2.20"`），但该版本在阿里云镜像仓库中可能尚未同步，或下载速度极慢。即使配置了镜像和代理，大版本 Kotlin 插件的编译依赖链也极为庞大。

**解决方案**: **降级 Flutter 工具链的 Kotlin 版本**，使其与 Gradle 8.7 内嵌的 Kotlin 版本（1.9.22）一致。

需要修改两个文件（位于 Flutter SDK 安装目录下，非项目目录）:

**文件 1**: `/opt/flutter/packages/flutter_tools/gradle/build.gradle.kts`

```kotlin
// 将 kotlin("jvm") version 从 "2.2.20" 改为 "1.9.22"
plugins {
    `java-gradle-plugin`
    groovy
    `kotlin-dsl`
    kotlin("jvm") version "1.9.22"  // 原为 "2.2.20"
}

dependencies {
    // 将 kotlin-gradle-plugin 从 "2.0.0" 改为 "1.9.22"
    implementation("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22")  // 原为 "2.0.0"
    // 将 AGP 从 "8.11.1" 改为 "8.6.0"（与项目配置一致）
    compileOnly("com.android.tools.build:gradle:8.6.0")  // 原为 "8.11.1"
}
```

**文件 2**: `/opt/flutter/packages/flutter_tools/gradle/settings.gradle.kts`

添加 `pluginManagement` 块和阿里云镜像仓库:

```kotlin
pluginManagement {
    repositories {
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/public") }
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
```

**注意事项**:
- 此修改是对 Flutter SDK 的全局修改，会影响该 SDK 下的所有项目
- 如需恢复，执行 `cd /opt/flutter && git checkout -- packages/flutter_tools/gradle/`
- 降级 Kotlin 不会影响项目本身使用的 Kotlin 版本（项目在 `settings.gradle` 中独立声明 `org.jetbrains.kotlin.android` version `2.0.20`）

---

### 4.3 Gradle 内存不足导致 Daemon 崩溃

**问题现象**: 构建过程中报 "Gradle build daemon disappeared unexpectedly" 或 Daemon 进程被 OOM Killer 杀死。

**根因分析**: 默认 Gradle JVM 内存参数过大，在内存受限的沙箱环境中触发 OOM。

**解决方案**: 在 `android/gradle.properties` 中限制 JVM 内存:

```properties
org.gradle.jvmargs=-Xmx1536m -XX:MaxMetaspaceSize=384m -XX:+UseSerialGC
```

- `-Xmx1536m`: 最大堆内存 1.5GB
- `-XX:MaxMetaspaceSize=384m`: 限制元空间，防止类加载器泄漏
- `-XX:+UseSerialGC`: 使用串行 GC，减少 GC 线程开销（单核环境友好）

---

### 4.4 AndroidX 依赖版本冲突

**问题现象**: 编译时报 `url_launcher` 插件引入的 `androidx.activity:activity` 新版本要求 AGP 8.9.1+，但项目使用 AGP 8.6.0。

**解决方案**: 在 `android/build.gradle` 和 `android/app/build.gradle` 中强制使用兼容版本:

```groovy
// android/build.gradle 和 android/app/build.gradle 中
configurations.all {
    resolutionStrategy {
        force 'androidx.core:core:1.13.1'
        force 'androidx.core:core-ktx:1.13.1'
        force 'androidx.browser:browser:1.8.0'
        force 'androidx.activity:activity:1.9.3'
        force 'androidx.fragment:fragment:1.8.5'
        force 'androidx.annotation:annotation:1.8.2'
    }
}
```

---

### 4.5 APK 元数据读取失败（包名/版本号显示 unknown）

**问题现象**: 构建出的 APK 在应用内解析时，包名、应用名、版本号全部显示 "unknown"。

**根因分析**: `ManifestParser` 的字符串池解析存在索引对齐 bug。当遇到空字符串或解析失败的条目时，未向 `strings` 列表添加占位空字符串，导致后续所有索引全部偏移，属性值全部指向错误的字符串。

**解决方案**: 在 `manifest_parser.dart` 的 `_parseStringPool` 方法中，**所有异常路径都必须添加空字符串占位**:

```dart
// 错误写法（跳过失败条目，导致索引错位）
if (absOff >= data.length) continue;

// 正确写法（添加空字符串保持索引对齐）
if (absOff >= data.length) {
    strings.add('');  // 必须添加！
    continue;
}
```

同时增加了 `_parseFallback()` 回退解析方法，当结构化解析失败时，从原始字节中扫描 UTF-8/UTF-16LE 字符串，通过正则匹配提取包名、权限、版本号等关键信息。

---

### 4.6 Flutter SDK 不在 PATH 中

**问题现象**: 执行 `flutter` 命令报 "command not found"。

**解决方案**: 每次构建前显式设置环境变量:

```bash
export PUB_HOSTED_URL=https://pub.flutter-io.cn
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export ANDROID_HOME=/opt/android-sdk
export PATH="/opt/flutter/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
```

---

## 五、构建步骤（从零开始）

### 5.1 一键构建（推荐）

项目根目录已提供环境固化脚本 `setup_build_env.sh`:

```bash
# 方式 1: 直接执行（自动配置环境 + 构建）
bash /workspace/setup_build_env.sh

# 方式 2: source 后手动控制
source /workspace/setup_build_env.sh
full_setup    # 配置环境
build_apk     # 构建 APK
```

### 5.2 手动构建

```bash
# 1. 设置环境变量
export PUB_HOSTED_URL=https://pub.flutter-io.cn
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export ANDROID_HOME=/opt/android-sdk
export PATH="/opt/flutter/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

# 2. 进入项目目录
cd /workspace/reverse_tool_ai

# 3. 清理并获取依赖
flutter clean
flutter pub get

# 4. 构建 APK（跳过依赖版本检查，因为工具链 Kotlin 已降级）
flutter build apk --target-platform android-arm64 --android-skip-build-dependency-validation

# 5. 构建产物位置
# build/app/outputs/flutter-apk/app-release.apk
```

### 5.3 首次环境搭建（全新机器）

如果 Flutter SDK 和 Android SDK 均未安装:

```bash
# 1. 安装 Java 17
apt-get update && apt-get install -y openjdk-17-jdk-headless unzip

# 2. 安装 Flutter SDK
git clone --depth 1 --branch stable https://github.com/flutter/flutter.git /opt/flutter
export PATH="/opt/flutter/bin:$PATH"
flutter precache

# 3. 安装 Android SDK
mkdir -p /opt/android-sdk
# 下载 cmdline-tools: https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip cmdline-tools.zip -d /opt/android-sdk/
mv /opt/android-sdk/cmdline-tools /opt/android-sdk/cmdline-tools-tmp
mkdir -p /opt/android-sdk/cmdline-tools/latest
mv /opt/android-sdk/cmdline-tools-tmp/* /opt/android-sdk/cmdline-tools/latest/
rm -rf /opt/android-sdk/cmdline-tools-tmp

# 4. 安装 SDK 组件
export ANDROID_HOME=/opt/android-sdk
yes | sdkmanager --licenses
sdkmanager "platform-tools" "platforms;android-34" "platforms;android-35" "platforms;android-36" \
    "build-tools;34.0.0" "build-tools;36.0.0" "ndk;28.2.13676358" "cmake;3.22.1"

# 5. 应用 Flutter 工具链补丁（见第四节 4.2）
#    修改 /opt/flutter/packages/flutter_tools/gradle/build.gradle.kts
#    修改 /opt/flutter/packages/flutter_tools/gradle/settings.gradle.kts

# 6. 配置 Gradle 代理（见第四节 4.1）
#    修改 android/gradle.properties 添加代理配置

# 7. 构建
cd /workspace/reverse_tool_ai
flutter clean && flutter pub get
flutter build apk --target-platform android-arm64 --android-skip-build-dependency-validation
```

---

## 六、开发进度

### 6.1 已完成功能（✅ 全部可用）

| 模块 | 功能 | 完成度 | 关键文件 |
|------|------|--------|---------|
| APK 基本信息解析 | 包名/版本/SDK/大小统计 | ✅ 100% | `apk_analyzer.dart` |
| Manifest 解析 | 二进制 XML 结构化解析 + 回退 | ✅ 100% | `manifest_parser.dart` |
| Manifest XML 重建 | 可读 XML 文本输出 | ✅ 100% | `manifest_parser.dart` |
| 组件分析 | 四大组件 + 导出 + Intent Filter | ✅ 100% | `manifest_parser.dart` |
| Deep Link 提取 | scheme/host/path 组合 | ✅ 100% | `manifest_parser.dart` |
| DEX 类提取 | 类名/方法/字段/接口/父类 | ✅ 100% | `apk_analyzer.dart` |
| DEX 指令反汇编 | Dalvik → smali 汇编级 | ✅ 100% | `dex_disassembler.dart` |
| DEX 字符串提取 | UTF-8 字符串池解析 | ✅ 100% | `apk_analyzer.dart` |
| 字符串解密检测 | Base64/Hex/XOR/ROT13/URL | ✅ 100% | `crypto_utils.dart` |
| 混淆检测 | 短名比例/熵值/等级判定 | ✅ 100% | `apk_analyzer.dart` |
| 签名检测 | V1/V2/V3 签名块 | ✅ 100% | `apk_analyzer.dart` |
| 证书解析 | X.509 主题/签发者/序列号/指纹 | ✅ 100% | `cert_parser.dart` |
| 哈希计算 | MD5/SHA1/SHA256 | ✅ 100% | `apk_analyzer.dart` |
| URL/IP 提取 | 正则匹配 + 误报过滤 | ✅ 100% | `apk_analyzer.dart` |
| 敏感 API 检测 | 60+ 关键词扫描 | ✅ 100% | `apk_analyzer.dart` |
| 逆向关键词检测 | 40+ VIP/Pro/Premium 等关键词 | ✅ 100% | `apk_analyzer.dart` |
| 第三方 SDK 识别 | 100+ SDK 指纹库 | ✅ 100% | `sdk_detector.dart` |
| 加壳/加固检测 | 360/腾讯/梆梆/爱加密等 | ✅ 100% | `packer_detector.dart` |
| 权限风险分类 | 普通/危险/签名 + 中文说明 | ✅ 100% | `permission_classifier.dart` |
| 安全评估报告 | 多维度安全风险评分 | ✅ 100% | `apk_analyzer.dart` |
| SO/ELF 解析 | ELF 头/节区/符号表/JNI | ✅ 100% | `so_analyzer.dart` |
| 文件结构树 | ZIP 条目树形展示 | ✅ 100% | `apk_analyzer.dart` |
| 原生库架构分析 | ABI 分类统计 | ✅ 100% | `apk_analyzer.dart` |
| 文本报告导出 | 纯文本格式 | ✅ 100% | `apk_analyzer.dart` |
| JSON 报告导出 | 结构化 JSON | ✅ 100% | `apk_analyzer.dart` |
| 内存管理 | LRU 缓存 + 内存追踪 + GC | ✅ 100% | `memory_manager.dart` |
| UI 22 个 Tab 页 | 完整分析界面 | ✅ 100% | `home_page.dart` |
| 文件选择器 | APK/SO 文件选择 | ✅ 100% | `file_picker_service.dart` |
| 交叉引用分析 | 方法/字段/字符串引用查找 | ✅ 100% | `xref_analyzer.dart` |
| 方法调用图 | 调用关系图 + 热点方法排行 | ✅ 100% | `call_graph_analyzer.dart` |
| 类继承关系树 | 继承层级树 + 接口列表 | ✅ 100% | `inheritance_analyzer.dart` |
| API 端点提取 | REST/GraphQL/Retrofit 路径 | ✅ 100% | `api_endpoint_extractor.dart` |
| 硬编码密钥检测 | AWS/Google/Stripe/JWT/AES 等 | ✅ 100% | `secret_detector.dart` |
| 反调试/反Root检测 | 7类防护检测 | ✅ 100% | `anti_debug_detector.dart` |
| Frida 脚本生成 | Java/Native Hook 自动生成 | ✅ 100% | `frida_generator.dart` |
| DEX 字符串编辑 | 就地修改 + 校验和重算 | ✅ 100% | `dex_editor.dart` |
| APK 重新打包 | ZIP 重建 + 条目替换 | ✅ 100% | `apk_repacker.dart` |
| APK V1 重签名 | 自签名证书生成 + 签名 | ✅ 100% | `apk_resigner.dart` |

### 6.2 代码统计

- **Dart 源文件**: 43 个
- **总代码行数**: 约 15,200 行
- **核心解析引擎**: 约 8,500 行（纯 Dart，无第三方依赖）
- **UI 层**: 约 5,200 行
- **数据模型**: 约 800 行
- **服务/工具层**: 约 700 行

---

## 七、待开发内容（TODO）

以下为计划中但尚未实现的功能，按优先级排列:

### P0 - 高优先级

1. **Smali 补丁功能完善**
   - 当前 `smali_patcher.dart` 仅为框架代码
   - 需要实现: smali 代码编辑、方法替换、字段修改、DEX 重新打包
   - 关联文件: `smali_patcher.dart`, `smali_patch_provider.dart`, `models/smali_method.dart`

2. **多 DEX 完整反汇编**
   - 当前 `disassembleDex()` 只反汇编第一个 `classes.dex`
   - 需要支持 `classes2.dex`, `classes3.dex` 等多 DEX 文件

### P1 - 中优先级

3. **资源文件解析**
   - `res_analyzer.dart` 已有框架，但 `resources.arsc` 解析不完整
   - 需要实现: ARSC 表解析、资源 ID → 资源名映射、字符串资源提取

4. **APK 签名验证**
   - 当前仅检测签名块是否存在，未验证签名有效性
   - 需要实现: V1 签名校验（MANIFEST.MF → CERT.SF → CERT.RSA 签名验证链）

5. **APK 对比分析**
   - 两个 APK 的 diff 功能（权限变化、组件变化、SDK 变化等）
   - 需要新增 UI Tab 和对比逻辑

6. **调用图可视化**
   - 当前调用图以列表形式展示热点方法
   - 需要可视化图形展示调用链（需要图布局算法）

### P2 - 低优先级

7. **APK 安装功能**
   - 直接从应用内安装分析的 APK（需要 `REQUEST_INSTALL_PACKAGES` 权限）

8. **历史记录持久化**
   - 当前分析结果仅在内存中（LRU 缓存），退出后丢失
   - 需要将分析结果序列化到 SQLite/SharedPreferences

9. **多语言支持 (i18n)**
   - 当前界面硬编码中文，需要添加英文等多语言支持

10. **深色/浅色主题切换**
    - 当前固定为深色主题 (`Brightness.dark`)

11. **APK 瘦身分析**
    - 分析 APK 中无用资源、重复文件、过大文件
    - 提供瘦身建议

12. **导出格式扩展**
    - 当前支持 TXT 和 JSON，可扩展 HTML 报告、PDF 报告

---

## 八、架构说明与技术要点

### 8.1 纯 Dart 解析引擎

项目的核心设计理念是**零外部依赖**。所有二进制格式解析（ZIP、DEX、ELF、AXML、X.509）均使用 Dart 原生 `Uint8List` + 手动字节操作实现，不调用 apktool、jadx、readelf 等外部工具。

**优势**: 可在 Android 设备上离线运行，无需 root，无需安装额外工具。  
**代价**: 解析逻辑复杂度高，需要深入理解各文件格式的二进制结构。

### 8.2 ManifestParser 双模式解析

```
ManifestParser.parse(data)
    ├── 结构化解析 (structured)
    │   ├── 字符串池解析 (StringPool)
    │   ├── 命名空间映射 (Namespace)
    │   ├── 元素树构建 (StartElement/EndElement)
    │   ├── 属性解析 (TypedValue → 字符串/整数/布尔/引用)
    │   └── XML 文本重建
    │
    └── 回退解析 (fallback) — 结构化失败时自动触发
        ├── UTF-8 字符串扫描
        ├── UTF-16LE 字符串扫描
        └── 正则匹配 (包名/权限/版本号)
```

**关键设计**: 字符串池解析中，所有异常路径**必须**添加空字符串占位以保持索引对齐。这是曾导致 "包名读取失败" bug 的根因。

### 8.3 内存管理

```dart
// LRU 缓存: 限制 4 个分析结果驻留
static final LruCache<String, dynamic> _resultCache = LruCache(maxEntries: 4);

// 内存追踪: 大文件读取后注册，解析完成后释放
final bytes = MemoryManager().track(await _readFile(path));
// ... 解析逻辑 ...
MemoryManager().release(bytes);  // 主动释放

// 缓存键含文件指纹: 避免文件变更后命中旧缓存
static String _cacheKey(String path, String kind) {
    final stat = File(path).statSync();
    return '$path#$kind#${stat.size}#${stat.modified.millisecondsSinceEpoch}';
}
```

### 8.4 状态管理

使用 Provider 模式，4 个 Provider:

| Provider | 职责 |
|----------|------|
| `AppStateProvider` | 全局状态：当前文件路径、当前 Tab、日志 |
| `ApkAnalysisProvider` | APK 分析结果：所有分析数据 + 异步加载方法 |
| `SoAnalysisProvider` | SO 分析结果：ELF 解析数据 |
| `SmaliPatchProvider` | Smali 补丁状态（框架，待实现） |

### 8.5 UI 结构

`home_page.dart` 包含 14 个 Tab:

```
APK 分析 | Manifest | 组件分析 | 安全评估 | SDK 检测 | 权限分析 |
DEX 搜索 | 字符串 | SO 分析 | DEX 反汇编 | URL/IP | 敏感 API |
逆向关键词 | 文件结构
```

Tab 切换时自动触发对应数据的异步加载（懒加载模式）。

---

## 九、输出要求与编码规范

### 9.1 代码规范

- **语言**: Dart 3.x，启用空安全 (null safety)
- **命名**: 文件名 `snake_case`，类名 `PascalCase`，变量/方法 `camelCase`
- **注释**: 公共方法必须有 `///` 文档注释，复杂逻辑需行内注释
- **模型**: 使用 `const` 构造函数，不可变数据类
- **异步**: 所有 I/O 操作使用 `Future` + `async/await`
- **错误处理**: 解析方法内部 try-catch，不向上抛出解析异常（返回空结果）

### 9.2 新增分析功能模板

新增一个分析功能的步骤:

1. **数据模型**: 在 `lib/models/` 下新建或扩展模型类
2. **核心逻辑**: 在 `lib/core/apk_analyzer.dart` 或新建 `lib/core/xxx_detector.dart`
3. **缓存**: 使用 `_cacheKey()` + `_resultCache` 模式
4. **内存**: 使用 `MemoryManager().track()` / `release()`
5. **Provider**: 在 `apk_analysis_provider.dart` 添加状态字段和异步加载方法
6. **UI**: 在 `home_page.dart` 添加 Tab 或在 `widgets/` 新建面板组件
7. **报告**: 在 `generateReport()` 和 `exportAsJson()` 中添加新分析结果

### 9.3 文件格式解析注意事项

- **字节序**: Android 二进制文件普遍使用小端序 (LE)，使用 `HexUtils.readUint32LE()` 等方法
- **ULEB128**: DEX 格式大量使用 ULEB128 编码，参考 `_readULEB128()` 实现
- **字符串池**: 空字符串必须占位，保持索引对齐（见 4.5 节）
- **ZIP 解压**: 使用 `ZLibCodec(raw: true)` 解压 DEFLATE 压缩数据
- **边界检查**: 所有数组访问前检查 `offset + length <= data.length`

---

## 十、环境固化脚本

项目根目录包含以下固化文件:

| 文件 | 说明 |
|------|------|
| `setup_build_env.sh` | 一键环境固化脚本，`source` 后运行 `build_apk` 即可构建 |
| `BUILD_ENV_SNAPSHOT.txt` | 环境快照文档，记录所有配置和版本信息 |

### setup_build_env.sh 提供的函数

```bash
source setup_build_env.sh

full_setup            # 完整环境配置（环境变量 + 工具链补丁 + 代理配置）
setup_env             # 仅配置环境变量
setup_android_sdk     # 安装 Android SDK
setup_flutter         # 安装 Flutter SDK
patch_flutter_toolchain  # 应用 Flutter 工具链兼容性补丁
setup_gradle_proxy    # 配置 Gradle 代理
build_apk             # 构建 APK（clean + pub get + build）
```

---

## 附录: 关键文件快速索引

| 需求 | 文件 | 关键方法/类 |
|------|------|------------|
| APK ZIP 解析 | `core/apk_analyzer.dart` | `_parseZipCentralDirectory()`, `_extractFile()` |
| DEX 类提取 | `core/apk_analyzer.dart` | `_parseDexClassesDetailed()`, `_readDexString()` |
| DEX 反汇编 | `core/dex_disassembler.dart` | `DexDisassembler.disassemble()` |
| Manifest 解析 | `core/manifest_parser.dart` | `ManifestParser.parse()`, `_parseFallback()` |
| SO/ELF 解析 | `core/so_analyzer.dart` | `SoAnalyzer.analyze()` |
| 签名检测 | `core/apk_analyzer.dart` | `detectSignatureBlock()` |
| 证书解析 | `core/cert_parser.dart` | `CertParser.parse()` |
| SDK 检测 | `core/sdk_detector.dart` | `SdkDetector.detect()` |
| 加壳检测 | `core/packer_detector.dart` | `PackerDetector.detect()` |
| 权限分类 | `core/permission_classifier.dart` | `PermissionClassifier.classify()` |
| 内存管理 | `core/memory_manager.dart` | `MemoryManager`, `LruCache` |
| 字节读取 | `utils/hex_utils.dart` | `readUint16LE()`, `readUint32LE()`, `readUint64LE()` |
| 字符串工具 | `utils/string_utils.dart` | `entropy()`, `isPrintable()`, `hasChinese()` |
| 加解密 | `utils/crypto_utils.dart` | `tryBase64Decode()`, `tryHexDecode()`, `tryXorDecode()` |
| 状态管理 | `providers/apk_analysis_provider.dart` | `ApkAnalysisProvider` |
| 主界面 | `ui/home_page.dart` | `HomePage`, `_HomePageState` |
| Gradle 配置 | `android/gradle.properties` | JVM 参数 + 代理配置 |
| Gradle 设置 | `android/settings.gradle` | 插件版本 + 仓库配置 |
| 应用配置 | `android/app/build.gradle` | compileSdk/minSdk/targetSdk + AndroidX 强制版本 |
