# 智能逆向助手 - 项目交接文档 V2

> **版本**: 2.0.0
> **更新日期**: 2026-07-29
> **项目名称**: reverse_tool_ai (智能逆向助手)
> **应用包名**: com.revtool.reverse_tool_ai
> **代码规模**: 56 个 Dart 文件，约 24,800 行代码

---

## 一、项目概述

「智能逆向助手」是一款 Android 端 APK/SO 逆向分析工具箱，使用 Flutter 开发。**所有核心解析逻辑均为纯 Dart 实现，不依赖 apktool、jadx 等外部工具**。用户在手机上选择 APK 或 SO 文件后，应用即可在本地完成解析。集成 AI Agent 引擎，支持自然语言交互式逆向分析。

### 核心特色

- **纯 Dart 解析引擎**：ZIP/DEX/ELF/AXML 全部自研解析，零原生依赖
- **AI 智能分析**：集成多路 AI Provider（Pollinations/Cehpoint/自定义 OpenAI 兼容接口），支持自然语言提问 + 工具调用循环
- **22 个分析维度**：从基本信息到安全评估、从 DEX 反汇编到 Frida 脚本生成
- **离线运行**：除 AI 对话外，所有分析功能完全离线

---

## 二、开发环境

### 2.1 基础环境

| 组件 | 版本 | 路径/备注 |
|------|------|-----------|
| OS | Linux x86_64 | |
| Java | OpenJDK 17.0.19 | `JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64` |
| Flutter | 3.44.8 (stable) | `FLUTTER_HOME=/opt/flutter` |
| Dart | 3.12.2 (stable) | 随 Flutter 附带 |
| Gradle | 8.7 | 项目内 wrapper，自动下载 |
| Android Gradle Plugin | 8.6.0 | `android/settings.gradle` |
| Kotlin | 2.0.20 (项目) / 1.9.22 (工具链) | 见下方踩坑说明 |
| NDK | 28.2.13676358 | |
| Android SDK | compileSdk=36, minSdk=24, targetSdk=34 | `ANDROID_HOME=/opt/android-sdk` |

### 2.2 镜像与代理配置

```bash
# Flutter Pub 镜像（国内必须）
export PUB_HOSTED_URL=https://pub.flutter-io.cn
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn

# Gradle 代理（android/gradle.properties 中已配置）
# systemProp.http.proxyHost=127.0.0.1
# systemProp.http.proxyPort=18080
# systemProp.https.proxyHost=127.0.0.1
# systemProp.https.proxyPort=18080
```

### 2.3 构建命令

```bash
# 方式一：使用环境固化脚本（推荐）
source /workspace/setup_build_env.sh
build_apk

# 方式二：手动构建
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export ANDROID_HOME=/opt/android-sdk
export ANDROID_SDK_ROOT=/opt/android-sdk
export PATH=$PATH:/opt/flutter/bin

cd /workspace/reverse_tool_ai
flutter clean
flutter pub get
flutter build apk --release --android-skip-build-dependency-validation

# 产物路径
# build/app/outputs/flutter-apk/app-release.apk
```

### 2.4 已知构建踩坑（6 项）

1. **Gradle 代理缺失**：Gradle 不读系统环境变量代理，必须在 `android/gradle.properties` 中显式配置 `systemProp.http(s).proxyHost/Port`
2. **Flutter 工具链 Kotlin 版本冲突**：Flutter 3.44.8 自带 Kotlin 2.2.20 插件，与 Gradle 8.7 不兼容。需修改 Flutter SDK 全局文件 `packages/flutter_tools/gradle/settings.gradle.kts` 和 `build.gradle.kts`，将 Kotlin 降级到 1.9.22
3. **Gradle OOM**：JVM 内存需限制为 `-Xmx1536m -XX:MaxMetaspaceSize=384m -XX:+UseSerialGC`
4. **AndroidX 版本冲突**：`url_launcher` 插件与 AGP 8.6.0 存在冲突，需在 `android/build.gradle` 中强制指定 `androidx.core:core:1.13.1` 等版本
5. **Manifest 解析异常**：二进制 XML 解析时，异常路径必须添加空字符串占位，否则字符串池索引错位
6. **Flutter SDK 不在 PATH**：构建脚本中需显式 `export PATH=$PATH:/opt/flutter/bin`

---

## 三、项目结构

```
reverse_tool_ai/
├── lib/                              # 56 个 Dart 文件，约 24,800 行
│   ├── main.dart                     # 应用入口，7 个 Provider 注册
│   │
│   ├── core/                         # 核心解析引擎（22 个文件，纯 Dart）
│   │   ├── apk_analyzer.dart         # APK 主分析器 — ZIP/DEX/综合报告
│   │   ├── manifest_parser.dart      # AndroidManifest 二进制 XML 解析
│   │   ├── dex_disassembler.dart     # DEX 指令反汇编器 → smali
│   │   ├── so_analyzer.dart          # ELF/SO 文件解析器
│   │   ├── apk_signer.dart           # APK 签名块检测
│   │   ├── cert_parser.dart          # X.509 证书解析（简化版）
│   │   ├── res_analyzer.dart         # resources.arsc 解析（简化版）
│   │   ├── sdk_detector.dart         # 第三方 SDK 识别（100+ 特征）
│   │   ├── packer_detector.dart      # 加壳/加固检测
│   │   ├── permission_classifier.dart # 权限风险分类
│   │   ├── secret_detector.dart      # 硬编码密钥/Token 检测
│   │   ├── anti_debug_detector.dart  # 反调试/反Root 检测
│   │   ├── api_endpoint_extractor.dart # REST API 端点提取
│   │   ├── frida_generator.dart      # Frida Hook 脚本生成
│   │   ├── dex_editor.dart           # DEX 字符串编辑器
│   │   ├── apk_repacker.dart         # APK 重新打包
│   │   ├── apk_resigner.dart         # APK V1 重签名
│   │   ├── call_graph_analyzer.dart  # 方法调用图分析
│   │   ├── inheritance_analyzer.dart # 类继承关系树
│   │   ├── xref_analyzer.dart        # 交叉引用分析
│   │   ├── smali_patcher.dart        # Smali 补丁工具（框架）
│   │   └── memory_manager.dart       # LRU 缓存 + 内存管理
│   │
│   ├── ai/                           # AI 集成模块（6 个文件）
│   │   ├── ai_provider.dart          # AI Provider 抽象 + 3 个内置实现
│   │   ├── multi_ai_client.dart      # 多路 AI 客户端（故障转移 + 持久化）
│   │   ├── mcp_agent_engine.dart     # MCP Agent 引擎（对话+工具调用循环）
│   │   ├── local_analyzer_tools.dart # 本地工具集（逆向数据→AI 工具）
│   │   ├── local_mcp_client.dart     # 本地 MCP 客户端适配器
│   │   └── tool_executor.dart        # 工具执行器抽象接口
│   │
│   ├── mcp/                          # MCP 协议层（2 个文件）
│   │   ├── mcp_client.dart           # 远程 MCP 客户端（SSE/HTTP）
│   │   └── mcp_models.dart           # MCP 数据模型
│   │
│   ├── models/                       # 数据模型（4 个文件）
│   │   ├── apk_info.dart             # APK 信息 + 分析结果模型
│   │   ├── dex_class.dart            # DEX 类/方法/字段模型
│   │   ├── smali_method.dart         # Smali 方法模型
│   │   └── so_symbol.dart            # ELF 符号模型
│   │
│   ├── providers/                    # 状态管理（4 个文件）
│   │   ├── apk_analysis_provider.dart # APK 分析状态
│   │   ├── app_state_provider.dart    # 全局应用状态
│   │   ├── so_analysis_provider.dart  # SO 分析状态
│   │   └── smali_patch_provider.dart  # Smali 补丁状态
│   │
│   ├── services/                     # 服务层（5 个文件）
│   │   ├── cache_service.dart        # 磁盘缓存
│   │   ├── export_service.dart       # 报告导出
│   │   ├── file_picker_service.dart  # 文件选择
│   │   ├── storage_service.dart      # 存储服务
│   │   └── upload_service.dart       # 文件上传
│   │
│   ├── ui/                           # 主界面
│   │   └── home_page.dart            # 主页面（22 个 Tab 页）
│   │
│   ├── widgets/                      # UI 组件（8 个文件）
│   │   ├── ai_chat_panel.dart        # AI 聊天面板
│   │   ├── ai_config_dialog.dart     # AI 接口配置对话框
│   │   ├── advanced_panels.dart      # 高级分析面板（交叉引用/调用图等）
│   │   ├── info_card.dart            # APK 信息卡片
│   │   ├── log_panel.dart            # 日志面板
│   │   ├── result_panels.dart        # 搜索结果面板
│   │   ├── so_analysis_panels.dart   # SO 分析面板
│   │   └── tree_panel.dart           # DEX 类树面板
│   │
│   └── utils/                        # 工具类（3 个文件）
│       ├── crypto_utils.dart         # 加密工具（Base64/Hex/XOR/ROT13）
│       ├── hex_utils.dart            # 十六进制/字节读写
│       └── string_utils.dart         # 熵值/可打印判断
│
├── android/                          # Android 原生工程
│   ├── app/build.gradle              # 应用级配置
│   ├── build.gradle                  # 项目级配置（阿里云镜像+AndroidX强制版本）
│   ├── settings.gradle               # AGP 8.6.0 + Kotlin 2.0.20
│   ├── gradle.properties             # JVM 参数 + 代理配置
│   ├── local.properties              # SDK 路径
│   └── gradle/wrapper/               # Gradle 8.7 wrapper
│
├── pubspec.yaml                      # Flutter 依赖配置
├── pubspec.lock                      # 依赖锁定文件
├── PROJECT_HANDOVER.md               # 旧版交接文档（2026-07-24）
├── PROJECT_HANDOVER_V2.md            # 本文档
└── build/                            # 构建产物（不在 ZIP 中）
    └── app/outputs/flutter-apk/
        └── app-release.apk           # 编译产物（58.3MB）
```

---

## 四、架构设计

### 4.1 分层架构

```
┌──────────────────────────────────────────────┐
│              UI 层 (ui/ + widgets/)           │
│   HomePage (22 Tab) + AI Chat Panel + 组件    │
├──────────────────────────────────────────────┤
│           状态管理层 (providers/)              │
│  ApkAnalysisProvider / SoAnalysisProvider    │
│  AppStateProvider / SmaliPatchProvider       │
├──────────────────────────────────────────────┤
│           AI 集成层 (ai/ + mcp/)              │
│  McpAgentEngine (对话循环)                    │
│  MultiAiClientImpl (多路故障转移)              │
│  LocalAnalyzerTools (逆向数据→AI工具)          │
├──────────────────────────────────────────────┤
│           核心引擎层 (core/)                   │
│  ApkAnalyzer / DexDisassembler / SoAnalyzer  │
│  ManifestParser / SdkDetector / ...          │
├──────────────────────────────────────────────┤
│           工具层 (utils/ + services/)         │
│  HexUtils / StringUtils / CryptoUtils        │
│  CacheService / ExportService / ...          │
└──────────────────────────────────────────────┘
```

### 4.2 Provider 依赖注入图

```
MultiProvider
├── AppStateProvider              (全局状态)
├── ApkAnalysisProvider           (APK 分析结果)
├── SoAnalysisProvider            (SO 分析结果)
├── SmaliPatchProvider            (Smali 补丁状态)
├── MultiAiClientImpl             (AI 客户端管理)
├── LocalMcpClient                ← 依赖 ApkAnalysis + SoAnalysis + AppState
│   └── LocalAnalyzerTools        (将逆向数据包装为 AI 工具)
└── McpAgentEngine                ← 依赖 MultiAiClient + LocalMcpClient
    (AI 对话 + 工具调用循环引擎)
```

### 4.3 AI Agent 工作流

```
用户输入 → McpAgentEngine.processRequest()
  ↓
构建系统提示词（含工具列表 + 当前 APK 状态）
  ↓
调用 MultiAiClient.chatCompletion()
  ↓
AI 返回 JSON 工具调用 or 自然语言回复
  ↓
若为工具调用 → LocalMcpClient.callTool() → LocalAnalyzerTools.executeTool()
  ↓                                    ↓
  ↓                              自动触发数据提取（如尚未分析）
  ↓                                    ↓
  ← 工具结果回喂 AI ← ← ← ← ← ← ←
  ↓
循环迭代（最多 60 次）直到 AI 给出最终结论
```

### 4.4 关键设计决策

| 决策 | 原因 |
|------|------|
| 纯 Dart 解析（非 FFI/JNI） | 避免 ARM/x86 双架构编译问题，确保跨平台兼容 |
| Manifest 双模式解析 | 结构化解析失败时回退到字节扫描，提高兼容性 |
| LRU 内存管理 | 大 APK 解析结果可能占数百 MB，需主动回收 |
| AI Provider 自动故障转移 | 免费 AI 服务不稳定，需多路冗余 |
| SharedPreferences 持久化 AI 配置 | 覆盖安装不丢失用户配置 |
| 工具自动触发机制 | AI 调用 local_get_urls 等工具时自动触发数据提取 |

---

## 五、开发进度

### 5.1 已完成功能（✅ 100%）

#### 核心解析引擎

| 模块 | 功能 | 状态 | 关键文件 |
|------|------|------|----------|
| ZIP 解析 | APK/ZIP 文件结构解析、条目提取、DEFLATE 解压 | ✅ | `apk_analyzer.dart` |
| Manifest 解析 | 二进制 XML 结构化解析 + 回退字节扫描 | ✅ | `manifest_parser.dart` |
| DEX 解析 | 类名/方法/字段提取、字符串池提取 | ✅ | `apk_analyzer.dart` |
| DEX 反汇编 | Dalvik 字节码 → smali 汇编（单 DEX） | ✅ | `dex_disassembler.dart` |
| ELF/SO 解析 | ELF 头/节区/符号表/动态段/重定位/安全特性 | ✅ | `so_analyzer.dart` |
| 签名检测 | V1/V2/V3 签名方案检测 + 证书信息提取 | ✅ (简化) | `apk_signer.dart`, `cert_parser.dart` |
| 资源解析 | resources.arsc 基础解析 | ✅ (简化) | `res_analyzer.dart` |

#### 安全分析

| 模块 | 功能 | 状态 | 关键文件 |
|------|------|------|----------|
| 安全评估 | debuggable/导出组件/明文流量/SDK 风险 | ✅ | `apk_analyzer.dart` |
| 混淆检测 | 短名比例/熵值/单字符类名/可疑等级 | ✅ | `apk_analyzer.dart` |
| SDK 识别 | 100+ SDK 特征匹配（8 大分类） | ✅ | `sdk_detector.dart` |
| 加壳检测 | 360/腾讯/梆梆/爱加密等壳识别 | ✅ | `packer_detector.dart` |
| 权限分类 | 官方保护级别分类 + 中文说明 | ✅ | `permission_classifier.dart` |
| 敏感 API | 60+ 敏感 API 关键词扫描 | ✅ | `apk_analyzer.dart` |
| 密钥检测 | AWS/Google/Stripe/JWT/AES/RSA 等密钥模式 | ✅ | `secret_detector.dart` |
| 反调试检测 | 反调试/反Root/反模拟器/反Hook/SafetyNet | ✅ | `anti_debug_detector.dart` |
| URL/IP 提取 | DEX + resources.arsc + assets + XML 全扫描 | ✅ | `apk_analyzer.dart` |
| API 端点提取 | REST/GraphQL/Retrofit 注解提取 | ✅ | `api_endpoint_extractor.dart` |

#### 高级功能

| 模块 | 功能 | 状态 | 关键文件 |
|------|------|------|----------|
| 交叉引用分析 | 方法/字段/字符串交叉引用搜索 | ✅ | `xref_analyzer.dart` |
| 调用图分析 | invoke 指令 → caller→callee 关系图 | ✅ | `call_graph_analyzer.dart` |
| 继承树分析 | 类继承层级树构建 | ✅ | `inheritance_analyzer.dart` |
| Frida 脚本生成 | DEX 方法/SO 符号 → Frida JS 脚本 | ✅ | `frida_generator.dart` |
| DEX 字符串编辑 | 就地字符串替换（仅缩短）+ 校验和重算 | ✅ | `dex_editor.dart` |
| APK 重新打包 | ZIP 条目替换 + 重写 | ✅ | `apk_repacker.dart` |
| APK V1 签名 | MANIFEST.MF + CERT.SF 生成 | ✅ (部分) | `apk_resigner.dart` |
| 哈希计算 | MD5/SHA1/SHA256 | ✅ | `apk_analyzer.dart` |
| 文件树 | APK 内部文件结构树 | ✅ | `apk_analyzer.dart` |
| 报告生成 | 纯文本报告 | ✅ | `apk_analyzer.dart` |
| Smali 补丁 | 基础搜索/方法替换框架 | ✅ (框架) | `smali_patcher.dart` |

#### AI 集成

| 模块 | 功能 | 状态 | 关键文件 |
|------|------|------|----------|
| 多路 AI 客户端 | Pollinations/Cehpoint/自定义 Provider + 自动故障转移 | ✅ | `multi_ai_client.dart` |
| AI 配置持久化 | SharedPreferences 存储自定义 Provider 配置 | ✅ | `multi_ai_client.dart` |
| MCP Agent 引擎 | 对话 + 工具调用循环（最多 60 轮迭代） | ✅ | `mcp_agent_engine.dart` |
| 本地工具集 | 22 个 local_ 工具暴露逆向数据给 AI | ✅ | `local_analyzer_tools.dart` |
| 工具自动触发 | AI 调用工具时自动触发数据提取 | ✅ | `local_analyzer_tools.dart` |
| 503 限流降级 | 手动模式下 503 错误自动切换备用 Provider | ✅ | `multi_ai_client.dart` |
| 远程 MCP 支持 | SSE/HTTP 传输 + JSON-RPC 协议 | ✅ | `mcp/mcp_client.dart` |
| AI 聊天面板 | 自然语言交互 + 8 个快捷问题模板 | ✅ | `ai_chat_panel.dart` |
| AI 配置对话框 | Provider 选择/模型扫描/连接测试 | ✅ | `ai_config_dialog.dart` |

#### UI 界面

| Tab 页 | 功能 | 状态 |
|--------|------|------|
| APK 信息 | 包名/版本/SDK/大小/DEX 类数 | ✅ |
| Manifest | XML 文本展示 | ✅ |
| 组件 | Activity/Service/Receiver/Provider 列表 | ✅ |
| 安全评估 | 风险等级/问题列表 | ✅ |
| SDK 检测 | 第三方 SDK 列表 + 分类统计 | ✅ |
| 权限 | 权限列表 + 风险分类 | ✅ |
| DEX 搜索 | 类名/方法名搜索 | ✅ |
| 字符串 | 字符串分析结果 | ✅ |
| SO 分析 | ELF 概览/符号/导入导出 | ✅ |
| 反汇编 | smali 级反汇编 | ✅ |
| URL/IP | 提取的网络地址 | ✅ |
| 敏感 API | 敏感 API 调用列表 | ✅ |
| 逆向关键词 | VIP/Pro/Premium 等关键词 | ✅ |
| 文件结构 | APK 内部文件树 | ✅ |
| 交叉引用 | 方法/字段/字符串引用 | ✅ |
| 调用图 | 方法调用关系 | ✅ |
| 继承关系 | 类继承树 | ✅ |
| API 端点 | REST API 路径 | ✅ |
| 密钥检测 | 硬编码密钥/Token | ✅ |
| 反调试 | 反逆向防护检测 | ✅ |
| Frida | Hook 脚本生成 | ✅ |
| DEX 编辑 | 字符串修改 + 重打包 | ✅ |
| AI 助手 | 自然语言对话分析 | ✅ |

### 5.2 代码统计

| 目录 | 文件数 | 约行数 |
|------|--------|--------|
| lib/core/ | 22 | ~12,000 |
| lib/ai/ | 6 | ~2,800 |
| lib/mcp/ | 2 | ~800 |
| lib/models/ | 4 | ~900 |
| lib/providers/ | 4 | ~1,200 |
| lib/services/ | 5 | ~600 |
| lib/ui/ | 1 | ~3,000 |
| lib/widgets/ | 8 | ~2,500 |
| lib/utils/ | 3 | ~400 |
| lib/main.dart | 1 | ~100 |
| **合计** | **56** | **~24,800** |

---

## 六、待开发内容

### P0 - 高优先级（核心功能补全）

| # | 功能 | 当前状态 | 涉及文件 | 说明 |
|---|------|----------|----------|------|
| 1 | **Smali 补丁功能完善** | 框架级实现 | `smali_patcher.dart`, `smali_patch_provider.dart` | 需实现：DEX 重新打包、字段修改、批量补丁管理、方法体完整编辑 |
| 2 | **多 DEX 完整反汇编** | 仅处理 classes.dex | `apk_analyzer.dart` → `disassembleDex()` | 需支持 classes2.dex、classes3.dex 等多 DEX 文件循环反汇编 |
| 3 | **CERT.RSA 完整签名** | 占位文本 | `apk_resigner.dart` | 当前 CERT.RSA 仅为占位字符串，需实现 PKCS#7 签名块生成，否则签名后 APK 无法安装 |

### P1 - 中优先级（功能增强）

| # | 功能 | 当前状态 | 说明 |
|---|------|----------|------|
| 4 | **X.509 证书完整解析** | 简化版（正则提取 CN=） | 需实现 ASN.1 解析，提取完整的签发者/有效期/序列号/指纹哈希 |
| 5 | **resources.arsc 完整解析** | 简化版（前 20 条字符串） | 需解析 RES_TABLE_PACKAGE_TYPE 块，实现资源 ID→资源名映射、字符串资源完整提取 |
| 6 | **APK 签名验证链** | 仅检测文件存在 | 需实现 V1 签名校验：MANIFEST.MF → CERT.SF → CERT.RSA 完整验证链 |
| 7 | **APK 对比分析** | 未实现 | 两个 APK 的 diff（权限/组件/SDK 变化），需新增 UI Tab |
| 8 | **调用图可视化** | 列表展示 | 当前仅文本列表，需图形化调用链展示（可考虑 Graphviz 或 Canvas 绘制） |
| 9 | **DEX 字符串扩展编辑** | 仅支持缩短 | 当前 modifyString() 只支持新串 ≤ 原串长度，需支持字符串扩展（重建 DEX 结构） |

### P2 - 低优先级（体验优化）

| # | 功能 | 当前状态 | 说明 |
|---|------|----------|------|
| 10 | **APK 安装功能** | 未实现 | 应用内直接安装 APK，需 `REQUEST_INSTALL_PACKAGES` 权限 |
| 11 | **历史记录持久化** | 仅内存 LRU（4 条） | 需序列化到 SQLite/SharedPreferences，退出后可恢复 |
| 12 | **多语言支持 (i18n)** | 硬编码中文 | 需添加英文等多语言支持 |
| 13 | **深色/浅色主题切换** | 固定深色 | main.dart 中 `brightness: Brightness.dark` 硬编码 |
| 14 | **APK 瘦身分析** | 未实现 | 分析无用资源、重复文件、过大文件，给出优化建议 |
| 15 | **导出格式扩展** | 仅 TXT | 扩展 JSON/HTML/PDF 报告导出 |
| 16 | **DEX 反汇编 opcode 覆盖** | 部分 opcode 回退 hex | 补全 dex_disassembler.dart 中未覆盖的 Dalvik 指令格式 |

---

## 七、AI 工具清单（local_ 工具）

AI Agent 可调用以下 22 个本地工具获取已分析的逆向数据：

| 工具名 | 功能 | 自动触发 |
|--------|------|----------|
| `local_get_apk_info` | APK 基本信息（包名/版本/SDK/大小） | 否（依赖主分析流程） |
| `local_get_permissions` | 权限列表 + 风险分类 | 否 |
| `local_get_components` | 四大组件列表 + exported 状态 | 否 |
| `local_get_manifest` | 完整 AndroidManifest.xml 文本 | 否 |
| `local_get_signature` | 签名信息（V1/V2/V3 + 证书） | 否 |
| `local_get_hash` | 文件哈希（MD5/SHA1/SHA256） | 否 |
| `local_get_security_report` | 安全评估报告 | ✅ 自动触发 assessSecurity() |
| `local_get_sdk_detection` | 第三方 SDK 列表 | ✅ 自动触发 detectSdks() |
| `local_get_packer_detection` | 加壳检测结果 | 否（主分析流程已包含） |
| `local_get_native_libs` | 原生库（.so）信息 | 否 |
| `local_get_urls` | URL/IP 地址列表 | ✅ 自动触发 extractUrls() |
| `local_get_sensitive_apis` | 敏感 API 调用列表 | ✅ 自动触发 detectSensitiveApis() |
| `local_get_dex_classes` | DEX 类名列表（支持 query 过滤） | 否 |
| `local_search_dex` | DEX 中搜索类名/方法名 | ✅ 自动触发 searchInDex() |
| `local_get_file_tree` | APK 内部文件结构树 | ✅ 自动触发 loadFileTree() |
| `local_get_strings` | 字符串分析结果 | ✅ 自动触发 analyzeStrings() |
| `local_get_deep_links` | 深度链接信息 | 否 |
| `local_get_obfuscation` | 代码混淆检测结果 | ✅ 自动触发 detectObfuscation() |
| `local_get_size_breakdown` | 文件大小分类明细 | 否 |
| `local_get_secrets` | 硬编码密钥/Token | ✅ 自动触发 detectSecrets() |
| `local_get_api_endpoints` | 网络 API 端点 | ✅ 自动触发 extractApiEndpoints() |
| `local_get_anti_debug` | 反调试/反Root 检测 | ✅ 自动触发 detectAntiDebug() |
| `local_generate_report` | 生成完整分析报告 | 否 |
| `local_get_current_file` | 当前文件路径和名称 | 否 |

### AI Provider 配置

| Provider | 类型 | 需要密钥 | 说明 |
|----------|------|----------|------|
| Pollinations.ai | 内置 | 否 | 免费，POST 方式，Agent 推荐 |
| Cehpoint AI | 内置 | 否 | 免费，多模型可选（GPT-4o/DeepSeek/Claude 等） |
| Pollinations GET | 内置 | 否 | 免费，GET 备用通道 |
| 自定义 OpenAI 兼容 | 用户配置 | 是 | 支持 DeepSeek/OpenAI/Claude 等兼容接口 |

---

## 八、输出要求（接手开发规范）

### 8.1 代码规范

- **语言**：Dart 3.x，使用 null safety
- **状态管理**：统一使用 Provider + ChangeNotifier
- **命名规范**：
  - 类名：PascalCase（如 `ApkAnalyzer`）
  - 变量/方法名：camelCase（如 `extractUrls`）
  - 常量：lowerCamelCase（如 `cacheKey`）
  - 文件名：snake_case（如 `apk_analyzer.dart`）
- **注释**：公共 API 必须有 `///` 文档注释，中文编写
- **错误处理**：所有异步方法必须 try-catch，错误信息存入 `_error` 字段并 `notifyListeners()`

### 8.2 新增分析器规范

```dart
class XxxAnalyzer {
  final String path;

  XxxAnalyzer(this.path);

  /// 解析入口
  Future<XxxResult> analyze() async {
    try {
      // 1. 读取文件（使用 MemoryManager 跟踪内存）
      final bytes = MemoryManager().track(await File(path).readAsBytes());

      // 2. 解析逻辑...

      // 3. 释放内存
      MemoryManager().release(bytes);

      return result;
    } catch (e) {
      throw Exception('XXX 分析失败: $e');
    }
  }
}
```

### 8.3 新增 AI 工具规范

1. 在 `local_analyzer_tools.dart` 的 `tools` 列表中添加 `LocalTool` 定义
2. 实现对应的 `_getXxx` 异步方法
3. 如果数据可能未提取，添加自动触发逻辑：

```dart
Future<String> _getXxx(Map<String, dynamic> args) async {
  var result = apkProvider.xxxResult;
  // 自动触发数据提取
  if (result == null && appState.currentFilePath != null) {
    await apkProvider.extractXxx(appState.currentFilePath!);
    result = apkProvider.xxxResult;
  }
  if (result == null) return '尚未进行 XXX 分析，请先分析 APK 文件。';
  return _formatJson({...});
}
```

4. 在 `ApkAnalysisProvider` 中添加对应的状态字段和提取方法
5. 工具返回的"无数据"提示不应被标记为错误（`LocalMcpClient` 中仅 `错误:` 和 `工具执行异常:` 开头为错误）

### 8.4 新增 UI Tab 规范

1. 在 `home_page.dart` 的 `TabBar` 和 `TabBarView` 中添加对应项
2. 使用 `Consumer<ApkAnalysisProvider>` 或 `Selector` 响应数据变化
3. 空数据状态显示灰色提示文字
4. 加载中状态显示 CircularProgressIndicator

### 8.5 构建提交规范

```bash
# 编译前必须验证
export ANDROID_HOME=/opt/android-sdk
flutter clean && flutter pub get
flutter build apk --release --android-skip-build-dependency-validation

# 产物验证
ls -lh build/app/outputs/flutter-apk/app-release.apk
# 预期大小: ~58MB
```

---

## 九、依赖清单

### pubspec.yaml 依赖

| 依赖 | 版本 | 用途 |
|------|------|------|
| flutter | SDK | UI 框架 |
| provider | ^6.1.2 | 状态管理 |
| file_picker | ^8.0.0 | 文件选择器 |
| path_provider | ^2.1.3 | 路径获取 |
| path | ^1.9.0 | 路径处理 |
| http | ^1.2.1 | HTTP 请求（AI 接口调用） |
| url_launcher | ^6.2.5 | 打开外部 URL |
| crypto | ^3.0.3 | 哈希计算（MD5/SHA1/SHA256） |
| shared_preferences | ^2.2.3 | AI 配置持久化 |

**注意**：核心解析引擎（ZIP/DEX/ELF/AXML）不依赖任何第三方库，全部纯 Dart 实现。

---

## 十、快速上手指南

### 10.1 环境准备

```bash
# 1. 安装 Flutter 3.44.x
# 参考: https://docs.flutter.dev/get-started/install

# 2. 配置环境变量
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export ANDROID_HOME=/opt/android-sdk
export ANDROID_SDK_ROOT=/opt/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
export PUB_HOSTED_URL=https://pub.flutter-io.cn
export FLUTTER_STORAGE_BASE_URL=https://storage.flutter-io.cn

# 3. 验证环境
flutter doctor
```

### 10.2 编译运行

```bash
cd reverse_tool_ai
flutter pub get
flutter run  # 调试模式
# 或
flutter build apk --release --android-skip-build-dependency-validation  # 发布构建
```

### 10.3 关键文件入口

| 要做什么 | 看哪个文件 |
|---------|-----------|
| 了解应用入口和 Provider 注册 | `lib/main.dart` |
| 了解主界面和 Tab 结构 | `lib/ui/home_page.dart` |
| 新增 APK 分析功能 | `lib/core/apk_analyzer.dart` + `lib/providers/apk_analysis_provider.dart` |
| 新增 AI 工具 | `lib/ai/local_analyzer_tools.dart` |
| 修改 AI 对话逻辑 | `lib/ai/mcp_agent_engine.dart` |
| 修改 AI Provider 配置 | `lib/ai/multi_ai_client.dart` |
| 新增 UI 组件 | `lib/widgets/` 目录下新建文件 |
| 修改 Android 编译配置 | `android/app/build.gradle` |

### 10.4 调试技巧

- AI 对话日志：`McpAgentEngine` 中的 `_messages` 和 `_conversationHistory` 包含完整对话历史
- 解析缓存：`ApkAnalyzer` 使用 LRU 缓存，修改分析逻辑后需 `flutter clean` 或清除缓存
- 内存监控：`MemoryManager` 单例可跟踪内存使用，超 256MB 触发 GC
- AI 工具调试：在 `LocalAnalyzerTools.executeTool()` 中添加日志可追踪工具调用链

---

## 十一、版本历史

| 版本 | 日期 | 主要变更 |
|------|------|----------|
| 1.0.0 | 2026-07-20 | 初始版本：基础 APK 分析功能 |
| 1.5.0 | 2026-07-22 | 新增 SO/ELF 分析、安全评估、混淆检测 |
| 2.0.0 | 2026-07-24 | 新增 AI Agent 引擎、22 个分析维度、Frida 脚本生成、DEX 编辑 |
| 2.0.1 | 2026-07-28 | 修复 AI 配置持久化、APK 路径传递、工具自动触发、503 限流降级 |
| 2.0.2 | 2026-07-29 | 增强 URL 提取范围（resources.arsc/assets/XML）、修复工具误标错误 |

---

## 附录：构建环境快照

详见项目根目录 `BUILD_ENV_SNAPSHOT.txt`（如存在）或 `/workspace/BUILD_ENV_SNAPSHOT.txt`。
构建环境固化脚本：`/workspace/setup_build_env.sh`。

---

*本文档由项目开发团队编写，最后更新于 2026-07-29。如有疑问请参考源代码注释。*
