#!/bin/bash
# ============================================================
#  智能逆向助手 - 构建环境固化脚本
#  用途: 在新环境中一键配置所有构建依赖并构建 APK
#  用法: source setup_build_env.sh
#        build_apk
# ============================================================

set -e

# ---- 颜色输出 ----
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; }

# ---- 基础路径 ----
export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
export FLUTTER_HOME="${FLUTTER_HOME:-/opt/flutter}"
export PROJECT_DIR="${PROJECT_DIR:-/workspace/reverse_tool_ai}"

# ---- 镜像/代理配置 ----
export PUB_HOSTED_URL="${PUB_HOSTED_URL:-https://pub.flutter-io.cn}"
export FLUTTER_STORAGE_BASE_URL="${FLUTTER_STORAGE_BASE_URL:-https://storage.flutter-io.cn}"
PROXY_HOST="${PROXY_HOST:-127.0.0.1}"
PROXY_PORT="${PROXY_PORT:-18080}"

# ---- 环境变量固化函数 ----
setup_env() {
    info "=== 配置环境变量 ==="

    # 确保 JAVA_HOME 有效
    if [ ! -d "$JAVA_HOME" ]; then
        warn "JAVA_HOME=$JAVA_HOME 不存在，尝试查找..."
        JAVA_HOME=$(readlink -f /usr/lib/jvm/java-17-openjdk-amd64 2>/dev/null || \
                    readlink -f /usr/lib/jvm/java-11-openjdk-amd64 2>/dev/null || "")
        if [ -z "$JAVA_HOME" ]; then
            error "未找到 Java，请安装: apt-get install -y openjdk-17-jdk-headless"
            return 1
        fi
        export JAVA_HOME
    fi
    info "JAVA_HOME=$JAVA_HOME"

    # Android SDK
    if [ ! -d "$ANDROID_HOME" ]; then
        warn "Android SDK 不存在，正在安装..."
        setup_android_sdk
    fi
    info "ANDROID_HOME=$ANDROID_HOME"

    # Flutter SDK
    if [ ! -f "$FLUTTER_HOME/bin/flutter" ]; then
        warn "Flutter SDK 不存在，正在安装..."
        setup_flutter
    fi
    info "FLUTTER_HOME=$FLUTTER_HOME"

    # 构建 PATH
    export PATH="$FLUTTER_HOME/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$ANDROID_HOME/build-tools/36.0.0:$PATH"

    info "=== 环境变量配置完成 ==="
}

# ---- Android SDK 安装 ----
setup_android_sdk() {
    info "安装 Android SDK..."
    mkdir -p "$ANDROID_HOME"

    # 安装 cmdline-tools
    local CMDLINE_URL="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
    local CMDLINE_ZIP="/tmp/cmdline-tools.zip"

    if [ ! -f "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
        curl -L --proxy "$PROXY_HOST:$PROXY_PORT" -o "$CMDLINE_ZIP" "$CMDLINE_URL" 2>/dev/null || \
        curl -L -o "$CMDLINE_ZIP" "$CMDLINE_URL" 2>/dev/null
        mkdir -p "$ANDROID_HOME/cmdline-tools"
        unzip -qo "$CMDLINE_ZIP" -d "$ANDROID_HOME/cmdline-tools"
        mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
        rm -f "$CMDLINE_ZIP"
    fi

    export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"

    # 接受许可
    yes | sdkmanager --sdk_root="$ANDROID_HOME" --licenses > /dev/null 2>&1 || true

    # 安装必要组件
    sdkmanager --sdk_root="$ANDROID_HOME" \
        "platform-tools" \
        "platforms;android-36" \
        "platforms;android-35" \
        "platforms;android-34" \
        "build-tools;36.0.0" \
        "build-tools;34.0.0" \
        "ndk;28.2.13676358" \
        "cmake;3.22.1" \
        2>&1 | tail -3

    info "Android SDK 安装完成"
}

# ---- Flutter SDK 安装 ----
setup_flutter() {
    info "安装 Flutter SDK..."
    if [ ! -d "$FLUTTER_HOME" ]; then
        git clone --depth 1 --branch stable \
            https://github.com/flutter/flutter.git "$FLUTTER_HOME" 2>&1 | tail -3
    fi
    export PATH="$FLUTTER_HOME/bin:$PATH"

    # 配置 Flutter 镜像
    flutter config --no-analytics 2>/dev/null || true

    # 预缓存
    flutter precache 2>&1 | tail -3

    info "Flutter SDK 安装完成"
}

# ---- 配置 Gradle 代理 ----
setup_gradle_proxy() {
    local GRADLE_PROPS="$PROJECT_DIR/android/gradle.properties"
    info "配置 Gradle 代理..."

    # 确保代理配置存在
    if ! grep -q "systemProp.http.proxyHost" "$GRADLE_PROPS" 2>/dev/null; then
        cat >> "$GRADLE_PROPS" << 'GRADLEEOF'

# === 代理配置（可通过环境变量覆盖）===
systemProp.http.proxyHost=127.0.0.1
systemProp.http.proxyPort=18080
systemProp.https.proxyHost=127.0.0.1
systemProp.https.proxyPort=18080
GRADLEEOF
    fi

    info "Gradle 代理配置完成"
}

# ---- 修复 Flutter 工具链（兼容性补丁）----
patch_flutter_toolchain() {
    info "应用 Flutter 工具链兼容性补丁..."

    local TOOLCHAIN_DIR="$FLUTTER_HOME/packages/flutter_tools/gradle"

    # 1. settings.gradle.kts - 添加镜像仓库
    cat > "$TOOLCHAIN_DIR/settings.gradle.kts" << 'SETTINGSEOF'
pluginManagement {
    repositories {
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        gradlePluginPortal()
        google()
        mavenCentral()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        maven { url = uri("https://maven.aliyun.com/repository/google") }
        maven { url = uri("https://maven.aliyun.com/repository/public") }
        maven { url = uri("https://maven.aliyun.com/repository/gradle-plugin") }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
SETTINGSEOF

    # 2. build.gradle.kts - 降级 Kotlin 版本以兼容 Gradle 8.7
    cat > "$TOOLCHAIN_DIR/build.gradle.kts" << 'BUILDEOF'
// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    `java-gradle-plugin`
    groovy
    `kotlin-dsl`
    kotlin("jvm") version "1.9.22"
}

group = "dev.flutter.plugin"
version = "1.0.0"

tasks.validatePlugins {
    enableStricterValidation.set(true)
}

gradlePlugin {
    plugins {
        create("flutterPlugin") {
            id = "dev.flutter.flutter-gradle-plugin"
            implementationClass = "com.flutter.gradle.FlutterPlugin"
        }
        create("flutterAppPluginLoaderPlugin") {
            id = "dev.flutter.flutter-plugin-loader"
            implementationClass = "com.flutter.gradle.FlutterAppPluginLoaderPlugin"
        }
    }
}

tasks.withType<JavaCompile> {
    options.release.set(11)
}

tasks.test {
    useJUnitPlatform()
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_11)
    }
}

dependencies {
    compileOnly("androidx.annotation:annotation-jvm:1.9.1")
    implementation("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.4.0")
    compileOnly("com.android.tools.build:gradle:8.6.0")

    testImplementation(kotlin("test"))
    testImplementation("com.android.tools.build:gradle:8.6.0")
    testImplementation("org.mockito:mockito-core:5.8.0")
    testImplementation("io.mockk:mockk:1.13.16")
}
BUILDEOF

    info "Flutter 工具链补丁应用完成"
}

# ---- APK 构建 ----
build_apk() {
    info "=== 开始构建 APK ==="

    cd "$PROJECT_DIR"

    # 清理
    flutter clean 2>&1 | tail -1

    # 获取依赖
    flutter pub get 2>&1 | tail -3

    # 构建
    flutter build apk --target-platform android-arm64 --android-skip-build-dependency-validation 2>&1

    # 检查结果
    local APK_PATH="$PROJECT_DIR/build/app/outputs/flutter-apk/app-release.apk"
    if [ -f "$APK_PATH" ]; then
        local SIZE=$(du -h "$APK_PATH" | cut -f1)
        info "=== APK 构建成功! ==="
        info "路径: $APK_PATH"
        info "大小: $SIZE"

        # 提取 APK 信息
        if command -v aapt2 &>/dev/null; then
            echo ""
            info "--- APK 信息 ---"
            aapt2 dump badging "$APK_PATH" 2>/dev/null | grep -E "package:|application-label:'" | head -3
        fi
    else
        error "APK 构建失败，请检查上方日志"
        return 1
    fi
}

# ---- 一键完整设置 ----
full_setup() {
    info "============================================"
    info "  智能逆向助手 - 环境一键固化"
    info "============================================"
    setup_env
    patch_flutter_toolchain
    setup_gradle_proxy
    info "环境固化完成！运行 build_apk 开始构建"
}

# 如果直接执行（而非 source），则运行完整设置
if [ "${BASH_SOURCE[0]}" = "${0}" ]; then
    full_setup
    build_apk
fi