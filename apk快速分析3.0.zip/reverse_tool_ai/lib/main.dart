import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_state_provider.dart';
import 'providers/apk_analysis_provider.dart';
import 'providers/so_analysis_provider.dart';
import 'providers/smali_patch_provider.dart';
import 'ai/ai_provider.dart';
import 'ai/multi_ai_client.dart';
import 'ai/local_analyzer_tools.dart';
import 'ai/local_mcp_client.dart';
import 'ai/mcp_agent_engine.dart';
import 'ui/home_page.dart';

void main() {
  runApp(const ReverseToolAI());
}

class ReverseToolAI extends StatelessWidget {
  const ReverseToolAI({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        // 基础状态 Provider
        ChangeNotifierProvider(create: (_) => AppStateProvider()),
        ChangeNotifierProvider(create: (_) => ApkAnalysisProvider()),
        ChangeNotifierProvider(create: (_) => SoAnalysisProvider()),
        ChangeNotifierProvider(create: (_) => SmaliPatchProvider()),

        // AI 相关 Provider
        // 1. 多路 AI 客户端（管理 Pollinations/Cehpoint/自定义 Provider）
        ChangeNotifierProvider(create: (_) => MultiAiClientImpl()),

        // 2. 本地工具执行器（将应用已分析的逆向数据暴露为 AI 可调用工具）
        //    依赖 ApkAnalysisProvider/SoAnalysisProvider/AppStateProvider
        ChangeNotifierProxyProvider3<
            ApkAnalysisProvider, SoAnalysisProvider, AppStateProvider,
            LocalMcpClient>(
          create: (ctx) => LocalMcpClient(LocalAnalyzerTools(
            apkProvider: ctx.read<ApkAnalysisProvider>(),
            soProvider: ctx.read<SoAnalysisProvider>(),
            appState: ctx.read<AppStateProvider>(),
          )),
          update: (ctx, apk, so, app, prev) {
            // LocalAnalyzerTools 是无状态的薄包装，持有 Provider 引用即可
            // Provider 是单例，引用不变，无需重建 LocalMcpClient
            return prev ??
                LocalMcpClient(LocalAnalyzerTools(
                  apkProvider: apk,
                  soProvider: so,
                  appState: app,
                ));
          },
        ),

        // 3. MCP Agent 引擎（AI 对话 + 工具调用循环）
        //    依赖 MultiAiClient 和 LocalMcpClient（ToolExecutor）
        ChangeNotifierProxyProvider2<MultiAiClientImpl, LocalMcpClient,
            McpAgentEngine>(
          create: (ctx) => McpAgentEngine(
            ctx.read<MultiAiClientImpl>(),
            ctx.read<LocalMcpClient>(),
          ),
          update: (ctx, aiClient, toolExecutor, prev) =>
              prev ??
              McpAgentEngine(
                aiClient as MultiAiClient,
                toolExecutor,
              ),
        ),
      ],
      child: MaterialApp(
        title: '智能逆向助手',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorSchemeSeed: const Color(0xFF3388CC),
          useMaterial3: true,
          brightness: Brightness.dark,
        ),
        home: const HomePage(),
      ),
    );
  }
}
