import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../ai/ai_provider.dart';
import '../ai/tool_executor.dart';
import 'mcp_models.dart';

/// MCP (Model Context Protocol) 客户端
///
/// 支持 SSE 和 Streamable HTTP 两种传输方式，可根据 URL 自动检测：
/// - URL 路径以 `/sse` 结尾或包含 `/sse` 时使用 SSE 传输
/// - 其他情况使用 Streamable HTTP 传输
///
/// 主要功能：
/// - JSON-RPC 协议：initialize / tools/list / tools/call
/// - 会话管理（`mcp-session-id` 请求头）
/// - 自动重连（指数退避，最多 5 次）
/// - 工具列表获取与调用
/// - 工具启用/禁用切换
/// - 连接状态管理与日志记录
///
/// 用法示例：
/// ```dart
/// final client = McpClient();
/// await client.connect('http://localhost:3000/sse');
/// final result = await client.listTools();
/// final callResult = await client.callTool('tool_name', {'arg': 'value'});
/// await client.disconnect();
/// ```
class McpClient extends ToolExecutor {
  McpClient();

  // ===================== 状态字段 =====================
  McpConnectionState _connectionState = McpDisconnected();
  final List<McpTool> _tools = [];
  final List<String> _logs = [];
  String? _serverInfo;

  // ===================== 会话信息 =====================
  String? _sessionId; // mcp-session-id
  String? _endpointUrl; // SSE 消息端点 URL
  String _transport = 'streamable-http'; // 'sse' | 'streamable-http'
  String? _serverUrl; // 服务器基础 URL
  Map<String, String> _baseHeaders = {}; // 用户自定义请求头

  // ===================== HTTP & SSE =====================
  http.Client? _httpClient;
  StreamSubscription<List<int>>? _sseSubscription;
  int _requestId = 0; // JSON-RPC 请求 ID 计数器
  bool _disposed = false;
  bool _manualDisconnect = false; // 是否为手动断开（不触发重连）

  // SSE 请求/响应匹配：key = 请求 ID
  final Map<int, Completer<Map<String, dynamic>>> _pendingRequests = {};

  // SSE endpoint 等待
  Completer<bool>? _endpointCompleter;

  // SSE 流解析缓冲
  String _sseBuffer = '';
  String _sseEventType = '';
  String _sseData = '';

  // ===================== 重连 =====================
  Timer? _reconnectTimer;
  int _reconnectAttempt = 0;

  // ===================== 公开属性 =====================

  /// 当前连接状态
  McpConnectionState get connectionState => _connectionState;

  /// 已发现的工具列表（只读）
  List<McpTool> get tools => List.unmodifiable(_tools);

  /// 日志列表（只读）
  List<String> get logs => List.unmodifiable(_logs);

  /// 服务器信息
  String? get serverInfo => _serverInfo;

  /// 当前传输模式
  String get transport => _transport;

  // ===================== 内部辅助方法 =====================

  /// 更新连接状态并通知监听者
  void _setState(McpConnectionState state) {
    if (_disposed) return;
    _connectionState = state;
    notifyListeners();
  }

  /// 添加日志（带时间戳，自动限制数量）
  void _addLog(String message) {
    if (_disposed) return;
    final ts = DateTime.now().toIso8601String().substring(11, 19);
    _logs.add('[$ts] $message');
    // 限制日志数量，避免内存无限增长
    if (_logs.length > 500) {
      _logs.removeRange(0, _logs.length - 500);
    }
    if (kDebugMode) {
      debugPrint('[MCP] $message');
    }
    notifyListeners();
  }

  /// 清空日志
  void clearLogs() {
    _logs.clear();
    notifyListeners();
  }

  // ===================== 传输模式检测 =====================

  /// 根据URL自动检测传输模式
  /// URL 路径以 `/sse` 结尾或包含 `/sse` 时使用 SSE，否则使用 Streamable HTTP
  String _detectTransport(String url) {
    try {
      final uri = Uri.parse(url);
      final path = uri.path.toLowerCase();
      if (path.endsWith('/sse') || path.contains('/sse')) {
        return 'sse';
      }
    } catch (_) {
      // URL 解析失败，默认使用 Streamable HTTP
    }
    return 'streamable-http';
  }

  // ===================== 连接 =====================

  /// 连接到 MCP 服务器
  ///
  /// [url] - MCP 服务器地址
  /// [headers] - 自定义请求头
  Future<void> connect(String url, {Map<String, String>? headers}) async {
    if (_disposed) return;

    // 保存连接参数
    _serverUrl = url;
    _baseHeaders = headers ?? {};
    _transport = _detectTransport(url);
    _manualDisconnect = false;
    _reconnectAttempt = 0;

    // 清理旧连接
    await _cleanupConnection();

    _setState(McpConnecting());
    _addLog('正在连接 MCP 服务器: $url (传输模式: $_transport)');

    _httpClient = http.Client();

    try {
      final ok = await _doConnect();
      if (ok) {
        _reconnectAttempt = 0;
        _setState(McpConnected());
        _addLog('MCP 服务器连接成功');
      } else {
        _setState(McpError('连接失败', '初始化未成功'));
        _addLog('MCP 服务器连接失败');
        _scheduleReconnect();
      }
    } catch (e) {
      _setState(McpError('连接异常', e.toString()));
      _addLog('连接异常: $e');
      _scheduleReconnect();
    }
  }

  /// 执行实际连接和初始化流程
  ///
  /// 流程：
  /// 1. SSE 模式下建立长连接并等待 endpoint 事件
  /// 2. 发送 initialize 请求完成握手
  /// 3. 发送 initialized 通知
  /// 4. 拉取工具列表
  Future<bool> _doConnect() async {
    try {
      if (_transport == 'sse') {
        // SSE 模式：先建立长连接，等待 endpoint 事件
        await _startSseConnection();
        final gotEndpoint = await _waitForEndpoint(
          timeoutSeconds: McpConstants.initTimeoutSeconds,
        );
        if (!gotEndpoint) {
          _addLog('SSE: 在超时时间内未收到 endpoint 事件');
          return false;
        }
      }

      // 发送 initialize 请求完成 JSON-RPC 握手
      final initialized = await _initialize();
      if (!initialized) return false;

      // 初始化成功后拉取工具列表
      final toolResult = await listTools();
      if (toolResult.isSuccess) {
        _addLog('已发现 ${_tools.length} 个工具');
      } else {
        _addLog('获取工具列表失败: ${toolResult.exceptionOrNull()}');
      }

      return true;
    } catch (e) {
      _addLog('连接/初始化失败: $e');
      return false;
    }
  }

  // ===================== SSE 传输 =====================

  /// 建立 SSE 长连接（GET 请求，读取 text/event-stream）
  Future<void> _startSseConnection() async {
    // 重置 SSE 解析状态
    _sseBuffer = '';
    _sseEventType = '';
    _sseData = '';
    _endpointCompleter = Completer<bool>();

    final uri = Uri.parse(_serverUrl!);
    final request = http.Request('GET', uri);
    request.headers['Accept'] = 'text/event-stream';
    request.headers['Cache-Control'] = 'no-cache';
    _baseHeaders.forEach((k, v) => request.headers[k] = v);

    final response = await _httpClient!.send(request);

    if (response.statusCode != 200) {
      throw StateError(
        'SSE 连接失败，HTTP 状态码: ${response.statusCode}',
      );
    }

    _sseSubscription = response.stream.listen(
      (bytes) => _handleSseBytes(bytes),
      onError: (e) {
        _addLog('SSE 流错误: $e');
        if (!_manualDisconnect && !_disposed) {
          _scheduleReconnect();
        }
      },
      onDone: () {
        _addLog('SSE 连接已关闭');
        if (!_manualDisconnect && !_disposed) {
          _scheduleReconnect();
        }
      },
      cancelOnError: true,
    );

    _addLog('SSE 长连接已建立');
  }

  /// 等待 SSE endpoint 事件（服务器告知消息端点 URL）
  Future<bool> _waitForEndpoint({int timeoutSeconds = 30}) async {
    if (_endpointCompleter == null) return false;
    try {
      return await _endpointCompleter!.future
          .timeout(Duration(seconds: timeoutSeconds));
    } on TimeoutException {
      return false;
    } catch (e) {
      _addLog('等待 endpoint 异常: $e');
      return false;
    }
  }

  /// 处理 SSE 字节流：将字节解码为文本并按行解析事件
  void _handleSseBytes(List<int> bytes) {
    _sseBuffer += utf8.decode(bytes, allowMalformed: true);

    // 按行解析 SSE 事件
    while (true) {
      final idx = _sseBuffer.indexOf('\n');
      if (idx == -1) break;

      final line = _sseBuffer.substring(0, idx);
      _sseBuffer = _sseBuffer.substring(idx + 1);
      final cleanLine = line.replaceAll('\r', '');

      if (cleanLine.isEmpty) {
        // 空行 = 事件边界，分发当前已累积的事件
        _dispatchSseEvent();
      } else if (cleanLine.startsWith('event:')) {
        _sseEventType = cleanLine.substring(6).trim();
      } else if (cleanLine.startsWith('data:')) {
        final data = cleanLine.substring(5);
        // SSE 规范：data: 后有一个可选前导空格
        final trimmed = data.startsWith(' ') ? data.substring(1) : data;
        // 多行 data 用换行符连接
        _sseData = _sseData.isEmpty ? trimmed : '$_sseData\n$trimmed';
      }
      // 忽略注释行（以 : 开头，如心跳）和其他行
    }
  }

  /// 分发一个完整的 SSE 事件
  void _dispatchSseEvent() {
    if (_sseData.isEmpty) {
      _sseEventType = '';
      _sseData = '';
      return;
    }

    switch (_sseEventType) {
      case 'endpoint':
        _handleEndpointEvent(_sseData);
        break;
      case 'message':
        _handleMessageEvent(_sseData);
        break;
      default:
        // 忽略未知事件类型（如 ping）
        break;
    }

    // 重置事件缓冲
    _sseEventType = '';
    _sseData = '';
  }

  /// 处理 endpoint 事件：获取消息端点 URL
  void _handleEndpointEvent(String data) {
    _endpointUrl = _resolveUrl(_serverUrl!, data.trim());
    _addLog('SSE 消息端点: $_endpointUrl');

    if (_endpointCompleter != null && !_endpointCompleter!.isCompleted) {
      _endpointCompleter!.complete(true);
    }
  }

  /// 处理 message 事件：JSON-RPC 响应或服务器通知
  void _handleMessageEvent(String data) {
    try {
      final json = jsonDecode(data) as Map<String, dynamic>;
      final rawId = json['id'];

      if (rawId != null) {
        // 响应消息：按请求 ID 匹配并完成对应的 Completer
        final id = _parseRequestId(rawId);
        if (id != null) {
          final completer = _pendingRequests.remove(id);
          if (completer != null && !completer.isCompleted) {
            if (json.containsKey('error')) {
              final err = json['error'];
              completer.completeError(
                StateError(err is String ? err : jsonEncode(err)),
              );
            } else {
              completer.complete(
                json['result'] as Map<String, dynamic>? ?? {},
              );
            }
          }
        }
      } else {
        // 通知消息（无 ID）：记录日志
        final method = json['method'];
        _addLog('收到服务器通知: $method');
      }
    } catch (e) {
      _addLog('解析 SSE 消息失败: $e');
    }
  }

  /// 解析 JSON-RPC 请求 ID（支持 int / double / String）
  int? _parseRequestId(dynamic rawId) {
    if (rawId is int) return rawId;
    if (rawId is double) return rawId.toInt();
    if (rawId is String) return int.tryParse(rawId);
    return null;
  }

  /// 通过 SSE 传输发送 JSON-RPC 请求
  ///
  /// 将请求 POST 到消息端点，实际响应通过 SSE 流返回，
  /// 通过 Completer + 请求 ID 匹配实现请求/响应关联。
  Future<Map<String, dynamic>?> _sendRequestSse(
    String method,
    Map<String, dynamic> params, {
    int timeoutSeconds = 60,
  }) async {
    if (_endpointUrl == null) {
      throw StateError('SSE 消息端点未就绪');
    }

    final id = ++_requestId;
    final message = {
      'jsonrpc': '2.0',
      'id': id,
      'method': method,
      'params': params,
    };

    final completer = Completer<Map<String, dynamic>>();
    _pendingRequests[id] = completer;

    try {
      // POST 请求到消息端点（服务器返回 202 或 200，实际结果在 SSE 流中）
      final response = await _httpClient!.post(
        Uri.parse(_endpointUrl!),
        headers: {
          'Content-Type': 'application/json',
          ..._baseHeaders,
          if (_sessionId != null) 'mcp-session-id': _sessionId!,
        },
        body: jsonEncode(message),
      );

      if (response.statusCode != 200 && response.statusCode != 202) {
        _pendingRequests.remove(id);
        throw StateError(
          'SSE POST 失败，HTTP 状态码: ${response.statusCode}',
        );
      }

      // 等待 SSE 流中的响应消息
      // 注意：Dart 的 Completer 没有 timeout 方法，需对 .future 调用 timeout
      final result = await completer.future.timeout(
        Duration(seconds: timeoutSeconds),
        onTimeout: () {
          _pendingRequests.remove(id);
          throw TimeoutException('SSE 请求超时: $method');
        },
      );
      return result;
    } catch (e) {
      // 确保清理 pending 请求
      _pendingRequests.remove(id);
      rethrow;
    }
  }

  // ===================== Streamable HTTP 传输 =====================

  /// 通过 Streamable HTTP 传输发送 JSON-RPC 请求
  ///
  /// 直接 POST JSON-RPC 请求到服务器 URL，响应可能是：
  /// - application/json：直接解析 JSON
  /// - text/event-stream：解析 SSE 事件提取结果
  Future<Map<String, dynamic>?> _sendRequestStreamableHttp(
    String method,
    Map<String, dynamic> params, {
    int timeoutSeconds = 60,
  }) async {
    final id = ++_requestId;
    final message = {
      'jsonrpc': '2.0',
      'id': id,
      'method': method,
      'params': params,
    };

    final response = await _httpClient!
        .post(
          Uri.parse(_serverUrl!),
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json, text/event-stream',
            ..._baseHeaders,
            if (_sessionId != null) 'mcp-session-id': _sessionId!,
          },
          body: jsonEncode(message),
        )
        .timeout(Duration(seconds: timeoutSeconds));

    // 捕获并保存 session ID
    final sid = response.headers['mcp-session-id'];
    if (sid != null && sid.isNotEmpty) {
      _sessionId = sid;
    }

    if (response.statusCode != 200) {
      throw StateError(
        '请求失败 ($method)，HTTP 状态码: ${response.statusCode}'
        '${response.body.isNotEmpty ? ': ${response.body}' : ''}',
      );
    }

    final contentType = response.headers['content-type'] ?? '';

    if (contentType.contains('text/event-stream')) {
      // SSE 格式响应：解析事件流提取结果
      return _parseSseResponseBody(response.body, method);
    } else {
      // JSON 格式响应：直接解析
      return _parseJsonResponseBody(response.body, method);
    }
  }

  /// 解析 JSON 格式的响应体
  Map<String, dynamic>? _parseJsonResponseBody(String body, String method) {
    try {
      final json = jsonDecode(body) as Map<String, dynamic>;
      if (json.containsKey('error')) {
        final err = json['error'];
        throw StateError(
          'JSON-RPC 错误 ($method): ${err is String ? err : jsonEncode(err)}',
        );
      }
      return json['result'] as Map<String, dynamic>?;
    } catch (e) {
      if (e is StateError) rethrow;
      throw StateError('解析 JSON 响应失败 ($method): $e');
    }
  }

  /// 解析 SSE 格式的响应体（Streamable HTTP 模式下服务器可能返回 SSE）
  ///
  /// 遍历所有事件，返回第一个包含 result 的消息；
  /// 如果遇到 error 消息则抛出异常。
  Map<String, dynamic>? _parseSseResponseBody(String body, String method) {
    final lines = body.split('\n');
    final dataBuffer = <String>[];
    Map<String, dynamic>? errorJson;

    // 遍历所有行（包含一个虚拟空行以处理末尾事件）
    for (int i = 0; i <= lines.length; i++) {
      final line = i < lines.length ? lines[i].replaceAll('\r', '') : '';

      if (line.isEmpty) {
        // 事件边界：处理已累积的数据
        if (dataBuffer.isNotEmpty) {
          final data = dataBuffer.join('\n');
          try {
            final json = jsonDecode(data) as Map<String, dynamic>;
            if (json.containsKey('error')) {
              errorJson = json;
            } else if (json.containsKey('result')) {
              return json['result'] as Map<String, dynamic>?;
            }
          } catch (_) {
            // 跳过无效 JSON
          }
        }
        dataBuffer.clear();
      } else if (line.startsWith('data:')) {
        final data = line.substring(5);
        final trimmed = data.startsWith(' ') ? data.substring(1) : data;
        dataBuffer.add(trimmed);
      }
    }

    // 如果有错误消息，抛出异常
    if (errorJson != null) {
      final err = errorJson['error'];
      throw StateError(
        'JSON-RPC 错误 ($method): ${err is String ? err : jsonEncode(err)}',
      );
    }

    throw StateError('SSE 响应中未找到有效消息 ($method)');
  }

  // ===================== JSON-RPC 核心方法 =====================

  /// 发送 JSON-RPC 请求（自动选择传输方式）
  Future<Map<String, dynamic>?> _sendRequest(
    String method,
    Map<String, dynamic> params, {
    int timeoutSeconds = 60,
  }) async {
    if (_httpClient == null) {
      throw StateError('客户端未连接');
    }

    if (_transport == 'sse') {
      return _sendRequestSse(method, params, timeoutSeconds: timeoutSeconds);
    } else {
      return _sendRequestStreamableHttp(
        method,
        params,
        timeoutSeconds: timeoutSeconds,
      );
    }
  }

  /// 发送 JSON-RPC 通知（无响应）
  Future<void> _sendNotification(
    String method, [
    Map<String, dynamic>? params,
  ]) async {
    try {
      final message = <String, dynamic>{
        'jsonrpc': '2.0',
        'method': method,
      };
      if (params != null) message['params'] = params;

      // 根据传输模式选择目标 URL
      final targetUrl = _transport == 'sse' ? _endpointUrl : _serverUrl;
      if (targetUrl == null) {
        _addLog('发送通知失败：无可用端点 ($method)');
        return;
      }

      await _httpClient!.post(
        Uri.parse(targetUrl),
        headers: {
          'Content-Type': 'application/json',
          ..._baseHeaders,
          if (_sessionId != null) 'mcp-session-id': _sessionId!,
        },
        body: jsonEncode(message),
      );
    } catch (e) {
      _addLog('发送通知失败 ($method): $e');
    }
  }

  /// 初始化 MCP 会话
  ///
  /// 发送 initialize 请求，获取服务器信息与协议版本，
  /// 然后发送 initialized 通知完成握手。
  Future<bool> _initialize() async {
    try {
      final result = await _sendRequest(
        'initialize',
        {
          'protocolVersion': '2024-11-05',
          'capabilities': {},
          'clientInfo': {
            'name': 'reverse_tool_ai',
            'version': '2.0.0',
          },
        },
        timeoutSeconds: McpConstants.initTimeoutSeconds,
      );

      if (result == null) {
        _addLog('初始化未收到响应');
        return false;
      }

      // 保存服务器信息
      final serverInfo = result['serverInfo'];
      if (serverInfo is Map<String, dynamic>) {
        _serverInfo =
            '${serverInfo['name'] ?? 'unknown'} v${serverInfo['version'] ?? '?'}';
      } else {
        _serverInfo = null;
      }

      // 记录协议版本
      final protocolVersion = result['protocolVersion'];
      _addLog('服务器信息: $_serverInfo (协议版本: $protocolVersion)');

      // 发送 initialized 通知完成握手
      await _sendNotification('notifications/initialized');

      return true;
    } catch (e) {
      _addLog('初始化失败: $e');
      return false;
    }
  }

  // ===================== 公开 API 方法 =====================

  /// 获取工具列表
  ///
  /// 向服务器发送 tools/list 请求，刷新本地工具列表。
  /// 返回 [Result] 包含工具列表或错误信息。
  Future<Result<List<McpTool>>> listTools() async {
    if (_httpClient == null) {
      return Result.error('客户端未连接');
    }

    try {
      final result = await _sendRequest(
        'tools/list',
        {},
        timeoutSeconds: McpConstants.toolCallTimeoutSeconds,
      );

      if (result == null) {
        return Result.error('未收到响应');
      }

      // 解析工具列表
      final toolsList = result['tools'] as List? ?? [];
      _tools.clear();
      for (final t in toolsList) {
        try {
          _tools.add(McpTool.fromJson(t as Map<String, dynamic>));
        } catch (e) {
          _addLog('解析工具定义失败: $e');
        }
      }

      _addLog('工具列表已更新（${_tools.length} 个）');
      notifyListeners();
      return Result.success(List<McpTool>.from(_tools));
    } catch (e) {
      _addLog('获取工具列表失败: $e');
      return Result.error(e.toString());
    }
  }

  /// 调用工具
  ///
  /// [name] - 工具名称
  /// [arguments] - 工具参数
  /// 返回 [Result] 包含工具调用结果或错误信息。
  Future<Result<McpToolCallResult>> callTool(
    String name,
    Map<String, dynamic> arguments,
  ) async {
    if (_httpClient == null) {
      return Result.error('客户端未连接');
    }

    // 检查工具是否被禁用
    for (final tool in _tools) {
      if (tool.name == name && !tool.enabled) {
        return Result.error('工具已禁用: $name');
      }
    }

    try {
      _addLog('调用工具: $name (参数: ${_formatArguments(arguments)})');

      final result = await _sendRequest(
        'tools/call',
        {
          'name': name,
          'arguments': arguments,
        },
        timeoutSeconds: McpConstants.toolCallTimeoutSeconds,
      );

      if (result == null) {
        return Result.error('未收到响应');
      }

      // 截断过长的文本输出，避免内存问题
      _truncateResultContent(result);

      final callResult = McpToolCallResult.fromJson(result);
      _addLog('工具调用完成: $name (错误: ${callResult.isError})');
      return Result.success(callResult);
    } catch (e) {
      _addLog('工具调用失败 ($name): $e');
      return Result.error(e.toString());
    }
  }

  /// 切换工具启用/禁用状态
  void toggleToolEnabled(String toolName) {
    for (final tool in _tools) {
      if (tool.name == toolName) {
        tool.enabled = !tool.enabled;
        _addLog('工具 ${tool.enabled ? "已启用" : "已禁用"}: $toolName');
        notifyListeners();
        return;
      }
    }
  }

  /// 获取已启用的工具列表
  List<McpTool> getEnabledTools() {
    return _tools.where((t) => t.enabled).toList();
  }

  // ===================== 断开连接 =====================

  /// 断开与 MCP 服务器的连接
  ///
  /// 手动断开不会触发自动重连。
  Future<void> disconnect() async {
    _manualDisconnect = true;
    _reconnectTimer?.cancel();
    _reconnectTimer = null;

    await _cleanupConnection();

    _tools.clear();
    _sessionId = null;
    _endpointUrl = null;
    _serverInfo = null;
    _sseBuffer = '';
    _sseEventType = '';
    _sseData = '';
    _reconnectAttempt = 0;
    _requestId = 0;

    _setState(McpDisconnected());
    _addLog('已断开 MCP 连接');
  }

  /// 清理连接资源（SSE 订阅、pending 请求、HTTP 客户端）
  Future<void> _cleanupConnection() async {
    await _sseSubscription?.cancel();
    _sseSubscription = null;

    // 取消所有等待中的请求
    for (final completer in _pendingRequests.values) {
      if (!completer.isCompleted) {
        completer.completeError(StateError('连接已断开'));
      }
    }
    _pendingRequests.clear();

    _httpClient?.close();
    _httpClient = null;
  }

  // ===================== 自动重连 =====================

  /// 安排重连（指数退避）
  ///
  /// 重连延迟 = baseDelay * 2^attempt，上限为 maxReconnectDelayMs。
  /// 超过最大重连次数后停止并进入错误状态。
  void _scheduleReconnect() {
    if (_disposed || _manualDisconnect) return;

    if (_reconnectAttempt >= McpConstants.maxReconnectAttempts) {
      _setState(McpError(
        '重连失败',
        '已达到最大重连次数 ${McpConstants.maxReconnectAttempts}',
      ));
      _addLog('已达到最大重连次数，停止重连');
      return;
    }

    final attempt = _reconnectAttempt + 1;
    final delay = _calculateBackoff(_reconnectAttempt);

    _setState(McpReconnecting(attempt, McpConstants.maxReconnectAttempts));
    _addLog(
      '将在 ${delay}ms 后进行第 $attempt/${McpConstants.maxReconnectAttempts} 次重连',
    );

    _reconnectTimer?.cancel();
    _reconnectTimer = Timer(Duration(milliseconds: delay), () async {
      if (_disposed || _manualDisconnect) return;
      _reconnectAttempt = attempt;

      // 清理旧连接，创建新的 HTTP 客户端
      await _cleanupConnection();
      _httpClient = http.Client();

      try {
        _addLog('正在重连...');
        final ok = await _doConnect();
        if (ok) {
          _reconnectAttempt = 0;
          _setState(McpConnected());
          _addLog('重连成功');
        } else {
          _addLog('重连失败，继续重试');
          _scheduleReconnect();
        }
      } catch (e) {
        _addLog('重连异常: $e');
        _scheduleReconnect();
      }
    });
  }

  /// 计算指数退避延迟（毫秒）
  int _calculateBackoff(int attempt) {
    final delay = McpConstants.baseReconnectDelayMs * (1 << attempt);
    return delay > McpConstants.maxReconnectDelayMs
        ? McpConstants.maxReconnectDelayMs
        : delay;
  }

  // ===================== 工具方法 =====================

  /// 将相对端点 URL 解析为完整 URL
  ///
  /// 支持以下格式：
  /// - 完整 URL（http://...）→ 直接返回
  /// - 绝对路径（/messages）→ 拼接 scheme://host:port
  /// - 相对路径（messages）→ 基于当前路径目录拼接
  String _resolveUrl(String baseUrl, String endpoint) {
    if (endpoint.startsWith('http://') || endpoint.startsWith('https://')) {
      return endpoint;
    }

    final base = Uri.parse(baseUrl);
    final host = base.host;
    final port = base.port;
    final portStr = port != 0 ? ':$port' : '';

    if (endpoint.startsWith('/')) {
      // 绝对路径
      return '${base.scheme}://$host$portStr$endpoint';
    }

    // 相对路径：基于当前路径的目录
    final basePath = base.path;
    final lastSlash = basePath.lastIndexOf('/');
    final dir = lastSlash > 0 ? basePath.substring(0, lastSlash) : '';
    return '${base.scheme}://$host$portStr$dir/$endpoint';
  }

  /// 截断 JSON-RPC 结果中过长的文本内容
  ///
  /// 超过 [McpConstants.maxToolOutputChars] 的文本会被截断并附加提示。
  void _truncateResultContent(Map<String, dynamic> result) {
    final contentList = result['content'];
    if (contentList is! List) return;

    final truncated = <Map<String, dynamic>>[];
    for (final item in contentList) {
      if (item is Map<String, dynamic>) {
        final newItem = Map<String, dynamic>.from(item);
        final text = newItem['text'];
        if (text is String &&
            text.length > McpConstants.maxToolOutputChars) {
          newItem['text'] =
              '${text.substring(0, McpConstants.maxToolOutputChars)}'
              '\n... [输出已截断，原始长度: ${text.length} 字符]';
        }
        truncated.add(newItem);
      }
    }
    result['content'] = truncated;
  }

  /// 格式化参数用于日志（截断过长内容）
  String _formatArguments(Map<String, dynamic> args) {
    final str = jsonEncode(args);
    if (str.length > McpConstants.toolOutputPreviewChars) {
      return '${str.substring(0, McpConstants.toolOutputPreviewChars)}...';
    }
    return str;
  }

  // ===================== 资源释放 =====================

  @override
  void dispose() {
    _disposed = true;
    _manualDisconnect = true;

    _reconnectTimer?.cancel();
    _reconnectTimer = null;

    _sseSubscription?.cancel();
    _sseSubscription = null;

    // 取消所有等待中的请求
    for (final completer in _pendingRequests.values) {
      if (!completer.isCompleted) {
        completer.completeError(StateError('客户端已销毁'));
      }
    }
    _pendingRequests.clear();

    _httpClient?.close();
    _httpClient = null;

    super.dispose();
  }
}
