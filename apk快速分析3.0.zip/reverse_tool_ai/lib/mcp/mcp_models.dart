// MCP 连接状态
sealed class McpConnectionState {}
class McpDisconnected extends McpConnectionState {}
class McpConnecting extends McpConnectionState {}
class McpConnected extends McpConnectionState {}
class McpReconnecting extends McpConnectionState {
  final int attempt;
  final int maxAttempts;
  McpReconnecting(this.attempt, this.maxAttempts);
}
class McpError extends McpConnectionState {
  final String message;
  final String? detail;
  McpError(this.message, [this.detail]);
}

// MCP 工具定义
class McpTool {
  final String name;
  final String? description;
  final Map<String, dynamic>? inputSchemaProperties;
  final List<String>? inputSchemaRequired;
  bool enabled;
  McpTool({required this.name, this.description, this.inputSchemaProperties, this.inputSchemaRequired, this.enabled = true});

  factory McpTool.fromJson(Map<String, dynamic> json) {
    final schema = json['inputSchema'] as Map<String, dynamic>?;
    return McpTool(
      name: json['name'] ?? '',
      description: json['description'],
      inputSchemaProperties: schema?['properties'] as Map<String, dynamic>?,
      inputSchemaRequired: schema?['required'] != null ? List<String>.from(schema!['required']) : null,
      enabled: true,
    );
  }
}

// MCP 工具调用结果
class McpToolContent {
  final String type;
  final String? text;
  final String? data;
  McpToolContent({required this.type, this.text, this.data});

  factory McpToolContent.fromJson(Map<String, dynamic> json) {
    return McpToolContent(
      type: json['type'] ?? 'text',
      text: json['text'],
      data: json['data'],
    );
  }
}

class McpNextAction {
  final String tool;
  final String purpose;
  final String? description;
  final Map<String, dynamic> arguments;
  McpNextAction({required this.tool, this.purpose = '', this.description, this.arguments = const {}});

  factory McpNextAction.fromJson(Map<String, dynamic> json) {
    return McpNextAction(
      tool: json['tool'] ?? '',
      purpose: json['purpose'] ?? '',
      description: json['description'],
      arguments: json['arguments'] != null ? Map<String, dynamic>.from(json['arguments']) : {},
    );
  }
}

class McpToolCallResult {
  final List<McpToolContent> content;
  final bool isError;
  final List<McpNextAction>? nextActions;
  McpToolCallResult({required this.content, this.isError = false, this.nextActions});

  factory McpToolCallResult.fromJson(Map<String, dynamic> json) {
    return McpToolCallResult(
      content: (json['content'] as List?)?.map((e) => McpToolContent.fromJson(e as Map<String, dynamic>)).toList() ?? [],
      isError: json['isError'] ?? false,
      nextActions: (json['nextActions'] as List?)?.map((e) => McpNextAction.fromJson(e as Map<String, dynamic>)).toList(),
    );
  }
}

// MCP 常量
class McpConstants {
  static const int maxToolOutputChars = 32768;
  static const int toolOutputPreviewChars = 4096;
  static const int maxReconnectAttempts = 5;
  static const int baseReconnectDelayMs = 1000;
  static const int maxReconnectDelayMs = 30000;
  static const int toolCallTimeoutSeconds = 120;
  static const int initTimeoutSeconds = 30;
  static const int maxAgentIterations = 60;
}
