import '../mcp/mcp_models.dart';
import 'ai_provider.dart';
import 'tool_executor.dart';
import 'local_analyzer_tools.dart';

/// 本地工具执行器
///
/// 不需要外部 MCP 服务器，直接将应用已分析的逆向数据
///（包名、权限、SDK、签名、组件、安全报告等）包装为
/// AI 可调用的工具，让 AI Agent 能读取应用学到的参数。
///
/// 实现 [ToolExecutor] 接口，与 [McpClient] 互换使用。
class LocalMcpClient extends ToolExecutor {
  final LocalAnalyzerTools _localTools;

  /// 缓存的工具列表（避免每次 getter 都重建）
  List<McpTool>? _cachedTools;

  LocalMcpClient(this._localTools);

  @override
  List<McpTool> get tools {
    if (_cachedTools != null) return _cachedTools!;
    _cachedTools = _localTools.tools.map((t) {
      // 构建输入 schema
      final props = <String, dynamic>{};
      final required = <String>[];

      // 所有工具都支持可选的 query 参数（用于过滤/搜索）
      props['query'] = {
        'type': 'string',
        'description': '可选的搜索关键词，用于过滤结果',
      };

      // 将必填参数加入 schema
      for (final p in t.requiredParams) {
        required.add(p);
        props[p] = {
          'type': 'string',
          'description': '必填参数: $p',
        };
      }

      return McpTool(
        name: t.name,
        description: t.description,
        inputSchemaProperties: props,
        inputSchemaRequired: required.isEmpty ? null : required,
        enabled: true,
      );
    }).toList();
    return _cachedTools!;
  }

  @override
  Future<Result<McpToolCallResult>> callTool(
    String name,
    Map<String, dynamic> arguments,
  ) async {
    try {
      final result = await _localTools.executeTool(name, arguments);
      // 只有真正的执行错误才标记为 isError
      // "尚未分析"/"未检测到" 等是有效的空结果提示，不是错误
      final isError = result.startsWith('错误:') ||
          result.startsWith('工具执行异常:');

      return Result.success(McpToolCallResult(
        content: [
          McpToolContent(type: 'text', text: result),
        ],
        isError: isError,
      ));
    } catch (e) {
      return Result.error('本地工具执行失败: $e');
    }
  }

  /// 刷新工具缓存（当分析数据变化时可调用）
  void refresh() {
    _cachedTools = null;
    notifyListeners();
  }
}
