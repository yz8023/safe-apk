/// AI 提供方系统 - Kotlin 版本的 Dart 移植
///
/// 定义了一套统一的 AI 对话/文本生成抽象，以及若干具体实现：
/// - [PollinationsProvider]：免密钥的 Pollinations 文本接口
/// - [CehpointProvider]：免密钥的 Cehpoint OpenAI 兼容接口
/// - [OpenAICompatibleProvider]：可配置的通用 OpenAI 兼容接口（支持 DeepSeek 等）
///
/// 所有网络调用均包裹在 try-catch 中，失败时返回 [Result.failure]，
/// 不会抛出未捕获异常，便于上层安全使用。
library;

import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

// ============================================================================
// Result<T> —— 仿 Kotlin kotlinx.Result 的轻量封装
// ============================================================================

/// 仿 Kotlin `Result<T>` 的结果封装。
///
/// 一个 [Result] 要么是成功（持有值），要么是失败（持有异常），
/// 通过 [isSuccess] / [isFailure] 区分，并通过 [getOrNull] / [exceptionOrNull]
/// 安全取值，避免直接抛出异常。
class Result<T> {
  final T? _value;
  final Exception? _error;

  // 私有构造：成功路径
  const Result._success(this._value) : _error = null;

  // 私有构造：失败路径
  const Result._failure(this._error) : _value = null;

  /// 是否为成功结果
  bool get isSuccess => _error == null;

  /// 是否为失败结果
  bool get isFailure => _error != null;

  /// 返回成功持有的值；若为失败则返回 null
  T? getOrNull() => _value;

  /// 返回失败持有的异常；若为成功则返回 null
  Exception? exceptionOrNull() => _error;

  /// 构造一个成功结果
  static Result<T> success<T>(T value) => Result<T>._success(value);

  /// 构造一个失败结果（传入异常对象）
  static Result<T> failure<T>(Exception error) => Result<T>._failure(error);

  /// 构造一个失败结果（传入错误消息字符串）
  ///
  /// 便捷工厂：将字符串消息包装为 [Exception] 后构造失败结果，
  /// 便于调用方直接传字符串而非显式构造异常。
  static Result<T> error<T>(String message) =>
      Result<T>._failure(Exception(message));

  /// 链式转换：仅当成功时对值应用 [transform]，失败则原样传递
  Result<R> map<R>(R Function(T value) transform) {
    if (isSuccess) {
      return Result.success(transform(_value as T));
    }
    return Result.failure(_error!);
  }

  /// 成功时返回值，失败时返回 [fallback]
  T getOrDefault(T fallback) => isSuccess ? (_value as T) : fallback;

  @override
  String toString() =>
      isSuccess ? 'Result.success($_value)' : 'Result.failure($_error)';
}

// ============================================================================
// 数据类
// ============================================================================

/// AI 提供方信息（用于在 UI 中展示可选提供方列表）
class ProviderInfo {
  /// 唯一标识，如 'pollinations' / 'cehpoint'
  final String id;

  /// 显示名称
  final String name;

  /// 描述说明
  final String description;

  /// 是否为免密钥提供方（无需用户填写 API Key 即可使用）
  final bool isKeyless;

  const ProviderInfo({
    required this.id,
    required this.name,
    required this.description,
    required this.isKeyless,
  });

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ProviderInfo &&
          runtimeType == other.runtimeType &&
          id == other.id &&
          name == other.name &&
          description == other.description &&
          isKeyless == other.isKeyless;

  @override
  int get hashCode => Object.hash(id, name, description, isKeyless);

  @override
  String toString() =>
      'ProviderInfo(id=$id, name=$name, isKeyless=$isKeyless)';
}

/// 自定义提供方配置（用户可自行添加的 OpenAI 兼容服务）
class CustomProviderConfig {
  /// 唯一标识
  final String id;

  /// 显示名称
  final String name;

  /// 接口基址，如 https://api.example.com/v1/chat/completions
  final String baseUrl;

  /// API 密钥（可空，部分自建服务无需鉴权）
  final String apiKey;

  /// 默认使用的模型名
  final String modelName;

  const CustomProviderConfig({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.apiKey,
    required this.modelName,
  });

  /// 复制并部分修改字段
  CustomProviderConfig copyWith({
    String? id,
    String? name,
    String? baseUrl,
    String? apiKey,
    String? modelName,
  }) =>
      CustomProviderConfig(
        id: id ?? this.id,
        name: name ?? this.name,
        baseUrl: baseUrl ?? this.baseUrl,
        apiKey: apiKey ?? this.apiKey,
        modelName: modelName ?? this.modelName,
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is CustomProviderConfig &&
          runtimeType == other.runtimeType &&
          id == other.id &&
          name == other.name &&
          baseUrl == other.baseUrl &&
          apiKey == other.apiKey &&
          modelName == other.modelName;

  @override
  int get hashCode => Object.hash(id, name, baseUrl, apiKey, modelName);

  @override
  String toString() =>
      'CustomProviderConfig(id=$id, name=$name, baseUrl=$baseUrl, '
      'modelName=$modelName)';
}

// ============================================================================
// AiProvider 抽象
// ============================================================================

/// AI 提供方抽象接口。
///
/// 所有具体提供方需实现对话补全、文本生成与健康检查能力；
/// [fetchModels] 提供默认空实现，可按需覆写。
abstract class AiProvider {
  /// 提供方名称
  String get name;

  /// 是否可用（已配置且可访问）
  bool get isAvailable;
  set isAvailable(bool value);

  /// 当前使用的模型名
  String get modelName;
  set modelName(String value);

  /// 对话补全：传入消息列表，返回模型生成的文本
  Future<Result<String>> chatCompletion(
      List<Map<String, String>> messages);

  /// 文本生成：传入单条提示词，返回模型生成的文本
  Future<Result<String>> generateText(String prompt);

  /// 健康检查：探测服务是否可达，返回是否健康
  Future<bool> healthCheck();

  /// 获取可用模型列表，默认返回空列表
  Future<List<String>> fetchModels() async => [];
}

// ============================================================================
// 内部工具：解析 OpenAI 格式响应
// ============================================================================

/// 从 OpenAI 兼容格式的响应体中提取 `choices[0].message.content`。
///
/// 当 [supportReasoning] 为 true 时，若 `content` 为空，会回退读取
/// `reasoning_content` 字段（用于兼容 DeepSeek 等返回推理内容的服务）。
String _extractOpenAIContent(
  Map<String, dynamic> data, {
  bool supportReasoning = false,
}) {
  final choices = data['choices'];
  if (choices is! List || choices.isEmpty) return '';
  final first = choices[0];
  if (first is! Map<String, dynamic>) return '';
  final message = first['message'];
  if (message is! Map<String, dynamic>) return '';

  final content = message['content'];
  if (content != null && content.toString().isNotEmpty) {
    return content.toString();
  }

  // content 为空时，按需回退到 reasoning_content（DeepSeek）
  if (supportReasoning) {
    final reasoning = message['reasoning_content'];
    if (reasoning != null) {
      return reasoning.toString();
    }
  }
  return '';
}

// ============================================================================
// PollinationsProvider —— 免密钥
// ============================================================================

/// Pollinations 提供方（免密钥）。
///
/// - 对话补全：POST `https://text.pollinations.ai/`，请求体为
///   `{"model": modelName, "messages": [...]}`，响应为纯文本。
/// - 文本生成：GET `https://text.pollinations.ai/{encodedPrompt}?model=openai`，
///   响应为纯文本。
/// - 健康检查：HEAD `https://text.pollinations.ai/`。
class PollinationsProvider implements AiProvider {
  @override
  final String name = 'Pollinations.ai';

  /// 免密钥，始终视为可用
  @override
  bool isAvailable = true;

  @override
  String modelName;

  /// Pollinations 文本接口基址
  static const String _baseUrl = 'https://text.pollinations.ai/';

  PollinationsProvider({this.modelName = 'openai'});

  @override
  Future<Result<String>> chatCompletion(
      List<Map<String, String>> messages) async {
    try {
      final body = jsonEncode({
        'model': modelName,
        'messages': messages,
      });
      final resp = await http.post(
        Uri.parse(_baseUrl),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );
      if (resp.statusCode != 200) {
        return Result.failure(Exception(
            'Pollinations 请求失败: ${resp.statusCode} ${resp.body}'));
      }
      // POST 返回纯文本
      return Result.success(resp.body);
    } catch (e) {
      return Result.failure(Exception('Pollinations 请求异常: $e'));
    }
  }

  @override
  Future<Result<String>> generateText(String prompt) async {
    try {
      // 对提示词进行 URL 编码后拼接到路径
      final encoded = Uri.encodeComponent(prompt);
      final url = '$_baseUrl$encoded?model=openai';
      final resp = await http.get(Uri.parse(url));
      if (resp.statusCode != 200) {
        return Result.failure(Exception(
            'Pollinations 请求失败: ${resp.statusCode} ${resp.body}'));
      }
      // GET 返回纯文本
      return Result.success(resp.body);
    } catch (e) {
      return Result.failure(Exception('Pollinations 请求异常: $e'));
    }
  }

  @override
  Future<bool> healthCheck() async {
    try {
      final resp = await http.head(Uri.parse(_baseUrl));
      // 5xx 视为不可用，其余（含 4xx）说明服务在线
      return resp.statusCode < 500;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<List<String>> fetchModels() async => [];
}

// ============================================================================
// CehpointProvider —— 免密钥，OpenAI 兼容
// ============================================================================

/// Cehpoint 提供方（免密钥，OpenAI 兼容）。
///
/// - 对话补全：POST `https://ai-api.cehpoint.co.in/v1/chat/completions`，
///   请求体为 `{"model": modelName, "max_tokens": 2000, "messages": [...]}`，
///   响应为 OpenAI 格式 JSON，取 `choices[0].message.content`。
/// - 默认模型：`gpt-4o-mini`。
class CehpointProvider implements AiProvider {
  @override
  final String name = 'Cehpoint AI';

  /// 免密钥，始终视为可用
  @override
  bool isAvailable = true;

  @override
  String modelName;

  /// Cehpoint OpenAI 兼容接口地址
  static const String _endpoint =
      'https://ai-api.cehpoint.co.in/v1/chat/completions';

  CehpointProvider({this.modelName = 'gpt-4o-mini'});

  @override
  Future<Result<String>> chatCompletion(
      List<Map<String, String>> messages) async {
    try {
      final body = jsonEncode({
        'model': modelName,
        'max_tokens': 2000,
        'messages': messages,
      });
      final resp = await http.post(
        Uri.parse(_endpoint),
        headers: {'Content-Type': 'application/json'},
        body: body,
      );
      if (resp.statusCode != 200) {
        return Result.failure(Exception(
            'Cehpoint 请求失败: ${resp.statusCode} ${resp.body}'));
      }
      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      // 解析 OpenAI 格式响应
      final content = _extractOpenAIContent(data);
      if (content.isEmpty) {
        return Result.failure(Exception('Cehpoint 响应中未找到有效内容'));
      }
      return Result.success(content);
    } catch (e) {
      return Result.failure(Exception('Cehpoint 请求异常: $e'));
    }
  }

  @override
  Future<Result<String>> generateText(String prompt) {
    // 包装成单条用户消息复用对话补全
    return chatCompletion([
      {'role': 'user', 'content': prompt},
    ]);
  }

  @override
  Future<bool> healthCheck() async {
    try {
      // 以最小请求探测服务可达性
      final resp = await http.post(
        Uri.parse(_endpoint),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'model': modelName,
          'max_tokens': 1,
          'messages': [
            {'role': 'user', 'content': 'hi'},
          ],
        }),
      );
      return resp.statusCode < 500;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<List<String>> fetchModels() async => [];
}

// ============================================================================
// PollinationsGetProvider —— 免密钥，GET 备用通道
// ============================================================================

/// Pollinations GET 方式 Provider（备用通道）。
///
/// - 对话补全：将多轮对话合并为单条 prompt，GET
///   `https://text.pollinations.ai/{encodedPrompt}?model=openai&nologo=true`
/// - 文本生成：GET 同上 URL
/// - 响应为纯文本
class PollinationsGetProvider implements AiProvider {
  @override
  final String name = 'Pollinations GET';

  @override
  bool isAvailable = true;

  @override
  String modelName;

  static const String _baseUrl = 'https://text.pollinations.ai/';

  PollinationsGetProvider({this.modelName = 'openai'});

  /// 将多轮对话合并为单条 prompt
  String _buildPromptFromMessages(List<Map<String, String>> messages) {
    final sb = StringBuffer();
    for (final msg in messages) {
      final role = msg['role'] ?? 'user';
      final content = msg['content'] ?? '';
      switch (role) {
        case 'system':
          sb.write('System: $content\n');
          break;
        case 'assistant':
          sb.write('Assistant: $content\n');
          break;
        default:
          sb.write('User: $content\n');
      }
    }
    sb.write('Assistant:');
    return sb.toString();
  }

  @override
  Future<Result<String>> chatCompletion(
      List<Map<String, String>> messages) async {
    try {
      final prompt = _buildPromptFromMessages(messages);
      final encoded = Uri.encodeComponent(prompt);
      final url = '$_baseUrl$encoded?model=$modelName&nologo=true';
      final resp = await http.get(Uri.parse(url));
      if (resp.statusCode != 200) {
        return Result.failure(
            Exception('Pollinations GET 请求失败: ${resp.statusCode}'));
      }
      final result = resp.body.trim();
      if (result.isEmpty) {
        return Result.failure(Exception('空响应'));
      }
      return Result.success(result);
    } catch (e) {
      return Result.failure(Exception('Pollinations GET 请求异常: $e'));
    }
  }

  @override
  Future<Result<String>> generateText(String prompt) async {
    try {
      final encoded = Uri.encodeComponent(prompt);
      final url = '$_baseUrl$encoded?model=$modelName&nologo=true';
      final resp = await http.get(Uri.parse(url));
      if (resp.statusCode != 200) {
        return Result.failure(
            Exception('Pollinations GET 请求失败: ${resp.statusCode}'));
      }
      final result = resp.body.trim();
      if (result.isEmpty) {
        return Result.failure(Exception('空响应'));
      }
      return Result.success(result);
    } catch (e) {
      return Result.failure(Exception('Pollinations GET 请求异常: $e'));
    }
  }

  @override
  Future<bool> healthCheck() async {
    try {
      final resp = await http.get(
        Uri.parse('${_baseUrl}hi?model=openai&nologo=true'),
      );
      return resp.statusCode < 500;
    } catch (_) {
      return false;
    }
  }

  @override
  Future<List<String>> fetchModels() async => [];
}

// ============================================================================
// OpenAICompatibleProvider —— 通用可配置
// ============================================================================

/// 通用 OpenAI 兼容提供方（可配置 baseUrl / apiKey / modelName）。
///
/// - 对话补全：POST 到 [baseUrl]，请求体为 `{"model": modelName, "messages": [...]}`；
///   当 [apiKey] 非空时附加 `Authorization: Bearer {apiKey}` 头。
/// - 响应解析：标准 OpenAI 格式 `choices[0].message.content`；并兼容 DeepSeek
///   的 `reasoning_content` 字段；若响应体包含 `error` 字段则判定为失败。
/// - [fetchModels]：GET `{baseUrl}/models`（将 `/chat/completions` 替换为 `/models`）。
class OpenAICompatibleProvider implements AiProvider {
  @override
  String name;

  /// 接口基址，用户可输入完整或部分 URL
  String baseUrl;

  /// API 密钥，可为空（部分自建服务无需鉴权）
  String apiKey;

  @override
  String modelName;

  /// 可用性标记（可被外部设置）
  @override
  bool isAvailable;

  /// 最近一次健康检查的详细消息（供 UI 展示）
  String lastHealthMessage = '';

  OpenAICompatibleProvider({
    this.baseUrl = '',
    this.apiKey = '',
    this.modelName = '',
    String? name,
    this.isAvailable = false,
  }) : name = name ?? 'OpenAI兼容';

  /// 规范化 chat completions 端点 URL
  ///
  /// 用户可能输入以下格式，统一补全为完整端点：
  /// - `https://api.deepseek.com` → `.../v1/chat/completions`
  /// - `https://api.deepseek.com/v1` → `.../v1/chat/completions`
  /// - `https://api.deepseek.com/v1/` → `.../v1/chat/completions`
  /// - `https://api.deepseek.com/v1/chat/completions` → 原样返回
  String get _chatEndpoint {
    if (baseUrl.isEmpty) return '';
    // 已包含 /chat/completions，直接返回
    if (baseUrl.contains('/chat/completions')) return baseUrl;
    // 去除末尾斜杠
    var url = baseUrl.endsWith('/')
        ? baseUrl.substring(0, baseUrl.length - 1)
        : baseUrl;
    // 如果已包含 /v1 或 /v2 等版本号路径，直接追加
    if (url.contains(RegExp(r'/v\d+$'))) {
      return '$url/chat/completions';
    }
    // 否则追加 /v1/chat/completions（OpenAI 约定）
    return '$url/v1/chat/completions';
  }

  /// 构造请求头：始终带 JSON 类型，apiKey 非空时附 Bearer 鉴权
  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (apiKey.isNotEmpty) 'Authorization': 'Bearer $apiKey',
      };

  @override
  Future<Result<String>> chatCompletion(
      List<Map<String, String>> messages) async {
    try {
      final endpoint = _chatEndpoint;
      if (endpoint.isEmpty) {
        return Result.failure(Exception('接口地址未配置'));
      }
      final body = jsonEncode({
        'model': modelName,
        'messages': messages,
      });
      final resp = await http.post(
        Uri.parse(endpoint),
        headers: _headers,
        body: body,
      ).timeout(const Duration(seconds: 60));
      if (resp.statusCode != 200) {
        return Result.failure(Exception(
            '请求失败: ${resp.statusCode} ${resp.body}'));
      }

      final data = jsonDecode(resp.body) as Map<String, dynamic>;

      // 处理错误字段：部分服务在 200 下也可能返回 error
      if (data['error'] != null) {
        final err = data['error'];
        final msg = err is Map<String, dynamic>
            ? (err['message'] ?? err.toString())
            : err.toString();
        return Result.failure(Exception('API 错误: $msg'));
      }

      // 解析内容，兼容 DeepSeek 的 reasoning_content
      final content =
          _extractOpenAIContent(data, supportReasoning: true);
      if (content.isEmpty) {
        return Result.failure(Exception('响应中未找到有效内容'));
      }
      return Result.success(content);
    } catch (e) {
      return Result.failure(Exception('请求异常: $e'));
    }
  }

  @override
  Future<Result<String>> generateText(String prompt) {
    // 包装成单条用户消息复用对话补全
    return chatCompletion([
      {'role': 'user', 'content': prompt},
    ]);
  }

  @override
  Future<bool> healthCheck() async {
    try {
      final endpoint = _chatEndpoint;
      if (endpoint.isEmpty) {
        lastHealthMessage = '接口地址未配置';
        return false;
      }
      // 使用实际 chat completion 请求探测，发送最简短的消息
      final body = jsonEncode({
        'model': modelName,
        'max_tokens': 1,
        'messages': [
          {'role': 'user', 'content': 'hi'}
        ],
      });
      final resp = await http.post(
        Uri.parse(endpoint),
        headers: _headers,
        body: body,
      ).timeout(const Duration(seconds: 15));

      final code = resp.statusCode;
      // 200 = 完全正常
      if (code == 200) {
        lastHealthMessage = '连接正常，模型可用';
        return true;
      }
      // 401/403 = 服务可达，但鉴权失败（API Key 错误）
      if (code == 401 || code == 403) {
        lastHealthMessage = '服务可达，但鉴权失败 (HTTP $code)，请检查 API Key';
        return true; // 服务本身是可达的
      }
      // 400 = 服务可达，但请求参数有误（如模型名错误）
      if (code == 400) {
        // 尝试提取错误信息
        String detail = '';
        try {
          final data = jsonDecode(resp.body);
          if (data is Map && data['error'] != null) {
            final err = data['error'];
            detail = err is Map ? (err['message']?.toString() ?? '') : err.toString();
          }
        } catch (_) {}
        lastHealthMessage = '服务可达，但请求被拒 (HTTP 400)${detail.isNotEmpty ? ': $detail' : ''}\n请检查模型名是否正确';
        return true; // 服务本身是可达的
      }
      // 429 = 限流，服务可达
      if (code == 429) {
        lastHealthMessage = '服务可达，但触发限流 (HTTP 429)，请稍后重试';
        return true;
      }
      // 404 = 端点不存在（URL 错误）
      if (code == 404) {
        lastHealthMessage = '端点不存在 (HTTP 404)，请检查接口地址是否正确';
        return false;
      }
      // 5xx = 服务端错误
      lastHealthMessage = '服务端错误 (HTTP $code)，请稍后重试';
      return false;
    } catch (e) {
      lastHealthMessage = '连接异常: $e';
      return false;
    }
  }

  @override
  Future<List<String>> fetchModels() async {
    try {
      // 将 /chat/completions 替换为 /models
      final modelsUrl = _modelsEndpoint();
      if (modelsUrl.isEmpty) return [];
      final resp = await http.get(
        Uri.parse(modelsUrl),
        headers: _headers,
      ).timeout(const Duration(seconds: 15));
      if (resp.statusCode != 200) return [];
      final data = jsonDecode(resp.body);
      // OpenAI 约定：{ "data": [ { "id": "..." }, ... ] }
      if (data is Map<String, dynamic>) {
        final list = data['data'];
        if (list is List) {
          return list
              .map((e) => (e is Map<String, dynamic>)
                  ? e['id']?.toString() ?? ''
                  : e.toString())
              .where((s) => s.isNotEmpty)
              .toList();
        }
      } else if (data is List) {
        // 个别服务直接返回数组
        return data
            .map((e) => (e is Map<String, dynamic>)
                ? e['id']?.toString() ?? ''
                : e.toString())
            .where((s) => s.isNotEmpty)
            .toList();
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  /// 由规范化端点推导 models 端点：将 `/chat/completions` 替换为 `/models`
  String _modelsEndpoint() {
    final endpoint = _chatEndpoint;
    if (endpoint.contains('/chat/completions')) {
      return endpoint.replaceAll('/chat/completions', '/models');
    }
    // 兜底
    return '${endpoint.endsWith('/') ? endpoint.substring(0, endpoint.length - 1) : endpoint}/models';
  }
}

// ============================================================================
// MultiAiClient —— 多 AI 提供方聚合客户端
// ============================================================================

/// 多 AI 提供方聚合客户端（抽象）。
///
/// 对应 Kotlin 版的 `MultiAiClient`，负责在多个 [AiProvider] 之间
/// 选择并分发请求，特别面向 Agent 场景（需要稳定可用的提供方）。
///
/// 具体实现可基于配置文件、运行时探测等策略选择默认提供方。
/// 本抽象仅定义接口契约，实现类需自行维护提供方列表与当前选中状态。
abstract class MultiAiClient extends ChangeNotifier {
  /// 所有已配置的提供方列表
  List<AiProvider> get allProviders;

  /// 支持 Agent 场景的提供方子集。
  ///
  /// Agent 场景通常需要较稳定的对话能力与工具调用支持，
  /// 此列表可由实现类按可用性/能力过滤后返回。
  List<AiProvider> get agentProviders;

  /// 当前选中的提供方名称
  String get currentProviderName;

  /// 对话补全：使用当前选中的提供方发送请求。
  ///
  /// [messages] 为 OpenAI 风格的消息列表（role/content）。
  /// 成功返回模型生成的文本，失败返回错误信息。
  Future<Result<String>> chatCompletion(
      List<Map<String, String>> messages);

  /// 确保当前选中一个支持 Agent 的提供方。
  ///
  /// 若当前提供方不在 [agentProviders] 中，则切换到第一个可用的
  /// Agent 提供方。返回最终选中的提供方名称，若没有任何可用
  /// Agent 提供方则返回 null。
  String? ensureAgentProvider();
}
