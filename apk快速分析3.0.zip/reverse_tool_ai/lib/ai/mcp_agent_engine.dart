import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'ai_provider.dart';
import 'tool_executor.dart';
import '../mcp/mcp_models.dart';

/// Agent 对话中的一条消息
class AgentMessage {
  /// 角色：`user` / `assistant` / `system`
  final String role;

  /// 消息内容
  final String content;

  /// 是否为错误消息
  final bool isError;

  /// 时间戳
  final DateTime timestamp;

  AgentMessage({
    required this.role,
    required this.content,
    this.isError = false,
    DateTime? timestamp,
  }) : timestamp = timestamp ?? DateTime.now();
}

/// 解析出的工具调用
class _ParsedToolCall {
  final String name;
  final Map<String, dynamic> arguments;
  const _ParsedToolCall(this.name, this.arguments);
}

/// MCP Agent 引擎
///
/// 从 Kotlin `McpAgentEngine` 移植而来。核心职责：
///
/// 1. 接收用户自然语言请求
/// 2. 调用 AI 决定需要调用哪些 MCP 工具
/// 3. 执行工具调用，并将结果回喂给 AI
/// 4. 循环迭代直至分析完成或达到最大迭代次数
/// 5. 对常见错误进行自动恢复
///
/// 引擎是一个 [ChangeNotifier]，UI 可监听其状态变化。
class McpAgentEngine extends ChangeNotifier {
  final MultiAiClient multiAiClient;
  final ToolExecutor mcpClient;

  /// 对话最大迭代次数
  static const int maxIterations = 60;

  /// 工具输出预览最大字符数
  static const int maxToolOutputPreview = 4096;

  /// AI 单次响应最大保留字符数（防止上下文爆炸）
  static const int maxAiResponseChars = 8000;

  List<AgentMessage> _messages = [];
  List<AgentMessage> get messages => _messages;

  bool _isProcessing = false;
  bool get isProcessing => _isProcessing;

  String _currentStep = '';
  String get currentStep => _currentStep;

  /// 发送给 AI 的对话历史（role/content）
  List<Map<String, String>> _conversationHistory = [];

  /// 进入循环前对工具列表做的快照，保证一次请求内工具描述稳定
  List<McpTool> _mcpToolsSnapshot = [];

  /// 用户是否请求取消
  bool _cancelled = false;

  /// 最近一次打开的 APK 路径（用于 WORKSPACE_NOT_FOUND 自动恢复）
  String _lastOpenedApk = '';

  /// 当前工作区 ID（用于会话恢复）
  String _currentWorkspaceId = '';

  /// 当前编辑会话 ID（用于 EDIT_SESSION 自动恢复）
  String _currentEditSessionId = '';

  McpAgentEngine(this.multiAiClient, this.mcpClient);

  // ===========================================================================
  // 公共 API
  // ===========================================================================

  /// 取消当前正在进行的任务
  void cancel() {
    if (!_isProcessing) return;
    _cancelled = true;
    _currentStep = '正在取消...';
    notifyListeners();
  }

  /// 清空所有消息与对话历史
  void clearMessages() {
    _messages = [];
    _conversationHistory = [];
    _currentStep = '';
    _currentWorkspaceId = '';
    _currentEditSessionId = '';
    notifyListeners();
  }

  /// 从指定消息重新发起请求
  ///
  /// 截断到 [messageIndex]（不包含该索引之后的消息），并返回被移除的最后一条
  /// 用户消息内容，便于 UI 直接调用 [processRequest] 重试。
  /// 若找不到可重试的用户消息，返回 null。
  String? retryFromMessage(int messageIndex) {
    if (messageIndex < 0 || messageIndex >= _messages.length) return null;

    // 找到从 messageIndex 开始往后的第一条用户消息
    String? userContent;
    for (int i = messageIndex; i < _messages.length; i++) {
      if (_messages[i].role == 'user') {
        userContent = _messages[i].content;
        break;
      }
    }
    if (userContent == null) return null;

    // 截断消息与历史
    _messages = _messages.sublist(0, messageIndex);
    _rebuildConversationHistoryFromMessages();
    notifyListeners();
    return userContent;
  }

  /// 处理用户请求
  ///
  /// 主循环：最多迭代 [maxIterations] 次。每次迭代：
  /// 1. 构建系统提示词（含工具描述）
  /// 2. 调用 AI 获取响应
  /// 3. 解析工具调用 JSON
  /// 4. 若无工具调用 -> 视为最终答复，结束
  /// 5. 若有工具调用 -> 执行并回喂结果，继续
  Future<void> processRequest(String userMessage,
      {String workDir = '/sdcard/'}) async {
    if (_isProcessing) {
      debugPrint('[McpAgentEngine] 已有任务进行中，忽略新请求');
      return;
    }

    _cancelled = false;
    _isProcessing = true;
    _currentStep = '准备中...';

    // 如果 workDir 指向具体文件（而非默认 /sdcard/），更新最近打开的 APK 路径
    if (workDir.isNotEmpty && workDir != '/sdcard/') {
      _lastOpenedApk = workDir;
    }

    // 记录用户消息（去掉系统注入的提示部分，只在对话历史中保留原文）
    final displayMessage = _stripSystemHint(userMessage);
    _messages = [..._messages, AgentMessage(role: 'user', content: displayMessage)];
    _conversationHistory = [
      ..._conversationHistory,
      {'role': 'user', 'content': userMessage}
    ];
    notifyListeners();

    try {
      // 确保使用支持 Agent 的提供方
      final providerName = multiAiClient.ensureAgentProvider();
      if (providerName == null) {
        _addAssistantMessage('当前没有可用的 Agent 提供方，请先在设置中配置 AI 提供方。',
            isError: true);
        return;
      }

      // 对工具列表做快照，保证一次请求内系统提示词稳定
      _mcpToolsSnapshot = List<McpTool>.from(mcpClient.tools);

      if (_mcpToolsSnapshot.isEmpty) {
        _addAssistantMessage(
            '当前没有可用的分析工具。请先选择并分析 APK 文件，然后重试。');
        return;
      }

      int consecutiveErrors = 0;
      int iteration = 0;

      while (iteration < maxIterations) {
        if (_cancelled) {
          _addSystemMessage('已取消任务。', isError: false);
          break;
        }

        iteration++;
        _currentStep = '思考中... (第 $iteration/$maxIterations 步)';
        notifyListeners();

        // 1. 构建消息列表（system + 历史）
        final systemPrompt = _buildSystemPrompt(workDir);
        final aiMessages = <Map<String, String>>[
          {'role': 'system', 'content': systemPrompt},
          ..._conversationHistory,
        ];

        // 2. 调用 AI
        final Result<String> aiResult;
        try {
          aiResult = await multiAiClient.chatCompletion(aiMessages);
        } catch (e) {
          _addAssistantMessage('AI 调用异常: $e', isError: true);
          _currentStep = 'AI 调用异常';
          notifyListeners();
          break;
        }

        if (aiResult.isFailure) {
          consecutiveErrors++;
          final err = aiResult.exceptionOrNull()?.toString() ?? '未知错误';
          _addSystemMessage('AI 调用失败 ($consecutiveErrors/3): $err',
              isError: true);

          if (consecutiveErrors >= 3) {
            _addAssistantMessage('AI 调用连续失败 3 次，已终止任务。错误: $err',
                isError: true);
            break;
          }
          // 注入错误提示后继续重试
          _conversationHistory.add({
            'role': 'user',
            'content': '上一次调用失败: $err\n请继续完成任务。'
          });
          continue;
        }
        consecutiveErrors = 0;

        var response = _filterPollinationsAd(aiResult.getOrNull() ?? '');
        if (response.isEmpty) {
          // 空响应，提示后继续
          _conversationHistory.add({
            'role': 'user',
            'content': '你的上一次回复为空，请继续。'
          });
          continue;
        }

        // 3. 判断是否为「思考/格式错误」的中间态
        if (_isThinkingOrFormatError(response)) {
          // 仅作为中间思考加入历史，继续循环让 AI 输出正式内容
          _conversationHistory
              .add({'role': 'assistant', 'content': response});
          _conversationHistory.add({
            'role': 'user',
            'content': '请直接输出工具调用 JSON，或给出最终结论，不要只描述思考过程。'
          });
          continue;
        }

        // 4. 解析工具调用
        final parsed = _parseToolCall(response);

        if (parsed == null) {
          // 无工具调用 -> 最终答复
          _addAssistantMessage(response);
          _currentStep = '完成';
          notifyListeners();
          break;
        }

        // 5. 执行工具调用
        final toolName = parsed.name;
        final args = parsed.arguments;

        // 校验工具是否存在
        if (!mcpClient.tools.any((t) => t.name == toolName)) {
          _addAssistantMessage(
              '调用了不存在的工具: `$toolName`。\n可用工具: ${mcpClient.tools.map((t) => t.name).join(", ")}',
              isError: true);
          _conversationHistory.add({
            'role': 'user',
            'content': '工具 `$toolName` 不存在，请使用上述可用工具之一。'
          });
          continue;
        }

        _currentStep = '调用工具: $toolName';
        _messages = [
          ..._messages,
          AgentMessage(
              role: 'assistant',
              content:
                  '调用工具: $toolName\n参数: ${_formatArguments(args)}')
        ];
        // 将 AI 响应加入历史（保留其原始推理，便于后续上下文）
        _conversationHistory
            .add({'role': 'assistant', 'content': response});
        notifyListeners();

        // 执行工具调用
        // McpClient.callTool 返回 Result<McpToolCallResult>
        final toolCallResult = await mcpClient.callTool(toolName, args);

        // 统一转换为内部使用的工具结果结构
        String resultText;
        bool isToolError;
        List<McpNextAction> nextActions = const [];

        if (toolCallResult.isSuccess) {
          final callResult = toolCallResult.getOrNull()!;
          resultText = _extractResultText(callResult);
          isToolError = callResult.isError;
          nextActions = callResult.nextActions ?? const [];
        } else {
          // 调用本身失败（网络/协议错误）
          final err = toolCallResult.exceptionOrNull()?.toString() ?? '未知错误';
          resultText = '工具调用失败: $err';
          isToolError = true;
        }

        // 捕获 workspaceId / editSessionId / 最近 APK 路径
        _captureSessionIds(resultText, toolName, args);

        // 处理工具结果
        bool recovered = false;

        if (isToolError) {
          // 尝试自动恢复
          final recovery = await _tryAutoRecover(
              toolName, resultText, args, workDir);
          if (recovery != null) {
            resultText = recovery;
            recovered = true;
          } else {
            // 注入错误修复提示
            resultText = _addErrorHints(toolName, resultText);
          }
        }

        // 截断过长输出
        final truncated = _truncateToolOutput(resultText);

        // 添加到消息与历史
        final prefix = isToolError
            ? (recovered ? '工具结果(已自动恢复)' : '工具错误')
            : '工具结果';
        _messages = [
          ..._messages,
          AgentMessage(
              role: 'system',
              content: '[$prefix] $toolName:\n$truncated',
              isError: isToolError && !recovered)
        ];

        // 将 nextActions 转为字符串列表
        final nextActionStrings = _nextActionsToStrings(nextActions);
        // 若 nextActions 为空，尝试从文本中解析
        final allNextActions = nextActionStrings.isNotEmpty
            ? nextActionStrings
            : _extractNextActionsFromText(resultText);

        // 回喂给 AI
        final feedback = _buildToolFeedback(
            toolName, truncated, isToolError, recovered, allNextActions);
        _conversationHistory
            .add({'role': 'user', 'content': feedback});

        notifyListeners();

        // 自动跟随 nextActions（若 nextActions 恰好是可用工具名，则提示 AI 优先调用）
        // 这里不直接执行，而是通过 feedback 引导 AI 在下一轮调用，
        // 避免参数推断错误导致的连锁失败。
      }

      // 达到最大迭代仍未给出最终结论 -> 请求一次总结
      if (!_cancelled && iteration >= maxIterations) {
        _currentStep = '生成总结...';
        notifyListeners();
        _conversationHistory.add({
          'role': 'user',
          'content': '已达到最大迭代次数 ($maxIterations)，请根据已有工具结果给出最终分析结论。'
        });
        final summaryResult = await multiAiClient.chatCompletion(
          [
            {'role': 'system', 'content': _buildSystemPrompt(workDir)},
            ..._conversationHistory,
          ],
        );
        if (summaryResult.isSuccess) {
          final summary = _filterPollinationsAd(summaryResult.getOrNull() ?? '');
          if (summary.isNotEmpty &&
              _parseToolCall(summary) == null &&
              !_isThinkingOrFormatError(summary)) {
            _addAssistantMessage(summary);
          } else {
            _addAssistantMessage('已达到最大迭代次数，未能生成最终结论。可在对话中继续追问。');
          }
        }
      }
    } catch (e) {
      _addAssistantMessage('分析过程中发生异常: $e', isError: true);
    } finally {
      _isProcessing = false;
      _currentStep = '';
      notifyListeners();
    }
  }

  // ===========================================================================
  // 工具结果文本提取
  // ===========================================================================

  /// 从 [McpToolCallResult] 中提取所有文本内容并拼接。
  ///
  /// MCP 工具结果可能包含多个 content 块（text/image 等），
  /// 此处仅提取 text 类型的内容，用换行符连接。
  String _extractResultText(McpToolCallResult result) {
    final texts = <String>[];
    for (final c in result.content) {
      if (c.type == 'text' && c.text != null && c.text!.isNotEmpty) {
        texts.add(c.text!);
      } else if (c.text != null && c.text!.isNotEmpty) {
        // 非 text 类型但带文本也一并收集
        texts.add(c.text!);
      }
    }
    return texts.join('\n');
  }

  /// 从工具结果文本中提取 workspaceId。
  ///
  /// 支持以下形式：
  /// - JSON: `"workspaceId":"xxx"` 或 `"workspace_id":"xxx"`
  /// - 自然语言: `workspaceId: xxx` 或 `工作区ID: xxx`
  String? _extractWorkspaceId(String text) {
    // JSON 风格
    final jsonRegex =
        RegExp(r'"?workspace[_-]?[iI]d"?\s*:\s*"([^"]+)"');
    final jsonMatch = jsonRegex.firstMatch(text);
    if (jsonMatch != null) {
      final v = jsonMatch.group(1);
      if (v != null && v.isNotEmpty) return v;
    }
    // 键值对风格
    final kvRegex =
        RegExp(r'workspace[_-]?[iI]d\s*[:=]\s*"?([a-zA-Z0-9_\-/.]+)"?',
            caseSensitive: false);
    final kvMatch = kvRegex.firstMatch(text);
    if (kvMatch != null) {
      final v = kvMatch.group(1);
      if (v != null && v.isNotEmpty) return v;
    }
    // 中文「工作区ID」
    final cnRegex = RegExp(r'工作区\s*[Ii][Dd]\s*[:：]\s*"?([a-zA-Z0-9_\-/.]+)"?');
    final cnMatch = cnRegex.firstMatch(text);
    if (cnMatch != null) {
      final v = cnMatch.group(1);
      if (v != null && v.isNotEmpty) return v;
    }
    return null;
  }

  /// 从工具结果文本中提取 editSessionId。
  ///
  /// 支持以下形式：
  /// - JSON: `"editSessionId":"xxx"` 或 `"sessionId":"xxx"`
  /// - 自然语言: `editSessionId: xxx`
  String? _extractEditSessionId(String text) {
    final patterns = <RegExp>[
      RegExp(r'"?edit[_-]?[sS]ession[_-]?[iI]d"?\s*:\s*"([^"]+)"'),
      RegExp(r'"?session[_-]?[iI]d"?\s*:\s*"([^"]+)"'),
      RegExp(r'edit[_-]?[sS]ession[_-]?[iI]d\s*[:=]\s*"?([a-zA-Z0-9_\-/.]+)"?',
          caseSensitive: false),
      RegExp(r'session[_-]?[iI]d\s*[:=]\s*"?([a-zA-Z0-9_\-/.]+)"?',
          caseSensitive: false),
    ];
    for (final regex in patterns) {
      final match = regex.firstMatch(text);
      if (match != null) {
        final v = match.group(1);
        if (v != null && v.isNotEmpty) return v;
      }
    }
    return null;
  }

  /// 将 [List<McpNextAction>] 转换为可读的字符串列表。
  ///
  /// 优先使用 description，其次使用「tool: purpose」格式。
  List<String> _nextActionsToStrings(List<McpNextAction>? actions) {
    if (actions == null || actions.isEmpty) return const [];
    return actions.map((a) {
      if (a.description != null && a.description!.trim().isNotEmpty) {
        return a.description!.trim();
      }
      if (a.purpose.isNotEmpty) {
        return '${a.tool}: ${a.purpose}';
      }
      return a.tool;
    }).toList();
  }

  // ===========================================================================
  // 系统提示词
  // ===========================================================================

  /// 构建系统提示词
  ///
  /// 包含：
  /// - 角色定位
  /// - 可用工具描述与参数
  /// - MT Manager 工作流指南（若检测到 mt_apk_ 工具）
  /// - JSON 输出格式规则
  /// - 参数使用规则
  String _buildSystemPrompt(String workDir) {
    final buf = StringBuffer();

    buf.writeln('你是一个专业的 Android 逆向分析智能助手。');
    buf.writeln('你可以通过调用工具来获取应用已分析的逆向数据（包名、权限、SDK、签名、组件、安全报告等），');
    buf.writeln('然后基于这些数据给出专业的分析结论和建议。');
    buf.writeln('用户会用自然语言描述需求，你需要将其分解为具体的工具调用步骤。');
    buf.writeln();
    buf.writeln('重要提示：工具名称以 local_ 开头的是本地工具，它们直接读取应用已分析的参数，');
    buf.writeln('无需重新解析 APK。请优先调用这些工具获取数据，再给出分析结论。');
    buf.writeln();

    // 工具列表
    buf.writeln('## 可用工具');
    buf.writeln();
    for (final tool in _mcpToolsSnapshot) {
      buf.writeln('### ${tool.name}');
      final desc = (tool.description ?? '').trim();
      if (desc.isNotEmpty) {
        buf.writeln(desc);
      }
      final props = tool.inputSchemaProperties ?? const <String, dynamic>{};
      final required = tool.inputSchemaRequired ?? const <String>[];
      if (props.isNotEmpty) {
        buf.writeln('参数:');
        for (final entry in props.entries) {
          final pName = entry.key;
          final pDef = entry.value;
          final type = (pDef is Map<String, dynamic>)
              ? (pDef['type']?.toString() ?? 'any')
              : 'any';
          final pDesc = (pDef is Map<String, dynamic>)
              ? (pDef['description']?.toString() ?? '')
              : '';
          final isReq = required.contains(pName);
          final enumVals = (pDef is Map<String, dynamic>)
              ? pDef['enum']
              : null;
          final enumStr = (enumVals is List && enumVals.isNotEmpty)
              ? '，可选值: ${enumVals.map((e) => e.toString()).join(" | ")}'
              : '';
          buf.writeln(
              '  - $pName ($type${isReq ? ", 必填" : ", 可选"}$enumStr): $pDesc');
        }
      }
      buf.writeln();
    }

    // MT Manager 工作流指南
    final hasMtTools =
        _mcpToolsSnapshot.any((t) => t.name.startsWith('mt_apk_'));
    if (hasMtTools) {
      buf.writeln('## MT Manager APK 分析工作流指南');
      buf.writeln(_mtApkWorkflowGuide);
      buf.writeln();
    }

    // 当前会话状态
    buf.writeln('## 当前会话状态');
    if (workDir.isNotEmpty && workDir != '/sdcard/') {
      buf.writeln('- 已加载文件: $workDir');
      buf.writeln('- 数据状态: 应用已分析完成，local_ 工具可直接返回数据');
    } else {
      buf.writeln('- 工作目录: $workDir');
    }
    if (_currentWorkspaceId.isNotEmpty) {
      buf.writeln('- 当前 workspaceId: $_currentWorkspaceId');
    }
    if (_lastOpenedApk.isNotEmpty) {
      buf.writeln('- 最近打开的 APK: $_lastOpenedApk');
    }
    if (_currentEditSessionId.isNotEmpty) {
      buf.writeln('- 当前 editSessionId: $_currentEditSessionId');
    }
    buf.writeln();
    buf.writeln('重要：当用户说"这个APK"或"这个应用"时，说明文件已经打开并分析完毕。');
    buf.writeln('请直接调用 local_get_apk_info / local_get_permissions / local_get_components 等工具获取数据，');
    buf.writeln('不要要求用户提供文件路径或重新打开文件。');
    buf.writeln();

    // JSON 输出规则
    buf.writeln('## 输出规则');
    buf.writeln();
    buf.writeln('1. 当需要调用工具时，**只**输出如下 JSON（不要输出任何额外文字、解释或 markdown）：');
    buf.writeln('{"tool":"工具名","arguments":{"参数名":"参数值"}}');
    buf.writeln();
    buf.writeln('2. 当分析完成、无需再调用工具时，用自然语言给出最终结论。');
    buf.writeln('3. 一次只调用一个工具，等待结果后再决定下一步。');
    buf.writeln('4. 参数必须是合法 JSON：字符串用双引号，布尔为 true/false，数字不需要引号。');
    buf.writeln('5. 不要把 JSON 包裹在 ```json 代码块中，直接输出裸 JSON。');
    buf.writeln('6. 若上一轮工具返回错误，请根据错误信息调整参数后重试，或换用其他工具。');
    buf.writeln();

    // 参数使用规则
    buf.writeln('## 参数使用规则');
    buf.writeln('- 路径参数：使用绝对路径，或相对工作目录的路径。');
    buf.writeln('- 关键词搜索：尽量使用精确的类名/方法名，避免过于宽泛的关键词。');
    buf.writeln('- 若返回 TEXT_MATCH_AMBIGUOUS（匹配歧义），请补充更精确的匹配条件（包名、完整方法签名等）。');
    buf.writeln('- 若返回 WORKSPACE_NOT_FOUND（工作区未找到），请先调用打开/初始化工作区的工具。');
    buf.writeln('- 若返回 EDIT_SESSION 相关错误，请重新创建编辑会话后再操作。');
    buf.writeln('- workspaceId / editSessionId 等会话标识请沿用之前工具返回的值，不要臆造。');

    return buf.toString();
  }

  /// MT Manager (mt_apk_*) 工具的标准分析工作流
  static const String _mtApkWorkflowGuide = '''
典型 APK 分析与修改流程：

1. 打开 APK：调用 `mt_apk_open`（参数：apk 路径），获取 workspaceId。
2. 浏览结构：调用 `mt_apk_list_files` 查看包内文件树，定位目标 dex/资源。
3. 查看清单：调用 `mt_apk_get_manifest` 获取 AndroidManifest 信息（包名、组件、权限）。
4. 搜索代码：调用 `mt_apk_search_dex` 在 DEX 中按类名/方法名/字符串搜索。
5. 反汇编：调用 `mt_apk_disassemble_method` 反汇编目标方法的 smali 指令。
6. 编辑 DEX：
   - 先调用 `mt_apk_create_edit_session` 创建编辑会话，拿到 editSessionId。
   - 再调用 `mt_apk_edit_method` 修改方法 smali。
7. 保存：调用 `mt_apk_save_workspace` 保存修改。
8. 导出：调用 `mt_apk_export` 导出修改后的 APK。

注意：
- 编辑类操作必须先创建 editSession，并复用返回的 sessionId。
- 修改后务必 save，否则 export 的仍是旧文件。
- 反汇编结果可能较长，请聚焦关键方法，避免无意义地全量反汇编。
''';

  // ===========================================================================
  // 工具调用解析
  // ===========================================================================

  /// 解析 AI 响应中的工具调用
  ///
  /// 支持以下格式：
  /// - `{"tool":"x","arguments":{...}}`
  /// - `{"name":"x","arguments":{...}}`
  /// - `{"tool_calls":[{"name":"x","arguments":{...}}]}`
  /// - `{"tool_calls":[{"function":{"name":"x","arguments":{...}}}]}`
  /// - 上述 JSON 被包裹在 markdown 代码块或混在自然语言中
  /// - `arguments` 可以是对象，也可以是 JSON 字符串
  _ParsedToolCall? _parseToolCall(String response) {
    var text = response.trim();
    if (text.isEmpty) return null;

    // 1. 去除 markdown 代码块包裹
    text = _stripCodeFences(text).trim();

    // 2. 尝试直接整体解析
    var decoded = _tryDecodeJson(text);
    if (decoded == null) {
      // 3. 从文本中抽取第一个完整 JSON 对象
      final extracted = _extractFirstJsonObject(text);
      if (extracted == null) return null;
      decoded = _tryDecodeJson(extracted);
      if (decoded == null) return null;
    }

    if (decoded is! Map) return null;
    final map = Map<String, dynamic>.from(decoded);

    // 格式 A: {"tool":"x","arguments":{...}}
    if (map.containsKey('tool')) {
      final name = map['tool']?.toString();
      if (name != null && name.isNotEmpty) {
        return _ParsedToolCall(name, _normalizeArguments(map['arguments']));
      }
    }

    // 格式 B: {"name":"x","arguments":{...}}
    if (map.containsKey('name') && !map.containsKey('tool')) {
      final name = map['name']?.toString();
      if (name != null && name.isNotEmpty) {
        return _ParsedToolCall(name, _normalizeArguments(map['arguments']));
      }
    }

    // 格式 C: {"tool_calls":[...]}
    if (map.containsKey('tool_calls')) {
      final calls = map['tool_calls'];
      if (calls is List && calls.isNotEmpty) {
        final first = calls.first;
        if (first is Map) {
          final m = Map<String, dynamic>.from(first);
          // C1: {"name":...,"arguments":...}
          if (m.containsKey('name')) {
            final name = m['name']?.toString();
            if (name != null && name.isNotEmpty) {
              return _ParsedToolCall(
                  name, _normalizeArguments(m['arguments']));
            }
          }
          // C2: {"function":{"name":...,"arguments":...}}  (OpenAI 风格)
          if (m.containsKey('function') && m['function'] is Map) {
            final fn = Map<String, dynamic>.from(m['function'] as Map);
            final name = fn['name']?.toString();
            if (name != null && name.isNotEmpty) {
              return _ParsedToolCall(
                  name, _normalizeArguments(fn['arguments']));
            }
          }
          // C3: {"tool":...,"arguments":...}
          if (m.containsKey('tool')) {
            final name = m['tool']?.toString();
            if (name != null && name.isNotEmpty) {
              return _ParsedToolCall(
                  name, _normalizeArguments(m['arguments']));
            }
          }
        }
      }
    }

    // 格式 D: 顶层 function_call
    if (map.containsKey('function_call') && map['function_call'] is Map) {
      final fc = Map<String, dynamic>.from(map['function_call'] as Map);
      final name = fc['name']?.toString();
      if (name != null && name.isNotEmpty) {
        return _ParsedToolCall(name, _normalizeArguments(fc['arguments']));
      }
    }

    return null;
  }

  /// 去除 markdown 代码围栏（```json ... ``` 或 ``` ... ```）
  String _stripCodeFences(String text) {
    final t = text.trim();
    final fenceRegex = RegExp(r'^```(?:json|JSON)?\s*\n?([\s\S]*?)\n?```\s*$');
    final m = fenceRegex.firstMatch(t);
    if (m != null) {
      return m.group(1) ?? t;
    }
    // 中间被围栏包裹的情况，只保留围栏内内容
    if (t.contains('```')) {
      final innerRegex = RegExp(r'```(?:json|JSON)?\s*\n?([\s\S]*?)\n?```');
      final m2 = innerRegex.firstMatch(t);
      if (m2 != null) {
        return m2.group(1) ?? t;
      }
    }
    return t;
  }

  /// 尝试 JSON 解码，失败返回 null
  dynamic _tryDecodeJson(String text) {
    try {
      return jsonDecode(text);
    } catch (_) {
      return null;
    }
  }

  /// 从文本中抽取第一个完整 JSON 对象（按花括号配对，注意字符串转义）
  String? _extractFirstJsonObject(String text) {
    final start = text.indexOf('{');
    if (start < 0) return null;

    int depth = 0;
    bool inString = false;
    bool escape = false;
    for (int i = start; i < text.length; i++) {
      final ch = text[i];
      if (inString) {
        if (escape) {
          escape = false;
        } else if (ch == r'\') {
          escape = true;
        } else if (ch == '"') {
          inString = false;
        }
      } else {
        if (ch == '"') {
          inString = true;
        } else if (ch == '{') {
          depth++;
        } else if (ch == '}') {
          depth--;
          if (depth == 0) {
            return text.substring(start, i + 1);
          }
        }
      }
    }
    return null;
  }

  /// 将 arguments 规范化为 Map
  ///
  /// 支持对象、JSON 字符串、null 三种情况。
  Map<String, dynamic> _normalizeArguments(dynamic args) {
    if (args == null) return const {};
    if (args is Map) {
      return args.map((k, v) => MapEntry(k.toString(), v));
    }
    if (args is String) {
      final s = args.trim();
      if (s.isEmpty) return const {};
      // 字符串可能是 JSON
      final decoded = _tryDecodeJson(s);
      if (decoded is Map) {
        return decoded.map((k, v) => MapEntry(k.toString(), v));
      }
      // 也可能是 "key=value" 形式，尽力解析
      return const {};
    }
    return const {};
  }

  // ===========================================================================
  // 思考/格式错误检测
  // ===========================================================================

  /// 判断 AI 响应是否为「中间思考」或「格式错误」
  ///
  /// 返回 true 表示该响应既不是合法工具调用，也不是最终答复，
  /// 应加入历史并提示 AI 重新输出，而不是当作最终结论。
  bool _isThinkingOrFormatError(String response) {
    final text = response.trim();
    if (text.isEmpty) return true;

    // 去除 think / thinking 标签内容
    var stripped = text;
    stripped = stripped
        .replaceAll(
            RegExp(r'<think(?:ing)?>[\s\S]*?</think(?:ing)?>', caseSensitive: false),
            '')
        .trim();
    // 未闭合的 <think> 开始标签（仅思考没有结论）
    stripped = stripped
        .replaceAll(RegExp(r'<think(?:ing)?>[\s\S]*$', caseSensitive: false),
            '')
        .trim();

    if (stripped.isEmpty) return true;

    // 若去掉思考后能解析出工具调用，则不算思考态
    if (_parseToolCall(stripped) != null) return false;

    // 若去掉思考后是较长的实质内容（>120 字符），视为最终答复
    if (stripped.length > 120) return false;

    // 短文本：检测是否仅为「过渡性思考」措辞
    final thinkingPatterns = <RegExp>[
      RegExp(r'^我(需要|先|来|将|会|应该|打算)', caseSensitive: false),
      RegExp(r'^让我', caseSensitive: false),
      RegExp(r'^接下来', caseSensitive: false),
      RegExp(r'^首先', caseSensitive: false),
      RegExp(r'^然后', caseSensitive: false),
      RegExp(r'^好的[,，。！]?\s*', caseSensitive: false),
      RegExp(r'^分析一下', caseSensitive: false),
      RegExp(r'^步骤\d', caseSensitive: false),
      RegExp(r'^\d+[.、]\s*', caseSensitive: false),
    ];
    for (final p in thinkingPatterns) {
      if (p.hasMatch(stripped)) return true;
    }

    return false;
  }

  // ===========================================================================
  // 工具输出处理
  // ===========================================================================

  /// 截断过长的工具输出，保留前 [maxToolOutputPreview] 字符预览
  String _truncateToolOutput(String output) {
    if (output.length <= maxToolOutputPreview) return output;
    final preview = output.substring(0, maxToolOutputPreview);
    return '$preview\n\n... [输出已截断，原始长度 ${output.length} 字符，'
        '仅显示前 $maxToolOutputPreview 字符预览]';
  }

  /// 从工具结果文本中解析 nextActions
  ///
  /// 支持两种形式：
  /// - JSON 字段：`"nextActions": ["action1","action2"]`
  /// - 自然语言：`建议下一步：xxx`
  List<String> _extractNextActionsFromText(String text) {
    final actions = <String>{};

    // JSON 数组形式
    final regex = RegExp(r'"nextActions"\s*:\s*\[([^\]]*)\]',
        caseSensitive: false);
    for (final match in regex.allMatches(text)) {
      final arrStr = match.group(1) ?? '';
      final itemRegex = RegExp(r'"((?:[^"\\]|\\.)*)"');
      for (final m in itemRegex.allMatches(arrStr)) {
        final action = m.group(1);
        if (action != null && action.trim().isNotEmpty) {
          actions.add(action.trim());
        }
      }
    }

    // 自然语言「建议下一步」
    final suggestRegex =
        RegExp(r'建议下一步[：:]\s*(.+)', caseSensitive: false);
    for (final match in suggestRegex.allMatches(text)) {
      final suggestion = match.group(1)?.trim();
      if (suggestion != null && suggestion.isNotEmpty) {
        actions.add(suggestion);
      }
    }

    return actions.toList();
  }

  // ===========================================================================
  // Pollinations 广告过滤
  // ===========================================================================

  /// 移除 Pollinations.ai 免费接口在响应末尾附加的广告/水印
  String _filterPollinationsAd(String response) {
    if (response.isEmpty) return response;
    var result = response;

    const markers = [
      '[Note: ',
      '[Generated with Pollinations',
      'https://pollinations.ai',
      '[pollinations.ai]',
      'pollinations.ai',
    ];
    for (final ad in markers) {
      final idx = result.indexOf(ad);
      if (idx >= 0) {
        result = result.substring(0, idx);
      }
    }

    // 移除尾部 "powered by ..." 之类
    result = result
        .replaceAll(
            RegExp(r'\n*powered\s+by\s+pollinations\.ai.*$', caseSensitive: false),
            '')
        .trim();

    return result;
  }

  /// 从用户消息中剥离系统注入的提示部分
  ///
  /// AiChatPanel 会在用户消息末尾追加 `[系统提示: ...]` 来引导 AI，
  /// 这部分对用户不可见，需要在显示时剥离。
  String _stripSystemHint(String message) {
    final idx = message.indexOf('\n\n[系统提示:');
    if (idx >= 0) {
      return message.substring(0, idx).trim();
    }
    return message;
  }

  // ===========================================================================
  // 会话 ID 捕获与自动恢复
  // ===========================================================================

  /// 从工具结果文本中捕获 workspaceId / editSessionId / 最近 APK 路径。
  ///
  /// 由于 [McpToolCallResult] 本身不持有这些字段，需要从文本中解析。
  void _captureSessionIds(
      String resultText, String toolName, Map<String, dynamic> args) {
    final wsId = _extractWorkspaceId(resultText);
    if (wsId != null && wsId.isNotEmpty) {
      _currentWorkspaceId = wsId;
    }

    final editId = _extractEditSessionId(resultText);
    if (editId != null && editId.isNotEmpty) {
      _currentEditSessionId = editId;
    }

    // 打开类工具：记录最近打开的 APK 路径
    if (toolName.contains('open') || toolName.contains('apk_open')) {
      final path = args['path']?.toString() ??
          args['apkPath']?.toString() ??
          args['apk']?.toString();
      if (path != null && path.isNotEmpty) {
        _lastOpenedApk = path;
      }
    }
  }

  /// 尝试对常见错误进行自动恢复
  ///
  /// [errorText] 为工具返回的错误文本。
  /// 返回非空字符串表示恢复成功（其内容为恢复操作的结果文本）；
  /// 返回 null 表示无法自动恢复，调用方应走错误提示分支。
  Future<String?> _tryAutoRecover(
    String toolName,
    String errorText,
    Map<String, dynamic> originalArgs,
    String workDir,
  ) async {
    final upper = errorText.toUpperCase();

    // ----- WORKSPACE_NOT_FOUND -----
    if (upper.contains('WORKSPACE_NOT_FOUND') ||
        upper.contains('WORKSPACE NOT FOUND') ||
        upper.contains('NO_WORKSPACE') ||
        _containsAny(errorText, ['未打开', '没有打开', '请先打开', '工作区不存在', '工作空间不存在'])) {
      return _recoverWorkspace(originalArgs, workDir);
    }

    // ----- EDIT_SESSION 相关错误 -----
    if (upper.contains('EDIT_SESSION') ||
        upper.contains('SESSION_NOT_FOUND') ||
        upper.contains('SESSION_EXPIRED') ||
        upper.contains('SESSION NOT FOUND') ||
        _containsAny(errorText, ['编辑会话', '会话不存在', '会话已过期', '会话失效'])) {
      return _recoverEditSession(originalArgs);
    }

    // ----- TEXT_MATCH_AMBIGUOUS：无法自动恢复，交由 AI 处理 -----
    if (upper.contains('TEXT_MATCH_AMBIGUOUS') ||
        upper.contains('AMBIGUOUS') ||
        _containsAny(errorText, ['匹配歧义', '多个匹配', '匹配到多个'])) {
      // 返回 null，由 _addErrorHints 注入更精确匹配的提示
      return null;
    }

    // ----- 工具未找到：无法自动恢复 -----
    return null;
  }

  /// 恢复工作区：重新打开最近一次的 APK
  Future<String?> _recoverWorkspace(
      Map<String, dynamic> originalArgs, String workDir) async {
    final openTool = _findToolByKeywords(['mt_apk_open', 'open_apk', 'open', 'apk_open']);
    if (openTool == null) return null;

    String? apkPath = _lastOpenedApk.isNotEmpty ? _lastOpenedApk : null;
    if (apkPath == null || apkPath.isEmpty) {
      // 从原参数中找路径
      apkPath = originalArgs['path']?.toString() ??
          originalArgs['apkPath']?.toString() ??
          originalArgs['apk']?.toString();
    }
    if (apkPath == null || apkPath.isEmpty) return null;

    try {
      final result = await mcpClient.callTool(openTool.name, {'path': apkPath});
      if (result.isSuccess) {
        final callResult = result.getOrNull()!;
        final text = _extractResultText(callResult);
        if (!callResult.isError) {
          final wsId = _extractWorkspaceId(text);
          if (wsId != null && wsId.isNotEmpty) {
            _currentWorkspaceId = wsId;
          }
          _lastOpenedApk = apkPath;
          return '已自动恢复工作区（重新打开 $apkPath）。\n$text';
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 恢复编辑会话：重新创建 edit session
  Future<String?> _recoverEditSession(Map<String, dynamic> originalArgs) async {
    final createTool = _findToolByKeywords(
        ['mt_apk_create_edit_session', 'create_edit_session', 'create_session']);
    if (createTool == null) return null;

    final args = <String, dynamic>{};
    if (_currentWorkspaceId.isNotEmpty) {
      args['workspaceId'] = _currentWorkspaceId;
    }
    // 透传可能的 dexPath
    final dexPath = originalArgs['dexPath']?.toString() ??
        originalArgs['dex']?.toString();
    if (dexPath != null) args['dexPath'] = dexPath;

    try {
      final result = await mcpClient.callTool(createTool.name, args);
      if (result.isSuccess) {
        final callResult = result.getOrNull()!;
        final text = _extractResultText(callResult);
        if (!callResult.isError) {
          final editId = _extractEditSessionId(text);
          if (editId != null && editId.isNotEmpty) {
            _currentEditSessionId = editId;
          }
          return '已自动恢复编辑会话。\n$text';
        }
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  /// 根据工具名关键词查找工具
  McpTool? _findToolByKeywords(List<String> keywords) {
    for (final kw in keywords) {
      for (final t in mcpClient.tools) {
        if (t.name == kw || t.name.contains(kw)) return t;
      }
    }
    return null;
  }

  /// 为错误内容追加修复提示
  String _addErrorHints(String toolName, String errorText) {
    final upper = errorText.toUpperCase();
    final hints = <String>[];

    if (upper.contains('TEXT_MATCH_AMBIGUOUS') ||
        _containsAny(errorText, ['匹配歧义', '多个匹配'])) {
      hints.add('提示：匹配到多个结果。请补充更精确的匹配条件，如完整类名、方法签名、包名等。');
    }
    if (upper.contains('WORKSPACE_NOT_FOUND') ||
        _containsAny(errorText, ['工作区不存在', '未打开'])) {
      hints.add('提示：工作区未初始化。请先调用打开 APK 的工具创建工作区。');
    }
    if (upper.contains('TEXT_NOT_FOUND') ||
        _containsAny(errorText, ['未找到', '不存在', '没有找到'])) {
      hints.add('提示：未找到目标。请确认类名/方法名/字符串拼写，或尝试更宽泛的关键词。');
    }
    if (upper.contains('INVALID_ARGUMENT') ||
        upper.contains('INVALID_PARAM') ||
        _containsAny(errorText, ['参数无效', '参数错误'])) {
      hints.add('提示：参数无效。请检查参数类型与取值是否符合工具定义。');
    }
    if (upper.contains('TIMEOUT') || _containsAny(errorText, ['超时'])) {
      hints.add('提示：操作超时。可尝试缩小分析范围后重试。');
    }
    if (upper.contains('PERMISSION_DENIED') ||
        _containsAny(errorText, ['权限不足', '拒绝访问'])) {
      hints.add('提示：权限不足。请确认文件可读/可写，或检查路径是否正确。');
    }

    if (hints.isEmpty) return errorText;
    return '$errorText\n\n${hints.join('\n')}';
  }

  // ===========================================================================
  // 工具反馈构建
  // ===========================================================================

  /// 构建回喂给 AI 的工具结果消息
  String _buildToolFeedback(
    String toolName,
    String truncatedResult,
    bool isError,
    bool recovered,
    List<String> nextActions,
  ) {
    final buf = StringBuffer();
    buf.writeln('工具 `$toolName` 的执行结果:');
    if (isError) {
      buf.writeln(recovered ? '[已自动恢复]' : '[执行出错]');
    }
    buf.writeln(truncatedResult);
    if (nextActions.isNotEmpty) {
      buf.writeln();
      buf.writeln('建议的下一步动作:');
      for (int i = 0; i < nextActions.length; i++) {
        buf.writeln('${i + 1}. ${nextActions[i]}');
      }
      buf.writeln('请根据上述结果与建议决定下一步：继续调用工具，或给出最终结论。');
    } else {
      buf.writeln();
      buf.writeln('请根据上述结果决定下一步：继续调用工具，或给出最终结论。'
          '若已足够回答用户问题，请用自然语言输出最终分析。');
    }
    return buf.toString();
  }

  // ===========================================================================
  // 辅助方法
  // ===========================================================================

  /// 格式化参数用于展示
  String _formatArguments(Map<String, dynamic> args) {
    if (args.isEmpty) return '{}';
    try {
      return const JsonEncoder.withIndent('  ').convert(args);
    } catch (_) {
      return args.toString();
    }
  }

  /// 判断文本是否包含任一子串（大小写不敏感）
  bool _containsAny(String text, List<String> needles) {
    final lower = text.toLowerCase();
    for (final n in needles) {
      if (lower.contains(n.toLowerCase())) return true;
    }
    return false;
  }

  /// 添加 assistant 消息并通知
  void _addAssistantMessage(String content, {bool isError = false}) {
    _messages = [
      ..._messages,
      AgentMessage(role: 'assistant', content: content, isError: isError)
    ];
    notifyListeners();
  }

  /// 添加 system 消息并通知
  void _addSystemMessage(String content, {bool isError = false}) {
    _messages = [
      ..._messages,
      AgentMessage(role: 'system', content: content, isError: isError)
    ];
    notifyListeners();
  }

  /// 从当前 _messages 重建 _conversationHistory
  ///
  /// 用于 retryFromMessage 截断后保持两者一致。
  void _rebuildConversationHistoryFromMessages() {
    _conversationHistory = _messages
        .where((m) => m.role == 'user' || m.role == 'assistant')
        .map((m) => {'role': m.role, 'content': m.content})
        .toList();
  }
}
