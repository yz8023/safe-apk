import 'ai_provider.dart';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 多路 AI 客户端实现
///
/// 对应 Kotlin 版 `MultiAiClient`，管理多个 AI Provider，
/// 支持自动故障转移和手动选择。
///
/// 内置 Provider：
/// 1. Pollinations.ai POST（免费免注册，Agent 推荐）
/// 2. Cehpoint AI（免费免注册，多模型可选）
/// 3. Pollinations.ai GET（免费免注册，备用通道）
///
/// 支持添加自定义 OpenAI 兼容 Provider。
/// 自定义 Provider 配置通过 SharedPreferences 持久化，覆盖安装不丢失。
class MultiAiClientImpl extends MultiAiClient {
  // 持久化存储 key
  static const _prefsKey = 'ai_custom_providers';
  static const _prefsSelectedKey = 'ai_selected_provider';

  // 内置 Provider
  final PollinationsProvider _pollinationsPost = PollinationsProvider();
  final CehpointProvider _cehpointProvider = CehpointProvider();
  final PollinationsGetProvider _pollinationsGet = PollinationsGetProvider();

  // 自定义 Provider 配置列表
  final List<CustomProviderConfig> _customConfigs = [];

  // 自定义 Provider 持久化实例（与 _customConfigs 一一对应）
  final List<OpenAICompatibleProvider> _customProviderInstances = [];

  // 扫描到的模型列表缓存（key: provider name, value: 模型名列表）
  final Map<String, List<String>> _scannedModels = {};

  // 正在扫描的 Provider 名称集合
  final Set<String> _scanningProviders = {};

  // 扫描错误信息（key: provider name, value: 错误消息）
  final Map<String, String> _scanErrors = {};

  // 当前选中的 Provider 索引（-1 表示自动模式）
  int _manualProviderIndex = -1;
  String _selectedModel = 'auto';

  // 状态
  String _currentProviderName = '';
  String _lastError = '';
  int _switchCount = 0;

  MultiAiClientImpl() {
    // 异步加载持久化的配置
    _loadFromPrefs();
  }

  /// 从 SharedPreferences 加载自定义 Provider 配置
  Future<void> _loadFromPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonStr = prefs.getString(_prefsKey);
      if (jsonStr != null && jsonStr.isNotEmpty) {
        final list = jsonDecode(jsonStr) as List;
        for (final item in list) {
          if (item is Map<String, dynamic>) {
            final config = CustomProviderConfig(
              id: item['id'] ?? 'custom_${DateTime.now().millisecondsSinceEpoch}',
              name: item['name'] ?? '自定义接口',
              baseUrl: item['baseUrl'] ?? '',
              apiKey: item['apiKey'] ?? '',
              modelName: item['modelName'] ?? '',
            );
            _customConfigs.add(config);
            _customProviderInstances.add(OpenAICompatibleProvider(
              baseUrl: config.baseUrl,
              apiKey: config.apiKey,
              modelName: config.modelName,
              name: config.name,
              isAvailable: true,
            ));
          }
        }
      }

      // 恢复选中的 Provider
      final selected = prefs.getInt(_prefsSelectedKey);
      if (selected != null && selected >= 0) {
        final providers = allProviders;
        if (selected < providers.length) {
          _manualProviderIndex = selected;
          final provider = providers[selected];
          _selectedModel = provider.modelName;
          _currentProviderName = '${provider.name} (${provider.modelName})';
        }
      }

      notifyListeners();
    } catch (e) {
      // 加载失败不阻塞应用
      debugPrint('[MultiAiClient] 加载持久化配置失败: $e');
    }
  }

  /// 保存自定义 Provider 配置到 SharedPreferences
  Future<void> _saveToPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonList = _customConfigs.map((cfg) => {
        'id': cfg.id,
        'name': cfg.name,
        'baseUrl': cfg.baseUrl,
        'apiKey': cfg.apiKey,
        'modelName': cfg.modelName,
      }).toList();
      await prefs.setString(_prefsKey, jsonEncode(jsonList));
      // 保存选中的 Provider 索引
      await prefs.setInt(_prefsSelectedKey, _manualProviderIndex);
    } catch (e) {
      debugPrint('[MultiAiClient] 保存持久化配置失败: $e');
    }
  }

  // Provider → 模型映射
  static const Map<String, List<String>> _providerModelMap = {
    'Pollinations.ai': ['openai', 'openai-fast'],
    'Cehpoint AI': [
      'gpt-4o-mini', 'gpt-4o', 'gpt-4', 'gpt-4-turbo', 'gpt-3.5-turbo',
      'deepseek-chat', 'deepseek-r1', 'deepseek-v3',
      'gemini-2.0-flash', 'gemini-pro',
      'claude-3.5-sonnet', 'claude-3.5-haiku',
      'llama-3.3-70b', 'llama-3.1-70b',
      'mistral-large', 'qwen2.5', 'qwen-coder',
    ],
    'Pollinations GET': ['openai'],
  };

  // 模型 → Provider 映射
  static const Map<String, String> _modelProviderMap = {
    'openai': 'Pollinations.ai',
    'openai-fast': 'Pollinations.ai',
    'gpt-4o-mini': 'Cehpoint AI',
    'gpt-4o': 'Cehpoint AI',
    'gpt-4': 'Cehpoint AI',
    'gpt-4-turbo': 'Cehpoint AI',
    'gpt-3.5-turbo': 'Cehpoint AI',
    'deepseek-chat': 'Cehpoint AI',
    'deepseek-r1': 'Cehpoint AI',
    'deepseek-v3': 'Cehpoint AI',
    'gemini-2.0-flash': 'Cehpoint AI',
    'gemini-pro': 'Cehpoint AI',
    'claude-3.5-sonnet': 'Cehpoint AI',
    'claude-3.5-haiku': 'Cehpoint AI',
    'llama-3.3-70b': 'Cehpoint AI',
    'llama-3.1-70b': 'Cehpoint AI',
    'mistral-large': 'Cehpoint AI',
    'qwen2.5': 'Cehpoint AI',
    'qwen-coder': 'Cehpoint AI',
  };

  // 模型标签
  static const Map<String, String> modelLabels = {
    'openai': 'openai (Pollinations 免费)',
    'openai-fast': 'openai-fast (Pollinations 快速)',
    'gpt-4o-mini': 'GPT-4o Mini',
    'gpt-4o': 'GPT-4o',
    'gpt-4': 'GPT-4',
    'gpt-4-turbo': 'GPT-4 Turbo',
    'gpt-3.5-turbo': 'GPT-3.5 Turbo',
    'deepseek-chat': 'DeepSeek Chat',
    'deepseek-r1': 'DeepSeek R1 (推理)',
    'deepseek-v3': 'DeepSeek V3',
    'gemini-2.0-flash': 'Gemini 2.0 Flash',
    'gemini-pro': 'Gemini Pro',
    'claude-3.5-sonnet': 'Claude 3.5 Sonnet',
    'claude-3.5-haiku': 'Claude 3.5 Haiku',
    'llama-3.3-70b': 'Llama 3.3 70B',
    'llama-3.1-70b': 'Llama 3.1 70B',
    'mistral-large': 'Mistral Large',
    'qwen2.5': 'Qwen 2.5',
    'qwen-coder': 'Qwen Coder',
  };

  @override
  List<AiProvider> get allProviders {
    return <AiProvider>[
      _pollinationsPost,
      _cehpointProvider,
      _pollinationsGet,
      ..._customProviderInstances,
    ];
  }

  @override
  List<AiProvider> get agentProviders {
    return <AiProvider>[
      _pollinationsPost,
      _cehpointProvider,
      ..._customProviderInstances,
    ];
  }

  @override
  String get currentProviderName => _currentProviderName;

  String get lastError => _lastError;
  int get switchCount => _switchCount;
  String get selectedModel => _selectedModel;

  /// 当前手动选择的 Provider 索引（-1 表示自动模式）
  int get manualProviderIndex => _manualProviderIndex;

  /// 判断指定索引的 Provider + 模型组合是否为当前选中项
  ///
  /// 解决自定义接口与内置接口模型名冲突时选中状态判断错误的问题。
  bool isProviderModelSelected(int index, String model) {
    if (_manualProviderIndex != index) return false;
    if (_selectedModel == 'auto') return false;
    final providers = allProviders;
    if (index >= 0 && index < providers.length) {
      return providers[index].modelName == model;
    }
    return false;
  }

  /// 判断指定 Provider 是否正在扫描模型
  bool isScanning(String providerName) =>
      _scanningProviders.contains(providerName);

  /// 获取指定 Provider 的扫描错误信息
  String? getScanError(String providerName) => _scanErrors[providerName];

  /// 获取指定 Provider 扫描到的模型列表
  List<String> getScannedModels(String providerName) =>
      _scannedModels[providerName] ?? [];

  /// 扫描指定 Provider 的可用模型列表
  ///
  /// 调用 Provider 的 [fetchModels] 方法从 `/models` 端点获取模型列表。
  /// 扫描结果会缓存，供 UI 展示和选择。
  Future<List<String>> scanModels(int providerIndex) async {
    final providers = allProviders;
    if (providerIndex < 0 || providerIndex >= providers.length) return [];

    final provider = providers[providerIndex];
    final providerName = provider.name;

    _scanningProviders.add(providerName);
    _scanErrors.remove(providerName);
    notifyListeners();

    try {
      final models = await provider.fetchModels().timeout(
        const Duration(seconds: 20),
        onTimeout: () => [],
      );

      if (models.isNotEmpty) {
        _scannedModels[providerName] = models;
        // 如果当前选中的 Provider 的模型不在扫描结果中，
        // 且扫描结果只有 1 个模型，自动选中它
        if (_manualProviderIndex == providerIndex && models.length == 1) {
          provider.modelName = models.first;
          _selectedModel = models.first;
          _currentProviderName = '${provider.name} (${provider.modelName})';
        }
      } else {
        _scanErrors[providerName] = '未获取到模型列表，该接口可能不支持 /models 端点';
      }
      notifyListeners();
      return models;
    } catch (e) {
      _scanErrors[providerName] = '扫描失败: $e';
      notifyListeners();
      return [];
    } finally {
      _scanningProviders.remove(providerName);
      notifyListeners();
    }
  }

  /// 扫描表单中临时填写的接口（不添加到 Provider 列表）
  Future<(List<String> models, String? error)> scanTempModels({
    required String baseUrl,
    required String apiKey,
    required String modelName,
  }) async {
    final tempProvider = OpenAICompatibleProvider(
      baseUrl: baseUrl,
      apiKey: apiKey,
      modelName: modelName,
      name: '临时测试',
      isAvailable: true,
    );

    try {
      final models = await tempProvider.fetchModels().timeout(
        const Duration(seconds: 20),
        onTimeout: () => [],
      );
      if (models.isEmpty) {
        return (<String>[], '未获取到模型列表，该接口可能不支持 /models 端点');
      }
      return (models, null);
    } catch (e) {
      return (<String>[], '扫描失败: $e');
    }
  }

  /// 所有可用模型列表
  List<String> get allModels => _modelProviderMap.keys.toList();

  /// 获取指定 Provider 的模型列表
  ///
  /// 优先返回扫描到的模型；若无扫描结果则返回内置配置的模型。
  List<String> getModelsForProvider(String providerName) {
    // 优先返回扫描到的模型
    final scanned = _scannedModels[providerName];
    if (scanned != null && scanned.isNotEmpty) return scanned;

    // 内置 Provider
    final builtIn = _providerModelMap[providerName];
    if (builtIn != null) return builtIn;
    // 自定义 Provider：返回其配置的模型名
    for (final cfg in _customConfigs) {
      if (cfg.name == providerName && cfg.modelName.isNotBlank) {
        return [cfg.modelName];
      }
    }
    return [];
  }

  /// 添加自定义 Provider
  void addCustomProvider(CustomProviderConfig config) {
    _customConfigs.add(config);
    _customProviderInstances.add(OpenAICompatibleProvider(
      baseUrl: config.baseUrl,
      apiKey: config.apiKey,
      modelName: config.modelName,
      name: config.name,
      isAvailable: true,
    ));
    _saveToPrefs();
    notifyListeners();
  }

  /// 删除自定义 Provider
  void removeCustomProvider(String id) {
    final idx = _customConfigs.indexWhere((c) => c.id == id);
    if (idx >= 0) {
      _customConfigs.removeAt(idx);
      _customProviderInstances.removeAt(idx);
      // 如果删除的正好是当前选中的，切回自动模式
      final providerCount = 3 + _customProviderInstances.length;
      if (_manualProviderIndex >= providerCount) {
        _manualProviderIndex = -1;
        _selectedModel = 'auto';
        _currentProviderName = '';
      }
    }
    _saveToPrefs();
    notifyListeners();
  }

  /// 获取所有自定义 Provider 配置
  List<CustomProviderConfig> get customProviders => List.unmodifiable(_customConfigs);

  /// 手动选择 Provider（按索引）
  ///
  /// 对于内置 Provider 会自动选择第一个模型；
  /// 对于自定义 Provider 使用其配置的 modelName。
  void setManualProvider(int index) {
    _manualProviderIndex = index;
    final providers = allProviders;
    if (index >= 0 && index < providers.length) {
      final provider = providers[index];
      // 内置 Provider：从映射表选第一个模型
      final models = _providerModelMap[provider.name];
      if (models != null && models.isNotEmpty) {
        provider.modelName = models.first;
        _selectedModel = models.first;
      } else {
        // 自定义 Provider：直接使用其当前 modelName
        _selectedModel = provider.modelName;
      }
      _currentProviderName = '${provider.name} (${provider.modelName})';
    }
    _saveToPrefs();
    notifyListeners();
  }

  /// 切换到自动模式
  void setAutoMode() {
    _manualProviderIndex = -1;
    _selectedModel = 'auto';
    _currentProviderName = '';
    _saveToPrefs();
    notifyListeners();
  }

  /// 选择模型
  ///
  /// 内置模型通过 _modelProviderMap 查找对应 Provider；
  /// 自定义接口的模型直接在持久化实例中设置。
  void setModel(String model) {
    _selectedModel = model;
    // 先查内置
    final targetProvider = _modelProviderMap[model];
    if (targetProvider != null) {
      final provider = allProviders.where((p) => p.name == targetProvider).firstOrNull;
      if (provider != null) {
        provider.modelName = model;
        _manualProviderIndex = allProviders.indexOf(provider);
        _currentProviderName = '${provider.name} ($model)';
      }
    } else {
      // 查自定义 Provider：匹配 modelName 或 name
      for (int i = 0; i < _customProviderInstances.length; i++) {
        final p = _customProviderInstances[i];
        if (p.modelName == model || p.name == model) {
          p.modelName = model;
          _manualProviderIndex = 3 + i; // 前 3 个是内置
          _currentProviderName = '${p.name} ($model)';
          break;
        }
      }
    }
    _saveToPrefs();
    notifyListeners();
  }

  /// 直接选中指定索引的 Provider 及其模型
  void selectProvider(int index, [String? model]) {
    _manualProviderIndex = index;
    final providers = allProviders;
    if (index >= 0 && index < providers.length) {
      final provider = providers[index];
      if (model != null && model.isNotEmpty) {
        provider.modelName = model;
      }
      _selectedModel = provider.modelName;
      _currentProviderName = '${provider.name} (${provider.modelName})';
    }
    _saveToPrefs();
    notifyListeners();
  }

  @override
  String? ensureAgentProvider() {
    if (_manualProviderIndex >= 0) {
      final providers = allProviders;
      if (_manualProviderIndex < providers.length) {
        return providers[_manualProviderIndex].name;
      }
    }
    if (agentProviders.isNotEmpty) {
      return agentProviders.first.name;
    }
    return null;
  }

  @override
  Future<Result<String>> chatCompletion(List<Map<String, String>> messages) async {
    // 手动模式
    if (_manualProviderIndex >= 0) {
      final providers = allProviders;
      if (_manualProviderIndex < providers.length) {
        final provider = providers[_manualProviderIndex];
        _currentProviderName = '${provider.name} (${provider.modelName})';
        _lastError = '';
        notifyListeners();
        final result = _validateResponse(await _tryChat(provider, messages));
        if (result.isSuccess) return result;

        // 手动模式失败时，如果是服务端错误(503/429等)，自动降级到其他 Provider
        final errStr = result.exceptionOrNull()?.toString() ?? '';
        if (_isServerError(errStr)) {
          _lastError = '${provider.name} 服务不可用 ($errStr)，自动切换备用接口...';
          notifyListeners();
          // 降级到自动模式，跳过已失败的 Provider
          for (var i = 0; i < agentProviders.length; i++) {
            final fallback = agentProviders[i];
            if (identical(fallback, provider)) continue;
            _currentProviderName = '${fallback.name} (${fallback.modelName})';
            notifyListeners();
            final fbResult = _validateResponse(await _tryChat(fallback, messages));
            if (fbResult.isSuccess) {
              _switchCount++;
              _lastError = '';
              notifyListeners();
              return fbResult;
            }
          }
        }
        return result;
      }
    }

    // 自动模式：Agent 场景只用 agentProviders
    for (var i = 0; i < agentProviders.length; i++) {
      final provider = agentProviders[i];
      _currentProviderName = '${provider.name} (${provider.modelName})';
      _lastError = '';
      notifyListeners();

      final result = await _tryChat(provider, messages);
      if (result.isSuccess) {
        if (i > 0) _switchCount++;
        notifyListeners();
        return result;
      }
      _lastError = '${provider.name} 失败，切换下一个接口...';
      notifyListeners();
    }

    return Result.error('所有 AI 接口均不可用。请检查网络连接或稍后重试。');
  }

  /// 简单文本生成
  Future<Result<String>> generateText(String prompt) async {
    if (_manualProviderIndex >= 0) {
      final providers = allProviders;
      if (_manualProviderIndex < providers.length) {
        final provider = providers[_manualProviderIndex];
        _currentProviderName = '${provider.name} (${provider.modelName})';
        _lastError = '';
        notifyListeners();
        final result = _validateResponse(await _tryGenerate(provider, prompt));
        if (result.isSuccess) return result;

        // 手动模式失败时，如果是服务端错误(503/429等)，自动降级到其他 Provider
        final errStr = result.exceptionOrNull()?.toString() ?? '';
        if (_isServerError(errStr)) {
          _lastError = '${provider.name} 服务不可用，自动切换备用接口...';
          notifyListeners();
          for (var i = 0; i < allProviders.length; i++) {
            final fallback = allProviders[i];
            if (identical(fallback, provider)) continue;
            if (fallback is OpenAICompatibleProvider && fallback.baseUrl.isBlank) continue;
            _currentProviderName = '${fallback.name} (${fallback.modelName})';
            notifyListeners();
            final fbResult = _validateResponse(await _tryGenerate(fallback, prompt));
            if (fbResult.isSuccess) {
              _switchCount++;
              _lastError = '';
              notifyListeners();
              return fbResult;
            }
          }
        }
        return result;
      }
    }

    for (var i = 0; i < allProviders.length; i++) {
      final provider = allProviders[i];
      if (provider is OpenAICompatibleProvider && provider.baseUrl.isBlank) continue;

      _currentProviderName = '${provider.name} (${provider.modelName})';
      _lastError = '';
      notifyListeners();

      final result = await _tryGenerate(provider, prompt);
      if (result.isSuccess) {
        if (i > 0) _switchCount++;
        notifyListeners();
        return result;
      }
    }
    return Result.error('所有 AI 接口均不可用。');
  }

  Future<Result<String>> _tryChat(AiProvider provider, List<Map<String, String>> messages) async {
    try {
      return await provider.chatCompletion(messages);
    } catch (e) {
      return Result.failure(Exception(e.toString()));
    }
  }

  Future<Result<String>> _tryGenerate(AiProvider provider, String prompt) async {
    try {
      return await provider.generateText(prompt);
    } catch (e) {
      return Result.failure(Exception(e.toString()));
    }
  }

  Result<String> _validateResponse(Result<String> result) {
    if (result.isFailure) return result;
    final content = result.getOrNull() ?? '';
    if (_isErrorResponse(content)) {
      return Result.failure(Exception('返回错误响应'));
    }
    return result;
  }

  bool _isErrorResponse(String content) {
    final trimmed = content.trim();
    if (trimmed.isBlank) return true;
    if (trimmed.startsWith('{"error"')) return true;
    if (trimmed.startsWith('{"detail"')) return true;
    if (trimmed.startsWith('Error:')) return true;
    if (trimmed.startsWith('<!DOCTYPE') || trimmed.startsWith('<html')) return true;
    if (trimmed.contains('"status":404') ||
        trimmed.contains('"status":429') ||
        trimmed.contains('"status":500') ||
        trimmed.contains('"status":503')) {
      return true;
    }
    return false;
  }

  /// 判断错误是否为服务端错误（503/429/500 等），值得自动切换 Provider 重试
  bool _isServerError(String errorText) {
    final lower = errorText.toLowerCase();
    // HTTP 状态码
    if (lower.contains('503') || lower.contains('429') ||
        lower.contains('500') || lower.contains('502') ||
        lower.contains('504')) return true;
    // 常见限流/服务不可用关键词
    if (lower.contains('resourceexhausted') ||
        lower.contains('service unavailable') ||
        lower.contains('rate limit') ||
        lower.contains('too many requests') ||
        lower.contains('overloaded') ||
        lower.contains('capacity')) return true;
    return false;
  }

  /// 健康检查所有 Provider
  Future<void> healthCheck() async {
    for (final provider in allProviders) {
      if (provider is OpenAICompatibleProvider && provider.baseUrl.isBlank) continue;
      try {
        provider.isAvailable = await provider.healthCheck();
      } catch (_) {
        provider.isAvailable = false;
      }
    }
    notifyListeners();
  }
}

// ==================== String 扩展 ====================

extension StringExtension on String {
  bool get isNotBlank => trim().isNotEmpty;
  bool get isBlank => trim().isEmpty;
  String ifBlank(String Function() fallback) => isBlank ? fallback() : this;
}
