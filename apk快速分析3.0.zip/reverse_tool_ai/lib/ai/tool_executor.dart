import 'package:flutter/foundation.dart';
import '../mcp/mcp_models.dart';
import 'ai_provider.dart';

/// 抽象工具执行器接口
///
/// [McpClient]（远程 MCP 服务器）和 [LocalMcpClient]（本地分析工具）
/// 都实现此接口，使 [McpAgentEngine] 可以透明地使用远程或本地工具。
///
/// 继承 [ChangeNotifier] 以便 UI 监听工具列表变化。
abstract class ToolExecutor extends ChangeNotifier {
  /// 获取所有可用工具列表
  List<McpTool> get tools;

  /// 调用指定工具
  ///
  /// [name] - 工具名称
  /// [arguments] - 工具参数
  /// 返回 [Result] 包含工具调用结果或错误信息
  Future<Result<McpToolCallResult>> callTool(
    String name,
    Map<String, dynamic> arguments,
  );
}
