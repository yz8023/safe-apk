import 'dart:convert';
import '../providers/apk_analysis_provider.dart';
import '../providers/so_analysis_provider.dart';
import '../providers/app_state_provider.dart';

/// 本地分析工具定义
///
/// 将应用已分析的 APK/SO 数据包装为 AI 可调用的工具，
/// 让 AI 无需外部 MCP 服务器即可访问应用的逆向分析结果。
class LocalTool {
  final String name;
  final String description;
  final List<String> requiredParams;
  final Future<String> Function(Map<String, dynamic> args) handler;

  const LocalTool({
    required this.name,
    required this.description,
    this.requiredParams = const [],
    required this.handler,
  });
}

/// 本地分析工具集
///
/// 持有 [ApkAnalysisProvider] 和 [SoAnalysisProvider] 引用，
/// 将应用已经分析出的逆向数据暴露为工具供 AI Agent 调用。
class LocalAnalyzerTools {
  final ApkAnalysisProvider apkProvider;
  final SoAnalysisProvider soProvider;
  final AppStateProvider appState;

  LocalAnalyzerTools({
    required this.apkProvider,
    required this.soProvider,
    required this.appState,
  });

  /// 所有可用的本地工具列表
  List<LocalTool> get tools => [
    LocalTool(
      name: 'local_get_apk_info',
      description: '获取当前已分析的 APK 基本信息（包名、版本号、SDK版本、文件大小、主Activity等）',
      handler: _getApkInfo,
    ),
    LocalTool(
      name: 'local_get_permissions',
      description: '获取 APK 声明的所有权限列表及其风险等级分类',
      handler: _getPermissions,
    ),
    LocalTool(
      name: 'local_get_components',
      description: '获取 APK 的四大组件（Activity、Service、Receiver、Provider）列表，含 exported 状态',
      handler: _getComponents,
    ),
    LocalTool(
      name: 'local_get_manifest',
      description: '获取完整的 AndroidManifest.xml 文本内容',
      handler: _getManifest,
    ),
    LocalTool(
      name: 'local_get_signature',
      description: '获取 APK 签名信息（V1/V2/V3 签名块、证书签发者、有效期等）',
      handler: _getSignature,
    ),
    LocalTool(
      name: 'local_get_hash',
      description: '获取 APK 文件的哈希值（MD5、SHA1、SHA256）',
      handler: _getHash,
    ),
    LocalTool(
      name: 'local_get_security_report',
      description: '获取安全评估报告（风险等级、安全问题列表、高/中/低风险计数等）',
      handler: _getSecurityReport,
    ),
    LocalTool(
      name: 'local_get_sdk_detection',
      description: '获取检测到的第三方 SDK 列表（如友盟、Bugly、Glide 等）',
      handler: _getSdkDetection,
    ),
    LocalTool(
      name: 'local_get_packer_detection',
      description: '获取加壳/加固检测结果（是否加壳、壳类型）',
      handler: _getPackerDetection,
    ),
    LocalTool(
      name: 'local_get_native_libs',
      description: '获取原生库（.so 文件）信息列表，含架构和大小',
      handler: _getNativeLibs,
    ),
    LocalTool(
      name: 'local_get_urls',
      description: '获取从 APK 中提取的所有 URL 和 IP 地址列表',
      handler: _getUrls,
    ),
    LocalTool(
      name: 'local_get_sensitive_apis',
      description: '获取敏感 API 调用列表（如获取设备ID、读取联系人、发送短信等）',
      handler: _getSensitiveApis,
    ),
    LocalTool(
      name: 'local_get_dex_classes',
      description: '获取 DEX 文件中的类名列表。可传 query 参数进行过滤',
      requiredParams: [],
      handler: _getDexClasses,
    ),
    LocalTool(
      name: 'local_search_dex',
      description: '在 DEX 中搜索类名或方法名。必填参数: query（搜索关键词）',
      requiredParams: ['query'],
      handler: _searchDex,
    ),
    LocalTool(
      name: 'local_get_file_tree',
      description: '获取 APK 内部文件结构树',
      handler: _getFileTree,
    ),
    LocalTool(
      name: 'local_get_strings',
      description: '获取字符串分析结果（含解密样本、硬编码密钥等）',
      handler: _getStrings,
    ),
    LocalTool(
      name: 'local_get_deep_links',
      description: '获取深度链接（Deep Link）和 Intent Filter 信息',
      handler: _getDeepLinks,
    ),
    LocalTool(
      name: 'local_get_obfuscation',
      description: '获取代码混淆检测结果（混淆比例、熵值、可疑等级）',
      handler: _getObfuscation,
    ),
    LocalTool(
      name: 'local_get_size_breakdown',
      description: '获取 APK 文件大小分类明细（DEX、资源、原生库、Assets 等）',
      handler: _getSizeBreakdown,
    ),
    LocalTool(
      name: 'local_get_secrets',
      description: '获取硬编码密钥/Token 检测结果',
      handler: _getSecrets,
    ),
    LocalTool(
      name: 'local_get_api_endpoints',
      description: '获取网络 API 端点提取结果',
      handler: _getApiEndpoints,
    ),
    LocalTool(
      name: 'local_get_anti_debug',
      description: '获取反调试/反Root检测信息',
      handler: _getAntiDebug,
    ),
    LocalTool(
      name: 'local_generate_report',
      description: '生成完整的 APK 逆向分析报告（纯文本格式）',
      handler: _generateReport,
    ),
    LocalTool(
      name: 'local_get_current_file',
      description: '获取当前正在分析的文件路径和名称',
      handler: _getCurrentFile,
    ),
  ];

  /// 检查是否存在已分析的 APK 数据
  bool get hasApkData => apkProvider.apkInfo != null;

  /// 执行本地工具调用
  Future<String> executeTool(String toolName, Map<String, dynamic> args) async {
    final tool = tools.where((t) => t.name == toolName).firstOrNull;
    if (tool == null) {
      return '错误: 未知的本地工具 "$toolName"';
    }
    try {
      return await tool.handler(args);
    } catch (e) {
      return '工具执行异常: $e';
    }
  }

  /// 获取所有本地工具的描述文本（用于系统提示词）
  String get toolsDescription {
    final buf = StringBuffer();
    for (final tool in tools) {
      buf.writeln('- ${tool.name}: ${tool.description}');
      if (tool.requiredParams.isNotEmpty) {
        buf.writeln('  必填参数: ${tool.requiredParams.join(", ")}');
      }
    }
    return buf.toString();
  }

  // ===========================================================================
  // 工具处理函数
  // ===========================================================================

  Future<String> _getApkInfo(Map<String, dynamic> args) async {
    final info = apkProvider.apkInfo;
    if (info == null) return '尚未分析 APK 文件，请先选择并分析 APK。';
    final data = {
      '包名': info.packageName,
      '版本名': info.versionName,
      '版本号': info.versionCode,
      '应用名': info.applicationName ?? '未知',
      '主Activity': info.mainActivity,
      '最小SDK': info.minSdkVersion ?? '未知',
      '目标SDK': info.targetSdkVersion ?? '未知',
      '文件大小': '${(info.fileSize / 1024 / 1024).toStringAsFixed(2)} MB (${info.fileSize} bytes)',
      'DEX文件数': info.entries.where((e) => e.endsWith('.dex')).length,
      '总文件数': info.entries.length,
      'DEX类数量': info.dexClasses.length,
    };
    return _formatJson(data);
  }

  Future<String> _getPermissions(Map<String, dynamic> args) async {
    final info = apkProvider.apkInfo;
    if (info == null) return '尚未分析 APK 文件。';
    final permResult = apkProvider.permResult;
    final data = <String, dynamic>{
      '总权限数': info.permissions.length,
      '权限列表': info.permissions,
    };
    if (permResult != null) {
      data['权限分类'] = {
        '危险权限': permResult.classifications
            .where((c) => c.riskLabel == '危险')
            .map((c) => c.permission)
            .toList(),
        '普通权限': permResult.classifications
            .where((c) => c.riskLabel == '普通')
            .map((c) => c.permission)
            .toList(),
        '签名权限': permResult.classifications
            .where((c) => c.riskLabel == '签名' || c.riskLabel == '系统')
            .map((c) => c.permission)
            .toList(),
        '未知权限': permResult.classifications
            .where((c) => c.riskLabel == '未知')
            .map((c) => c.permission)
            .toList(),
        '危险权限数': permResult.dangerousCount,
        '普通权限数': permResult.normalCount,
        '签名权限数': permResult.signatureCount,
        '未知权限数': permResult.unknownCount,
      };
    }
    return _formatJson(data);
  }

  Future<String> _getComponents(Map<String, dynamic> args) async {
    final manifest = apkProvider.manifestInfo;
    if (manifest == null) return '尚未解析 Manifest。';
    final data = {
      'Activities': manifest.activityList.map((c) => {
        'name': c.name,
        'exported': c.exported,
        'enabled': c.enabled,
        'isLauncher': c.isLauncher,
        'permission': c.permission ?? '无',
      }).toList(),
      'Services': manifest.serviceList.map((c) => {
        'name': c.name,
        'exported': c.exported,
        'permission': c.permission ?? '无',
      }).toList(),
      'Receivers': manifest.receiverList.map((c) => {
        'name': c.name,
        'exported': c.exported,
        'permission': c.permission ?? '无',
      }).toList(),
      'Providers': manifest.providerList.map((c) => {
        'name': c.name,
        'exported': c.exported,
        'authorities': c.intentFilters.isNotEmpty ? c.intentFilters.toString() : '无',
      }).toList(),
      '导出组件数': manifest.exportedComponents.length,
    };
    return _formatJson(data);
  }

  Future<String> _getManifest(Map<String, dynamic> args) async {
    final manifest = apkProvider.manifestInfo;
    if (manifest == null) return '尚未解析 Manifest。';
    if (manifest.xmlContent.isNotEmpty) {
      return manifest.xmlContent;
    }
    return 'Manifest XML 内容为空，解析方式: ${manifest.parseMethod}';
  }

  Future<String> _getSignature(Map<String, dynamic> args) async {
    final cert = apkProvider.certInfo;
    final sigBlock = apkProvider.signatureBlock;
    final sigInfo = apkProvider.signatureInfo;
    final data = <String, dynamic>{};
    if (sigBlock != null) {
      data['签名方案'] = {
        '是否有签名块': sigBlock.hasSigningBlock,
        'V2签名': sigBlock.v2,
        'V3签名': sigBlock.v3,
        '签名块大小': sigBlock.blockSize,
        '摘要': sigBlock.summary,
      };
    }
    if (cert != null) {
      data['证书信息'] = {
        '签发者': cert.issuer,
        '主题': cert.subject,
        '序列号': cert.serialNumber,
        '有效期开始': cert.validFrom?.toString() ?? '未知',
        '有效期结束': cert.validTo?.toString() ?? '未知',
        '签名算法': cert.algorithm,
        '指纹': cert.fingerprint,
      };
    }
    if (sigInfo != null) {
      data['签名详情'] = sigInfo.toString();
    }
    if (data.isEmpty) return '尚未解析签名信息。';
    return _formatJson(data);
  }

  Future<String> _getHash(Map<String, dynamic> args) async {
    final hash = apkProvider.hashInfo;
    if (hash == null) return '尚未计算文件哈希。';
    return _formatJson({
      'MD5': hash.md5,
      'SHA1': hash.sha1,
      'SHA256': hash.sha256,
      '文件大小': hash.fileSize,
    });
  }

  Future<String> _getSecurityReport(Map<String, dynamic> args) async {
    var report = apkProvider.securityReport;
    // 如果尚未生成安全报告，自动触发评估
    if (report == null && appState.currentFilePath != null && apkProvider.apkInfo != null) {
      await apkProvider.assessSecurity(appState.currentFilePath!);
      report = apkProvider.securityReport;
    }
    if (report == null) return '尚未分析 APK 文件，无法生成安全报告。';
    final data = {
      '总体安全等级': report.overallLevel,
      '高风险问题数': report.highCount,
      '中风险问题数': report.mediumCount,
      '低风险问题数': report.lowCount,
      '问题列表': report.items.map((item) => {
        '类别': item.category,
        '标题': item.title,
        '描述': item.description,
        '等级': item.level.name,
      }).toList(),
    };
    return _formatJson(data);
  }

  Future<String> _getSdkDetection(Map<String, dynamic> args) async {
    var result = apkProvider.sdkResult;
    // 如果尚未进行 SDK 检测，自动触发
    if (result == null && appState.currentFilePath != null) {
      await apkProvider.detectSdks(appState.currentFilePath!);
      result = apkProvider.sdkResult;
    }
    if (result == null) return '尚未进行 SDK 检测，请先分析 APK 文件。';
    final data = {
      '检测到的SDK数量': result.totalSdkCount,
      'SDK列表': result.sdks.map((s) => {
        '名称': s.name,
        '类别': s.category,
        '描述': s.description,
        '匹配特征': s.matchedPatterns,
      }).toList(),
      '分类统计': result.categories,
    };
    return _formatJson(data);
  }

  Future<String> _getPackerDetection(Map<String, dynamic> args) async {
    final result = apkProvider.packerResult;
    if (result == null) return '尚未进行加壳检测。';
    return _formatJson({
      '是否加壳': result.isPacked,
      '壳类型': result.packerName ?? '无',
      '匹配详情': result.allMatches.map((m) => m.toString()).toList(),
      '命中特征': result.indicators,
    });
  }

  Future<String> _getNativeLibs(Map<String, dynamic> args) async {
    final summary = apkProvider.nativeLibSummary;
    final info = apkProvider.apkInfo;
    if (summary != null) {
      return _formatJson({
        '总SO文件数': summary.totalLibCount,
        '架构列表': summary.abis,
        '架构数': summary.abiCount,
        '总大小': summary.totalSizeStr,
      });
    }
    if (info != null) {
      final soFiles = info.entries.where((e) => e.endsWith('.so')).toList();
      return _formatJson({
        'SO文件列表': soFiles,
        '数量': soFiles.length,
      });
    }
    return '尚未分析原生库。';
  }

  Future<String> _getUrls(Map<String, dynamic> args) async {
    var urls = apkProvider.urls;
    // 如果尚未提取 URL，自动触发提取
    if (urls.isEmpty && appState.currentFilePath != null) {
      await apkProvider.extractUrls(appState.currentFilePath!);
      urls = apkProvider.urls;
    }
    if (urls.isEmpty) return '已扫描 APK 内容，未发现 URL/IP 地址。该应用可能使用了代码混淆、动态加载或原生层网络通信。';
    return _formatJson({
      '数量': urls.length,
      'URL/IP列表': urls,
    });
  }

  Future<String> _getSensitiveApis(Map<String, dynamic> args) async {
    var apis = apkProvider.sensitiveApis;
    // 如果尚未检测敏感 API，自动触发检测
    if (apis.isEmpty && appState.currentFilePath != null) {
      await apkProvider.detectSensitiveApis(appState.currentFilePath!);
      apis = apkProvider.sensitiveApis;
    }
    if (apis.isEmpty) return '已扫描 APK 内容，未检测到敏感 API 调用。';
    return _formatJson({
      '数量': apis.length,
      '敏感API列表': apis.map((a) => {
        '关键词': a.keyword,
        '描述': a.description,
        '匹配类型': a.matchType,
        '上下文': a.context,
      }).toList(),
    });
  }

  Future<String> _getDexClasses(Map<String, dynamic> args) async {
    final info = apkProvider.apkInfo;
    if (info == null) return '尚未分析 DEX。';
    var classes = info.dexClasses;
    final query = args['query'] as String?;
    if (query != null && query.isNotEmpty) {
      classes = classes.where((c) => c.toLowerCase().contains(query.toLowerCase())).toList();
    }
    const maxReturn = 200;
    final truncated = classes.length > maxReturn;
    final result = classes.take(maxReturn).toList();
    return _formatJson({
      '总类数': info.dexClasses.length,
      '匹配数': classes.length,
      if (truncated) '提示': '仅显示前 $maxReturn 个结果，请用 query 参数缩小范围',
      '类列表': result,
    });
  }

  Future<String> _searchDex(Map<String, dynamic> args) async {
    final query = args['query'] as String?;
    if (query == null || query.isEmpty) {
      return '错误: 必须提供 query 参数';
    }
    // 如果有已分析的 APK，自动触发搜索以获取完整结果
    if (appState.currentFilePath != null && apkProvider.apkInfo != null) {
      await apkProvider.searchInDex(appState.currentFilePath!, query);
    }
    final result = apkProvider.searchResult;
    if (result != null) {
      return _formatJson({
        '搜索关键词': query,
        '匹配数': result.matches.length,
        '匹配结果': result.matches.map((m) => {
          '类型': m.type,
          '名称': m.name,
          '完整名': m.fullName,
          '所属类': m.className ?? '无',
        }).take(50).toList(),
      });
    }
    final info = apkProvider.apkInfo;
    if (info == null) return '尚未分析 DEX。';
    final matches = info.dexClasses
        .where((c) => c.toLowerCase().contains(query.toLowerCase()))
        .take(50)
        .toList();
    return _formatJson({
      '搜索关键词': query,
      '匹配数': matches.length,
      '匹配类': matches,
    });
  }

  Future<String> _getFileTree(Map<String, dynamic> args) async {
    var tree = apkProvider.fileTree;
    // 如果尚未加载文件树，自动触发
    if (tree.isEmpty && appState.currentFilePath != null) {
      await apkProvider.loadFileTree(appState.currentFilePath!);
      tree = apkProvider.fileTree;
    }
    if (tree.isEmpty) return '尚未获取文件树，请先分析 APK 文件。';
    return _formatJson({
      '文件数': tree.length,
      '文件树': tree.map((f) => {
        '名称': f.name,
        '路径': f.path,
        '大小': f.size,
        '是否文件': f.isFile,
      }).take(100).toList(),
    });
  }

  Future<String> _getStrings(Map<String, dynamic> args) async {
    var analysis = apkProvider.stringAnalysis;
    // 如果尚未进行字符串分析，自动触发
    if (analysis == null && appState.currentFilePath != null) {
      await apkProvider.analyzeStrings(appState.currentFilePath!);
      analysis = apkProvider.stringAnalysis;
    }
    if (analysis == null) return '尚未进行字符串分析，请先分析 APK 文件。';
    final data = <String, dynamic>{
      '总字符串数': analysis.totalStrings,
      '解密数量': analysis.decryptedCount,
    };
    if (analysis.decryptedSamples.isNotEmpty) {
      data['解密样本'] = analysis.decryptedSamples.map((d) => {
        '原始值': d.original,
        '解密值': d.decoded,
        '解密方式': d.method,
      }).take(20).toList();
    }
    return _formatJson(data);
  }

  Future<String> _getDeepLinks(Map<String, dynamic> args) async {
    final manifest = apkProvider.manifestInfo;
    if (manifest == null) return '尚未解析 Manifest。';
    if (manifest.deepLinks.isEmpty) return '未检测到深度链接。';
    return _formatJson({
      '深度链接数': manifest.deepLinks.length,
      '链接列表': manifest.deepLinks.map((d) => {
        'scheme': d.scheme,
        'host': d.host,
        'path': d.path,
        '完整URI': d.uri,
      }).toList(),
    });
  }

  Future<String> _getObfuscation(Map<String, dynamic> args) async {
    var result = apkProvider.obfuscationResult;
    // 如果尚未进行混淆检测，自动触发
    if (result == null && appState.currentFilePath != null) {
      await apkProvider.detectObfuscation(appState.currentFilePath!);
      result = apkProvider.obfuscationResult;
    }
    if (result == null) return '尚未进行混淆检测，请先分析 APK 文件。';
    return _formatJson({
      '短名比例': '${(result.shortNameRatio * 100).toStringAsFixed(1)}%',
      '平均熵值': result.averageEntropy.toStringAsFixed(3),
      '单字符类比例': '${(result.singleCharClassRatio * 100).toStringAsFixed(1)}%',
      '可疑等级': result.suspicionLevel,
      '总名称数': result.totalNames,
    });
  }

  Future<String> _getSizeBreakdown(Map<String, dynamic> args) async {
    final breakdown = apkProvider.sizeBreakdown;
    if (breakdown == null) return '尚未分析文件大小。';
    return _formatJson({
      '总大小': '${(breakdown.totalSize / 1024 / 1024).toStringAsFixed(2)} MB',
      'DEX大小': '${(breakdown.dexSize / 1024 / 1024).toStringAsFixed(2)} MB (${(breakdown.dexRatio * 100).toStringAsFixed(1)}%)',
      '资源大小': '${(breakdown.resourcesSize / 1024 / 1024).toStringAsFixed(2)} MB (${(breakdown.resourcesRatio * 100).toStringAsFixed(1)}%)',
      '原生库大小': '${(breakdown.nativeLibSize / 1024 / 1024).toStringAsFixed(2)} MB (${(breakdown.nativeLibRatio * 100).toStringAsFixed(1)}%)',
      'Assets大小': '${(breakdown.assetsSize / 1024 / 1024).toStringAsFixed(2)} MB (${(breakdown.assetsRatio * 100).toStringAsFixed(1)}%)',
      'META-INF大小': '${(breakdown.metaInfSize / 1024 / 1024).toStringAsFixed(2)} MB',
    });
  }

  Future<String> _getSecrets(Map<String, dynamic> args) async {
    var result = apkProvider.secretResult;
    // 如果尚未进行密钥检测，自动触发
    if (result == null && appState.currentFilePath != null) {
      await apkProvider.detectSecrets(appState.currentFilePath!);
      result = apkProvider.secretResult;
    }
    if (result == null) return '尚未进行密钥检测，请先分析 APK 文件。';
    return _formatJson({
      '检测到的密钥数': result.findings.length,
      '高危数量': result.highCount,
      '中危数量': result.mediumCount,
      '低危数量': result.lowCount,
      '密钥列表': result.findings.map((s) => {
        '类型': s.type,
        '脱敏值': s.maskedValue,
        '风险等级': s.riskLevel.name,
        '描述': s.description,
      }).take(20).toList(),
    });
  }

  Future<String> _getApiEndpoints(Map<String, dynamic> args) async {
    var result = apkProvider.apiEndpoints;
    // 如果尚未提取 API 端点，自动触发
    if (result == null && appState.currentFilePath != null) {
      await apkProvider.extractApiEndpoints(appState.currentFilePath!);
      result = apkProvider.apiEndpoints;
    }
    if (result == null) return '尚未提取 API 端点，请先分析 APK 文件。';
    return _formatJson({
      '端点数': result.totalEndpoints,
      'API端点': result.endpoints.map((e) => {
        '路径': e.path,
        'HTTP方法': e.httpMethod,
        '来源字符串': e.sourceString,
        '匹配模式': e.matchPattern,
      }).take(50).toList(),
    });
  }

  Future<String> _getAntiDebug(Map<String, dynamic> args) async {
    var result = apkProvider.antiDebugResult;
    // 如果尚未进行反调试检测，自动触发
    if (result == null && appState.currentFilePath != null) {
      await apkProvider.detectAntiDebug(appState.currentFilePath!);
      result = apkProvider.antiDebugResult;
    }
    if (result == null) return '尚未进行反调试检测，请先分析 APK 文件。';
    return _formatJson({
      '总发现数': result.totalCount,
      '发现明细': result.findings.map((f) => {
        '类别': f.category.name,
        '关键词': f.keyword,
        '描述': f.description,
        '风险等级': f.riskLevel.name,
      }).toList(),
      '分类统计': result.categoryCounts.map((k, v) => MapEntry(k.name, v)),
    });
  }

  Future<String> _generateReport(Map<String, dynamic> args) async {
    final info = apkProvider.apkInfo;
    if (info == null) return '尚未分析 APK，无法生成报告。';
    final buf = StringBuffer();
    buf.writeln('========== APK 逆向分析报告 ==========');
    buf.writeln();
    buf.writeln('【基本信息】');
    buf.writeln('  包名: ${info.packageName}');
    buf.writeln('  版本: ${info.versionName} (${info.versionCode})');
    buf.writeln('  应用名: ${info.applicationName ?? "未知"}');
    buf.writeln('  主Activity: ${info.mainActivity}');
    buf.writeln('  SDK: min=${info.minSdkVersion ?? "未知"}, target=${info.targetSdkVersion ?? "未知"}');
    buf.writeln('  文件大小: ${(info.fileSize / 1024 / 1024).toStringAsFixed(2)} MB');
    buf.writeln('  DEX类数量: ${info.dexClasses.length}');
    buf.writeln();

    buf.writeln('【权限列表】 (${info.permissions.length}个)');
    for (final p in info.permissions) {
      buf.writeln('  - $p');
    }
    buf.writeln();

    final manifest = apkProvider.manifestInfo;
    if (manifest != null) {
      buf.writeln('【组件信息】');
      buf.writeln('  Activities: ${manifest.activityList.length}个');
      buf.writeln('  Services: ${manifest.serviceList.length}个');
      buf.writeln('  Receivers: ${manifest.receiverList.length}个');
      buf.writeln('  Providers: ${manifest.providerList.length}个');
      buf.writeln('  导出组件: ${manifest.exportedComponents.length}个');
      buf.writeln();
    }

    final hash = apkProvider.hashInfo;
    if (hash != null) {
      buf.writeln('【文件哈希】');
      buf.writeln('  MD5: ${hash.md5}');
      buf.writeln('  SHA1: ${hash.sha1}');
      buf.writeln('  SHA256: ${hash.sha256}');
      buf.writeln();
    }

    final security = apkProvider.securityReport;
    if (security != null) {
      buf.writeln('【安全评估】');
      buf.writeln('  等级: ${security.overallLevel}');
      buf.writeln('  高风险: ${security.highCount}, 中风险: ${security.mediumCount}, 低风险: ${security.lowCount}');
      for (final item in security.items) {
        buf.writeln('  - [${item.level.name}] ${item.title}: ${item.description}');
      }
      buf.writeln();
    }

    final sdk = apkProvider.sdkResult;
    if (sdk != null && sdk.sdks.isNotEmpty) {
      buf.writeln('【第三方SDK】 (${sdk.totalSdkCount}个)');
      for (final s in sdk.sdks) {
        buf.writeln('  - ${s.name} (${s.category})');
      }
      buf.writeln();
    }

    final packer = apkProvider.packerResult;
    if (packer != null) {
      buf.writeln('【加壳检测】');
      buf.writeln('  是否加壳: ${packer.isPacked}');
      if (packer.isPacked) {
        buf.writeln('  壳类型: ${packer.packerName}');
      }
      buf.writeln();
    }

    if (apkProvider.urls.isNotEmpty) {
      buf.writeln('【URL/IP地址】 (${apkProvider.urls.length}个)');
      for (final u in apkProvider.urls.take(20)) {
        buf.writeln('  - $u');
      }
      if (apkProvider.urls.length > 20) {
        buf.writeln('  ... 共${apkProvider.urls.length}个');
      }
      buf.writeln();
    }

    return buf.toString();
  }

  Future<String> _getCurrentFile(Map<String, dynamic> args) async {
    final path = appState.currentFilePath;
    final name = appState.currentFileName;
    if (path == null || path.isEmpty) {
      return '当前没有打开任何文件。';
    }
    return _formatJson({
      '文件路径': path,
      '文件名': name ?? '未知',
      '文件类型': name?.toLowerCase().endsWith('.apk') == true ? 'APK' : '其他',
    });
  }

  // ===========================================================================
  // 辅助方法
  // ===========================================================================

  String _formatJson(Map<String, dynamic> data) {
    try {
      return const JsonEncoder.withIndent('  ').convert(data);
    } catch (_) {
      return data.toString();
    }
  }
}
