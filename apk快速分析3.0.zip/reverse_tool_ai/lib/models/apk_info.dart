/// APK 基础信息模型
class ApkInfo {
  final String packageName;
  final String versionName;
  final int versionCode;
  final List<String> permissions;
  final String mainActivity;
  final List<String> dexClasses;
  final int fileSize;
  final List<String> entries;
  final String? applicationName;
  final String? minSdkVersion;
  final String? targetSdkVersion;

  const ApkInfo({
    required this.packageName,
    required this.versionName,
    required this.versionCode,
    required this.permissions,
    required this.mainActivity,
    required this.dexClasses,
    required this.fileSize,
    required this.entries,
    this.applicationName,
    this.minSdkVersion,
    this.targetSdkVersion,
  });
}

/// 搜索匹配结果
class SearchMatch {
  final String type; // 'class' | 'method' | 'field'
  final String name;
  final String fullName;
  final String? className;

  const SearchMatch({
    required this.type,
    required this.name,
    required this.fullName,
    this.className,
  });
}

class SearchResult {
  final String query;
  final List<SearchMatch> matches;

  const SearchResult({required this.query, required this.matches});
}

/// 字符串解密结果
class DecryptedString {
  final String original;
  final String decoded;
  final String method;

  const DecryptedString({
    required this.original,
    required this.decoded,
    required this.method,
  });
}

class StringAnalysis {
  final int totalStrings;
  final List<String> sampleStrings;
  final int decryptedCount;
  final List<DecryptedString> decryptedSamples;

  const StringAnalysis({
    required this.totalStrings,
    required this.sampleStrings,
    required this.decryptedCount,
    required this.decryptedSamples,
  });
}

/// 混淆检测结果
class ObfuscationResult {
  final int totalNames;
  final double shortNameRatio;
  final double averageEntropy;
  final double singleCharClassRatio;
  final String suspicionLevel;
  final List<String> sampleClasses;
  final List<String> sampleMethods;

  const ObfuscationResult({
    required this.totalNames,
    required this.shortNameRatio,
    required this.averageEntropy,
    required this.singleCharClassRatio,
    required this.suspicionLevel,
    required this.sampleClasses,
    this.sampleMethods = const [],
  });
}

/// 敏感 API 检测结果项
class SensitiveApiItem {
  final String keyword;
  final String description;
  final String matchType; // 'class' | 'method' | 'string'
  final String context;

  const SensitiveApiItem({
    required this.keyword,
    required this.description,
    required this.matchType,
    required this.context,
  });
}

/// 文件树节点
class FileTreeNode {
  final String name;
  final String path;
  final int size;
  final int compressedSize;
  final bool isFile;

  const FileTreeNode({
    required this.name,
    required this.path,
    this.size = 0,
    this.compressedSize = 0,
    required this.isFile,
  });
}

/// 逆向关键词检测结果项
class ReverseKeywordItem {
  final String keyword;
  final String matchType; // 'method' | 'field' | 'string' | 'class'
  final String className;
  final String memberName;
  final String fullContext;

  const ReverseKeywordItem({
    required this.keyword,
    required this.matchType,
    required this.className,
    required this.memberName,
    required this.fullContext,
  });
}

/// APK 内的 SO 文件条目
class ApkSoEntry {
  final String name;
  final String fullPath;
  final String abi;
  final int size;

  const ApkSoEntry({
    required this.name,
    required this.fullPath,
    required this.abi,
    required this.size,
  });

  String get sizeStr {
    if (size >= 1024 * 1024) return '${(size / 1024 / 1024).toStringAsFixed(2)} MB';
    if (size >= 1024) return '${(size / 1024).toStringAsFixed(1)} KB';
    return '$size B';
  }
}

/// APK 文件哈希信息
class ApkHashInfo {
  final String md5;
  final String sha1;
  final String sha256;
  final int fileSize;

  const ApkHashInfo({
    required this.md5,
    required this.sha1,
    required this.sha256,
    required this.fileSize,
  });
}

/// APK 文件大小分类统计
class FileSizeBreakdown {
  final int dexSize;
  final int resourcesSize;
  final int nativeLibSize;
  final int assetsSize;
  final int metaInfSize;
  final int otherSize;
  final int totalSize;

  const FileSizeBreakdown({
    required this.dexSize,
    required this.resourcesSize,
    required this.nativeLibSize,
    required this.assetsSize,
    required this.metaInfSize,
    required this.otherSize,
    required this.totalSize,
  });

  double get dexRatio => totalSize > 0 ? dexSize / totalSize : 0;
  double get resourcesRatio => totalSize > 0 ? resourcesSize / totalSize : 0;
  double get nativeLibRatio => totalSize > 0 ? nativeLibSize / totalSize : 0;
  double get assetsRatio => totalSize > 0 ? assetsSize / totalSize : 0;
}

/// 安全评估项
class SecurityAssessmentItem {
  final String category;
  final String title;
  final String description;
  final SecurityLevel level;

  const SecurityAssessmentItem({
    required this.category,
    required this.title,
    required this.description,
    required this.level,
  });
}

enum SecurityLevel { high, medium, low, info }

/// 安全评估报告
class SecurityReport {
  final List<SecurityAssessmentItem> items;
  final int highCount;
  final int mediumCount;
  final int lowCount;

  const SecurityReport({
    required this.items,
    required this.highCount,
    required this.mediumCount,
    required this.lowCount,
  });

  String get overallLevel {
    if (highCount > 0) return '高风险';
    if (mediumCount > 0) return '中风险';
    if (lowCount > 0) return '低风险';
    return '安全';
  }
}
