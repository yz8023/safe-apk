/// Smali 方法模型
class SmaliMethod {
  final String className;
  final String methodName;
  final String descriptor;
  final String accessFlags;
  final String body;
  final int startLine;
  final int endLine;

  const SmaliMethod({
    required this.className,
    required this.methodName,
    required this.descriptor,
    required this.accessFlags,
    required this.body,
    required this.startLine,
    required this.endLine,
  });
}

/// Smali 补丁结果
class PatchResult {
  final bool success;
  final String? filePath;
  final String? originalCode;
  final String? newCode;
  final String? error;

  const PatchResult({
    required this.success,
    this.filePath,
    this.originalCode,
    this.newCode,
    this.error,
  });
}

/// Smali 搜索匹配
class SmaliSearchResult {
  final String filePath;
  final int lineNumber;
  final String content;
  final String? methodName;

  const SmaliSearchResult({
    required this.filePath,
    required this.lineNumber,
    required this.content,
    this.methodName,
  });
}
