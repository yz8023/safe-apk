/// DEX 类结构模型
class DexClass {
  final String name;
  final List<DexMethod> methods;
  final List<DexField> fields;
  final String? superClass;
  final List<String> interfaces;
  final int accessFlags;

  const DexClass({
    required this.name,
    this.methods = const [],
    this.fields = const [],
    this.superClass,
    this.interfaces = const [],
    this.accessFlags = 0,
  });

  String get simpleName => name.split('/').last.replaceAll(';', '');
  String get packageName {
    final parts = name.replaceAll('L', '').replaceAll(';', '').split('/');
    if (parts.length > 1) parts.removeLast();
    return parts.join('.');
  }
}

class DexMethod {
  final String name;
  final String descriptor;
  final int accessFlags;
  final int codeSize;

  const DexMethod({
    required this.name,
    required this.descriptor,
    this.accessFlags = 0,
    this.codeSize = 0,
  });

  /// 返回类型，如 'V', 'Z', 'Ljava/lang/String;'
  String get returnType {
    final idx = descriptor.lastIndexOf(')');
    return idx >= 0 ? descriptor.substring(idx + 1) : 'V';
  }

  /// 参数类型列表
  List<String> get paramTypes {
    final start = descriptor.indexOf('(');
    final end = descriptor.indexOf(')');
    if (start < 0 || end < 0 || end <= start + 1) return [];
    return _parseTypes(descriptor.substring(start + 1, end));
  }

  static List<String> _parseTypes(String s) {
    final types = <String>[];
    int i = 0;
    while (i < s.length) {
      if (s[i] == '[') {
        // 数组类型
        int j = i + 1;
        while (j < s.length && s[j] == '[') j++;
        if (j < s.length && s[j] == 'L') {
          final end = s.indexOf(';', j);
          if (end >= 0) {
            types.add(s.substring(i, end + 1));
            i = end + 1;
            continue;
          }
        }
        types.add(s.substring(i, j + 1));
        i = j + 1;
      } else if (s[i] == 'L') {
        final end = s.indexOf(';', i);
        if (end >= 0) {
          types.add(s.substring(i, end + 1));
          i = end + 1;
        } else {
          break;
        }
      } else {
        types.add(s[i]);
        i++;
      }
    }
    return types;
  }
}

class DexField {
  final String name;
  final String type;
  final int accessFlags;

  const DexField({
    required this.name,
    required this.type,
    this.accessFlags = 0,
  });
}
