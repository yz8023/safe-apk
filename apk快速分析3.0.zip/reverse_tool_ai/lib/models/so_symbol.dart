/// ELF/SO 符号模型
class ElfInfo {
  final String arch;
  final String fileType;
  final bool is64Bit;
  final bool isLittleEndian;
  final int entryPoint;
  final int elfHeaderSize;
  final int flags;
  final String abi;
  final List<ElfSection> sections;
  final List<ProgramHeader> programHeaders;
  final List<ElfSymbol> symbols;
  final List<ElfSymbol> dynamicSymbols;
  final List<ElfSymbol> exports;
  final List<ElfSymbol> imports;
  final List<String> dependencies;
  final List<DynamicEntry> dynamicEntries;
  final List<RelocationEntry> relocations;
  final List<int> initArray;
  final List<int> finiArray;
  final String? soname;
  final String? runpath;
  final String? buildId;
  final SoSecurityFeatures? securityFeatures;
  final int fileSize;

  const ElfInfo({
    required this.arch,
    required this.fileType,
    required this.is64Bit,
    this.isLittleEndian = true,
    this.entryPoint = 0,
    this.elfHeaderSize = 0,
    this.flags = 0,
    this.abi = 'ELFOSABI_NONE',
    required this.sections,
    this.programHeaders = const [],
    required this.symbols,
    required this.dynamicSymbols,
    required this.exports,
    required this.imports,
    required this.dependencies,
    this.dynamicEntries = const [],
    this.relocations = const [],
    this.initArray = const [],
    this.finiArray = const [],
    this.soname,
    this.runpath,
    this.buildId,
    this.securityFeatures,
    this.fileSize = 0,
  });
}

class ElfSection {
  final int index;
  final String name;
  final int type;
  final int address;
  final int offset;
  final int size;
  final int flags;
  final int link;
  final int info;
  final int addrAlign;
  final int entSize;

  const ElfSection({
    required this.index,
    required this.name,
    required this.type,
    required this.address,
    required this.offset,
    required this.size,
    this.flags = 0,
    this.link = 0,
    this.info = 0,
    this.addrAlign = 0,
    this.entSize = 0,
  });

  bool get isExecutable => (flags & 0x4) != 0;
  bool get isWritable => (flags & 0x1) != 0;
  bool get isReadable => (flags & 0x2) != 0;
  bool get isAlloc => (flags & 0x2) != 0;

  String get typeStr {
    switch (type) {
      case 0: return 'NULL';
      case 1: return 'PROGBITS';
      case 2: return 'SYMTAB';
      case 3: return 'STRTAB';
      case 4: return 'RELA';
      case 5: return 'HASH';
      case 6: return 'DYNAMIC';
      case 7: return 'NOTE';
      case 8: return 'NOBITS';
      case 9: return 'REL';
      case 10: return 'SHLIB';
      case 11: return 'DYNSYM';
      case 14: return 'INIT_ARRAY';
      case 15: return 'FINI_ARRAY';
      case 16: return 'PREINIT_ARRAY';
      case 17: return 'GROUP';
      case 18: return 'SYMTAB_SHNDX';
      case 0x6ffffff5: return 'GNU_ATTRIBUTES';
      case 0x6ffffff6: return 'GNU_HASH';
      case 0x6ffffffd: return 'GNU_verdef';
      case 0x6ffffffe: return 'GNU_verneed';
      case 0x6fffffff: return 'GNU_versym';
      default: return type >= 0x70000000 ? 'LOPROC' : '0x${type.toRadixString(16)}';
    }
  }

  String get flagsStr {
    final sb = StringBuffer();
    if (isWritable) sb.write('W');
    if (isAlloc) sb.write('A');
    if (isExecutable) sb.write('X');
    if ((flags & 0x10) != 0) sb.write('M'); // MERGE
    if ((flags & 0x20) != 0) sb.write('S'); // STRINGS
    if ((flags & 0x40) != 0) sb.write('I'); // INFO_LINK
    if ((flags & 0x80) != 0) sb.write('L'); // LINK_ORDER
    return sb.toString();
  }
}

class ElfSymbol {
  final String name;
  final int value;
  final int size;
  final String binding;
  final String type;
  final String visibility;
  final int sectionIndex;

  const ElfSymbol({
    required this.name,
    required this.value,
    required this.size,
    required this.binding,
    required this.type,
    this.visibility = 'DEFAULT',
    required this.sectionIndex,
  });

  String get sectionIndexStr {
    switch (sectionIndex) {
      case 0: return 'UNDEF';
      case 0xFFF1: return 'ABS';
      case 0xFFF2: return 'COMMON';
      case 0xFFFF: return 'XINDEX';
      default: return '$sectionIndex';
    }
  }
}

/// Program Header (段头)
class ProgramHeader {
  final int type;
  final int flags;
  final int offset;
  final int vaddr;
  final int paddr;
  final int filesz;
  final int memsz;
  final int align;

  const ProgramHeader({
    required this.type,
    required this.flags,
    required this.offset,
    required this.vaddr,
    required this.paddr,
    required this.filesz,
    required this.memsz,
    required this.align,
  });

  String get typeStr {
    switch (type) {
      case 0: return 'NULL';
      case 1: return 'LOAD';
      case 2: return 'DYNAMIC';
      case 3: return 'INTERP';
      case 4: return 'NOTE';
      case 5: return 'SHLIB';
      case 6: return 'PHDR';
      case 7: return 'TLS';
      case 0x6474e550: return 'GNU_EH_FRAME';
      case 0x6474e551: return 'GNU_STACK';
      case 0x6474e552: return 'GNU_RELRO';
      case 0x6474e553: return 'GNU_PROPERTY';
      default: return '0x${type.toRadixString(16)}';
    }
  }

  String get flagsStr {
    final sb = StringBuffer();
    if ((flags & 0x1) != 0) sb.write('X');
    if ((flags & 0x2) != 0) sb.write('W');
    if ((flags & 0x4) != 0) sb.write('R');
    return sb.toString();
  }

  bool get isExecutable => (flags & 0x1) != 0;
  bool get isWritable => (flags & 0x2) != 0;
  bool get isReadable => (flags & 0x4) != 0;
}

/// 动态段条目
class DynamicEntry {
  final int tag;
  final int value;
  final String tagName;
  final String? stringVal;

  const DynamicEntry({
    required this.tag,
    required this.value,
    required this.tagName,
    this.stringVal,
  });
}

/// 重定位条目
class RelocationEntry {
  final int offset;
  final int info;
  final int symIndex;
  final int relocType;
  final String? symbolName;
  final String relocTypeStr;
  final bool isAddend;

  const RelocationEntry({
    required this.offset,
    required this.info,
    required this.symIndex,
    required this.relocType,
    this.symbolName,
    required this.relocTypeStr,
    this.isAddend = false,
  });
}

/// SO 文件中提取的字符串
class SoString {
  final int offset;
  final String value;
  final String section;
  final int address;

  const SoString({
    required this.offset,
    required this.value,
    required this.section,
    this.address = 0,
  });

  int get length => value.length;

  /// 文件偏移的十六进制
  String get offsetHex => '0x${offset.toRadixString(16)}';

  /// 虚拟地址的十六进制
  String get addressHex => '0x${address.toRadixString(16)}';
}

/// 安全特性检测结果
class SoSecurityFeatures {
  final bool hasNX;
  final bool hasRELRO;
  final bool hasFullRELRO;
  final bool isPIE;
  final bool hasStackCanary;
  final bool hasFORTIFY;

  const SoSecurityFeatures({
    required this.hasNX,
    required this.hasRELRO,
    required this.hasFullRELRO,
    required this.isPIE,
    required this.hasStackCanary,
    required this.hasFORTIFY,
  });

  String get securityScore {
    int score = 0;
    if (hasNX) score++;
    if (hasFullRELRO) score += 2;
    else if (hasRELRO) score++;
    if (isPIE) score++;
    if (hasStackCanary) score++;
    if (hasFORTIFY) score++;
    return '$score/6';
  }

  String get securityLevel {
    int score = 0;
    if (hasNX) score++;
    if (hasFullRELRO) score += 2;
    else if (hasRELRO) score++;
    if (isPIE) score++;
    if (hasStackCanary) score++;
    if (hasFORTIFY) score++;
    if (score >= 5) return '高';
    if (score >= 3) return '中';
    return '低';
  }
}

/// 字符串交叉引用结果
class XrefResult {
  final int fileOffset;
  final int address;
  final String section;
  final String? referencedBy;
  final String context;

  const XrefResult({
    required this.fileOffset,
    required this.address,
    required this.section,
    this.referencedBy,
    required this.context,
  });

  String get addressHex => '0x${address.toRadixString(16)}';
  String get fileOffsetHex => '0x${fileOffset.toRadixString(16)}';
}

/// JNI 函数信息
class JniFunction {
  final String name;
  final int address;
  final String type; // 'static' or 'registered'

  const JniFunction({
    required this.name,
    required this.address,
    required this.type,
  });
}

/// 字节搜索结果
class ByteSearchResult {
  final int offset;
  final int address;
  final String section;
  final String hexDump;

  const ByteSearchResult({
    required this.offset,
    required this.address,
    required this.section,
    required this.hexDump,
  });
}
