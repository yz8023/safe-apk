/// 十六进制/二进制工具
class HexUtils {
  /// 字节数组转十六进制字符串
  static String bytesToHex(List<int> bytes, {String separator = ' '}) {
    return bytes.map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase()).join(separator);
  }

  /// 十六进制字符串转字节数组
  static List<int> hexToBytes(String hex) {
    final clean = hex.replaceAll(RegExp(r'[^0-9a-fA-F]'), '');
    if (clean.length % 2 != 0) return [];
    final bytes = <int>[];
    for (int i = 0; i < clean.length; i += 2) {
      bytes.add(int.parse(clean.substring(i, i + 2), radix: 16));
    }
    return bytes;
  }

  /// 读取小端 uint16
  static int readUint16LE(List<int> bytes, int offset) {
    if (offset + 1 >= bytes.length) return 0;
    return bytes[offset] | (bytes[offset + 1] << 8);
  }

  /// 读取小端 uint32
  static int readUint32LE(List<int> bytes, int offset) {
    if (offset + 3 >= bytes.length) return 0;
    return bytes[offset] |
        (bytes[offset + 1] << 8) |
        (bytes[offset + 2] << 16) |
        (bytes[offset + 3] << 24);
  }

  /// 读取大端 uint32
  static int readUint32BE(List<int> bytes, int offset) {
    if (offset + 3 >= bytes.length) return 0;
    return (bytes[offset] << 24) |
        (bytes[offset + 1] << 16) |
        (bytes[offset + 2] << 8) |
        bytes[offset + 3];
  }

  /// 读取小端 uint64
  static int readUint64LE(List<int> bytes, int offset) {
    final lo = readUint32LE(bytes, offset);
    final hi = readUint32LE(bytes, offset + 4);
    return (hi << 32) | (lo & 0xFFFFFFFF);
  }

  /// 读取大端 uint64
  static int readUint64BE(List<int> bytes, int offset) {
    final hi = readUint32BE(bytes, offset);
    final lo = readUint32BE(bytes, offset + 4);
    return (hi << 32) | (lo & 0xFFFFFFFF);
  }

  /// ULEB128 解码
  static int decodeULEB128(List<int> bytes, int offset) {
    int result = 0;
    int shift = 0;
    int pos = offset;
    while (pos < bytes.length) {
      final byte = bytes[pos++];
      result |= (byte & 0x7F) << shift;
      if ((byte & 0x80) == 0) break;
      shift += 7;
    }
    return result;
  }

  /// ULEB128p1 解码（用于 DEX string_ids）
  static int decodeULEB128p1(List<int> bytes, int offset) {
    return decodeULEB128(bytes, offset) - 1;
  }

  /// 格式化文件大小
  static String formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
    return '${(bytes / 1024 / 1024 / 1024).toStringAsFixed(1)} GB';
  }
}
