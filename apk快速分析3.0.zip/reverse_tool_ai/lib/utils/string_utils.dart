import 'dart:math' as math;

/// 字符串处理工具
class StringUtils {
  /// 检查字符串是否可打印（ASCII 范围）
  static bool isPrintable(String s) {
    return s.codeUnits.every((c) => c >= 32 && c < 127);
  }

  /// 检查字符串是否为有效的 Base64
  static bool isBase64(String s) {
    return RegExp(r'^[A-Za-z0-9+/]{4,}={0,2}$').hasMatch(s) &&
        s.length >= 8 &&
        s.length % 4 == 0;
  }

  /// 检查字符串是否为有效的十六进制
  static bool isHex(String s) {
    return RegExp(r'^[0-9a-fA-F]+$').hasMatch(s) && s.length >= 4;
  }

  /// 安全的字符串截断
  static String truncate(String s, int maxLen, {String ellipsis = '...'}) {
    if (s.length <= maxLen) return s;
    return s.substring(0, maxLen - ellipsis.length) + ellipsis;
  }

  /// 计算字符串信息熵（Shannon entropy）
  static double entropy(String s) {
    if (s.isEmpty) return 0;
    final freq = <int, int>{};
    for (final c in s.codeUnits) {
      freq[c] = (freq[c] ?? 0) + 1;
    }
    double ent = 0;
    for (final f in freq.values) {
      final p = f / s.length;
      ent -= p * (math.log(p) / math.ln2);
    }
    return ent;
  }

  /// DEX 类型描述符转人类可读
  static String dexTypeToReadable(String type) {
    final map = {
      'V': 'void',
      'Z': 'boolean',
      'B': 'byte',
      'S': 'short',
      'C': 'char',
      'I': 'int',
      'J': 'long',
      'F': 'float',
      'D': 'double',
    };
    if (map.containsKey(type)) return map[type]!;
    if (type.startsWith('[')) {
      return '${dexTypeToReadable(type.substring(1))}[]';
    }
    if (type.startsWith('L') && type.endsWith(';')) {
      return type.substring(1, type.length - 1).replaceAll('/', '.');
    }
    return type;
  }

  /// 检查字符串是否包含中文字符
  static bool hasChinese(String s) {
    return RegExp(r'[\u4e00-\u9fff]').hasMatch(s);
  }

  /// 安全的 substring，避免越界
  static String safeSubstring(String s, int start, int end) {
    if (start < 0) start = 0;
    if (end > s.length) end = s.length;
    if (start >= end) return '';
    return s.substring(start, end);
  }
}
