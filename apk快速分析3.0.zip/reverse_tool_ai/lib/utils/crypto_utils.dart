import 'dart:convert';
import 'string_utils.dart';

/// 加解密辅助工具
class CryptoUtils {
  /// 尝试 Base64 解码
  static String? tryBase64Decode(String s) {
    if (!StringUtils.isBase64(s)) return null;
    try {
      final decoded = base64.decode(s);
      final str = utf8.decode(decoded, allowMalformed: true);
      if (str.length > 2 && StringUtils.isPrintable(str)) {
        return str;
      }
    } catch (_) {}
    return null;
  }

  /// 尝试 Hex 解码
  static String? tryHexDecode(String s) {
    if (!StringUtils.isHex(s) || s.length % 2 != 0) return null;
    try {
      final bytes = <int>[];
      for (int i = 0; i < s.length; i += 2) {
        bytes.add(int.parse(s.substring(i, i + 2), radix: 16));
      }
      final str = utf8.decode(bytes, allowMalformed: true);
      if (str.length > 2 && StringUtils.isPrintable(str)) {
        return str;
      }
    } catch (_) {}
    return null;
  }

  /// 尝试 XOR 解密
  static String? tryXorDecode(String s, {List<int> keys = const [0, 1, 0xFF]}) {
    if (s.length < 4) return null;
    for (final key in keys) {
      try {
        final decoded = s.codeUnits
            .map((c) => c ^ key)
            .where((c) => c >= 32 && c < 127)
            .map((c) => String.fromCharCode(c))
            .join();
        if (decoded.length > 3 && StringUtils.isPrintable(decoded) && decoded != s) {
          return decoded;
        }
      } catch (_) {}
    }
    return null;
  }

  /// 尝试 ROT13
  static String? tryRot13(String s) {
    if (s.length < 4) return null;
    final result = s.split('').map((c) {
      final code = c.codeUnitAt(0);
      if (code >= 65 && code <= 90) return String.fromCharCode(((code - 65 + 13) % 26) + 65);
      if (code >= 97 && code <= 122) return String.fromCharCode(((code - 97 + 13) % 26) + 97);
      return c;
    }).join();
    if (result != s && StringUtils.isPrintable(result)) return result;
    return null;
  }

  /// 尝试 URL 解码
  static String? tryUrlDecode(String s) {
    if (!s.contains('%')) return null;
    try {
      final decoded = Uri.decodeComponent(s);
      if (decoded != s && decoded.length > 2) return decoded;
    } catch (_) {}
    return null;
  }

  /// 综合解密尝试
  static List<DecryptionAttempt> tryAll(String s) {
    final results = <DecryptionAttempt>[];
    final seen = <String>{};

    void add(String method, String? result) {
      if (result != null && result != s && result.length > 2 && !seen.contains(result)) {
        seen.add(result);
        results.add(DecryptionAttempt(original: s, method: method, result: result));
      }
    }

    add('base64', tryBase64Decode(s));
    add('hex', tryHexDecode(s));
    add('rot13', tryRot13(s));
    add('url', tryUrlDecode(s));
    for (final key in [0, 1, 0xFF]) {
      final decoded = s.codeUnits
          .map((c) => c ^ key)
          .where((c) => c >= 32 && c < 127)
          .map((c) => String.fromCharCode(c))
          .join();
      if (decoded.length > 3 && decoded != s) {
        add('xor-$key', decoded);
      }
    }
    return results;
  }
}

class DecryptionAttempt {
  final String original;
  final String method;
  final String result;

  const DecryptionAttempt({
    required this.original,
    required this.method,
    required this.result,
  });
}
