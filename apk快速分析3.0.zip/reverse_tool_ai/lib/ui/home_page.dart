import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../providers/app_state_provider.dart';
import '../providers/apk_analysis_provider.dart';
import '../providers/so_analysis_provider.dart';
import '../services/file_picker_service.dart';
import '../widgets/info_card.dart';
import '../widgets/log_panel.dart';
import '../widgets/tree_panel.dart';
import '../widgets/ai_chat_panel.dart';
import '../core/apk_signer.dart';
import '../core/dex_disassembler.dart';
import '../core/cert_parser.dart';
import '../core/manifest_parser.dart';
import '../core/apk_analyzer.dart';
import '../core/xref_analyzer.dart';
import '../core/call_graph_analyzer.dart';
import '../core/inheritance_analyzer.dart';
import '../core/api_endpoint_extractor.dart';
import '../core/secret_detector.dart';
import '../core/anti_debug_detector.dart';
import '../core/frida_generator.dart';
import '../core/dex_editor.dart';
import '../widgets/result_panels.dart';
import '../widgets/so_analysis_panels.dart';
import '../models/apk_info.dart';
import '../models/so_symbol.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchController = TextEditingController();
  final _xrefController = TextEditingController();
  final _fridaFilterController = TextEditingController();
  final _dexEditOldController = TextEditingController();
  final _dexEditNewController = TextEditingController();
  bool _isClearingCache = false;
  XrefType _xrefType = XrefType.method;

  static const _tabs = ['apk', 'manifest', 'components', 'security', 'sdk', 'permissions', 'search', 'strings', 'so', 'disasm', 'urls', 'sensitive', 'reverse_kw', 'filetree', 'xref', 'callgraph', 'inheritance', 'apiendpoints', 'secrets', 'antidebug', 'frida', 'dexeditor'];
  static const _tabLabels = ['APK 分析', 'Manifest', '组件分析', '安全评估', 'SDK 检测', '权限分析', 'DEX 搜索', '字符串', 'SO 分析', 'DEX 反汇编', 'URL/IP', '敏感 API', '逆向关键词', '文件结构', '交叉引用', '调用图', '继承关系', 'API端点', '密钥检测', '反调试', 'Frida', 'DEX编辑'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        context.read<AppStateProvider>().setTab(_tabs[_tabController.index]);
        // 自动加载对应 tab 数据
        _autoLoadTabData(_tabController.index);
      }
    });
  }

  void _autoLoadTabData(int index) {
    final apkProv = context.read<ApkAnalysisProvider>();
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath == null) return;
    final path = appState.currentFilePath!;
    final tab = _tabs[index];

    if (tab == 'urls' && apkProv.urls.isEmpty) {
      apkProv.extractUrls(path);
    } else if (tab == 'sensitive' && apkProv.sensitiveApis.isEmpty) {
      apkProv.detectSensitiveApis(path);
    } else if (tab == 'reverse_kw' && apkProv.reverseKeywords.isEmpty) {
      apkProv.detectReverseKeywords(path);
    } else if (tab == 'filetree' && apkProv.fileTree.isEmpty) {
      apkProv.loadFileTree(path);
    } else if (tab == 'sdk' && apkProv.sdkResult == null) {
      apkProv.detectSdks(path);
    } else if (tab == 'callgraph' && apkProv.callGraph == null) {
      apkProv.analyzeCallGraph(path);
    } else if (tab == 'inheritance' && apkProv.inheritanceTree == null) {
      apkProv.analyzeInheritance(path);
    } else if (tab == 'apiendpoints' && apkProv.apiEndpoints == null) {
      apkProv.extractApiEndpoints(path);
    } else if (tab == 'secrets' && apkProv.secretResult == null) {
      apkProv.detectSecrets(path);
    } else if (tab == 'antidebug' && apkProv.antiDebugResult == null) {
      apkProv.detectAntiDebug(path);
    } else if (tab == 'dexeditor' && apkProv.dexStrings == null) {
      apkProv.listDexStrings(path);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    _xrefController.dispose();
    _fridaFilterController.dispose();
    _dexEditOldController.dispose();
    _dexEditNewController.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final path = await FilePickerService.pickApkOrSo();
    if (path == null) return;

    final appState = context.read<AppStateProvider>();
    final apkProv = context.read<ApkAnalysisProvider>();
    final soProv = context.read<SoAnalysisProvider>();

    appState.setFile(path);
    appState.clearLog();
    appState.log('📂 已选择: ${appState.currentFileName}\n\n');

    apkProv.clear();
    soProv.clear();

    if (path.endsWith('.so')) {
      await soProv.analyzeSo(path);
      if (soProv.error != null) {
        appState.log('❌ ${soProv.error}');
      } else if (soProv.elfInfo != null) {
        appState.log('✅ SO 分析完成: ${soProv.elfInfo!.arch}');
      }
    } else {
      await apkProv.analyzeApk(path);
      if (apkProv.error != null) {
        appState.log('❌ ${apkProv.error}');
      } else if (apkProv.apkInfo != null) {
        appState.log('✅ APK 分析完成: ${apkProv.apkInfo!.packageName}');
        if (apkProv.manifestInfo != null) {
          final m = apkProv.manifestInfo!;
          appState.log('   版本: ${m.versionName} (${m.versionCode})');
          if (m.minSdkVersion != null) appState.log('   minSdk: ${m.minSdkVersion}');
          if (m.targetSdkVersion != null) appState.log('   targetSdk: ${m.targetSdkVersion}');
          appState.log('   组件: ${m.components.length} (导出: ${m.exportedComponents.length})');
          if (m.deepLinks.isNotEmpty) appState.log('   深度链接: ${m.deepLinks.length}');
        }
        if (apkProv.signatureInfo != null) {
          appState.log('🔑 签名: ${apkProv.signatureInfo!.summary}');
        }
        if (apkProv.signatureBlock != null && apkProv.signatureBlock!.hasSigningBlock) {
          appState.log('   签名块: ${apkProv.signatureBlock!.summary}');
        }
        if (apkProv.certInfo != null) {
          appState.log('   证书: ${apkProv.certInfo!.subject}');
        }
        // 预加载 APK 内的 SO 文件列表
        await soProv.listApkSoFiles(path);
        if (soProv.apkSoEntries.isNotEmpty) {
          appState.log('📦 发现 ${soProv.apkSoEntries.length} 个 SO 文件 (可在 SO 分析标签中选择)');
        }
      }
    }
  }

  Future<void> _exportReport() async {
    final appState = context.read<AppStateProvider>();
    final apkProv = context.read<ApkAnalysisProvider>();
    if (appState.currentFilePath == null) return;

    appState.log('📝 正在生成分析报告...');
    final report = await apkProv.generateReport(appState.currentFilePath!);
    if (report != null && mounted) {
      await Clipboard.setData(ClipboardData(text: report));
      appState.log('✅ 报告已生成并复制到剪贴板');
      if (mounted) {
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('分析报告'),
            content: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: SelectableText(
                  report,
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('关闭'),
              ),
            ],
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('智能逆向助手', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.folder_open),
            tooltip: '选择文件',
            onPressed: _pickFile,
          ),
          IconButton(
            icon: const Icon(Icons.delete_sweep),
            tooltip: '清空日志',
            onPressed: () => context.read<AppStateProvider>().clearLog(),
          ),
          IconButton(
            icon: const Icon(Icons.assessment),
            tooltip: '导出报告',
            onPressed: _exportReport,
          ),
          IconButton(
            icon: _isClearingCache
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.cleaning_services),
            tooltip: '清理缓存',
            onPressed: _isClearingCache
                ? null
                : () async {
                    final apkProv = context.read<ApkAnalysisProvider>();
                    setState(() => _isClearingCache = true);
                    try {
                      final (freed, removed) = await apkProv.clearCaches();
                      if (mounted) {
                        final mb = (freed / (1024 * 1024)).toStringAsFixed(2);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('已清理缓存: $removed 个文件, 释放 ${mb} MB'),
                            duration: const Duration(seconds: 2),
                          ),
                        );
                      }
                    } catch (e) {
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('清理缓存失败: $e')),
                        );
                      }
                    } finally {
                      if (mounted) setState(() => _isClearingCache = false);
                    }
                  },
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: _tabLabels.map((l) => Tab(text: l)).toList(),
        ),
      ),
      body: Column(
        children: [
          Consumer<AppStateProvider>(
            builder: (_, appState, __) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              color: const Color(0xFF1A1A2E),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      appState.currentFileName ?? '未选择文件 - 点击右上角选择 APK/SO 文件',
                      style: TextStyle(
                        color: appState.currentFileName != null ? Colors.white70 : Colors.white38,
                        fontSize: 14,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (appState.currentFilePath != null)
                    FilledButton.tonal(
                      onPressed: _pickFile,
                      child: const Text('换文件', style: TextStyle(fontSize: 12)),
                    ),
                ],
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildApkTab(),
                _buildManifestTab(),
                _buildComponentsTab(),
                _buildSecurityTab(),
                _buildSdkTab(),
                _buildPermissionsTab(),
                _buildSearchTab(),
                _buildStringsTab(),
                _buildSoTab(),
                _buildDisasmTab(),
                _buildUrlsTab(),
                _buildSensitiveTab(),
                _buildReverseKeywordTab(),
                _buildFileTreeTab(),
                _buildXrefTab(),
                _buildCallGraphTab(),
                _buildInheritanceTab(),
                _buildApiEndpointsTab(),
                _buildSecretsTab(),
                _buildAntiDebugTab(),
                _buildFridaTab(),
                _buildDexEditorTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAiPanel(),
        tooltip: 'AI 智能分析',
        child: const Icon(Icons.smart_toy),
      ),
    );
  }

  /// 显示 AI 悬浮聊天面板
  void _showAiPanel() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (context) => const _AiFloatingPanel(),
    );
  }

  Widget _buildApkTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (apkProv.isAnalyzing && apkProv.apkInfo == null) {
          return _buildAnalysisProgressView(apkProv);
        }
        if (apkProv.apkInfo == null) {
          return const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.android, size: 80, color: Colors.white24),
                SizedBox(height: 16),
                Text('选择 APK 文件开始分析', style: TextStyle(color: Colors.white54, fontSize: 16)),
              ],
            ),
          );
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            InfoCard(info: apkProv.apkInfo!),
            // 分析进度（正在分析其他子项时显示）
            if (apkProv.isAnalyzing) _buildAnalysisProgressBar(apkProv),
            // 重新分析按钮
            _buildReanalyzeButton(apkProv, appState),
            // 快速概览卡片：加壳/SDK/Native/组件统计
            const SizedBox(height: 8),
            _buildQuickOverviewCard(apkProv),
            // 文件哈希
            if (apkProv.hashInfo != null) ...[
              const SizedBox(height: 8),
              _buildHashCard(apkProv.hashInfo!),
            ],
            // 文件大小分布
            if (apkProv.sizeBreakdown != null) ...[
              const SizedBox(height: 8),
              _buildSizeBreakdownCard(apkProv.sizeBreakdown!),
            ],
            if (apkProv.signatureInfo != null) ...[
              const SizedBox(height: 8),
              _SignatureChip(info: apkProv.signatureInfo!),
            ],
            if (apkProv.signatureBlock != null && apkProv.signatureBlock!.hasSigningBlock) ...[
              const SizedBox(height: 4),
              _SignatureBlockChip(info: apkProv.signatureBlock!),
            ],
            if (apkProv.certInfo != null) ...[
              const SizedBox(height: 8),
              _CertCard(info: apkProv.certInfo!),
            ],
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: appState.currentFilePath != null
                  ? () async {
                      await apkProv.detectObfuscation(appState.currentFilePath!);
                      if (apkProv.obfuscationResult != null) {
                        appState.log('🔍 混淆等级: ${apkProv.obfuscationResult!.suspicionLevel}');
                      }
                    }
                  : null,
              icon: const Icon(Icons.shield),
              label: Text(apkProv.obfuscationResult != null ? '重新检测混淆' : '检测混淆'),
            ),
            if (apkProv.obfuscationResult != null) ...[
              const SizedBox(height: 12),
              ObfuscationCard(result: apkProv.obfuscationResult!),
            ],
            const SizedBox(height: 12),
            if (apkProv.dexTree.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text('DEX 类树', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ),
              TreePanel(items: apkProv.dexTree),
            ],
            const SizedBox(height: 12),
            LogPanel(text: appState.logText),
          ],
        );
      },
    );
  }

  Widget _buildAnalysisProgressView(ApkAnalysisProvider apkProv) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.android, size: 60, color: Colors.tealAccent),
            const SizedBox(height: 24),
            Text(
              apkProv.analysisStage.isNotEmpty ? apkProv.analysisStage : '正在分析...',
              style: const TextStyle(fontSize: 16, color: Colors.white70),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: apkProv.analysisProgress > 0 ? apkProv.analysisProgress : null,
                backgroundColor: Colors.white10,
                color: Colors.tealAccent,
                minHeight: 8,
              ),
            ),
            const SizedBox(height: 8),
            if (apkProv.analysisProgress > 0)
              Text(
                '${(apkProv.analysisProgress * 100).toInt()}%',
                style: TextStyle(fontSize: 13, color: Colors.grey[400]),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalysisProgressBar(ApkAnalysisProvider apkProv) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            children: [
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2, color: Colors.tealAccent),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  apkProv.analysisStage,
                  style: const TextStyle(fontSize: 13, color: Colors.white70),
                ),
              ),
              Text(
                '${(apkProv.analysisProgress * 100).toInt()}%',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildReanalyzeButton(ApkAnalysisProvider apkProv, AppStateProvider appState) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          FilledButton.tonalIcon(
            onPressed: apkProv.isAnalyzing || appState.currentFilePath == null
                ? null
                : () async {
                    await apkProv.clear();
                    await apkProv.analyzeApk(appState.currentFilePath!);
                    appState.log('🔄 重新分析完成');
                  },
            icon: const Icon(Icons.refresh, size: 18),
            label: const Text('重新分析', style: TextStyle(fontSize: 13)),
          ),
          const SizedBox(width: 8),
          if (apkProv.error != null)
            Expanded(
              child: Text(
                apkProv.error!,
                style: const TextStyle(fontSize: 12, color: Colors.redAccent),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildQuickOverviewCard(ApkAnalysisProvider apkProv) {
    final info = apkProv.apkInfo!;
    final manifest = apkProv.manifestInfo;
    final packer = apkProv.packerResult;
    final sdk = apkProv.sdkResult;
    final nativeLib = apkProv.nativeLibSummary;
    final res = apkProv.resInfo;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.dashboard, size: 18, color: Colors.tealAccent),
                const SizedBox(width: 8),
                const Text('快速概览', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ],
            ),
            const Divider(height: 12),
            // 加壳检测
            if (packer != null)
              _overviewRow(
                '加壳检测',
                packer.isPacked ? '⚠️ ${packer.packerName}' : '✅ 未加壳',
                packer.isPacked ? Colors.orangeAccent : Colors.green,
              ),
            // 组件统计
            if (manifest != null) ...[
              _overviewRow('Activity', '${manifest.components.where((c) => c.type == 'activity').length} 个', Colors.blueAccent),
              _overviewRow('Service', '${manifest.components.where((c) => c.type == 'service').length} 个', Colors.tealAccent),
              _overviewRow('Receiver', '${manifest.components.where((c) => c.type == 'receiver').length} 个', Colors.purpleAccent),
              _overviewRow('Provider', '${manifest.components.where((c) => c.type == 'provider').length} 个', Colors.amber),
              _overviewRow('导出组件', '${manifest.exportedComponents.length} 个', manifest.exportedComponents.isNotEmpty ? Colors.orangeAccent : Colors.green),
              if (manifest.deepLinks.isNotEmpty)
                _overviewRow('Deep Link', '${manifest.deepLinks.length} 个', Colors.cyan),
            ],
            // SDK 检测
            if (sdk != null && sdk.sdks.isNotEmpty)
              _overviewRow('第三方 SDK', '${sdk.sdks.length} 个', Colors.blueAccent),
            // Native 库
            if (nativeLib != null && nativeLib.totalLibCount > 0)
              _overviewRow('Native 库', '${nativeLib.totalLibCount} 个 (${nativeLib.abis.join(", ")})', Colors.tealAccent),
            // 资源
            if (res != null)
              _overviewRow('资源表', '${res.packageCount} 包 / ${res.stringCount} 字符串', Colors.grey),
            // 安全标志
            if (manifest != null) ...[
              _overviewRow('debuggable', manifest.debuggable ? '⚠️ true' : '✅ false',
                manifest.debuggable ? Colors.redAccent : Colors.green),
              _overviewRow('allowBackup', manifest.allowBackup ? '⚠️ true' : 'false',
                manifest.allowBackup ? Colors.orangeAccent : Colors.grey),
            ],
          ],
        ),
      ),
    );
  }

  Widget _overviewRow(String label, String value, Color valueColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 13, color: Colors.white70)),
          Text(value, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: valueColor)),
        ],
      ),
    );
  }

  Widget _buildHashCard(ApkHashInfo hash) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.fingerprint, size: 18, color: Colors.cyanAccent),
                const SizedBox(width: 8),
                const Text('文件哈希', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              ],
            ),
            const Divider(height: 12),
            _hashRow('MD5', hash.md5),
            _hashRow('SHA-1', hash.sha1),
            _hashRow('SHA-256', hash.sha256),
          ],
        ),
      ),
    );
  }

  Widget _hashRow(String algo, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 60,
            child: Text(algo, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
          ),
          Expanded(
            child: SelectableText(
              value,
              style: const TextStyle(fontSize: 11, fontFamily: 'monospace', color: Colors.tealAccent),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSizeBreakdownCard(FileSizeBreakdown sb) {
    String fmtSize(int bytes) {
      if (bytes >= 1024 * 1024) return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
      if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
      return '$bytes B';
    }

    final bars = <_SizeBarData>[
      _SizeBarData('DEX 代码', sb.dexSize, sb.dexRatio, Colors.blue),
      _SizeBarData('资源文件', sb.resourcesSize, sb.resourcesRatio, Colors.green),
      _SizeBarData('Native 库', sb.nativeLibSize, sb.nativeLibRatio, Colors.orange),
      _SizeBarData('Assets', sb.assetsSize, sb.assetsRatio, Colors.purple),
      _SizeBarData('META-INF', sb.metaInfSize, sb.metaInfSize / (sb.totalSize > 0 ? sb.totalSize : 1), Colors.grey),
      _SizeBarData('其他', sb.otherSize, sb.otherSize / (sb.totalSize > 0 ? sb.totalSize : 1), Colors.brown),
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.pie_chart, size: 18, color: Colors.amberAccent),
                const SizedBox(width: 8),
                const Text('文件大小分布', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                const Spacer(),
                Text('总计 ${fmtSize(sb.totalSize)}',
                    style: TextStyle(fontSize: 12, color: Colors.grey[400])),
              ],
            ),
            const Divider(height: 12),
            ...bars.map((b) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  SizedBox(
                    width: 70,
                    child: Text(b.label, style: const TextStyle(fontSize: 12)),
                  ),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(4),
                      child: LinearProgressIndicator(
                        value: b.ratio,
                        backgroundColor: Colors.white10,
                        color: b.color,
                        minHeight: 14,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    width: 80,
                    child: Text(
                      '${fmtSize(b.size)} (${(b.ratio * 100).toStringAsFixed(0)}%)',
                      style: const TextStyle(fontSize: 11, color: Colors.grey),
                      textAlign: TextAlign.right,
                    ),
                  ),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildSecurityTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (apkProv.apkInfo == null) {
          return const Center(child: Text('选择 APK 文件后进行安全评估', style: TextStyle(color: Colors.white38)));
        }
        final report = apkProv.securityReport;
        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            if (report == null) ...[
              Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.security, size: 64, color: Colors.white24),
                    const SizedBox(height: 16),
                    FilledButton.icon(
                      onPressed: apkProv.isAnalyzing
                          ? null
                          : () => apkProv.assessSecurity(appState.currentFilePath!),
                      icon: const Icon(Icons.shield),
                      label: const Text('开始安全评估'),
                    ),
                  ],
                ),
              ),
            ] else ...[
              // 总览卡片
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Icon(
                        report.highCount > 0 ? Icons.dangerous : (report.mediumCount > 0 ? Icons.warning : Icons.verified_user),
                        size: 48,
                        color: report.highCount > 0 ? Colors.red : (report.mediumCount > 0 ? Colors.orange : Colors.green),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        report.overallLevel,
                        style: TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: report.highCount > 0 ? Colors.red : (report.mediumCount > 0 ? Colors.orange : Colors.green),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _riskChip('高危', report.highCount, Colors.red),
                          _riskChip('中危', report.mediumCount, Colors.orange),
                          _riskChip('低危', report.lowCount, Colors.yellow),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              // 详细项目
              ...report.items.map((item) => Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(
                        item.level == SecurityLevel.high ? Icons.error : (item.level == SecurityLevel.medium ? Icons.warning_amber : Icons.info_outline),
                        size: 20,
                        color: item.level == SecurityLevel.high ? Colors.red : (item.level == SecurityLevel.medium ? Colors.orange : Colors.blue),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(item.title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                                ),
                                _levelChip(item.level),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text(item.category, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                            const SizedBox(height: 4),
                            Text(item.description, style: const TextStyle(fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )),
            ],
          ],
        );
      },
    );
  }

  Widget _riskChip(String label, int count, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: color.withOpacity(0.5)),
          ),
          child: Text('$count', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
        ),
        const SizedBox(height: 4),
        Text(label, style: TextStyle(fontSize: 12, color: color)),
      ],
    );
  }

  Widget _levelChip(SecurityLevel level) {
    final (label, color) = switch (level) {
      SecurityLevel.high => ('高危', Colors.red),
      SecurityLevel.medium => ('中危', Colors.orange),
      SecurityLevel.low => ('低危', Colors.yellow.shade700),
      SecurityLevel.info => ('提示', Colors.blue),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildSdkTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (apkProv.apkInfo == null) {
          return const Center(child: Text('选择 APK 文件后检测 SDK', style: TextStyle(color: Colors.white38)));
        }
        final sdkResult = apkProv.sdkResult;
        if (sdkResult == null) {
          if (apkProv.isAnalyzing) {
            return const Center(child: CircularProgressIndicator());
          }
          return Center(
            child: FilledButton.icon(
              onPressed: appState.currentFilePath != null
                  ? () => apkProv.detectSdks(appState.currentFilePath!)
                  : null,
              icon: const Icon(Icons.search),
              label: const Text('开始检测 SDK'),
            ),
          );
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.extension, size: 20, color: Colors.cyanAccent),
                        const SizedBox(width: 8),
                        Text('检测到 ${sdkResult.totalSdkCount} 个第三方 SDK',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    if (sdkResult.categories.isNotEmpty) ...[
                      const Text('分类统计', style: TextStyle(fontSize: 13, color: Colors.grey)),
                      const SizedBox(height: 4),
                      Wrap(
                        spacing: 6,
                        runSpacing: 4,
                        children: sdkResult.categories.entries.map((e) {
                          return Chip(
                            label: Text('${e.key}: ${e.value}', style: const TextStyle(fontSize: 11)),
                            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            visualDensity: VisualDensity.compact,
                          );
                        }).toList(),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            ...sdkResult.sdks.map((sdk) => Card(
              child: ListTile(
                leading: _sdkCategoryIcon(sdk.category),
                title: Text(sdk.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(sdk.description, style: const TextStyle(fontSize: 12)),
                    const SizedBox(height: 2),
                    Wrap(
                      spacing: 4,
                      children: [
                        Chip(
                          label: Text(sdk.category, style: const TextStyle(fontSize: 10)),
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          visualDensity: VisualDensity.compact,
                        ),
                        ...sdk.matchedPatterns.take(2).map((p) => Chip(
                          label: Text(p, style: const TextStyle(fontSize: 9, fontFamily: 'monospace')),
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          visualDensity: VisualDensity.compact,
                        )),
                      ],
                    ),
                  ],
                ),
                trailing: Text('${sdk.matchedPatterns.length} 项匹配',
                    style: const TextStyle(fontSize: 11, color: Colors.grey)),
              ),
            )),
          ],
        );
      },
    );
  }

  Widget _sdkCategoryIcon(String category) {
    switch (category) {
      case '广告': return const Icon(Icons.ad_units, color: Colors.orangeAccent);
      case '统计': return const Icon(Icons.analytics, color: Colors.blueAccent);
      case '推送': return const Icon(Icons.notifications_active, color: Colors.redAccent);
      case '社交': return const Icon(Icons.people, color: Colors.purpleAccent);
      case '支付': return const Icon(Icons.payment, color: Colors.greenAccent);
      case '地图': return const Icon(Icons.map, color: Colors.tealAccent);
      case '安全': return const Icon(Icons.security, color: Colors.amberAccent);
      case '框架': return const Icon(Icons.code, color: Colors.cyanAccent);
      default: return const Icon(Icons.widgets, color: Colors.grey);
    }
  }

  Widget _buildPermissionsTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (apkProv.apkInfo == null) {
          return const Center(child: Text('选择 APK 文件后分析权限', style: TextStyle(color: Colors.white38)));
        }
        final permResult = apkProv.permResult;
        if (permResult == null) {
          return const Center(child: CircularProgressIndicator());
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.admin_panel_settings, size: 20, color: Colors.amberAccent),
                        const SizedBox(width: 8),
                        Text('权限风险分析 (${permResult.classifications.length})',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _permStatChip('危险', permResult.dangerousCount, Colors.redAccent),
                        const SizedBox(width: 8),
                        _permStatChip('普通', permResult.normalCount, Colors.greenAccent),
                        const SizedBox(width: 8),
                        _permStatChip('签名', permResult.signatureCount, Colors.orangeAccent),
                        const SizedBox(width: 8),
                        _permStatChip('未知', permResult.unknownCount, Colors.grey),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            // 危险权限优先显示
            if (permResult.dangerousCount > 0) ...[
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 4),
                child: Text('危险权限', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.redAccent)),
              ),
              ...permResult.classifications.where((p) => p.level.name == 'dangerous').map((p) => Card(
                color: Colors.red.withOpacity(0.08),
                child: ListTile(
                  leading: const Icon(Icons.warning, color: Colors.redAccent, size: 20),
                  title: Text(p.permission.split('.').last, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                  subtitle: Text(p.description, style: const TextStyle(fontSize: 11)),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: Colors.redAccent.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(p.riskLabel, style: const TextStyle(fontSize: 10, color: Colors.redAccent)),
                  ),
                ),
              )),
            ],
            // 其他权限
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 4),
              child: Text('其他权限', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.grey)),
            ),
            ...permResult.classifications.where((p) => p.level.name != 'dangerous').map((p) => Card(
              child: ListTile(
                leading: _permLevelIcon(p.level.name),
                title: Text(p.permission.split('.').last, style: const TextStyle(fontSize: 13)),
                subtitle: Text(p.description, style: const TextStyle(fontSize: 11)),
                trailing: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: _permLevelColor(p.level.name).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(p.riskLabel, style: TextStyle(fontSize: 10, color: _permLevelColor(p.level.name))),
                ),
              ),
            )),
          ],
        );
      },
    );
  }

  Widget _permStatChip(String label, int count, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text('$label: $count', style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.bold)),
    );
  }

  Icon _permLevelIcon(String level) {
    switch (level) {
      case 'dangerous': return const Icon(Icons.warning, color: Colors.redAccent, size: 20);
      case 'normal': return const Icon(Icons.check_circle, color: Colors.greenAccent, size: 20);
      case 'signature':
      case 'signatureOrSystem': return const Icon(Icons.lock, color: Colors.orangeAccent, size: 20);
      default: return const Icon(Icons.help, color: Colors.grey, size: 20);
    }
  }

  Color _permLevelColor(String level) {
    switch (level) {
      case 'dangerous': return Colors.redAccent;
      case 'normal': return Colors.greenAccent;
      case 'signature':
      case 'signatureOrSystem': return Colors.orangeAccent;
      default: return Colors.grey;
    }
  }

  Widget _buildManifestTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (apkProv.apkInfo == null) {
          return const Center(child: Text('选择 APK 文件后查看 Manifest', style: TextStyle(color: Colors.white38)));
        }
        final manifest = apkProv.manifestInfo;
        if (manifest == null) {
          return const Center(child: CircularProgressIndicator());
        }
        return ListView(
          padding: const EdgeInsets.all(12),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.description, size: 20, color: Colors.tealAccent),
                        const SizedBox(width: 8),
                        const Text('AndroidManifest.xml', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        const Spacer(),
                        IconButton(
                          icon: const Icon(Icons.copy, size: 18),
                          tooltip: '复制 XML',
                          onPressed: () {
                            Clipboard.setData(ClipboardData(text: manifest.xmlContent));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('已复制 Manifest XML'), duration: Duration(seconds: 1)),
                            );
                          },
                        ),
                      ],
                    ),
                    const Divider(height: 12),
                    // 快速信息摘要
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        if (manifest.debuggable)
                          _tagChip('debuggable', Colors.red),
                        if (manifest.allowBackup)
                          _tagChip('allowBackup', Colors.orange),
                        if (manifest.supportsRtl)
                          _tagChip('supportsRtl', Colors.blue),
                        if (manifest.isPersistent)
                          _tagChip('persistent', Colors.purple),
                        if (manifest.installLocation != null)
                          _tagChip('install: ${manifest.installLocation}', Colors.teal),
                      ],
                    ),
                    const SizedBox(height: 8),
                    // XML 文本
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1E1E),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      constraints: const BoxConstraints(maxHeight: 500),
                      child: SingleChildScrollView(
                        child: SelectableText(
                          manifest.xmlContent.isNotEmpty
                              ? manifest.xmlContent
                              : '<!-- XML 重建失败 -->',
                          style: const TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 11,
                            height: 1.4,
                            color: Colors.greenAccent,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            // 权限列表
            if (manifest.permissions.isNotEmpty) ...[
              _sectionTitle('权限 (${manifest.permissions.length})'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: manifest.permissions.map((p) {
                      final short = p.split('.').last;
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.lock, size: 14, color: Colors.amber),
                            const SizedBox(width: 8),
                            Expanded(
                              child: SelectableText(
                                p,
                                style: const TextStyle(fontSize: 12),
                              ),
                            ),
                            Text(short, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            // 特性声明
            if (manifest.features.isNotEmpty) ...[
              _sectionTitle('硬件/软件特性 (${manifest.features.length})'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: manifest.features.map((f) {
                      final short = f.split('.').last;
                      return Chip(
                        label: Text(short, style: const TextStyle(fontSize: 11)),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            // 深度链接
            if (manifest.deepLinks.isNotEmpty) ...[
              _sectionTitle('深度链接 / URI Scheme (${manifest.deepLinks.length})'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: manifest.deepLinks.map((link) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(
                          children: [
                            const Icon(Icons.link, size: 14, color: Colors.cyanAccent),
                            const SizedBox(width: 8),
                            Expanded(
                              child: SelectableText(
                                link.uri,
                                style: const TextStyle(fontSize: 12, color: Colors.cyanAccent),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            // meta-data
            if (manifest.metaData.isNotEmpty) ...[
              _sectionTitle('Meta-Data (${manifest.metaData.length})'),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: manifest.metaData.entries.map((e) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 2,
                              child: SelectableText(e.key, style: TextStyle(fontSize: 11, color: Colors.grey[400])),
                            ),
                            Expanded(
                              flex: 3,
                              child: SelectableText(e.value, style: const TextStyle(fontSize: 11)),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 12),
            LogPanel(text: appState.logText),
          ],
        );
      },
    );
  }

  Widget _buildComponentsTab() {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, apkProv, __) {
        if (apkProv.apkInfo == null) {
          return const Center(child: Text('选择 APK 文件后查看组件分析', style: TextStyle(color: Colors.white38)));
        }
        final manifest = apkProv.manifestInfo;
        if (manifest == null || manifest.components.isEmpty) {
          return const Center(child: Text('无组件信息', style: TextStyle(color: Colors.white38)));
        }

        final exported = manifest.exportedComponents;

        return DefaultTabController(
          length: 5,
          child: Column(
            children: [
              // 统计摘要
              Container(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    _statBadge('Activity', manifest.activityList.length, Colors.blue),
                    _statBadge('Service', manifest.serviceList.length, Colors.green),
                    _statBadge('Receiver', manifest.receiverList.length, Colors.orange),
                    _statBadge('Provider', manifest.providerList.length, Colors.purple),
                    _statBadge('导出', exported.length, Colors.red),
                  ],
                ),
              ),
              TabBar(
                isScrollable: true,
                tabAlignment: TabAlignment.start,
                tabs: const [
                  Tab(text: 'Activity'),
                  Tab(text: 'Service'),
                  Tab(text: 'Receiver'),
                  Tab(text: 'Provider'),
                  Tab(text: '导出组件'),
                ],
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    _buildComponentList(manifest.activityList),
                    _buildComponentList(manifest.serviceList),
                    _buildComponentList(manifest.receiverList),
                    _buildComponentList(manifest.providerList),
                    _buildComponentList(exported),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildComponentList(List<ComponentInfo> components) {
    if (components.isEmpty) {
      return const Center(child: Text('无', style: TextStyle(color: Colors.white38)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: components.length,
      itemBuilder: (ctx, i) {
        final comp = components[i];
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 4),
          child: ExpansionTile(
            leading: Icon(
              _componentIcon(comp.type),
              size: 20,
              color: comp.exported ? Colors.red : Colors.blue,
            ),
            title: Text(
              comp.shortName,
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
            ),
            subtitle: Text(
              comp.name,
              style: TextStyle(fontSize: 10, color: Colors.grey[500]),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _compDetailRow('类型', comp.type),
                    _compDetailRow('完整名称', comp.name),
                    _compDetailRow('导出', comp.exported ? 'true' : 'false',
                        color: comp.exported ? Colors.red : null),
                    _compDetailRow('启用', comp.enabled ? 'true' : 'false'),
                    if (comp.permission != null)
                      _compDetailRow('权限', comp.permission!),
                    if (comp.process != null)
                      _compDetailRow('进程', comp.process!),
                    if (comp.isLauncher)
                      _compDetailRow('启动器', 'LAUNCHER', color: Colors.green),
                    if (comp.intentFilters.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      const Text('Intent Filters', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      ...comp.intentFilters.map((iflt) => _buildIntentFilter(iflt)),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildIntentFilter(IntentFilterInfo iflt) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (iflt.actions.isNotEmpty)
            _ifRow('Action', iflt.actions, Colors.blueAccent),
          if (iflt.categories.isNotEmpty)
            _ifRow('Category', iflt.categories, Colors.greenAccent),
          if (iflt.dataSchemes.isNotEmpty)
            _ifRow('Scheme', iflt.dataSchemes, Colors.cyanAccent),
          if (iflt.dataHosts.isNotEmpty)
            _ifRow('Host', iflt.dataHosts, Colors.orangeAccent),
          if (iflt.dataPaths.isNotEmpty)
            _ifRow('Path', iflt.dataPaths, Colors.purpleAccent),
        ],
      ),
    );
  }

  Widget _ifRow(String label, List<String> values, Color color) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 70,
            child: Text(label, style: TextStyle(fontSize: 10, color: Colors.grey[500])),
          ),
          Expanded(
            child: Wrap(
              spacing: 4,
              runSpacing: 2,
              children: values.map((v) {
                final short = v.split('.').last;
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: color.withOpacity(0.4)),
                  ),
                  child: Text(short, style: TextStyle(fontSize: 10, color: color)),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  IconData _componentIcon(String type) {
    switch (type) {
      case 'activity': return Icons.phone_android;
      case 'service': return Icons.settings_applications;
      case 'receiver': return Icons.sensors;
      case 'provider': return Icons.storage;
      default: return Icons.extension;
    }
  }

  Widget _compDetailRow(String label, String value, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 70,
            child: Text(label, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
          ),
          Expanded(
            child: SelectableText(
              value,
              style: TextStyle(fontSize: 11, color: color),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statBadge(String label, int count, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Text('$count', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: color)),
            Text(label, style: TextStyle(fontSize: 10, color: color.withOpacity(0.8))),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(text, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
    );
  }

  Widget _tagChip(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(text, style: TextStyle(fontSize: 11, color: color)),
    );
  }

  Widget _buildSearchTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      decoration: const InputDecoration(
                        hintText: '输入类名/方法名搜索...',
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(),
                      ),
                      onSubmitted: (q) async {
                        if (appState.currentFilePath != null) {
                          await apkProv.searchInDex(appState.currentFilePath!, q);
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: apkProv.isAnalyzing || appState.currentFilePath == null
                        ? null
                        : () async {
                            await apkProv.searchInDex(appState.currentFilePath!, _searchController.text);
                          },
                    child: apkProv.isAnalyzing
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('搜索'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: apkProv.searchResult == null
                  ? const Center(child: Text('输入关键词搜索 DEX 中的类和方法', style: TextStyle(color: Colors.white38)))
                  : SearchResultPanel(result: apkProv.searchResult!),
            ),
            LogPanel(text: appState.logText, maxHeight: 150),
          ],
        );
      },
    );
  }

  Widget _buildStringsTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: FilledButton.icon(
                onPressed: apkProv.isAnalyzing || appState.currentFilePath == null
                    ? null
                    : () async {
                        await apkProv.analyzeStrings(appState.currentFilePath!);
                        if (apkProv.stringAnalysis != null) {
                          appState.log('🔓 发现 ${apkProv.stringAnalysis!.decryptedCount} 个加密字符串');
                        }
                      },
                icon: apkProv.isAnalyzing
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.lock_open),
                label: const Text('分析字符串加密'),
              ),
            ),
            Expanded(
              child: apkProv.stringAnalysis == null
                  ? const Center(child: Text('点击上方按钮分析 DEX 中的字符串加密', style: TextStyle(color: Colors.white38)))
                  : StringAnalysisPanel(analysis: apkProv.stringAnalysis!),
            ),
            LogPanel(text: appState.logText, maxHeight: 150),
          ],
        );
      },
    );
  }

  Widget _buildSoTab() {
    return Consumer2<SoAnalysisProvider, AppStateProvider>(
      builder: (_, soProv, appState, __) {
        if (soProv.isAnalyzing) {
          return const Center(child: CircularProgressIndicator());
        }
        if (soProv.elfInfo == null) {
          final hasApk = appState.currentFilePath != null &&
              appState.currentFilePath!.endsWith('.apk');
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.memory, size: 80, color: Colors.white24),
                const SizedBox(height: 16),
                const Text('选择 .so 文件分析 ELF 结构', style: TextStyle(color: Colors.white54, fontSize: 16)),
                if (hasApk) ...[
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: () => _showApkSoPicker(context, soProv, appState),
                    icon: const Icon(Icons.folder_zip),
                    label: const Text('从 APK 中选择 SO'),
                  ),
                ],
              ],
            ),
          );
        }
        return _SoTabContent(soProv: soProv, appState: appState);
      },
    );
  }

  Widget _buildDisasmTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.code, size: 80, color: Colors.white24),
                SizedBox(height: 16),
                Text('选择 APK 文件后，在此查看 DEX 指令反汇编（汇编级）',
                    style: TextStyle(color: Colors.white54, fontSize: 16)),
              ],
            ),
          );
        }
        if (apkProv.disassembly == null) {
          final busy = apkProv.isAnalyzing;
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('纯 Dart DEX 指令解码器 · 到汇编级（非 Java/Kotlin 源码）',
                    style: TextStyle(color: Colors.white54)),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: busy
                      ? null
                      : () async {
                          await apkProv.disassembleDex(appState.currentFilePath!);
                          if (apkProv.disassembly != null) {
                            appState.log(
                                '🔧 DEX 反汇编完成: ${apkProv.disassembly!.classes.length} 类 / '
                                '${apkProv.disassembly!.totalMethods} 方法 / '
                                '${apkProv.disassembly!.totalInstructions} 条指令');
                          }
                        },
                  icon: busy
                      ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.bolt),
                  label: Text(busy ? '反汇编中...' : '开始反汇编'),
                ),
              ],
            ),
          );
        }
        return _DisasmExplorer(disasm: apkProv.disassembly!);
      },
    );
  }

  Widget _buildUrlsTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('选择 APK 文件后提取 URL/IP', style: TextStyle(color: Colors.white38)));
        }
        if (apkProv.isAnalyzing && apkProv.urls.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }
        if (apkProv.urls.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.link_off, size: 48, color: Colors.white24),
                const SizedBox(height: 8),
                const Text('未找到 URL/IP', style: TextStyle(color: Colors.white38)),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () => apkProv.extractUrls(appState.currentFilePath!),
                  icon: const Icon(Icons.refresh),
                  label: const Text('重新提取'),
                ),
              ],
            ),
          );
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Text('发现 ${apkProv.urls.length} 个 URL/IP', style: const TextStyle(color: Colors.white54, fontSize: 13)),
                  const Spacer(),
                  FilledButton.tonal(
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: apkProv.urls.join('\n')));
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('已复制到剪贴板'), duration: Duration(seconds: 1)),
                        );
                      }
                    },
                    child: const Text('复制全部', style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: apkProv.urls.length,
                itemBuilder: (ctx, i) {
                  final url = apkProv.urls[i];
                  final isUrl = url.startsWith('http');
                  return Card(
                    margin: const EdgeInsets.only(bottom: 4),
                    child: ListTile(
                      leading: Icon(
                        isUrl ? Icons.language : Icons.dns,
                        size: 20,
                        color: isUrl ? Colors.blueAccent : Colors.orangeAccent,
                      ),
                      title: SelectableText(url, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                      dense: true,
                      trailing: isUrl
                          ? IconButton(
                              icon: const Icon(Icons.open_in_new, size: 18, color: Colors.blueAccent),
                              tooltip: '打开',
                              onPressed: () async {
                                final uri = Uri.tryParse(url);
                                if (uri != null) {
                                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                                }
                              },
                            )
                          : null,
                      onTap: isUrl
                          ? () async {
                              final uri = Uri.tryParse(url);
                              if (uri != null) {
                                await launchUrl(uri, mode: LaunchMode.externalApplication);
                              }
                            }
                          : null,
                    ),
                  );
                },
              ),
            ),
            LogPanel(text: appState.logText, maxHeight: 120),
          ],
        );
      },
    );
  }

  Widget _buildSensitiveTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('选择 APK 文件后检测敏感 API', style: TextStyle(color: Colors.white38)));
        }
        if (apkProv.isAnalyzing && apkProv.sensitiveApis.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }
        if (apkProv.sensitiveApis.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.security, size: 48, color: Colors.white24),
                const SizedBox(height: 8),
                const Text('未检测到敏感 API', style: TextStyle(color: Colors.white38)),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () => apkProv.detectSensitiveApis(appState.currentFilePath!),
                  icon: const Icon(Icons.refresh),
                  label: const Text('重新检测'),
                ),
              ],
            ),
          );
        }
        // 按类别分组
        final classItems = apkProv.sensitiveApis.where((s) => s.matchType == 'class').toList();
        final methodItems = apkProv.sensitiveApis.where((s) => s.matchType == 'method').toList();
        final stringItems = apkProv.sensitiveApis.where((s) => s.matchType == 'string').toList();

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Text(
                    '检测到 ${apkProv.sensitiveApis.length} 项 '
                    '(类:${classItems.length} 方法:${methodItems.length} 字符串:${stringItems.length})',
                    style: const TextStyle(color: Colors.white54, fontSize: 13),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: apkProv.sensitiveApis.length,
                itemBuilder: (ctx, i) {
                  final s = apkProv.sensitiveApis[i];
                  final color = s.matchType == 'class'
                      ? Colors.redAccent
                      : s.matchType == 'method'
                          ? Colors.orangeAccent
                          : Colors.yellowAccent;
                  final icon = s.matchType == 'class'
                      ? Icons.class_
                      : s.matchType == 'method'
                          ? Icons.functions
                          : Icons.text_snippet;
                  return Card(
                    margin: const EdgeInsets.only(bottom: 4),
                    child: ExpansionTile(
                      leading: Icon(icon, size: 20, color: color),
                      title: Text(s.keyword, style: const TextStyle(fontFamily: 'monospace', fontSize: 13)),
                      subtitle: Text(s.description, style: const TextStyle(fontSize: 11, color: Colors.white38)),
                      children: [
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(12),
                          color: const Color(0xFF0E0E1A),
                          child: SelectableText(
                            s.context,
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.white70),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            LogPanel(text: appState.logText, maxHeight: 120),
          ],
        );
      },
    );
  }

  Widget _buildReverseKeywordTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('选择 APK 文件后自动检测逆向关键词', style: TextStyle(color: Colors.white38)));
        }
        if (apkProv.isAnalyzing && apkProv.reverseKeywords.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }
        if (apkProv.reverseKeywords.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.search_off, size: 48, color: Colors.white24),
                const SizedBox(height: 8),
                const Text('未检测到逆向关键词', style: TextStyle(color: Colors.white38)),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () => apkProv.detectReverseKeywords(appState.currentFilePath!),
                  icon: const Icon(Icons.refresh),
                  label: const Text('重新检测'),
                ),
              ],
            ),
          );
        }

        // 按关键词分组统计
        final keywordGroups = <String, List<ReverseKeywordItem>>{};
        for (final item in apkProv.reverseKeywords) {
          keywordGroups.putIfAbsent(item.keyword, () => []).add(item);
        }
        final sortedKeywords = keywordGroups.keys.toList()..sort();

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Text(
                    '发现 ${apkProv.reverseKeywords.length} 个匹配 '
                    '(${keywordGroups.length} 个关键词)',
                    style: const TextStyle(color: Colors.white54, fontSize: 13),
                  ),
                  const Spacer(),
                  FilledButton.tonal(
                    onPressed: () async {
                      final buf = StringBuffer();
                      for (final item in apkProv.reverseKeywords) {
                        buf.writeln('[${item.keyword}] ${item.matchType}: ${item.fullContext}');
                      }
                      await Clipboard.setData(ClipboardData(text: buf.toString()));
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('已复制全部到剪贴板'), duration: Duration(seconds: 1)),
                        );
                      }
                    },
                    child: const Text('复制全部', style: TextStyle(fontSize: 12)),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: sortedKeywords.length,
                itemBuilder: (ctx, i) {
                  final kw = sortedKeywords[i];
                  final items = keywordGroups[kw]!;
                  return Card(
                    margin: const EdgeInsets.only(bottom: 6),
                    child: ExpansionTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.deepPurple.withOpacity(0.3),
                        radius: 16,
                        child: Text(
                          '${items.length}',
                          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.deepPurpleAccent),
                        ),
                      ),
                      title: Text(
                        kw,
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 14, fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        '${items.where((e) => e.matchType == 'method').length} 方法 / '
                        '${items.where((e) => e.matchType == 'string').length} 字符串 / '
                        '${items.where((e) => e.matchType == 'class').length} 类',
                        style: const TextStyle(fontSize: 11, color: Colors.white38),
                      ),
                      children: items.map((item) {
                        final typeColor = item.matchType == 'method'
                            ? Colors.orangeAccent
                            : item.matchType == 'class'
                                ? Colors.redAccent
                                : Colors.yellowAccent;
                        final typeIcon = item.matchType == 'method'
                            ? Icons.functions
                            : item.matchType == 'class'
                                ? Icons.class_
                                : Icons.text_snippet;
                        return GestureDetector(
                          onLongPress: () async {
                            await Clipboard.setData(ClipboardData(text: item.fullContext));
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('已复制'), duration: Duration(milliseconds: 800)),
                              );
                            }
                          },
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            decoration: BoxDecoration(
                              border: Border(top: BorderSide(color: Colors.white10)),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(typeIcon, size: 16, color: typeColor),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      if (item.className.isNotEmpty)
                                        Text(
                                          item.className,
                                          style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.grey[400]),
                                        ),
                                      SelectableText(
                                        item.memberName,
                                        style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Colors.white70),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        item.fullContext,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(fontFamily: 'monospace', fontSize: 10, color: Colors.grey[600]),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Icon(Icons.copy, size: 14, color: Colors.grey[600]),
                              ],
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  );
                },
              ),
            ),
            LogPanel(text: appState.logText, maxHeight: 100),
          ],
        );
      },
    );
  }

  Widget _buildFileTreeTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('选择 APK 文件后查看文件结构', style: TextStyle(color: Colors.white38)));
        }
        if (apkProv.isAnalyzing && apkProv.fileTree.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }
        if (apkProv.fileTree.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.folder, size: 48, color: Colors.white24),
                const SizedBox(height: 8),
                const Text('无法加载文件结构', style: TextStyle(color: Colors.white38)),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () => apkProv.loadFileTree(appState.currentFilePath!),
                  icon: const Icon(Icons.refresh),
                  label: const Text('重新加载'),
                ),
              ],
            ),
          );
        }

        // 计算深度缩进
        int getDepth(String path) => '/'.allMatches(path).length;

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                '共 ${apkProv.fileTree.where((n) => n.isFile).length} 个文件',
                style: const TextStyle(color: Colors.white54, fontSize: 13),
              ),
            ),
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                itemCount: apkProv.fileTree.length,
                itemBuilder: (ctx, i) {
                  final node = apkProv.fileTree[i];
                  final depth = getDepth(node.path);
                  final sizeStr = node.isFile
                      ? node.size > 1024
                          ? '${(node.size / 1024).toStringAsFixed(1)} KB'
                          : '${node.size} B'
                      : '';

                  return Padding(
                    padding: EdgeInsets.only(left: depth * 16.0, right: 8),
                    child: Row(
                      children: [
                        Icon(
                          node.isFile ? Icons.insert_drive_file : Icons.folder,
                          size: 16,
                          color: node.isFile ? Colors.white38 : Colors.blueAccent,
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            node.name,
                            style: TextStyle(
                              fontFamily: 'monospace',
                              fontSize: 12,
                              color: node.isFile ? Colors.white70 : Colors.blueAccent,
                              fontWeight: node.isFile ? FontWeight.normal : FontWeight.bold,
                            ),
                          ),
                        ),
                        if (node.isFile)
                          Text(sizeStr, style: TextStyle(fontSize: 10, color: Colors.grey[500])),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  // ==================== 新增功能 Tab ====================

  Widget _buildXrefTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('请先选择 APK 文件', style: TextStyle(color: Colors.grey)));
        }
        if (apkProv.isAnalyzing && apkProv.xrefResults == null) {
          return const Center(child: CircularProgressIndicator());
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _xrefController,
                      decoration: const InputDecoration(
                        labelText: '搜索目标 (方法名/字段名/字符串)',
                        hintText: '例如: onCreate or Lcom/example/MainActivity',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      onSubmitted: (v) {
                        if (v.isNotEmpty) {
                          apkProv.analyzeXref(appState.currentFilePath!, v, type: _xrefType);
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  DropdownButton<XrefType>(
                    value: _xrefType,
                    items: const [
                      DropdownMenuItem(value: XrefType.method, child: Text('方法')),
                      DropdownMenuItem(value: XrefType.field, child: Text('字段')),
                      DropdownMenuItem(value: XrefType.string, child: Text('字符串')),
                    ],
                    onChanged: (v) {
                      if (v != null) {
                        setState(() => _xrefType = v);
                      }
                    },
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: apkProv.isAnalyzing
                        ? null
                        : () {
                            if (_xrefController.text.isNotEmpty) {
                              apkProv.analyzeXref(appState.currentFilePath!, _xrefController.text, type: _xrefType);
                            }
                          },
                    child: const Text('搜索'),
                  ),
                ],
              ),
            ),
            if (apkProv.error != null && apkProv.xrefResults == null)
              Padding(padding: const EdgeInsets.all(16), child: Text(apkProv.error!, style: const TextStyle(color: Colors.red)))
            else if (apkProv.xrefResults == null || apkProv.xrefResults!.isEmpty)
              const Expanded(child: Center(child: Text('输入搜索关键词后点击搜索', style: TextStyle(color: Colors.grey))))
            else
              Expanded(
                child: ListView.builder(
                  itemCount: apkProv.xrefResults!.length,
                  itemBuilder: (_, i) {
                    final result = apkProv.xrefResults![i];
                    return ExpansionTile(
                      title: Text('${result.targetName} (${result.totalReferences} 处引用)',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 13)),
                      subtitle: Text('类型: ${result.type.name}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      children: result.references.map((ref) {
                        return ListTile(
                          dense: true,
                          leading: const Icon(Icons.arrow_right, size: 16, color: Colors.tealAccent),
                          title: Text('${ref.referrerClass} -> ${ref.referrerMethod}',
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                          subtitle: Text('偏移: 0x${ref.offset.toRadixString(16)}', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _buildCallGraphTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('请先选择 APK 文件', style: TextStyle(color: Colors.grey)));
        }
        if (apkProv.isAnalyzing && apkProv.callGraph == null) {
          return const Center(child: CircularProgressIndicator());
        }
        final cg = apkProv.callGraph;
        if (cg == null || cg.totalNodes == 0) {
          return const Center(child: Text('无调用图数据', style: TextStyle(color: Colors.grey)));
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  _statChip('节点', '${cg.totalNodes}', Colors.blueAccent),
                  const SizedBox(width: 8),
                  _statChip('边', '${cg.totalEdges}', Colors.tealAccent),
                  const SizedBox(width: 8),
                  _statChip('热点方法', '${cg.hotspotMethods.length}', Colors.orangeAccent),
                ],
              ),
            ),
            const Divider(height: 1),
            const Padding(
              padding: EdgeInsets.all(8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('热点方法 (被调用最多)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: cg.hotspotMethods.length,
                itemBuilder: (_, i) {
                  final desc = cg.hotspotMethods[i];
                  final node = cg.nodes.where((n) => n.descriptor == desc).firstOrNull;
                  final callerCount = node?.callerCount ?? 0;
                  return ListTile(
                    dense: true,
                    leading: CircleAvatar(
                      radius: 12,
                      backgroundColor: Colors.orangeAccent.withOpacity(0.2),
                      child: Text('${i + 1}', style: const TextStyle(fontSize: 10, color: Colors.orangeAccent)),
                    ),
                    title: Text(desc, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                    subtitle: Text('被调用 $callerCount 次', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildInheritanceTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('请先选择 APK 文件', style: TextStyle(color: Colors.grey)));
        }
        if (apkProv.isAnalyzing && apkProv.inheritanceTree == null) {
          return const Center(child: CircularProgressIndicator());
        }
        final tree = apkProv.inheritanceTree;
        if (tree == null || tree.totalClasses == 0) {
          return const Center(child: Text('无继承关系数据', style: TextStyle(color: Colors.grey)));
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  _statChip('总类数', '${tree.totalClasses}', Colors.blueAccent),
                  const SizedBox(width: 8),
                  _statChip('根类', '${tree.rootClasses.length}', Colors.tealAccent),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                itemCount: tree.rootClasses.length,
                itemBuilder: (_, i) {
                  final rootName = tree.rootClasses[i];
                  return _buildInheritanceNode(tree, rootName, 0);
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildInheritanceNode(InheritanceTree tree, String className, int depth) {
    final node = tree.tree[className];
    if (node == null) {
      return ListTile(
        dense: true,
        contentPadding: EdgeInsets.only(left: 16.0 + depth * 20, right: 8),
        leading: const Icon(Icons.class_, size: 16, color: Colors.grey),
        title: Text(className, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
      );
    }
    final hasChildren = node.children.isNotEmpty;
    if (!hasChildren) {
      return ListTile(
        dense: true,
        contentPadding: EdgeInsets.only(left: 16.0 + depth * 20, right: 8),
        leading: Icon(
          node.isInterface ? Icons.api : Icons.class_,
          size: 16,
          color: node.isInterface ? Colors.purpleAccent : (node.isFinal ? Colors.redAccent : Colors.blueAccent),
        ),
        title: Text(className.replaceAll('L', '').replaceAll(';', '').replaceAll('/', '.'),
          style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
        subtitle: node.interfaces.isNotEmpty
          ? Text('实现: ${node.interfaces.map((i) => i.replaceAll('L', '').replaceAll(';', '').replaceAll('/', '.')).join(', ')}',
              style: const TextStyle(fontSize: 10, color: Colors.grey), maxLines: 1, overflow: TextOverflow.ellipsis)
          : null,
      );
    }
    return ExpansionTile(
      tilePadding: EdgeInsets.only(left: 16.0 + depth * 20, right: 8),
      leading: Icon(
        node.isInterface ? Icons.api : Icons.class_,
        size: 16,
        color: node.isInterface ? Colors.purpleAccent : (node.isFinal ? Colors.redAccent : Colors.blueAccent),
      ),
      title: Text(className.replaceAll('L', '').replaceAll(';', '').replaceAll('/', '.'),
        style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
      subtitle: node.interfaces.isNotEmpty
        ? Text('实现: ${node.interfaces.map((i) => i.replaceAll('L', '').replaceAll(';', '').replaceAll('/', '.')).join(', ')}',
            style: const TextStyle(fontSize: 10, color: Colors.grey), maxLines: 1, overflow: TextOverflow.ellipsis)
        : null,
      children: node.children.map((child) => _buildInheritanceNode(tree, child, depth + 1)).toList(),
    );
  }

  Widget _buildApiEndpointsTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('请先选择 APK 文件', style: TextStyle(color: Colors.grey)));
        }
        if (apkProv.isAnalyzing && apkProv.apiEndpoints == null) {
          return const Center(child: CircularProgressIndicator());
        }
        final result = apkProv.apiEndpoints;
        if (result == null || result.totalEndpoints == 0) {
          return const Center(child: Text('未提取到 API 端点', style: TextStyle(color: Colors.grey)));
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  _statChip('端点数', '${result.totalEndpoints}', Colors.blueAccent),
                  const SizedBox(width: 8),
                  _statChip('唯一路径', '${result.pathStats.length}', Colors.tealAccent),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                itemCount: result.endpoints.length,
                itemBuilder: (_, i) {
                  final ep = result.endpoints[i];
                  final methodColor = _httpMethodColor(ep.httpMethod);
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    child: ListTile(
                      dense: true,
                      leading: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: methodColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: methodColor.withOpacity(0.5)),
                        ),
                        child: Text(ep.httpMethod, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: methodColor)),
                      ),
                      title: Text(ep.path, style: const TextStyle(fontFamily: 'monospace', fontSize: 13)),
                      subtitle: Text('匹配: ${ep.matchPattern}', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                      onTap: () => _showDetailDialog(context, 'API 端点详情', [
                        '路径: ${ep.path}',
                        '方法: ${ep.httpMethod}',
                        '匹配模式: ${ep.matchPattern}',
                        '来源字符串: ${ep.sourceString}',
                      ]),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildSecretsTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('请先选择 APK 文件', style: TextStyle(color: Colors.grey)));
        }
        if (apkProv.isAnalyzing && apkProv.secretResult == null) {
          return const Center(child: CircularProgressIndicator());
        }
        final result = apkProv.secretResult;
        if (result == null || result.findings.isEmpty) {
          return const Center(child: Text('未检测到硬编码密钥/Token', style: TextStyle(color: Colors.grey)));
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  if (result.highCount > 0) _statChip('高危', '${result.highCount}', Colors.redAccent),
                  if (result.highCount > 0) const SizedBox(width: 8),
                  if (result.mediumCount > 0) _statChip('中危', '${result.mediumCount}', Colors.orangeAccent),
                  if (result.mediumCount > 0) const SizedBox(width: 8),
                  if (result.lowCount > 0) _statChip('低危', '${result.lowCount}', Colors.yellowAccent),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                itemCount: result.findings.length,
                itemBuilder: (_, i) {
                  final f = result.findings[i];
                  final riskColor = f.riskLevel == SecretRiskLevel.high
                    ? Colors.redAccent
                    : (f.riskLevel == SecretRiskLevel.medium ? Colors.orangeAccent : Colors.yellowAccent);
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    child: ListTile(
                      dense: true,
                      leading: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                        decoration: BoxDecoration(
                          color: riskColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(f.riskLabel, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: riskColor)),
                      ),
                      title: Text('${f.type}: ${f.maskedValue}', style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                      subtitle: Text('来源: ${f.sourceLabel} - ${f.source}', style: const TextStyle(fontSize: 10, color: Colors.grey), maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => _showDetailDialog(context, '密钥详情', [
                        '类型: ${f.type}',
                        '风险等级: ${f.riskLabel}',
                        '脱敏值: ${f.maskedValue}',
                        '描述: ${f.description}',
                        '来源类型: ${f.sourceLabel}',
                        '来源: ${f.source}',
                      ]),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildAntiDebugTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('请先选择 APK 文件', style: TextStyle(color: Colors.grey)));
        }
        if (apkProv.isAnalyzing && apkProv.antiDebugResult == null) {
          return const Center(child: CircularProgressIndicator());
        }
        final result = apkProv.antiDebugResult;
        if (result == null || !result.hasProtection) {
          return const Center(child: Text('未检测到反逆向防护代码', style: TextStyle(color: Colors.grey)));
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  if (result.hasAntiDebug) _statChip('反调试', '${result.categoryCounts[AntiDebugCategory.antiDebug] ?? 0}', Colors.redAccent),
                  if (result.hasAntiRoot) _statChip('反Root', '${result.categoryCounts[AntiDebugCategory.antiRoot] ?? 0}', Colors.orangeAccent),
                  if (result.hasAntiEmulator) _statChip('反模拟器', '${result.categoryCounts[AntiDebugCategory.antiEmulator] ?? 0}', Colors.amber),
                  if (result.hasAntiHook) _statChip('反Hook', '${result.categoryCounts[AntiDebugCategory.antiHook] ?? 0}', Colors.redAccent),
                  if (result.hasIntegrityCheck) _statChip('完整性校验', '${result.categoryCounts[AntiDebugCategory.integrity] ?? 0}', Colors.purpleAccent),
                  if (result.hasSafetyNet) _statChip('SafetyNet', '${result.categoryCounts[AntiDebugCategory.safetynet] ?? 0}', Colors.blueAccent),
                  if (result.hasProxyDetection) _statChip('VPN/代理', '${result.categoryCounts[AntiDebugCategory.proxy] ?? 0}', Colors.tealAccent),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                itemCount: result.findings.length,
                itemBuilder: (_, i) {
                  final f = result.findings[i];
                  final riskColor = f.riskLevel == AntiDebugRiskLevel.high
                    ? Colors.redAccent
                    : (f.riskLevel == AntiDebugRiskLevel.medium ? Colors.orangeAccent : Colors.yellowAccent);
                  return Card(
                    margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    child: ListTile(
                      dense: true,
                      leading: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                        decoration: BoxDecoration(
                          color: riskColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(f.riskLabel, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: riskColor)),
                      ),
                      title: Text('[${f.categoryLabel}] ${f.keyword}', style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                      subtitle: Text(f.description, style: const TextStyle(fontSize: 10, color: Colors.grey), maxLines: 2, overflow: TextOverflow.ellipsis),
                      onTap: () => _showDetailDialog(context, '反逆向防护详情', [
                        '类别: ${f.categoryLabel}',
                        '风险等级: ${f.riskLabel}',
                        '关键字: ${f.keyword}',
                        '描述: ${f.description}',
                        '上下文: ${f.context}',
                      ]),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildFridaTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('请先选择 APK 文件', style: TextStyle(color: Colors.grey)));
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _fridaFilterController,
                      decoration: const InputDecoration(
                        labelText: '类名过滤 (可选)',
                        hintText: '例如: com.example 或留空生成全部',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    onPressed: apkProv.isAnalyzing
                        ? null
                        : () {
                            apkProv.generateFridaScript(
                              appState.currentFilePath!,
                              filter: _fridaFilterController.text.isEmpty ? null : _fridaFilterController.text,
                            );
                          },
                    icon: const Icon(Icons.code, size: 18),
                    label: const Text('生成'),
                  ),
                ],
              ),
            ),
            if (apkProv.isAnalyzing && apkProv.fridaScript == null)
              const Expanded(child: Center(child: CircularProgressIndicator()))
            else if (apkProv.fridaScript != null) ...[
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  children: [
                    _statChip('类', '${apkProv.fridaScript!.classCount}', Colors.blueAccent),
                    const SizedBox(width: 8),
                    _statChip('方法', '${apkProv.fridaScript!.methodCount}', Colors.tealAccent),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: apkProv.fridaScriptText ?? ''));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('已复制到剪贴板'), duration: Duration(seconds: 1)),
                        );
                      },
                      icon: const Icon(Icons.copy, size: 16),
                      label: const Text('复制'),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: Container(
                  color: const Color(0xFF1E1E1E),
                  padding: const EdgeInsets.all(8),
                  child: SingleChildScrollView(
                    child: SelectableText(
                      apkProv.fridaScriptText ?? '',
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Color(0xFFD4D4D4)),
                    ),
                  ),
                ),
              ),
            ] else
              const Expanded(child: Center(child: Text('点击"生成"按钮创建 Frida Hook 脚本', style: TextStyle(color: Colors.grey)))),
          ],
        );
      },
    );
  }

  Widget _buildDexEditorTab() {
    return Consumer2<ApkAnalysisProvider, AppStateProvider>(
      builder: (_, apkProv, appState, __) {
        if (appState.currentFilePath == null) {
          return const Center(child: Text('请先选择 APK 文件', style: TextStyle(color: Colors.grey)));
        }
        if (apkProv.isAnalyzing && apkProv.dexStrings == null) {
          return const Center(child: CircularProgressIndicator());
        }
        final strings = apkProv.dexStrings;
        if (strings == null || strings.isEmpty) {
          return const Center(child: Text('未找到 DEX 字符串', style: TextStyle(color: Colors.grey)));
        }
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  _statChip('字符串数', '${strings.length}', Colors.blueAccent),
                  const SizedBox(width: 8),
                  const Text('(仅 classes.dex)', style: TextStyle(fontSize: 11, color: Colors.grey)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _dexEditOldController,
                      decoration: const InputDecoration(
                        labelText: '原字符串',
                        isDense: true,
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _dexEditNewController,
                      decoration: const InputDecoration(
                        labelText: '新字符串 (≤原长度)',
                        isDense: true,
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: apkProv.isAnalyzing
                        ? null
                        : () async {
                            if (_dexEditOldController.text.isEmpty || _dexEditNewController.text.isEmpty) return;
                            final outputPath = '${appState.currentFilePath!.replaceAll('.apk', '')}_modified.apk';
                            await apkProv.modifyDexStringAndRepack(
                              appState.currentFilePath!,
                              _dexEditOldController.text,
                              _dexEditNewController.text,
                              outputPath,
                            );
                            if (apkProv.editResultMessage != null) {
                              // ignore: use_build_context_synchronously
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(apkProv.editResultMessage!)),
                              );
                            }
                          },
                    child: const Text('修改并重打包'),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.builder(
                itemCount: strings.length,
                itemBuilder: (_, i) {
                  final s = strings[i];
                  return ListTile(
                    dense: true,
                    leading: Text('#${s.index}', style: const TextStyle(fontSize: 10, color: Colors.grey, fontFamily: 'monospace')),
                    title: Text(s.value, style: const TextStyle(fontFamily: 'monospace', fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('长度: ${s.length} 字节', style: const TextStyle(fontSize: 10, color: Colors.grey)),
                    onTap: () {
                      _dexEditOldController.text = s.value;
                    },
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  // ==================== 辅助方法 ====================

  Widget _statChip(String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('$label: ', style: TextStyle(fontSize: 11, color: color.withOpacity(0.8))),
          Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }

  Color _httpMethodColor(String method) {
    switch (method.toUpperCase()) {
      case 'GET': return Colors.green;
      case 'POST': return Colors.blue;
      case 'PUT': return Colors.orange;
      case 'DELETE': return Colors.red;
      case 'PATCH': return Colors.purple;
      default: return Colors.grey;
    }
  }

  void _showDetailDialog(BuildContext context, String title, List<String> lines) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title, style: const TextStyle(fontSize: 16)),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: lines.map((l) => Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: SelectableText(l, style: const TextStyle(fontSize: 12, fontFamily: 'monospace')),
            )).toList(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('关闭')),
        ],
      ),
    );
  }
}

/// 文件大小条形图数据
class _SizeBarData {
  final String label;
  final int size;
  final double ratio;
  final Color color;

  const _SizeBarData(this.label, this.size, this.ratio, this.color);
}

/// 签名版本标签
class _SignatureChip extends StatelessWidget {
  final SignatureInfo info;
  const _SignatureChip({required this.info});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.blue.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.blue.withOpacity(0.5)),
          ),
          child: Text(
            info.summary,
            style: const TextStyle(fontSize: 12, color: Colors.blueAccent),
          ),
        ),
      ],
    );
  }
}

/// V2/V3 签名块标签
class _SignatureBlockChip extends StatelessWidget {
  final SignatureBlockInfo info;
  const _SignatureBlockChip({required this.info});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.green.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.green.withOpacity(0.4)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.verified, size: 14, color: Colors.greenAccent),
              const SizedBox(width: 4),
              Text(
                info.summary,
                style: const TextStyle(fontSize: 11, color: Colors.greenAccent),
              ),
              if (info.blockSize > 0) ...[
                const SizedBox(width: 4),
                Text(
                  '(${(info.blockSize / 1024).toStringAsFixed(1)} KB)',
                  style: TextStyle(fontSize: 10, color: Colors.greenAccent.withOpacity(0.7)),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

/// 证书信息卡片
class _CertCard extends StatelessWidget {
  final CertInfo info;
  const _CertCard({required this.info});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.key, size: 20, color: Colors.amberAccent),
                const SizedBox(width: 8),
                const Text('签名证书', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
            const Divider(height: 16),
            _Row(label: '主题 (CN)', value: info.subject),
            _Row(label: '签发者', value: info.issuer),
            _Row(label: '序列号', value: info.serialNumber),
            _Row(label: '算法', value: info.algorithm),
            _Row(label: '指纹', value: info.fingerprint),
            if (info.validFrom != null)
              _Row(label: '有效期起', value: info.validFrom.toString()),
            if (info.validTo != null)
              _Row(label: '有效期至', value: info.validTo.toString()),
          ],
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  const _Row({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(
            width: 90,
            child: Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          ),
          Expanded(
            child: SelectableText(value, style: const TextStyle(fontSize: 13)),
          ),
        ],
      ),
    );
  }
}

/// DEX 反汇编浏览：按类名筛选 -> 展开类 -> 展开方法查看 smali 汇编
class _DisasmExplorer extends StatefulWidget {
  final DisassemblyResult disasm;
  const _DisasmExplorer({required this.disasm});

  @override
  State<_DisasmExplorer> createState() => _DisasmExplorerState();
}

class _DisasmExplorerState extends State<_DisasmExplorer> {
  final _filterController = TextEditingController();

  @override
  void dispose() {
    _filterController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = _filterController.text.toLowerCase();
    final filtered = widget.disasm.classes
        .where((c) => c.name.toLowerCase().contains(q))
        .toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '共 ${widget.disasm.classes.length} 个类 · '
                '${widget.disasm.totalMethods} 个方法 · '
                '${widget.disasm.totalInstructions} 条指令（汇编级）',
                style: const TextStyle(color: Colors.white54, fontSize: 13),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _filterController,
                decoration: const InputDecoration(
                  hintText: '按类名筛选（如 com/foo/MainActivity）...',
                  prefixIcon: Icon(Icons.filter_alt),
                  border: OutlineInputBorder(),
                ),
                onChanged: (_) => setState(() {}),
              ),
            ],
          ),
        ),
        Expanded(
          child: filtered.isEmpty
              ? const Center(
                  child: Text('无匹配类', style: TextStyle(color: Colors.white38)))
              : ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (ctx, i) {
                    final cls = filtered[i];
                    return ExpansionTile(
                      title: Text(cls.name,
                          style: const TextStyle(
                              fontFamily: 'monospace', fontSize: 13)),
                      subtitle: Text(
                        '${cls.methods.length} 方法'
                        '${cls.superClass != null ? ' · 继承 ${cls.superClass}' : ''}',
                        style: const TextStyle(color: Colors.white38, fontSize: 11),
                      ),
                      children: cls.methods.map((m) {
                        return ExpansionTile(
                          tilePadding: const EdgeInsets.only(left: 24),
                          title: Text(
                            '${_methodAccessLabel(m.accessFlags)} ${m.name}${m.descriptor}',
                            style: const TextStyle(fontSize: 13),
                          ),
                          subtitle: Text(
                            'regs=${m.registers} ins=${m.insSize} outs=${m.outsSize} code=${m.codeSize}B',
                            style: const TextStyle(
                                color: Colors.white38, fontSize: 10),
                          ),
                          children: [
                            Container(
                              constraints: const BoxConstraints(maxHeight: 420),
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 4),
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: const Color(0xFF0E0E1A),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.white12),
                              ),
                              child: SingleChildScrollView(
                                child: SelectableText(
                                  m.smali.join('\n'),
                                  style: const TextStyle(
                                      fontFamily: 'monospace',
                                      fontSize: 12,
                                      color: Colors.white70),
                                ),
                              ),
                            ),
                          ],
                        );
                      }).toList(),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

/// 显示 APK 内 SO 文件选择对话框（顶层函数，供多处调用）
void _showApkSoPicker(
    BuildContext context, SoAnalysisProvider soProv, AppStateProvider appState) {
  final apkPath = appState.currentFilePath!;
  // 首次加载 SO 列表
  if (soProv.apkSoEntries.isEmpty) {
    soProv.listApkSoFiles(apkPath);
  }

  showDialog(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('选择 APK 内的 SO 文件'),
      content: SizedBox(
        width: double.maxFinite,
        child: Consumer<SoAnalysisProvider>(
          builder: (_, prov, __) {
            if (prov.isAnalyzing && prov.apkSoEntries.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }
            if (prov.apkSoEntries.isEmpty) {
              return const Text('APK 内未找到 SO 文件', style: TextStyle(color: Colors.white54));
            }
            // 按 ABI 分组
            final abiGroups = <String, List<ApkSoEntry>>{};
            for (final e in prov.apkSoEntries) {
              abiGroups.putIfAbsent(e.abi, () => []).add(e);
            }
            final sortedAbis = abiGroups.keys.toList()..sort();

            return ListView.builder(
              shrinkWrap: true,
              itemCount: sortedAbis.length,
              itemBuilder: (_, i) {
                final abi = sortedAbis[i];
                final entries = abiGroups[abi]!;
                return ExpansionTile(
                  dense: true,
                  title: Text(abi, style: const TextStyle(fontFamily: 'monospace', fontSize: 13, fontWeight: FontWeight.bold)),
                  subtitle: Text('${entries.length} 个 SO', style: const TextStyle(fontSize: 11, color: Colors.white38)),
                  children: entries.map((e) {
                    return ListTile(
                      dense: true,
                      leading: const Icon(Icons.memory, size: 18, color: Colors.deepPurpleAccent),
                      title: Text(e.name, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                      subtitle: Text(e.sizeStr, style: const TextStyle(fontSize: 10, color: Colors.white38)),
                      onTap: () {
                        Navigator.pop(ctx);
                        prov.analyzeSoFromApk(apkPath, e);
                        appState.log('📦 从 APK 提取 SO: ${e.fullPath} (${e.sizeStr})');
                      },
                    );
                  }).toList(),
                );
              },
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('取消'),
        ),
      ],
    ),
  );
}

/// 字符串元数据标签
class _StringMetaChip extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StringMetaChip({required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(fontSize: 10, fontFamily: 'monospace'),
          children: [
            TextSpan(text: '$label: ', style: TextStyle(color: color.withOpacity(0.7))),
            TextSpan(text: value, style: TextStyle(color: color)),
          ],
        ),
      ),
    );
  }
}

/// 详情行（用于 SO 字符串面板）
class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const _DetailRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(label, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
          ),
          Expanded(
            child: SelectableText(
              value,
              style: const TextStyle(fontSize: 11, color: Colors.white70, fontFamily: 'monospace'),
            ),
          ),
        ],
      ),
    );
  }
}

String _methodAccessLabel(int f) {
  final parts = <String>[];
  if (f & 0x1 != 0) parts.add('public');
  if (f & 0x2 != 0) parts.add('private');
  if (f & 0x4 != 0) parts.add('protected');
  if (f & 0x8 != 0) parts.add('static');
  if (f & 0x10 != 0) parts.add('final');
  if (f & 0x100 != 0) parts.add('native');
  if (f & 0x200 != 0) parts.add('abstract');
  return parts.join(' ');
}

/// SO 分析多子标签内容
class _SoTabContent extends StatefulWidget {
  final SoAnalysisProvider soProv;
  final AppStateProvider appState;
  const _SoTabContent({required this.soProv, required this.appState});

  @override
  State<_SoTabContent> createState() => _SoTabContentState();
}

class _SoTabContentState extends State<_SoTabContent> with SingleTickerProviderStateMixin {
  late TabController _soTabController;
  final _stringSearchController = TextEditingController();
  final _byteSearchController = TextEditingController();
  final _hexOffsetController = TextEditingController(text: '0');
  final _hexLengthController = TextEditingController(text: '256');

  static const _soTabs = ['overview', 'sections', 'segments', 'symbols', 'dynamic', 'relocs', 'strings', 'hex', 'bytes', 'jni'];
  static const _soTabLabels = ['概览', '节区', '段头', '符号', '动态段', '重定位', '字符串', 'Hex Dump', '字节搜索', 'JNI'];

  @override
  void initState() {
    super.initState();
    _soTabController = TabController(length: _soTabs.length, vsync: this);
    _soTabController.addListener(() {
      if (!_soTabController.indexIsChanging) {
        _autoLoadSoTabData(_soTabController.index);
      }
    });
  }

  @override
  void dispose() {
    _soTabController.dispose();
    _stringSearchController.dispose();
    _byteSearchController.dispose();
    _hexOffsetController.dispose();
    _hexLengthController.dispose();
    super.dispose();
  }

  void _autoLoadSoTabData(int index) {
    final tab = _soTabs[index];
    final path = widget.soProv.currentSoPath ?? widget.appState.currentFilePath;
    if (path == null) return;

    if (tab == 'strings' && widget.soProv.soStrings.isEmpty) {
      widget.soProv.extractStrings(path);
    } else if (tab == 'jni' && widget.soProv.jniFunctions.isEmpty) {
      widget.soProv.detectJniFunctions(path);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // SO 来源信息栏
        if (widget.soProv.currentSoSource != null)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            color: const Color(0xFF1A2A1A),
            child: Row(
              children: [
                const Icon(Icons.file_present, size: 16, color: Colors.greenAccent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    widget.soProv.currentSoSource!,
                    style: const TextStyle(fontSize: 11, color: Colors.greenAccent, fontFamily: 'monospace'),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                TextButton.icon(
                  onPressed: () {
                    final appState = widget.appState;
                    if (appState.currentFilePath != null &&
                        appState.currentFilePath!.endsWith('.apk')) {
                      _showApkSoPicker(context, widget.soProv, appState);
                    }
                  },
                  icon: const Icon(Icons.swap_horiz, size: 16),
                  label: const Text('切换 SO', style: TextStyle(fontSize: 11)),
                  style: TextButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    minimumSize: const Size(0, 28),
                  ),
                ),
              ],
            ),
          ),
        TabBar(
          controller: _soTabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: _soTabLabels.map((l) => Tab(text: l)).toList(),
        ),
        Expanded(
          child: TabBarView(
            controller: _soTabController,
            children: [
              SoOverviewPanel(info: widget.soProv.elfInfo!),
              SoSectionsPanel(info: widget.soProv.elfInfo!),
              SoProgramHeadersPanel(info: widget.soProv.elfInfo!),
              SoSymbolsPanel(info: widget.soProv.elfInfo!),
              SoDynamicPanel(info: widget.soProv.elfInfo!),
              SoRelocationsPanel(info: widget.soProv.elfInfo!),
              _buildStringsTab(),
              _buildHexTab(),
              _buildByteSearchTab(),
              _buildJniTab(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStringsTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _stringSearchController,
                  decoration: const InputDecoration(
                    hintText: '搜索字符串...',
                    prefixIcon: Icon(Icons.search, size: 20),
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onSubmitted: (q) {
                    final path = widget.soProv.currentSoPath ?? widget.appState.currentFilePath;
                    if (path != null && q.isNotEmpty) {
                      widget.soProv.searchStrings(path, q);
                    }
                  },
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: () {
                  final path = widget.soProv.currentSoPath ?? widget.appState.currentFilePath;
                  if (path != null) {
                    final q = _stringSearchController.text;
                    if (q.isEmpty) {
                      widget.soProv.extractStrings(path);
                    } else {
                      widget.soProv.searchStrings(path, q);
                    }
                  }
                },
                child: const Text('搜索', style: TextStyle(fontSize: 12)),
              ),
            ],
          ),
        ),
        if (widget.soProv.soStrings.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '${widget.soProv.soStrings.length} 个字符串'
                '${widget.soProv.stringXrefs.isNotEmpty ? ' · ${widget.soProv.stringXrefs.length} 个交叉引用' : ''}',
                style: const TextStyle(color: Colors.white38, fontSize: 12),
              ),
            ),
          ),
        // 修改结果提示
        if (widget.soProv.modifyResult != null)
          Container(
            width: double.infinity,
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: widget.soProv.modifyResult!.startsWith('成功')
                  ? Colors.green.withOpacity(0.15)
                  : Colors.red.withOpacity(0.15),
              borderRadius: BorderRadius.circular(6),
              border: Border.all(
                color: widget.soProv.modifyResult!.startsWith('成功')
                    ? Colors.green.withOpacity(0.4)
                    : Colors.red.withOpacity(0.4),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  widget.soProv.modifyResult!.startsWith('成功') ? Icons.check_circle : Icons.error,
                  size: 16,
                  color: widget.soProv.modifyResult!.startsWith('成功')
                      ? Colors.greenAccent
                      : Colors.redAccent,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: SelectableText(
                    widget.soProv.modifyResult!,
                    style: const TextStyle(fontSize: 11, color: Colors.white70),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 14),
                  constraints: const BoxConstraints(),
                  padding: EdgeInsets.zero,
                  onPressed: () => widget.soProv.clearModifyResult(),
                ),
              ],
            ),
          ),
        Expanded(
          child: widget.soProv.soStrings.isEmpty
              ? const Center(child: Text('点击搜索提取字符串', style: TextStyle(color: Colors.white38)))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  itemCount: widget.soProv.soStrings.length,
                  itemBuilder: (ctx, i) {
                    final s = widget.soProv.soStrings[i];
                    return GestureDetector(
                      onLongPress: () async {
                        await Clipboard.setData(ClipboardData(text: s.value));
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('已复制字符串内容'), duration: Duration(milliseconds: 800)),
                          );
                        }
                      },
                      child: Card(
                        margin: const EdgeInsets.only(bottom: 2),
                        child: ExpansionTile(
                          dense: true,
                          tilePadding: const EdgeInsets.symmetric(horizontal: 12),
                          title: SelectableText(
                            s.value,
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                            maxLines: 2,
                          ),
                          subtitle: Padding(
                            padding: const EdgeInsets.only(top: 2),
                            child: Wrap(
                              spacing: 8,
                              children: [
                                _StringMetaChip(
                                  label: '地址',
                                  value: s.addressHex,
                                  color: Colors.blueAccent,
                                ),
                                _StringMetaChip(
                                  label: '长度',
                                  value: '${s.length}',
                                  color: Colors.orangeAccent,
                                ),
                                _StringMetaChip(
                                  label: '段',
                                  value: s.section,
                                  color: Colors.grey,
                                ),
                              ],
                            ),
                          ),
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // 详细信息
                                  _DetailRow('虚拟地址', s.addressHex),
                                  _DetailRow('文件偏移', s.offsetHex),
                                  _DetailRow('长度', '${s.length} 字节'),
                                  _DetailRow('所属段', s.section),
                                  _DetailRow('内容', s.value),
                                  const SizedBox(height: 8),
                                  // 操作按钮
                                  Row(
                                    children: [
                                      FilledButton.tonalIcon(
                                        onPressed: widget.soProv.isAnalyzing
                                            ? null
                                            : () => _findStringXrefs(s),
                                        icon: const Icon(Icons.call_split, size: 16),
                                        label: const Text('查调用', style: TextStyle(fontSize: 11)),
                                        style: FilledButton.styleFrom(
                                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                          minimumSize: const Size(0, 32),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      FilledButton.tonalIcon(
                                        onPressed: widget.soProv.isAnalyzing
                                            ? null
                                            : () => _showModifyStringDialog(s),
                                        icon: const Icon(Icons.edit, size: 16),
                                        label: const Text('修改字符串', style: TextStyle(fontSize: 11)),
                                        style: FilledButton.styleFrom(
                                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                          minimumSize: const Size(0, 32),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      TextButton.icon(
                                        onPressed: () async {
                                          await Clipboard.setData(ClipboardData(text: s.value));
                                          if (mounted) {
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('已复制'), duration: Duration(milliseconds: 600)),
                                            );
                                          }
                                        },
                                        icon: const Icon(Icons.copy, size: 16),
                                        label: const Text('复制', style: TextStyle(fontSize: 11)),
                                        style: TextButton.styleFrom(
                                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                                          minimumSize: const Size(0, 32),
                                        ),
                                      ),
                                    ],
                                  ),
                                  // 交叉引用结果
                                  if (widget.soProv.stringXrefs.isNotEmpty) ...[
                                    const SizedBox(height: 12),
                                    const Divider(height: 1),
                                    const SizedBox(height: 8),
                                    Text(
                                      '交叉引用 (${widget.soProv.stringXrefs.length})',
                                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.amberAccent),
                                    ),
                                    const SizedBox(height: 4),
                                    ...widget.soProv.stringXrefs.map((x) => Padding(
                                      padding: const EdgeInsets.only(bottom: 4),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFF1A1A2E),
                                          borderRadius: BorderRadius.circular(4),
                                        ),
                                        child: Row(
                                          children: [
                                            Icon(Icons.arrow_right, size: 14, color: Colors.amberAccent[200]),
                                            const SizedBox(width: 4),
                                            Expanded(
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  SelectableText(
                                                    x.referencedBy ?? '(unknown function)',
                                                    style: TextStyle(
                                                      fontFamily: 'monospace',
                                                      fontSize: 11,
                                                      color: x.referencedBy != null
                                                          ? Colors.greenAccent
                                                          : Colors.white38,
                                                    ),
                                                  ),
                                                  SelectableText(
                                                    '${x.section}  addr=${x.addressHex}  offset=${x.fileOffsetHex}',
                                                    style: TextStyle(
                                                      fontFamily: 'monospace',
                                                      fontSize: 10,
                                                      color: Colors.grey[500],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    )),
                                  ],
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  /// 查找字符串交叉引用
  void _findStringXrefs(SoString target) {
    final path = widget.soProv.currentSoPath ?? widget.appState.currentFilePath;
    if (path == null) return;
    widget.soProv.findStringXrefs(path, target);
  }

  /// 显示修改字符串对话框
  void _showModifyStringDialog(SoString target) {
    final controller = TextEditingController(text: target.value);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('修改字符串'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('原字符串: ${target.value}', style: const TextStyle(fontSize: 12, color: Colors.white54)),
            const SizedBox(height: 4),
            Text('地址: ${target.addressHex} · 长度: ${target.length} 字节',
                style: const TextStyle(fontSize: 11, color: Colors.white38, fontFamily: 'monospace')),
            const SizedBox(height: 4),
            Text('新字符串长度不能超过 ${target.length} 字节',
                style: const TextStyle(fontSize: 11, color: Colors.orangeAccent)),
            const SizedBox(height: 12),
            TextField(
              controller: controller,
              maxLines: 3,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: '新字符串',
                labelStyle: TextStyle(fontSize: 12),
              ),
              style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消'),
          ),
          FilledButton(
            onPressed: () {
              final newPath = widget.soProv.currentSoPath ?? widget.appState.currentFilePath;
              if (newPath == null) return;
              Navigator.pop(ctx);
              widget.soProv.modifyString(newPath, target, controller.text);
            },
            child: const Text('确认修改'),
          ),
        ],
      ),
    );
  }

  Widget _buildHexTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              const Text('偏移: ', style: TextStyle(fontSize: 12, color: Colors.white54)),
              SizedBox(
                width: 80,
                child: TextField(
                  controller: _hexOffsetController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  ),
                  style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
                ),
              ),
              const SizedBox(width: 8),
              const Text('长度: ', style: TextStyle(fontSize: 12, color: Colors.white54)),
              SizedBox(
                width: 80,
                child: TextField(
                  controller: _hexLengthController,
                  decoration: const InputDecoration(
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  ),
                  style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: () {
                  final path = widget.soProv.currentSoPath ?? widget.appState.currentFilePath;
                  if (path == null) return;
                  final offset = int.tryParse(_hexOffsetController.text) ?? 0;
                  final length = int.tryParse(_hexLengthController.text) ?? 256;
                  widget.soProv.getHexDump(path, offset, length);
                },
                child: const Text('查看', style: TextStyle(fontSize: 12)),
              ),
            ],
          ),
        ),
        Expanded(
          child: widget.soProv.hexDump == null
              ? const Center(child: Text('输入偏移和长度查看 Hex Dump', style: TextStyle(color: Colors.white38)))
              : SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SelectableText(
                      widget.soProv.hexDump!,
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.white70),
                    ),
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildByteSearchTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _byteSearchController,
                  decoration: const InputDecoration(
                    hintText: 'Hex 模式 (如 5F2403D5 或 5F 24 ?? D5)',
                    prefixIcon: Icon(Icons.search, size: 20),
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  style: const TextStyle(fontSize: 12, fontFamily: 'monospace'),
                  onSubmitted: (q) {
                    final path = widget.soProv.currentSoPath ?? widget.appState.currentFilePath;
                    if (path != null && q.isNotEmpty) {
                      widget.soProv.searchBytes(path, q);
                    }
                  },
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: () {
                  final path = widget.soProv.currentSoPath ?? widget.appState.currentFilePath;
                  if (path != null && _byteSearchController.text.isNotEmpty) {
                    widget.soProv.searchBytes(path, _byteSearchController.text);
                  }
                },
                child: const Text('搜索', style: TextStyle(fontSize: 12)),
              ),
            ],
          ),
        ),
        if (widget.soProv.byteSearchResults.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '找到 ${widget.soProv.byteSearchResults.length} 个匹配',
                style: const TextStyle(color: Colors.white38, fontSize: 12),
              ),
            ),
          ),
        Expanded(
          child: widget.soProv.byteSearchResults.isEmpty
              ? const Center(child: Text('输入 Hex 模式搜索字节', style: TextStyle(color: Colors.white38)))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  itemCount: widget.soProv.byteSearchResults.length,
                  itemBuilder: (ctx, i) {
                    final r = widget.soProv.byteSearchResults[i];
                    return GestureDetector(
                      onLongPress: () async {
                        await Clipboard.setData(ClipboardData(text: r.hexDump));
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('已复制'), duration: Duration(milliseconds: 800)),
                          );
                        }
                      },
                      child: Card(
                        margin: const EdgeInsets.only(bottom: 2),
                        child: ListTile(
                          dense: true,
                          title: SelectableText(
                            r.hexDump,
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                          ),
                          subtitle: Text(
                            '${r.section}  offset=0x${r.offset.toRadixString(16)}  addr=0x${r.address.toRadixString(16)}',
                            style: TextStyle(fontSize: 10, color: Colors.grey[500]),
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildJniTab() {
    final jniFuncs = widget.soProv.jniFunctions;
    return Column(
      children: [
        if (jniFuncs.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                '检测到 ${jniFuncs.length} 个 JNI 相关函数',
                style: const TextStyle(color: Colors.white38, fontSize: 12),
              ),
            ),
          ),
        Expanded(
          child: jniFuncs.isEmpty
              ? const Center(child: Text('无 JNI 函数', style: TextStyle(color: Colors.white38)))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  itemCount: jniFuncs.length,
                  itemBuilder: (ctx, i) {
                    final f = jniFuncs[i];
                    final typeColor = f.type == 'static'
                        ? Colors.greenAccent
                        : f.type == 'onload'
                            ? Colors.orangeAccent
                            : Colors.blueAccent;
                    return GestureDetector(
                      onLongPress: () async {
                        await Clipboard.setData(ClipboardData(text: f.name));
                        if (mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('已复制'), duration: Duration(milliseconds: 800)),
                          );
                        }
                      },
                      child: Card(
                        margin: const EdgeInsets.only(bottom: 2),
                        child: ListTile(
                          dense: true,
                          leading: Icon(Icons.link, size: 16, color: typeColor),
                          title: SelectableText(
                            f.name,
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                          ),
                          subtitle: Text(
                            '${f.type}  addr=0x${f.address.toRadixString(16)}',
                            style: TextStyle(fontSize: 10, color: Colors.grey[500]),
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

/// AI 悬浮面板
///
/// 以半屏 BottomSheet 形式展示 AI 聊天界面，
/// 可拖拽调整高度，不影响主界面的逆向分析操作。
class _AiFloatingPanel extends StatefulWidget {
  const _AiFloatingPanel();

  @override
  State<_AiFloatingPanel> createState() => _AiFloatingPanelState();
}

class _AiFloatingPanelState extends State<_AiFloatingPanel> {
  double _heightFactor = 0.7;

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return FractionallySizedBox(
      heightFactor: _heightFactor,
      child: Column(
        children: [
          // 拖拽手柄
          GestureDetector(
            behavior: HitTestBehavior.translucent,
            onVerticalDragUpdate: (details) {
              setState(() {
                _heightFactor = (_heightFactor - details.delta.dy / screenHeight)
                    .clamp(0.3, 0.95);
              });
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white30,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
            ),
          ),
          // AI 聊天面板
          const Expanded(child: AiChatPanel()),
        ],
      ),
    );
  }
}
