import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../providers/apk_analysis_provider.dart';
import '../providers/app_state_provider.dart';
import '../core/xref_analyzer.dart';
import '../core/call_graph_analyzer.dart';
import '../core/inheritance_analyzer.dart';
import '../core/api_endpoint_extractor.dart';
import '../core/secret_detector.dart';
import '../core/anti_debug_detector.dart';
import '../core/dex_editor.dart';

/// 高级分析面板 - 包含交叉引用、调用图、继承树、API端点等新功能的 UI 组件

// ==================== 交叉引用分析面板 ====================

class XrefPanel extends StatefulWidget {
  const XrefPanel({super.key});
  @override
  State<XrefPanel> createState() => _XrefPanelState();
}

class _XrefPanelState extends State<XrefPanel> {
  final _queryController = TextEditingController();
  XrefType _searchType = XrefType.method;

  @override
  void dispose() {
    _queryController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, prov, __) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  DropdownButton<XrefType>(
                    value: _searchType,
                    items: const [
                      DropdownMenuItem(value: XrefType.method, child: Text('方法')),
                      DropdownMenuItem(value: XrefType.field, child: Text('字段')),
                      DropdownMenuItem(value: XrefType.string, child: Text('字符串')),
                    ],
                    onChanged: (v) => setState(() => _searchType = v!),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _queryController,
                      decoration: const InputDecoration(
                        hintText: '输入搜索关键词...',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      onSubmitted: (_) => _search(prov),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: prov.isAnalyzing ? null : () => _search(prov),
                    child: const Text('搜索'),
                  ),
                ],
              ),
            ),
            Expanded(child: _buildResults(prov)),
          ],
        );
      },
    );
  }

  void _search(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath == null || _queryController.text.isEmpty) return;
    prov.analyzeXref(appState.currentFilePath!, _queryController.text, type: _searchType);
  }

  Widget _buildResults(ApkAnalysisProvider prov) {
    if (prov.isAnalyzing) {
      return const Center(child: CircularProgressIndicator());
    }
    if (prov.error != null) {
      return Center(child: Text(prov.error!, style: const TextStyle(color: Colors.red)));
    }
    final results = prov.xrefResults;
    if (results == null || results.isEmpty) {
      return const Center(child: Text('输入关键词后搜索交叉引用', style: TextStyle(color: Colors.white38)));
    }
    return ListView.builder(
      itemCount: results.length,
      itemBuilder: (_, i) {
        final r = results[i];
        return ExpansionTile(
          title: Text('${r.targetName} (${r.totalReferences} 处引用)', style: const TextStyle(fontSize: 13)),
          subtitle: Text('类型: ${r.type.name}', style: const TextStyle(fontSize: 11, color: Colors.white38)),
          children: r.references.take(100).map((ref) => ListTile(
            dense: true,
            leading: const Icon(Icons.arrow_right, size: 16),
            title: Text('${ref.referrerClass}->${ref.referrerMethod}', style: const TextStyle(fontSize: 12)),
            subtitle: Text('偏移: 0x${ref.offset.toRadixString(16)}', style: const TextStyle(fontSize: 10, color: Colors.white38)),
          )).toList(),
        );
      },
    );
  }
}

// ==================== 方法调用图面板 ====================

class CallGraphPanel extends StatefulWidget {
  const CallGraphPanel({super.key});
  @override
  State<CallGraphPanel> createState() => _CallGraphPanelState();
}

class _CallGraphPanelState extends State<CallGraphPanel> {
  @override
  Widget build(BuildContext context) {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, prov, __) {
        if (prov.callGraph == null) {
          return Center(
            child: FilledButton(
              onPressed: prov.isAnalyzing ? null : () => _load(prov),
              child: const Text('生成方法调用图'),
            ),
          );
        }
        final cg = prov.callGraph!;
        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 16,
                children: [
                  _statChip('节点数', cg.totalNodes),
                  _statChip('边数', cg.totalEdges),
                  _statChip('热点方法', cg.hotspotMethods.length),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                children: [
                  const Padding(
                    padding: EdgeInsets.all(12),
                    child: Text('热点方法 (被调用最多)', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  ),
                  ...cg.hotspotMethods.map((m) => ListTile(
                    dense: true,
                    leading: const Icon(Icons.local_fire_department, size: 16, color: Colors.orange),
                    title: Text(m, style: const TextStyle(fontSize: 12)),
                  )),
                  const Divider(),
                  const Padding(
                    padding: EdgeInsets.all(12),
                    child: Text('调用关系详情', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                  ),
                  ...cg.nodes.take(200).map((n) => ExpansionTile(
                    title: Text('${n.className}->${n.methodName}', style: const TextStyle(fontSize: 12)),
                    subtitle: Text('调用 ${n.callees.length} | 被调 ${n.callers.length}', style: const TextStyle(fontSize: 10)),
                    children: [
                      if (n.callees.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(left: 32),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('调用:', style: TextStyle(fontSize: 11, color: Colors.green)),
                              ...n.callees.take(20).map((c) => Text('  → $c', style: const TextStyle(fontSize: 11))),
                            ],
                          ),
                        ),
                      if (n.callers.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(left: 32),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text('被调用:', style: TextStyle(fontSize: 11, color: Colors.blue)),
                              ...n.callers.take(20).map((c) => Text('  ← $c', style: const TextStyle(fontSize: 11))),
                            ],
                          ),
                        ),
                    ],
                  )),
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _statChip(String label, int value) {
    return Chip(
      label: Text('$label: $value', style: const TextStyle(fontSize: 12)),
      visualDensity: VisualDensity.compact,
    );
  }

  void _load(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath != null) {
      prov.analyzeCallGraph(appState.currentFilePath!);
    }
  }
}

// ==================== 类继承树面板 ====================

class InheritancePanel extends StatefulWidget {
  const InheritancePanel({super.key});
  @override
  State<InheritancePanel> createState() => _InheritancePanelState();
}

class _InheritancePanelState extends State<InheritancePanel> {
  @override
  Widget build(BuildContext context) {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, prov, __) {
        if (prov.inheritanceTree == null) {
          return Center(
            child: FilledButton(
              onPressed: prov.isAnalyzing ? null : () => _load(prov),
              child: const Text('生成继承关系树'),
            ),
          );
        }
        final tree = prov.inheritanceTree!;
        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              child: Text('总类数: ${tree.totalClasses} | 根类: ${tree.rootClasses.length}', style: const TextStyle(fontSize: 13)),
            ),
            Expanded(
              child: ListView(
                children: tree.rootClasses.take(500).map((rootName) {
                  final node = tree.tree[rootName];
                  if (node == null) return const SizedBox.shrink();
                  return _buildNode(node, tree, 0);
                }).toList(),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildNode(InheritanceNode node, InheritanceTree tree, int depth) {
    final children = tree.findSubclasses(node.className);
    return ExpansionTile(
      tilePadding: EdgeInsets.only(left: 16.0 * depth + 16),
      title: Text(node.className, style: const TextStyle(fontSize: 12)),
      subtitle: Text(
        '父类: ${node.superClassName ?? "无"} | 子类: ${children.length}'
        '${node.interfaces.isNotEmpty ? " | 接口: ${node.interfaces.length}" : ""}',
        style: const TextStyle(fontSize: 10, color: Colors.white38),
      ),
      children: children.take(100).map((c) {
        final childNode = tree.tree[c];
        if (childNode == null) return ListTile(dense: true, title: Text(c, style: const TextStyle(fontSize: 11)));
        return _buildNode(childNode, tree, depth + 1);
      }).toList(),
    );
  }

  void _load(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath != null) {
      prov.analyzeInheritance(appState.currentFilePath!);
    }
  }
}

// ==================== API 端点面板 ====================

class ApiEndpointPanel extends StatefulWidget {
  const ApiEndpointPanel({super.key});
  @override
  State<ApiEndpointPanel> createState() => _ApiEndpointPanelState();
}

class _ApiEndpointPanelState extends State<ApiEndpointPanel> {
  @override
  Widget build(BuildContext context) {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, prov, __) {
        if (prov.apiEndpoints == null) {
          return Center(
            child: FilledButton(
              onPressed: prov.isAnalyzing ? null : () => _load(prov),
              child: const Text('提取 API 端点'),
            ),
          );
        }
        final result = prov.apiEndpoints!;
        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              child: Text('发现 ${result.totalEndpoints} 个 API 端点', style: const TextStyle(fontSize: 13)),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: result.endpoints.length,
                itemBuilder: (_, i) {
                  final ep = result.endpoints[i];
                  return ListTile(
                    dense: true,
                    leading: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: _methodColor(ep.httpMethod),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(ep.httpMethod, style: const TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                    title: Text(ep.path, style: const TextStyle(fontSize: 12)),
                    subtitle: Text('来源: ${ep.sourceString.length > 80 ? "${ep.sourceString.substring(0, 80)}..." : ep.sourceString}', style: const TextStyle(fontSize: 10, color: Colors.white38)),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Color _methodColor(String method) {
    switch (method.toUpperCase()) {
      case 'GET': return Colors.blue;
      case 'POST': return Colors.green;
      case 'PUT': return Colors.orange;
      case 'DELETE': return Colors.red;
      default: return Colors.grey;
    }
  }

  void _load(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath != null) {
      prov.extractApiEndpoints(appState.currentFilePath!);
    }
  }
}

// ==================== 密钥检测面板 ====================

class SecretPanel extends StatefulWidget {
  const SecretPanel({super.key});
  @override
  State<SecretPanel> createState() => _SecretPanelState();
}

class _SecretPanelState extends State<SecretPanel> {
  @override
  Widget build(BuildContext context) {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, prov, __) {
        if (prov.secretResult == null) {
          return Center(
            child: FilledButton(
              onPressed: prov.isAnalyzing ? null : () => _load(prov),
              child: const Text('扫描硬编码密钥'),
            ),
          );
        }
        final result = prov.secretResult!;
        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 16,
                children: [
                  _chip('高危', result.highCount, Colors.red),
                  _chip('中危', result.mediumCount, Colors.orange),
                  _chip('低危', result.lowCount, Colors.blue),
                  _chip('总计', result.findings.length, Colors.grey),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: result.findings.length,
                itemBuilder: (_, i) {
                  final f = result.findings[i];
                  return ListTile(
                    dense: true,
                    leading: Icon(
                      Icons.warning,
                      size: 16,
                      color: f.riskLevel == SecretRiskLevel.high ? Colors.red :
                             f.riskLevel == SecretRiskLevel.medium ? Colors.orange : Colors.blue,
                    ),
                    title: Text(f.type, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                    subtitle: Text('${f.maskedValue}\n${f.description}', style: const TextStyle(fontSize: 10, color: Colors.white38)),
                    isThreeLine: true,
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _chip(String label, int count, Color color) {
    return Chip(
      label: Text('$label: $count', style: TextStyle(fontSize: 12, color: color)),
      visualDensity: VisualDensity.compact,
    );
  }

  void _load(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath != null) {
      prov.detectSecrets(appState.currentFilePath!);
    }
  }
}

// ==================== 反调试检测面板 ====================

class AntiDebugPanel extends StatefulWidget {
  const AntiDebugPanel({super.key});
  @override
  State<AntiDebugPanel> createState() => _AntiDebugPanelState();
}

class _AntiDebugPanelState extends State<AntiDebugPanel> {
  @override
  Widget build(BuildContext context) {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, prov, __) {
        if (prov.antiDebugResult == null) {
          return Center(
            child: FilledButton(
              onPressed: prov.isAnalyzing ? null : () => _load(prov),
              child: const Text('检测反逆向防护'),
            ),
          );
        }
        final result = prov.antiDebugResult!;
        return Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              child: Wrap(
                spacing: 8,
                children: [
                  if (result.hasAntiDebug) _badge('反调试', Colors.red),
                  if (result.hasAntiRoot) _badge('反Root', Colors.red),
                  if (result.hasAntiEmulator) _badge('反模拟器', Colors.orange),
                  if (result.hasAntiHook) _badge('反Hook', Colors.red),
                  if (result.hasIntegrityCheck) _badge('完整性校验', Colors.orange),
                  if (result.hasSafetyNet) _badge('SafetyNet', Colors.blue),
                  if (result.hasProxyDetection) _badge('代理检测', Colors.blue),
                  if (!result.hasAntiDebug && !result.hasAntiRoot && !result.hasAntiHook)
                    _badge('未检测到反逆向', Colors.green),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: result.findings.length,
                itemBuilder: (_, i) {
                  final f = result.findings[i];
                  return ListTile(
                    dense: true,
                    leading: Icon(Icons.shield, size: 16, color: _riskColor(f.riskLevel)),
                    title: Text('${f.categoryLabel}: ${f.keyword}', style: const TextStyle(fontSize: 12)),
                    subtitle: Text('${f.description}\n上下文: ${f.context}', style: const TextStyle(fontSize: 10, color: Colors.white38)),
                    isThreeLine: true,
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _badge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.3), borderRadius: BorderRadius.circular(8)),
      child: Text(text, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.bold)),
    );
  }

  Color _riskColor(AntiDebugRiskLevel level) {
    switch (level) {
      case AntiDebugRiskLevel.high: return Colors.red;
      case AntiDebugRiskLevel.medium: return Colors.orange;
      case AntiDebugRiskLevel.low: return Colors.blue;
    }
  }

  void _load(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath != null) {
      prov.detectAntiDebug(appState.currentFilePath!);
    }
  }
}

// ==================== Frida 脚本面板 ====================

class FridaPanel extends StatefulWidget {
  const FridaPanel({super.key});
  @override
  State<FridaPanel> createState() => _FridaPanelState();
}

class _FridaPanelState extends State<FridaPanel> {
  final _filterController = TextEditingController();

  @override
  void dispose() {
    _filterController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, prov, __) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _filterController,
                      decoration: const InputDecoration(
                        hintText: '类名过滤 (可选，如 com.example)',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: prov.isAnalyzing ? null : () => _load(prov),
                    child: const Text('生成脚本'),
                  ),
                  const SizedBox(width: 8),
                  if (prov.fridaScriptText != null)
                    FilledButton.tonal(
                      onPressed: () => _copy(prov),
                      child: const Text('复制'),
                    ),
                ],
              ),
            ),
            if (prov.fridaScript != null)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('类: ${prov.fridaScript!.classCount} | 方法: ${prov.fridaScript!.methodCount} | ${prov.fridaScript!.generatedAt}',
                  style: const TextStyle(fontSize: 11, color: Colors.white38)),
              ),
            Expanded(
              child: prov.fridaScriptText == null
                ? const Center(child: Text('点击"生成脚本"创建 Frida Hook 脚本', style: TextStyle(color: Colors.white38)))
                : SingleChildScrollView(
                    padding: const EdgeInsets.all(8),
                    child: SelectableText(
                      prov.fridaScriptText!,
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.green),
                    ),
                  ),
            ),
          ],
        );
      },
    );
  }

  void _load(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath != null) {
      prov.generateFridaScript(appState.currentFilePath!, filter: _filterController.text.isEmpty ? null : _filterController.text);
    }
  }

  void _copy(ApkAnalysisProvider prov) {
    if (prov.fridaScriptText != null) {
      Clipboard.setData(ClipboardData(text: prov.fridaScriptText!));
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已复制到剪贴板')));
    }
  }
}

// ==================== DEX 字符串编辑面板 ====================

class DexEditorPanel extends StatefulWidget {
  const DexEditorPanel({super.key});
  @override
  State<DexEditorPanel> createState() => _DexEditorPanelState();
}

class _DexEditorPanelState extends State<DexEditorPanel> {
  final _oldController = TextEditingController();
  final _newController = TextEditingController();

  @override
  void dispose() {
    _oldController.dispose();
    _newController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ApkAnalysisProvider>(
      builder: (_, prov, __) {
        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('DEX 字符串修改', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  const Text('修改 classes.dex 中的字符串并重新打包 APK。新字符串长度必须 ≤ 原字符串长度。',
                    style: TextStyle(fontSize: 11, color: Colors.white38)),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _oldController,
                    decoration: const InputDecoration(labelText: '原字符串', border: OutlineInputBorder(), isDense: true),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: _newController,
                    decoration: const InputDecoration(labelText: '新字符串', border: OutlineInputBorder(), isDense: true),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      FilledButton(
                        onPressed: prov.isAnalyzing ? null : () => _modify(prov),
                        child: const Text('修改并打包'),
                      ),
                      const SizedBox(width: 8),
                      FilledButton.tonal(
                        onPressed: prov.isAnalyzing ? null : () => _listStrings(prov),
                        child: const Text('列出字符串'),
                      ),
                      const SizedBox(width: 8),
                      FilledButton.tonal(
                        onPressed: prov.isAnalyzing ? null : () => _sign(prov),
                        child: const Text('V1签名'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if (prov.editResultMessage != null)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.symmetric(horizontal: 12),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: prov.editResultMessage!.contains('成功') ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SelectableText(prov.editResultMessage!, style: const TextStyle(fontSize: 11)),
              ),
            Expanded(
              child: prov.dexStrings == null
                ? const Center(child: Text('点击"列出字符串"查看 DEX 字符串列表', style: TextStyle(color: Colors.white38)))
                : ListView.builder(
                    itemCount: prov.dexStrings!.length,
                    itemBuilder: (_, i) {
                      final s = prov.dexStrings![i];
                      return ListTile(
                        dense: true,
                        leading: Text('#${s.index}', style: const TextStyle(fontSize: 10, color: Colors.white38)),
                        title: Text(s.value, style: const TextStyle(fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text('长度: ${s.length} | 偏移: 0x${s.offset.toRadixString(16)}', style: const TextStyle(fontSize: 9, color: Colors.white38)),
                        onTap: () {
                          _oldController.text = s.value;
                        },
                      );
                    },
                  ),
            ),
          ],
        );
      },
    );
  }

  void _modify(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath == null) return;
    if (_oldController.text.isEmpty || _newController.text.isEmpty) return;
    final outputPath = '/data/user/work/modified.apk';
    prov.modifyDexStringAndRepack(appState.currentFilePath!, _oldController.text, _newController.text, outputPath);
  }

  void _listStrings(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath != null) {
      prov.listDexStrings(appState.currentFilePath!);
    }
  }

  void _sign(ApkAnalysisProvider prov) {
    final appState = context.read<AppStateProvider>();
    if (appState.currentFilePath == null) return;
    final outputPath = '/data/user/work/signed.apk';
    prov.signApkV1(appState.currentFilePath!, outputPath);
  }
}
