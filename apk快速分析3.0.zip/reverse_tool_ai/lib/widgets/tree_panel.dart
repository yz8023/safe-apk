import 'package:flutter/material.dart';

/// DEX 类树面板
class TreePanel extends StatelessWidget {
  final List<String> items;
  const TreePanel({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0E0E1A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white12),
      ),
      constraints: const BoxConstraints(maxHeight: 350),
      child: ListView.builder(
        shrinkWrap: true,
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: items.length,
        itemBuilder: (ctx, i) {
          final line = items[i];
          final isDir = line.trimLeft().startsWith('📁');
          final indent = line.length - line.trimLeft().length;

          return Padding(
            padding: EdgeInsets.only(
              left: 12.0 + indent * 1.5,
              right: 12,
              top: 2,
              bottom: 2,
            ),
            child: Text(
              line.trimLeft(),
              style: TextStyle(
                fontFamily: 'monospace',
                fontSize: 12,
                color: isDir ? Colors.blueAccent : Colors.white70,
                fontWeight: isDir ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          );
        },
      ),
    );
  }
}
