import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/so_symbol.dart';

/// SO 概览面板
class SoOverviewPanel extends StatelessWidget {
  final ElfInfo info;
  const SoOverviewPanel({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.memory, size: 28, color: Colors.deepPurpleAccent),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${info.arch} · ${info.fileType}',
                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            info.is64Bit ? '64-bit · ${info.isLittleEndian ? "LE" : "BE"}' : '32-bit · ${info.isLittleEndian ? "LE" : "BE"}',
                            style: TextStyle(fontSize: 13, color: Colors.grey[400]),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const Divider(height: 24),
                _StatRow(label: '架构', value: info.arch),
                _StatRow(label: '文件类型', value: info.fileType),
                _StatRow(label: '位数', value: info.is64Bit ? '64-bit' : '32-bit'),
                _StatRow(label: '字节序', value: info.isLittleEndian ? 'Little Endian' : 'Big Endian'),
                _StatRow(label: 'ABI', value: info.abi),
                _StatRow(label: '入口点', value: '0x${info.entryPoint.toRadixString(16)}'),
                _StatRow(label: '文件大小', value: _formatSize(info.fileSize)),
                _StatRow(label: '节区数', value: '${info.sections.length}'),
                _StatRow(label: '程序头数', value: '${info.programHeaders.length}'),
                _StatRow(label: '符号数', value: '${info.symbols.length}'),
                _StatRow(label: '动态符号', value: '${info.dynamicSymbols.length}'),
                _StatRow(label: '导出符号', value: '${info.exports.length}'),
                _StatRow(label: '导入符号', value: '${info.imports.length}'),
                _StatRow(label: '重定位数', value: '${info.relocations.length}'),
                if (info.buildId != null)
                  _StatRow(label: 'Build ID', value: info.buildId!),
                if (info.soname != null)
                  _StatRow(label: 'SONAME', value: info.soname!),
                if (info.runpath != null)
                  _StatRow(label: 'RUNPATH', value: info.runpath!),
              ],
            ),
          ),
        ),
        if (info.dependencies.isNotEmpty) ...[
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('依赖库', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: info.dependencies.map((d) {
                      return Chip(
                        label: Text(d, style: const TextStyle(fontSize: 11)),
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        visualDensity: VisualDensity.compact,
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
          ),
        ],
        if (info.securityFeatures != null) ...[
          const SizedBox(height: 8),
          _SecurityCard(features: info.securityFeatures!),
        ],
        if (info.initArray.isNotEmpty || info.finiArray.isNotEmpty) ...[
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('初始化/终止函数', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  if (info.initArray.isNotEmpty) ...[
                    Text('.init_array (${info.initArray.length})', style: TextStyle(fontSize: 12, color: Colors.orangeAccent[200])),
                    const SizedBox(height: 4),
                    ...info.initArray.map((addr) => Padding(
                      padding: const EdgeInsets.only(left: 16, bottom: 2),
                      child: SelectableText(
                        '0x${addr.toRadixString(16)}',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.white70),
                      ),
                    )),
                  ],
                  if (info.finiArray.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text('.fini_array (${info.finiArray.length})', style: TextStyle(fontSize: 12, color: Colors.redAccent[200])),
                    const SizedBox(height: 4),
                    ...info.finiArray.map((addr) => Padding(
                      padding: const EdgeInsets.only(left: 16, bottom: 2),
                      child: SelectableText(
                        '0x${addr.toRadixString(16)}',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.white70),
                      ),
                    )),
                  ],
                ],
              ),
            ),
          ),
        ],
      ],
    );
  }

  String _formatSize(int bytes) {
    if (bytes >= 1024 * 1024) return '${(bytes / 1024 / 1024).toStringAsFixed(2)} MB';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(2)} KB';
    return '$bytes B';
  }
}

/// 安全特性卡片
class _SecurityCard extends StatelessWidget {
  final SoSecurityFeatures features;
  const _SecurityCard({required this.features});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.security, size: 20, color: Colors.greenAccent),
                const SizedBox(width: 8),
                const Text('安全特性', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: features.securityLevel == '高'
                        ? Colors.green.withOpacity(0.2)
                        : features.securityLevel == '中'
                            ? Colors.orange.withOpacity(0.2)
                            : Colors.red.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${features.securityLevel} (${features.securityScore})',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: features.securityLevel == '高'
                          ? Colors.greenAccent
                          : features.securityLevel == '中'
                              ? Colors.orangeAccent
                              : Colors.redAccent,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _SecurityChip(label: 'NX (不可执行栈)', enabled: features.hasNX),
            _SecurityChip(label: 'RELRO (只读重定位)', enabled: features.hasRELRO),
            _SecurityChip(label: 'Full RELRO', enabled: features.hasFullRELRO),
            _SecurityChip(label: 'PIE (位置无关)', enabled: features.isPIE),
            _SecurityChip(label: 'Stack Canary (栈保护)', enabled: features.hasStackCanary),
            _SecurityChip(label: 'FORTIFY (强化函数)', enabled: features.hasFORTIFY),
          ],
        ),
      ),
    );
  }
}

class _SecurityChip extends StatelessWidget {
  final String label;
  final bool enabled;
  const _SecurityChip({required this.label, required this.enabled});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Icon(
            enabled ? Icons.check_circle : Icons.cancel,
            size: 16,
            color: enabled ? Colors.greenAccent : Colors.redAccent,
          ),
          const SizedBox(width: 8),
          Text(label, style: TextStyle(fontSize: 12, color: enabled ? Colors.white70 : Colors.white38)),
        ],
      ),
    );
  }
}

/// 节区列表面板
class SoSectionsPanel extends StatelessWidget {
  final ElfInfo info;
  const SoSectionsPanel({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: info.sections.length,
      itemBuilder: (ctx, i) {
        final sec = info.sections[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 4),
          child: ExpansionTile(
            dense: true,
            leading: Container(
              width: 32,
              alignment: Alignment.center,
              child: Text(
                '${sec.index}',
                style: const TextStyle(fontSize: 10, color: Colors.white38),
              ),
            ),
            title: Text(
              sec.name,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
            ),
            subtitle: Text(
              '${sec.typeStr} [${sec.flagsStr}]  size=${_formatSize(sec.size)}',
              style: const TextStyle(fontSize: 10, color: Colors.white38),
            ),
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _DetailRow('类型', sec.typeStr),
                    _DetailRow('地址', '0x${sec.address.toRadixString(16)}'),
                    _DetailRow('文件偏移', '0x${sec.offset.toRadixString(16)}'),
                    _DetailRow('大小', '${_formatSize(sec.size)} (${sec.size} bytes)'),
                    _DetailRow('标志', '${sec.flagsStr} (0x${sec.flags.toRadixString(16)})'),
                    _DetailRow('Link', '${sec.link}'),
                    _DetailRow('Info', '${sec.info}'),
                    _DetailRow('对齐', '${sec.addrAlign}'),
                    _DetailRow('Entry Size', '${sec.entSize}'),
                    Row(
                      children: [
                        if (sec.isExecutable)
                          const Padding(padding: EdgeInsets.only(right: 4), child: Chip(label: Text('X', style: TextStyle(fontSize: 10, color: Colors.redAccent)))),
                        if (sec.isWritable)
                          const Padding(padding: EdgeInsets.only(right: 4), child: Chip(label: Text('W', style: TextStyle(fontSize: 10, color: Colors.blueAccent)))),
                        if (sec.isReadable)
                          const Padding(padding: EdgeInsets.only(right: 4), child: Chip(label: Text('R', style: TextStyle(fontSize: 10, color: Colors.greenAccent)))),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _formatSize(int bytes) {
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)}K';
    return '$bytes';
  }
}

/// 程序头面板
class SoProgramHeadersPanel extends StatelessWidget {
  final ElfInfo info;
  const SoProgramHeadersPanel({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: info.programHeaders.length,
      itemBuilder: (ctx, i) {
        final ph = info.programHeaders[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 4),
          child: ExpansionTile(
            dense: true,
            leading: Container(
              width: 32,
              alignment: Alignment.center,
              child: Text('$i', style: const TextStyle(fontSize: 10, color: Colors.white38)),
            ),
            title: Text(
              ph.typeStr,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
            ),
            subtitle: Text(
              'flags=[${ph.flagsStr}]  vaddr=0x${ph.vaddr.toRadixString(16)}  filesz=${ph.filesz}',
              style: const TextStyle(fontSize: 10, color: Colors.white38),
            ),
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _DetailRow('类型', ph.typeStr),
                    _DetailRow('标志', '${ph.flagsStr} (0x${ph.flags.toRadixString(16)})'),
                    _DetailRow('偏移', '0x${ph.offset.toRadixString(16)}'),
                    _DetailRow('虚拟地址', '0x${ph.vaddr.toRadixString(16)}'),
                    _DetailRow('物理地址', '0x${ph.paddr.toRadixString(16)}'),
                    _DetailRow('文件大小', '${ph.filesz} bytes'),
                    _DetailRow('内存大小', '${ph.memsz} bytes'),
                    _DetailRow('对齐', '${ph.align}'),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// 符号面板
class SoSymbolsPanel extends StatefulWidget {
  final ElfInfo info;
  const SoSymbolsPanel({super.key, required this.info});

  @override
  State<SoSymbolsPanel> createState() => _SoSymbolsPanelState();
}

class _SoSymbolsPanelState extends State<SoSymbolsPanel> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _searchController = TextEditingController();
  List<ElfSymbol> _filteredExports = [];
  List<ElfSymbol> _filteredImports = [];
  List<ElfSymbol> _filteredDynsyms = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _filteredExports = widget.info.exports;
    _filteredImports = widget.info.imports;
    _filteredDynsyms = widget.info.dynamicSymbols;
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _filter(String query) {
    final q = query.toLowerCase();
    setState(() {
      _filteredExports = widget.info.exports.where((s) => s.name.toLowerCase().contains(q)).toList();
      _filteredImports = widget.info.imports.where((s) => s.name.toLowerCase().contains(q)).toList();
      _filteredDynsyms = widget.info.dynamicSymbols.where((s) => s.name.toLowerCase().contains(q)).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            controller: _searchController,
            decoration: const InputDecoration(
              hintText: '搜索符号名...',
              prefixIcon: Icon(Icons.search, size: 20),
              border: OutlineInputBorder(),
              contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            ),
            onChanged: _filter,
          ),
        ),
        TabBar(
          controller: _tabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          tabs: [
            Tab(text: '导出 (${_filteredExports.length})'),
            Tab(text: '导入 (${_filteredImports.length})'),
            Tab(text: '全部动态 (${_filteredDynsyms.length})'),
          ],
        ),
        Expanded(
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildSymbolList(_filteredExports),
              _buildSymbolList(_filteredImports),
              _buildSymbolList(_filteredDynsyms),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSymbolList(List<ElfSymbol> symbols) {
    if (symbols.isEmpty) {
      return const Center(child: Text('无符号', style: TextStyle(color: Colors.white38)));
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      itemCount: symbols.length,
      itemBuilder: (ctx, i) {
        final s = symbols[i];
        return GestureDetector(
          onLongPress: () async {
            await Clipboard.setData(ClipboardData(text: s.name));
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('已复制'), duration: Duration(milliseconds: 800)),
              );
            }
          },
          child: Card(
            margin: const EdgeInsets.only(bottom: 2),
            child: ListTile(
              dense: true,
              title: SelectableText(
                s.name.isNotEmpty ? s.name : '(unnamed)',
                style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
              ),
              subtitle: Text(
                '${s.binding} · ${s.type} · ${s.visibility} · 0x${s.value.toRadixString(16)}'
                '${s.size > 0 ? ' (size=${s.size})' : ''} · ${s.sectionIndexStr}',
                style: TextStyle(fontSize: 10, color: Colors.grey[500]),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// 动态段面板
class SoDynamicPanel extends StatelessWidget {
  final ElfInfo info;
  const SoDynamicPanel({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: info.dynamicEntries.length,
      itemBuilder: (ctx, i) {
        final entry = info.dynamicEntries[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 2),
          child: ListTile(
            dense: true,
            title: Text(
              entry.tagName,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 13, fontWeight: FontWeight.bold),
            ),
            subtitle: SelectableText(
              entry.stringVal != null
                  ? '${entry.stringVal}  (0x${entry.value.toRadixString(16)})'
                  : '0x${entry.value.toRadixString(16)}',
              style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.grey[400]),
            ),
          ),
        );
      },
    );
  }
}

/// 重定位表面板
class SoRelocationsPanel extends StatelessWidget {
  final ElfInfo info;
  const SoRelocationsPanel({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: info.relocations.length,
      itemBuilder: (ctx, i) {
        final rel = info.relocations[i];
        return Card(
          margin: const EdgeInsets.only(bottom: 2),
          child: ListTile(
            dense: true,
            title: SelectableText(
              rel.symbolName ?? '(no symbol)',
              style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
            ),
            subtitle: Text(
              '${rel.relocTypeStr}${rel.isAddend ? ' (RELA)' : ''}  offset=0x${rel.offset.toRadixString(16)}  sym=$rel.symIndex',
              style: TextStyle(fontSize: 10, color: Colors.grey[500]),
            ),
          ),
        );
      },
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;
  const _StatRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          ),
          Expanded(
            child: SelectableText(
              value,
              style: const TextStyle(fontSize: 12, color: Colors.white70),
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  const _DetailRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 80,
            child: Text(label, style: TextStyle(fontSize: 11, color: Colors.grey[500])),
          ),
          Expanded(
            child: SelectableText(
              value,
              style: const TextStyle(fontSize: 11, color: Colors.white70, fontFamily: 'monospace'),
            ),
          ),
        ],
      ),
    );
  }
}
