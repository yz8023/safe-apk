import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ai/mcp_agent_engine.dart';
import '../ai/multi_ai_client.dart';
import '../providers/app_state_provider.dart';
import '../providers/apk_analysis_provider.dart';
import 'ai_config_dialog.dart';

/// AI 智能分析聊天面板
///
/// 让用户用自然语言与 AI 交互，AI 可以调用应用已分析的逆向参数
///（包名、权限、SDK、签名、组件、安全报告等）来回答问题。
///
/// 可作为悬浮窗内容嵌入，也可独立使用。
class AiChatPanel extends StatefulWidget {
  const AiChatPanel({super.key});

  @override
  State<AiChatPanel> createState() => _AiChatPanelState();
}

class _AiChatPanelState extends State<AiChatPanel> {
  final _inputController = TextEditingController();
  final _scrollController = ScrollController();
  bool _autoScroll = true;

  /// 快捷问题模板
  static const _quickActions = [
    ('🔒 安全分析', '分析这个APK的安全状况，列出主要安全风险和建议'),
    ('📋 权限解读', '列出所有权限并解释每个权限的用途和风险等级'),
    ('🏗️ 架构分析', '分析这个应用的架构，包括包名、组件分布、SDK使用情况'),
    ('🔍 代码搜索', '搜索DEX中的关键类和方法，分析代码逻辑'),
    ('🔑 签名验证', '检查签名信息和证书详情，判断是否被二次打包'),
    ('📦 加壳检测', '检测是否加壳/加固，分析保护机制'),
    ('🌐 网络分析', '提取所有URL和API端点，分析网络通信'),
    ('📊 综合报告', '生成完整的逆向分析报告'),
  ];

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(() {
      if (!_scrollController.hasClients) return;
      if (_scrollController.position.userScrollDirection.name != 'idle') {
        _autoScroll = false;
      }
    });
  }

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    if (!_autoScroll) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;
    try {
      final engine = context.read<McpAgentEngine>();
      final appState = context.read<AppStateProvider>();
      final apkProvider = context.read<ApkAnalysisProvider>();

      // 获取当前打开的文件路径，传递给 AI 引擎
      final apkPath = appState.currentFilePath ?? '';
      final hasAnalyzed = apkProvider.apkInfo != null;

      // 如果有已分析的 APK，在消息前注入上下文提示
      String message = text;
      if (apkPath.isNotEmpty && hasAnalyzed) {
        // 告知 AI 当前已有分析数据，直接调用 local_ 工具即可
        message = '$text\n\n[系统提示: 用户已打开并分析 APK 文件: $apkPath，'
            '请直接调用 local_ 开头的工具获取已分析的数据，无需要求用户提供文件路径]';
      } else if (apkPath.isNotEmpty && !hasAnalyzed) {
        message = '$text\n\n[系统提示: 用户已选择文件 $apkPath 但尚未完成分析，'
            '请提示用户先等待分析完成]';
      }

      engine.processRequest(message, workDir: apkPath);
      _inputController.clear();
      _autoScroll = true;
      _scrollToBottom();
    } catch (e) {
      // 防止发送消息时崩溃
      debugPrint('发送消息异常: $e');
    }
  }

  /// 安全获取工具数量
  int _getToolCount(McpAgentEngine engine) {
    try {
      return engine.mcpClient.tools.length;
    } catch (_) {
      return 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<McpAgentEngine, MultiAiClientImpl>(
      builder: (context, engine, aiClient, _) {
        // 消息列表变化时自动滚动
        if (engine.messages.isNotEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _scrollToBottom();
          });
        }

        return Column(
          children: [
            // 顶部状态栏
            _buildStatusBar(engine, aiClient),

            // 消息列表
            Expanded(
              child: engine.messages.isEmpty
                  ? _buildWelcome(engine)
                  : _buildMessageList(engine),
            ),

            // 快捷操作栏
            if (engine.messages.isEmpty) _buildQuickActions(),

            // 底部输入栏
            _buildInputBar(engine),
          ],
        );
      },
    );
  }

  /// 构建顶部状态栏
  Widget _buildStatusBar(McpAgentEngine engine, MultiAiClientImpl aiClient) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: const Color(0xFF1A1A2E),
      child: Row(
        children: [
          Icon(
            engine.isProcessing ? Icons.autorenew : Icons.smart_toy,
            size: 16,
            color: engine.isProcessing
                ? Colors.orangeAccent
                : Colors.greenAccent,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              engine.isProcessing
                  ? engine.currentStep
                  : 'AI: ${aiClient.currentProviderName.isEmpty ? "未配置 (点击设置)" : aiClient.currentProviderName}',
              style: TextStyle(
                fontSize: 12,
                color: engine.isProcessing
                    ? Colors.orangeAccent
                    : Colors.white54,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // 设置按钮
          IconButton(
            icon: const Icon(Icons.settings, size: 18),
            tooltip: 'AI 接口配置',
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            onPressed: engine.isProcessing
                ? null
                : () => AiConfigDialog.show(context),
          ),
          if (engine.isProcessing)
            TextButton(
              onPressed: engine.cancel,
              child: const Text('取消', style: TextStyle(fontSize: 12)),
            ),
          if (!engine.isProcessing && engine.messages.isNotEmpty)
            TextButton(
              onPressed: () {
                engine.clearMessages();
              },
              child: const Text('清空', style: TextStyle(fontSize: 12)),
            ),
        ],
      ),
    );
  }

  /// 构建欢迎界面
  Widget _buildWelcome(McpAgentEngine engine) {
    final toolCount = _getToolCount(engine);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.psychology, size: 64, color: Colors.blue.withAlpha(120)),
            const SizedBox(height: 16),
            const Text(
              'AI 智能逆向分析',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white70,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'AI 可以读取应用已分析的所有参数\n（包名、权限、SDK、签名、组件、安全报告等）\n用自然语言提问即可',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 13, color: Colors.white38),
            ),
            const SizedBox(height: 16),
            // 提示配置接口
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.orange.withAlpha(20),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.orange.withAlpha(60)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.tips_and_updates, size: 14, color: Colors.orange.withAlpha(180)),
                  const SizedBox(width: 6),
                  Text(
                    '点击右上角设置配置 AI 接口',
                    style: TextStyle(fontSize: 11, color: Colors.orange.withAlpha(180)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            // 显示可用工具数量
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.blue.withAlpha(20),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.blue.withAlpha(60)),
              ),
              child: Text(
                '可用工具: $toolCount 个',
                style: TextStyle(fontSize: 12, color: Colors.blue.withAlpha(180)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 构建消息列表
  Widget _buildMessageList(McpAgentEngine engine) {
    return ListView.builder(
      controller: _scrollController,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      itemCount: engine.messages.length,
      itemBuilder: (ctx, i) {
        final msg = engine.messages[i];
        return _buildMessageBubble(msg);
      },
    );
  }

  /// 构建单条消息气泡
  Widget _buildMessageBubble(AgentMessage msg) {
    final isUser = msg.role == 'user';
    final isSystem = msg.role == 'system';
    final isError = msg.isError;

    Color bgColor;
    Color textColor;
    IconData? icon;
    String? label;

    if (isUser) {
      bgColor = Colors.blue.withAlpha(30);
      textColor = Colors.blue.shade100;
    } else if (isSystem) {
      bgColor = isError
          ? Colors.red.withAlpha(20)
          : Colors.grey.withAlpha(15);
      textColor = isError ? Colors.red.shade200 : Colors.white54;
      icon = isError ? Icons.error_outline : Icons.build;
      label = isError ? '工具错误' : '工具结果';
    } else {
      bgColor = isError
          ? Colors.red.withAlpha(20)
          : Colors.green.withAlpha(15);
      textColor = isError ? Colors.red.shade200 : Colors.green.shade50;
      icon = isError ? Icons.error : Icons.smart_toy;
      label = isError ? '错误' : 'AI';
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isUser) ...[
            CircleAvatar(
              radius: 14,
              backgroundColor: bgColor,
              child: Icon(icon, size: 14, color: textColor),
            ),
            const SizedBox(width: 8),
          ],
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(8),
                border: isSystem
                    ? Border.all(color: textColor.withAlpha(30), width: 0.5)
                    : null,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (label != null) ...[
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 10,
                        color: textColor.withAlpha(120),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(height: 4),
                  ],
                  SelectableText(
                    msg.content,
                    style: TextStyle(
                      fontSize: 13,
                      color: textColor,
                      height: 1.4,
                      fontFamily: isSystem ? 'monospace' : null,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isUser) ...[
            const SizedBox(width: 8),
            CircleAvatar(
              radius: 14,
              backgroundColor: bgColor,
              child: Icon(Icons.person, size: 14, color: textColor),
            ),
          ],
        ],
      ),
    );
  }

  /// 构建快捷操作栏
  Widget _buildQuickActions() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Wrap(
        spacing: 6,
        runSpacing: 4,
        children: _quickActions.map((action) {
          return ActionChip(
            label: Text(
              action.$1,
              style: const TextStyle(fontSize: 11),
            ),
            onPressed: () => _sendMessage(action.$2),
            visualDensity: VisualDensity.compact,
          );
        }).toList(),
      ),
    );
  }

  /// 构建底部输入栏
  Widget _buildInputBar(McpAgentEngine engine) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        border: Border(
          top: BorderSide(color: Colors.white.withAlpha(20), width: 0.5),
        ),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _inputController,
                enabled: !engine.isProcessing,
                maxLines: null,
                textInputAction: TextInputAction.send,
                onSubmitted: _sendMessage,
                decoration: InputDecoration(
                  hintText: engine.isProcessing
                      ? 'AI 正在思考中...'
                      : '输入问题，让 AI 分析这个 APK...',
                  hintStyle: TextStyle(color: Colors.white30, fontSize: 13),
                  filled: true,
                  fillColor: Colors.white.withAlpha(10),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                ),
                style: const TextStyle(fontSize: 13, color: Colors.white70),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: engine.isProcessing
                  ? null
                  : () => _sendMessage(_inputController.text),
              icon: const Icon(Icons.send, size: 18),
              style: IconButton.styleFrom(
                backgroundColor: Colors.blue,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
