import 'package:flutter/material.dart';
import '../models/apk_info.dart';

/// APK 信息卡片
class InfoCard extends StatelessWidget {
  final ApkInfo info;
  const InfoCard({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    final fileSizeKB = (info.fileSize / 1024).toStringAsFixed(1);
    final fileSizeMB = (info.fileSize / (1024 * 1024)).toStringAsFixed(2);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.android, size: 32, color: Colors.greenAccent),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        info.packageName,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'v${info.versionName} (${info.versionCode})',
                        style: TextStyle(fontSize: 13, color: Colors.grey[400]),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            _InfoRow(label: '包名', value: info.packageName),
            _InfoRow(label: '版本', value: '${info.versionName} (${info.versionCode})'),
            _InfoRow(label: '文件大小', value: '$fileSizeKB KB ($fileSizeMB MB)'),
            if (info.applicationName != null)
              _InfoRow(label: 'Application', value: info.applicationName!),
            if (info.minSdkVersion != null)
              _InfoRow(label: 'minSdk', value: info.minSdkVersion!),
            if (info.targetSdkVersion != null)
              _InfoRow(label: 'targetSdk', value: info.targetSdkVersion!),
            _InfoRow(label: '主 Activity', value: info.mainActivity),
            _InfoRow(label: 'DEX 类数', value: '${info.dexClasses.length}'),
            _InfoRow(label: '文件条目', value: '${info.entries.length}'),
            const SizedBox(height: 12),
            Text(
              '权限 (${info.permissions.length})',
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 4,
              children: info.permissions.take(30).map((p) {
                final short = p.split('.').last;
                return Chip(
                  label: Text(short, style: const TextStyle(fontSize: 11)),
                  materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  visualDensity: VisualDensity.compact,
                );
              }).toList(),
            ),
            if (info.permissions.length > 30)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  '... +${info.permissions.length - 30} more',
                  style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          ),
          Expanded(
            child: SelectableText(
              value,
              style: const TextStyle(fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
