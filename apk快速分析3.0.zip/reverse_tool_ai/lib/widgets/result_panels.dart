import 'package:flutter/material.dart';
import '../models/apk_info.dart';
import '../models/so_symbol.dart';

/// DEX 搜索结果面板
class SearchResultPanel extends StatelessWidget {
  final SearchResult result;
  const SearchResultPanel({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    if (result.matches.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.search_off, size: 48, color: Colors.white24),
            const SizedBox(height: 8),
            Text(
              '未找到匹配 "${result.query}" 的结果',
              style: const TextStyle(color: Colors.white38, fontSize: 14),
            ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Text(
            '查询: "${result.query}" · ${result.matches.length} 个匹配',
            style: const TextStyle(color: Colors.white54, fontSize: 13),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: result.matches.length,
            itemBuilder: (ctx, i) {
              final m = result.matches[i];
              final icon = m.type == 'class'
                  ? Icons.class_
                  : m.type == 'method'
                      ? Icons.functions
                      : Icons.data_object;

              return Card(
                margin: const EdgeInsets.only(bottom: 6),
                child: ListTile(
                  leading: Icon(icon, size: 20, color: Colors.blueAccent),
                  title: SelectableText(
                    m.fullName,
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                  ),
                  subtitle: Text(
                    '${m.type}${m.className != null ? ' · ${m.className}' : ''}',
                    style: TextStyle(fontSize: 11, color: Colors.grey[500]),
                  ),
                  dense: true,
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

/// 字符串分析面板
class StringAnalysisPanel extends StatelessWidget {
  final StringAnalysis analysis;
  const StringAnalysisPanel({super.key, required this.analysis});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('字符串统计', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _StatRow(label: '总字符串数', value: '${analysis.totalStrings}'),
                _StatRow(label: '已解密/可疑', value: '${analysis.decryptedCount}'),
                const Divider(height: 20),
                if (analysis.decryptedSamples.isNotEmpty) ...[
                  const Text('解密样本', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  ...analysis.decryptedSamples.take(20).map((d) => Card(
                        margin: const EdgeInsets.only(bottom: 4),
                        color: const Color(0xFF1A1A2E),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SelectableText(
                                '原始: ${d.original}',
                                style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.grey[400]),
                              ),
                              const SizedBox(height: 4),
                              SelectableText(
                                '解码: ${d.decoded}',
                                style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Colors.greenAccent),
                              ),
                              Text(
                                '方法: ${d.method}',
                                style: TextStyle(fontSize: 10, color: Colors.grey[600]),
                              ),
                            ],
                          ),
                        ),
                      )),
                ],
                const Divider(height: 20),
                const Text('字符串样本', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                ...analysis.sampleStrings.take(30).map((s) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: SelectableText(
                        s,
                        style: TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.grey[400]),
                      ),
                    )),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

/// 混淆检测卡片
class ObfuscationCard extends StatelessWidget {
  final ObfuscationResult result;
  const ObfuscationCard({super.key, required this.result});

  Color _levelColor(String level) {
    switch (level.toLowerCase()) {
      case 'high':
      case '高':
        return Colors.redAccent;
      case 'medium':
      case '中':
        return Colors.orangeAccent;
      default:
        return Colors.greenAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _levelColor(result.suspicionLevel);
    final pct = (result.shortNameRatio * 100).toStringAsFixed(1);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.shield, color: color, size: 24),
                const SizedBox(width: 8),
                Text(
                  '混淆等级: ${result.suspicionLevel}',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: color),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _StatRow(label: '检测名称总数', value: '${result.totalNames}'),
            _StatRow(label: '短名比例', value: '$pct%'),
            _StatRow(
                label: '平均熵值',
                value: result.averageEntropy.toStringAsFixed(3)),
            _StatRow(
                label: '单字符类比例',
                value: '${(result.singleCharClassRatio * 100).toStringAsFixed(1)}%'),
            if (result.sampleClasses.isNotEmpty) ...[
              const Divider(height: 20),
              const Text('混淆类名样本', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: result.sampleClasses.take(20).map((c) {
                  return Chip(
                    label: Text(c, style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    visualDensity: VisualDensity.compact,
                  );
                }).toList(),
              ),
            ],
            if (result.sampleMethods.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text('混淆方法名样本', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: result.sampleMethods.take(20).map((m) {
                  return Chip(
                    label: Text(m, style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    visualDensity: VisualDensity.compact,
                  );
                }).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// SO/ELF 信息卡片
class SoInfoCard extends StatelessWidget {
  final ElfInfo info;
  const SoInfoCard({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.memory, size: 28, color: Colors.deepPurpleAccent),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${info.arch} · ${info.fileType}',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        info.is64Bit ? '64-bit ELF' : '32-bit ELF',
                        style: TextStyle(fontSize: 13, color: Colors.grey[400]),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            _StatRow(label: '架构', value: info.arch),
            _StatRow(label: '文件类型', value: info.fileType),
            _StatRow(label: '位数', value: info.is64Bit ? '64-bit' : '32-bit'),
            _StatRow(label: '节区数', value: '${info.sections.length}'),
            _StatRow(label: '符号数', value: '${info.symbols.length}'),
            _StatRow(label: '动态符号', value: '${info.dynamicSymbols.length}'),
            _StatRow(label: '导出符号', value: '${info.exports.length}'),
            _StatRow(label: '导入符号', value: '${info.imports.length}'),
            if (info.dependencies.isNotEmpty) ...[
              const SizedBox(height: 8),
              const Text('依赖库', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: info.dependencies.map((d) {
                  return Chip(
                    label: Text(d, style: const TextStyle(fontSize: 11)),
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    visualDensity: VisualDensity.compact,
                  );
                }).toList(),
              ),
            ],
            if (info.exports.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Text('导出符号', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Container(
                constraints: const BoxConstraints(maxHeight: 200),
                decoration: BoxDecoration(
                  color: const Color(0xFF0E0E1A),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.white12),
                ),
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: info.exports.length > 100 ? 100 : info.exports.length,
                  itemBuilder: (ctx, i) {
                    final s = info.exports[i];
                    return ListTile(
                      dense: true,
                      title: SelectableText(
                        s.name.isNotEmpty ? s.name : '(unnamed)',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                      ),
                      subtitle: Text(
                        '${s.binding} · ${s.type} · 0x${s.value.toRadixString(16)}',
                        style: TextStyle(fontSize: 10, color: Colors.grey[500]),
                      ),
                    );
                  },
                ),
              ),
              if (info.exports.length > 100)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    '... +${info.exports.length - 100} more',
                    style: TextStyle(fontSize: 12, color: Colors.grey[500]),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final String label;
  final String value;
  const _StatRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(
            width: 110,
            child: Text(label, style: TextStyle(fontSize: 12, color: Colors.grey[500])),
          ),
          Expanded(
            child: SelectableText(value, style: const TextStyle(fontSize: 13)),
          ),
        ],
      ),
    );
  }
}
