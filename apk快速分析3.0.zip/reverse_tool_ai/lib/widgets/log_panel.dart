import 'package:flutter/material.dart';

/// 日志面板
class LogPanel extends StatelessWidget {
  final String text;
  final double? maxHeight;
  const LogPanel({super.key, required this.text, this.maxHeight});

  @override
  Widget build(BuildContext context) {
    if (text.isEmpty) return const SizedBox.shrink();

    return Container(
      constraints: BoxConstraints(
        maxHeight: maxHeight ?? 200,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFF0E0E1A),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white12),
      ),
      padding: const EdgeInsets.all(12),
      child: SingleChildScrollView(
        child: SelectableText(
          text,
          style: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 12,
            color: Colors.greenAccent,
            height: 1.5,
          ),
        ),
      ),
    );
  }
}
