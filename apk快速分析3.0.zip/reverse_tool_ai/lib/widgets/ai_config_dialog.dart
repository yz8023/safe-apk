import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../ai/ai_provider.dart';
import '../ai/multi_ai_client.dart';

/// AI 接口配置对话框
///
/// 让用户配置 AI 接口：
/// - 选择内置 Provider（Pollinations / Cehpoint）
/// - 添加自定义 OpenAI 兼容接口（baseUrl / apiKey / modelName）
/// - 选择当前使用的模型
class AiConfigDialog extends StatefulWidget {
  const AiConfigDialog({super.key});

  /// 显示配置对话框
  static Future<void> show(BuildContext context) {
    return showDialog(
      context: context,
      builder: (_) => const AiConfigDialog(),
    );
  }

  @override
  State<AiConfigDialog> createState() => _AiConfigDialogState();
}

class _AiConfigDialogState extends State<AiConfigDialog>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  // 自定义 Provider 表单控制器
  final _nameController = TextEditingController();
  final _baseUrlController = TextEditingController();
  final _apiKeyController = TextEditingController();
  final _modelNameController = TextEditingController();

  // 表单扫描状态
  bool _isFormScanning = false;
  List<String> _formScannedModels = [];
  String? _formScanError;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _nameController.dispose();
    _baseUrlController.dispose();
    _apiKeyController.dispose();
    _modelNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480, maxHeight: 600),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // 标题栏
            Container(
              padding: const EdgeInsets.fromLTRB(16, 12, 8, 0),
              child: Row(
                children: [
                  const Icon(Icons.settings, size: 20),
                  const SizedBox(width: 8),
                  const Text(
                    'AI 接口配置',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close, size: 20),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
            // Tab 栏
            TabBar(
              controller: _tabController,
              tabs: const [
                Tab(text: '接口选择'),
                Tab(text: '自定义接口'),
              ],
            ),
            // 内容
            Flexible(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildProviderSelection(),
                  _buildCustomProviderForm(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 构建内置 Provider 选择
  Widget _buildProviderSelection() {
    return Consumer<MultiAiClientImpl>(
      builder: (context, client, _) {
        final providers = client.allProviders;
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // 当前状态
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.blue.withAlpha(20),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue.withAlpha(60)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline, size: 16, color: Colors.blue),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      client.currentProviderName.isEmpty
                          ? '当前: 自动模式'
                          : '当前: ${client.currentProviderName}',
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // 自动模式
            RadioListTile<int>(
              value: -1,
              groupValue: client.manualProviderIndex,
              title: const Text('自动模式'),
              subtitle: const Text('自动选择最佳可用接口', style: TextStyle(fontSize: 12)),
              onChanged: (_) {
                client.setAutoMode();
                setState(() {});
              },
            ),
            const Divider(),
            // Provider 列表
            ...List.generate(providers.length, (index) {
              final provider = providers[index];
              final models = client.getModelsForProvider(provider.name);
              final isScanning = client.isScanning(provider.name);
              final scanError = client.getScanError(provider.name);
              final hasScanned = client.getScannedModels(provider.name).isNotEmpty;
              return ExpansionTile(
                leading: Icon(
                  _getProviderIcon(provider.name),
                  size: 20,
                  color: provider.isAvailable ? Colors.green : Colors.grey,
                ),
                title: Text(provider.name),
                subtitle: Text(
                  provider.isAvailable ? '可用' : '不可用',
                  style: TextStyle(
                    fontSize: 11,
                    color: provider.isAvailable ? Colors.green : Colors.red,
                  ),
                ),
                children: [
                  // 模型列表
                  if (models.isNotEmpty)
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: models.map((model) {
                        final isSelected = client.isProviderModelSelected(index, model);
                        return ChoiceChip(
                          label: Text(model, style: const TextStyle(fontSize: 11)),
                          selected: isSelected,
                          onSelected: (_) {
                            client.selectProvider(index, model);
                            setState(() {});
                          },
                        );
                      }).toList(),
                    )
                  else if (!isScanning)
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        '该接口无可选模型，使用默认模型: ${provider.modelName}',
                        style: const TextStyle(fontSize: 12, color: Colors.white54),
                      ),
                    ),
                  // 扫描中提示
                  if (isScanning)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Row(
                        children: [
                          const SizedBox(
                            width: 14, height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            '正在扫描可用模型...',
                            style: TextStyle(fontSize: 12, color: Colors.blue.shade300),
                          ),
                        ],
                      ),
                    ),
                  // 扫描错误
                  if (scanError != null && !isScanning)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      child: Text(
                        scanError,
                        style: const TextStyle(fontSize: 11, color: Colors.orange),
                      ),
                    ),
                  // 扫描成功提示
                  if (hasScanned && !isScanning && scanError == null)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                      child: Text(
                        '已扫描到 ${models.length} 个模型',
                        style: TextStyle(fontSize: 11, color: Colors.green.shade300),
                      ),
                    ),
                  // 操作按钮
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Wrap(
                      spacing: 8,
                      children: [
                        TextButton.icon(
                          icon: isScanning
                              ? const SizedBox(
                                  width: 14, height: 14,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.search, size: 16),
                          label: Text(hasScanned ? '重新扫描' : '扫描模型'),
                          onPressed: isScanning
                              ? null
                              : () => client.scanModels(index),
                        ),
                        TextButton.icon(
                          icon: const Icon(Icons.play_arrow, size: 16),
                          label: const Text('测试连接'),
                          onPressed: () => _testProvider(context, provider),
                        ),
                      ],
                    ),
                  ),
                ],
              );
            }),
            // 自定义接口列表
            if (client.customProviders.isNotEmpty) ...[
              const Divider(),
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('已添加的自定义接口:', style: TextStyle(fontSize: 13)),
              ),
              ...List.generate(client.customProviders.length, (i) {
                final cfg = client.customProviders[i];
                final providerIndex = 3 + i; // 前 3 个是内置
                final isSelected = client.manualProviderIndex == providerIndex;
                final provider = client.allProviders[providerIndex];
                final isScanning = client.isScanning(provider.name);
                final scannedCount = client.getScannedModels(provider.name).length;
                return ListTile(
                  leading: Icon(
                    isSelected ? Icons.check_circle : Icons.api,
                    size: 20,
                    color: isSelected ? Colors.blue : null,
                  ),
                  title: Text(cfg.name, style: const TextStyle(fontSize: 14)),
                  subtitle: Text(
                    scannedCount > 0
                        ? '${cfg.modelName} • 已扫描 $scannedCount 个模型 • ${cfg.baseUrl.length > 30 ? "${cfg.baseUrl.substring(0, 30)}..." : cfg.baseUrl}'
                        : '${cfg.modelName} • ${cfg.baseUrl.length > 40 ? "${cfg.baseUrl.substring(0, 40)}..." : cfg.baseUrl}',
                    style: const TextStyle(fontSize: 11),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: isScanning
                            ? const SizedBox(
                                width: 16, height: 16,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.search, size: 18),
                        tooltip: '扫描模型',
                        onPressed: isScanning
                            ? null
                            : () => client.scanModels(providerIndex),
                      ),
                      IconButton(
                        icon: const Icon(Icons.wifi_find, size: 18),
                        tooltip: '测试连接',
                        onPressed: () {
                          _testProvider(context, provider);
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, size: 18),
                        tooltip: '删除',
                        onPressed: () {
                          client.removeCustomProvider(cfg.id);
                          setState(() {});
                        },
                      ),
                    ],
                  ),
                  onTap: () {
                    client.selectProvider(providerIndex, cfg.modelName);
                    setState(() {});
                  },
                );
              }),
            ],
          ],
        );
      },
    );
  }

  /// 构建自定义 Provider 表单
  Widget _buildCustomProviderForm() {
    return Consumer<MultiAiClientImpl>(
      builder: (context, client, _) {
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '添加 OpenAI 兼容接口',
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              const Text(
                '支持 OpenAI / DeepSeek / 通义千问 / Moonshot 等兼容接口',
                style: TextStyle(fontSize: 11, color: Colors.white54),
              ),
              const SizedBox(height: 16),
              // 名称
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: '接口名称',
                  hintText: '如: 我的 DeepSeek',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const SizedBox(height: 12),
              // Base URL
              TextField(
                controller: _baseUrlController,
                decoration: const InputDecoration(
                  labelText: '接口地址 (Base URL)',
                  hintText: 'https://api.deepseek.com/v1',
                  helperText: '支持简写，自动补全 /chat/completions',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const SizedBox(height: 12),
              // API Key
              TextField(
                controller: _apiKeyController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'API Key',
                  hintText: 'sk-...',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
              const SizedBox(height: 12),
              // 模型名 + 扫描按钮
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: _formScannedModels.isNotEmpty
                        ? DropdownButtonFormField<String>(
                            value: _formScannedModels.contains(_modelNameController.text)
                                ? _modelNameController.text
                                : null,
                            decoration: const InputDecoration(
                              labelText: '模型名称',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: _formScannedModels.map((model) {
                              return DropdownMenuItem(
                                value: model,
                                child: Text(model, style: const TextStyle(fontSize: 12)),
                              );
                            }).toList(),
                            onChanged: (val) {
                              if (val != null) {
                                _modelNameController.text = val;
                                setState(() {});
                              }
                            },
                          )
                        : TextField(
                            controller: _modelNameController,
                            decoration: const InputDecoration(
                              labelText: '模型名称',
                              hintText: '如: deepseek-chat, gpt-4o-mini',
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                          ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    height: 48,
                    child: FilledButton.tonalIcon(
                      icon: _isFormScanning
                          ? const SizedBox(
                              width: 14, height: 14,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.search, size: 18),
                      label: const Text('扫描'),
                      onPressed: _isFormScanning ? null : () => _scanFormModels(context, client),
                    ),
                  ),
                ],
              ),
              // 扫描结果提示
              if (_formScanError != null && !_isFormScanning)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    _formScanError!,
                    style: const TextStyle(fontSize: 11, color: Colors.orange),
                  ),
                ),
              if (_formScannedModels.isNotEmpty && !_isFormScanning)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    '已扫描到 ${_formScannedModels.length} 个模型，请从下拉列表中选择',
                    style: TextStyle(fontSize: 11, color: Colors.green.shade300),
                  ),
                ),
              const SizedBox(height: 16),
              // 预设快捷填充
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: _presets.map((preset) {
                  return ActionChip(
                    label: Text(preset.name, style: const TextStyle(fontSize: 11)),
                    onPressed: () {
                      _nameController.text = preset.name;
                      _baseUrlController.text = preset.baseUrl;
                      _modelNameController.text = preset.modelName;
                      // 清除扫描结果，回到手动输入模式
                      setState(() {
                        _formScannedModels = [];
                        _formScanError = null;
                      });
                    },
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              // 操作按钮
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.wifi_find, size: 18),
                      label: const Text('测试连接'),
                      onPressed: () => _testFormConnection(context),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      icon: const Icon(Icons.add, size: 18),
                      label: const Text('添加接口'),
                      onPressed: () => _addCustomProvider(context, client),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  /// 扫描表单中填写的接口可用模型
  Future<void> _scanFormModels(
      BuildContext context, MultiAiClientImpl client) async {
    final baseUrl = _baseUrlController.text.trim();
    final apiKey = _apiKeyController.text.trim();
    final modelName = _modelNameController.text.trim();

    if (baseUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先填写接口地址')),
      );
      return;
    }

    setState(() {
      _isFormScanning = true;
      _formScanError = null;
      _formScannedModels = [];
    });

    final (models, error) = await client.scanTempModels(
      baseUrl: baseUrl,
      apiKey: apiKey,
      modelName: modelName.isEmpty ? 'test' : modelName,
    );

    if (!mounted) return;

    setState(() {
      _isFormScanning = false;
      _formScannedModels = models;
      _formScanError = error;
      // 如果扫描到模型且当前模型名为空，自动选中第一个
      if (models.isNotEmpty && _modelNameController.text.trim().isEmpty) {
        _modelNameController.text = models.first;
      }
    });

    if (models.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('扫描到 ${models.length} 个可用模型')),
      );
    } else if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error)),
      );
    }
  }

  /// 添加自定义 Provider
  void _addCustomProvider(BuildContext context, MultiAiClientImpl client) {
    final name = _nameController.text.trim();
    final baseUrl = _baseUrlController.text.trim();
    final apiKey = _apiKeyController.text.trim();
    final modelName = _modelNameController.text.trim();

    if (baseUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请填写接口地址')),
      );
      return;
    }
    if (modelName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请填写模型名称')),
      );
      return;
    }

    final config = CustomProviderConfig(
      id: 'custom_${DateTime.now().millisecondsSinceEpoch}',
      name: name.isEmpty ? '自定义接口' : name,
      baseUrl: baseUrl,
      apiKey: apiKey,
      modelName: modelName,
    );

    client.addCustomProvider(config);

    // 清空表单
    _nameController.clear();
    _baseUrlController.clear();
    _apiKeyController.clear();
    _modelNameController.clear();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已添加: ${config.name}')),
    );

    // 切换到接口选择页
    _tabController.animateTo(0);
  }

  /// 测试表单中填写的连接（不添加到列表）
  Future<void> _testFormConnection(BuildContext context) async {
    final baseUrl = _baseUrlController.text.trim();
    final apiKey = _apiKeyController.text.trim();
    final modelName = _modelNameController.text.trim();
    final name = _nameController.text.trim().isEmpty
        ? '自定义接口'
        : _nameController.text.trim();

    if (baseUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先填写接口地址')),
      );
      return;
    }
    if (modelName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请先填写模型名称')),
      );
      return;
    }

    // 创建临时 Provider 进行测试
    final tempProvider = OpenAICompatibleProvider(
      baseUrl: baseUrl,
      apiKey: apiKey,
      modelName: modelName,
      name: name,
      isAvailable: true,
    );

    await _testProvider(context, tempProvider);
  }

  /// 测试 Provider 连接
  Future<void> _testProvider(
      BuildContext context, AiProvider provider) async {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const SizedBox(
              width: 16, height: 16,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
            const SizedBox(width: 12),
            Text('正在测试 ${provider.name}...'),
          ],
        ),
        duration: const Duration(seconds: 15),
      ),
    );

    final ok = await provider.healthCheck();
    if (!mounted) return;

    // 获取详细消息
    String detail = '';
    if (provider is OpenAICompatibleProvider) {
      detail = provider.lastHealthMessage;
    }

    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              ok
                  ? '${provider.name} 连接正常 ✓'
                  : '${provider.name} 连接失败 ✗',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            if (detail.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  detail,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
          ],
        ),
        duration: Duration(seconds: ok ? 2 : 5),
      ),
    );
  }

  IconData _getProviderIcon(String name) {
    if (name.contains('Pollinations')) return Icons.local_florist;
    if (name.contains('Cehpoint')) return Icons.cloud;
    if (name.contains('自定义') || name.contains('OpenAI')) return Icons.api;
    return Icons.smart_toy;
  }

  /// 常见接口预设
  static const _presets = <_PresetConfig>[
    _PresetConfig(
      name: 'DeepSeek',
      baseUrl: 'https://api.deepseek.com/v1/chat/completions',
      modelName: 'deepseek-chat',
    ),
    _PresetConfig(
      name: 'OpenAI',
      baseUrl: 'https://api.openai.com/v1/chat/completions',
      modelName: 'gpt-4o-mini',
    ),
    _PresetConfig(
      name: '通义千问',
      baseUrl: 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
      modelName: 'qwen-turbo',
    ),
    _PresetConfig(
      name: 'Moonshot',
      baseUrl: 'https://api.moonshot.cn/v1/chat/completions',
      modelName: 'moonshot-v1-8k',
    ),
    _PresetConfig(
      name: '智谱 GLM',
      baseUrl: 'https://open.bigmodel.cn/api/paas/v4/chat/completions',
      modelName: 'glm-4-flash',
    ),
  ];
}

class _PresetConfig {
  final String name;
  final String baseUrl;
  final String modelName;
  const _PresetConfig({
    required this.name,
    required this.baseUrl,
    required this.modelName,
  });
}
