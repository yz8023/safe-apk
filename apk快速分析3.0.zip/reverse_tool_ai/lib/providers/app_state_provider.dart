import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;

/// 全局应用状态管理
class AppStateProvider extends ChangeNotifier {
  String? _currentFilePath;
  String _currentTab = 'apk';
  final _logs = <String>[];
  int _maxLogs = 200;

  String? get currentFilePath => _currentFilePath;
  String? get currentFileName => _currentFilePath != null ? p.basename(_currentFilePath!) : null;
  String get currentTab => _currentTab;
  String get logText => _logs.join('\n');

  void setFile(String path) {
    _currentFilePath = path;
    notifyListeners();
  }

  void setTab(String tab) {
    _currentTab = tab;
    notifyListeners();
  }

  void log(String message) {
    _logs.add(message);
    if (_logs.length > _maxLogs) {
      _logs.removeAt(0);
    }
    notifyListeners();
  }

  void clearLog() {
    _logs.clear();
    notifyListeners();
  }

  void clearFile() {
    _currentFilePath = null;
    notifyListeners();
  }
}
