import 'package:flutter/foundation.dart';
import '../core/smali_patcher.dart';
import '../models/smali_method.dart';

/// Smali 补丁领域状态管理
class SmaliPatchProvider extends ChangeNotifier {
  String? _smaliDir;
  List<SmaliSearchResult> _searchResults = [];
  List<PatchResult> _patchResults = [];
  bool _isWorking = false;
  String? _error;

  String? get smaliDir => _smaliDir;
  List<SmaliSearchResult> get searchResults => _searchResults;
  List<PatchResult> get patchResults => _patchResults;
  bool get isWorking => _isWorking;
  String? get error => _error;

  void setSmaliDir(String dir) {
    _smaliDir = dir;
    _searchResults = [];
    _patchResults = [];
    notifyListeners();
  }

  void clear() {
    _smaliDir = null;
    _searchResults = [];
    _patchResults = [];
    _error = null;
    notifyListeners();
  }

  Future<void> search(String query) async {
    if (_smaliDir == null || query.trim().isEmpty) return;
    _isWorking = true;
    _error = null;
    notifyListeners();

    try {
      final patcher = SmaliPatcher(_smaliDir!);
      _searchResults = await patcher.searchInSmali(query);
    } catch (e, st) {
      _error = '搜索失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isWorking = false;
      notifyListeners();
    }
  }

  Future<void> patch(String className, String methodName, String newBody) async {
    if (_smaliDir == null) return;
    _isWorking = true;
    _error = null;
    notifyListeners();

    try {
      final patcher = SmaliPatcher(_smaliDir!);
      final result = await patcher.patchMethod(className, methodName, newBody);
      _patchResults.add(result);
    } catch (e, st) {
      _error = '补丁失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isWorking = false;
      notifyListeners();
    }
  }
}
