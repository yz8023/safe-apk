import 'package:flutter/foundation.dart';
import '../core/so_analyzer.dart';
import '../core/apk_analyzer.dart';
import '../models/so_symbol.dart';
import '../models/apk_info.dart';

/// SO/ELF 分析领域状态管理
class SoAnalysisProvider extends ChangeNotifier {
  ElfInfo? _elfInfo;
  List<SoString> _soStrings = [];
  List<ByteSearchResult> _byteSearchResults = [];
  List<JniFunction> _jniFunctions = [];
  List<XrefResult> _stringXrefs = [];
  String? _hexDump;
  bool _isAnalyzing = false;
  String? _error;
  String? _modifyResult;

  /// APK 内 SO 文件列表
  List<ApkSoEntry> _apkSoEntries = [];
  /// 当前分析的 SO 文件路径（可能是直接选择的 .so 或从 APK 提取的临时文件）
  String? _currentSoPath;
  /// 当前 SO 来源描述（如 "APK: lib/arm64-v8a/libtest.so"）
  String? _currentSoSource;

  ElfInfo? get elfInfo => _elfInfo;
  List<SoString> get soStrings => _soStrings;
  List<ByteSearchResult> get byteSearchResults => _byteSearchResults;
  List<JniFunction> get jniFunctions => _jniFunctions;
  List<XrefResult> get stringXrefs => _stringXrefs;
  String? get hexDump => _hexDump;
  bool get isAnalyzing => _isAnalyzing;
  String? get error => _error;
  String? get modifyResult => _modifyResult;
  List<ApkSoEntry> get apkSoEntries => _apkSoEntries;
  String? get currentSoPath => _currentSoPath;
  String? get currentSoSource => _currentSoSource;

  void clear() {
    _elfInfo = null;
    _soStrings = [];
    _byteSearchResults = [];
    _jniFunctions = [];
    _stringXrefs = [];
    _hexDump = null;
    _error = null;
    _modifyResult = null;
    _apkSoEntries = [];
    _currentSoPath = null;
    _currentSoSource = null;
    notifyListeners();
  }

  /// 列出 APK 内的 SO 文件
  Future<void> listApkSoFiles(String apkPath) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final apkAnalyzer = ApkAnalyzer(apkPath);
      _apkSoEntries = await apkAnalyzer.listSoFiles();
    } catch (e, st) {
      _error = '列出 SO 文件失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 从 APK 中提取 SO 并分析
  Future<void> analyzeSoFromApk(String apkPath, ApkSoEntry soEntry) async {
    _isAnalyzing = true;
    _error = null;
    _elfInfo = null;
    _soStrings = [];
    _byteSearchResults = [];
    _jniFunctions = [];
    _stringXrefs = [];
    _hexDump = null;
    notifyListeners();

    try {
      final apkAnalyzer = ApkAnalyzer(apkPath);
      _currentSoPath = await apkAnalyzer.extractSoToTemp(soEntry.fullPath);
      _currentSoSource = 'APK: ${soEntry.fullPath}';

      final analyzer = SoAnalyzer(_currentSoPath!);
      _elfInfo = await analyzer.analyze();
    } catch (e, st) {
      _error = 'SO 分析失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> analyzeSo(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      _currentSoPath = path;
      _currentSoSource = path.split('/').last;
      final analyzer = SoAnalyzer(path);
      _elfInfo = await analyzer.analyze();
    } catch (e, st) {
      _error = 'SO 分析失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 获取当前 SO 路径（优先使用 currentSoPath，否则回退到传入的 path）
  String _resolvePath(String path) => _currentSoPath ?? path;

  Future<void> extractStrings(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = SoAnalyzer(_resolvePath(path));
      _soStrings = await analyzer.extractStrings();
    } catch (e, st) {
      _error = '字符串提取失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> searchStrings(String path, String pattern, {bool useRegex = false}) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = SoAnalyzer(_resolvePath(path));
      _soStrings = await analyzer.searchStrings(pattern, useRegex: useRegex);
    } catch (e, st) {
      _error = '字符串搜索失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 查找字符串的交叉引用
  Future<void> findStringXrefs(String path, SoString target) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = SoAnalyzer(_resolvePath(path));
      _stringXrefs = await analyzer.findStringXrefs(target);
    } catch (e, st) {
      _error = '交叉引用查找失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 修改 SO 文件中的字符串
  Future<void> modifyString(String path, SoString target, String newString) async {
    _isAnalyzing = true;
    _error = null;
    _modifyResult = null;
    notifyListeners();

    try {
      final analyzer = SoAnalyzer(_resolvePath(path));
      _modifyResult = await analyzer.modifyString(target, newString);
      // 修改后重新提取字符串以刷新列表
      _soStrings = await analyzer.extractStrings();
    } catch (e, st) {
      _error = '字符串修改失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 清除交叉引用结果
  void clearXrefs() {
    _stringXrefs = [];
    notifyListeners();
  }

  /// 清除修改结果
  void clearModifyResult() {
    _modifyResult = null;
    notifyListeners();
  }

  Future<void> searchBytes(String path, String pattern) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = SoAnalyzer(_resolvePath(path));
      _byteSearchResults = await analyzer.searchBytes(pattern);
    } catch (e, st) {
      _error = '字节搜索失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> getHexDump(String path, int offset, int length) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = SoAnalyzer(_resolvePath(path));
      _hexDump = await analyzer.getHexDump(offset, length);
    } catch (e, st) {
      _error = 'Hex Dump 失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> detectJniFunctions(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = SoAnalyzer(_resolvePath(path));
      _jniFunctions = await analyzer.detectJniFunctions();
    } catch (e, st) {
      _error = 'JNI 检测失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }
}
