import 'dart:io';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../core/apk_analyzer.dart';
import '../core/dex_disassembler.dart';
import '../core/manifest_parser.dart';
import '../core/cert_parser.dart';
import '../core/res_analyzer.dart';
import '../core/apk_signer.dart';
import '../core/memory_manager.dart';
import '../core/sdk_detector.dart';
import '../core/permission_classifier.dart';
import '../core/packer_detector.dart';
import '../core/xref_analyzer.dart';
import '../core/call_graph_analyzer.dart';
import '../core/inheritance_analyzer.dart';
import '../core/api_endpoint_extractor.dart';
import '../core/secret_detector.dart';
import '../core/anti_debug_detector.dart';
import '../core/frida_generator.dart';
import '../core/dex_editor.dart';
import '../core/apk_repacker.dart';
import '../core/apk_resigner.dart';
import '../services/cache_service.dart';
import '../models/apk_info.dart';
import '../models/dex_class.dart';

/// APK 分析领域状态管理
class ApkAnalysisProvider extends ChangeNotifier {
  ApkInfo? _apkInfo;
  ManifestInfo? _manifestInfo;
  SignatureInfo? _signatureInfo;
  SignatureBlockInfo? _signatureBlock;
  ResInfo? _resInfo;
  CertInfo? _certInfo;
  ObfuscationResult? _obfuscationResult;
  StringAnalysis? _stringAnalysis;
  SearchResult? _searchResult;
  List<DexClass> _dexClasses = [];
  DisassemblyResult? _disassembly;
  List<String> _urls = [];
  List<SensitiveApiItem> _sensitiveApis = [];
  List<FileTreeNode> _fileTree = [];
  List<ReverseKeywordItem> _reverseKeywords = [];
  ApkHashInfo? _hashInfo;
  FileSizeBreakdown? _sizeBreakdown;
  SecurityReport? _securityReport;
  SdkDetectionResult? _sdkResult;
  PackerDetectionResult? _packerResult;
  PermissionClassificationResult? _permResult;
  NativeLibSummary? _nativeLibSummary;
  bool _isAnalyzing = false;
  String? _error;
  double _analysisProgress = 0.0;
  String _analysisStage = '';

  // ===== 新增功能状态 =====
  List<XrefResult>? _xrefResults;
  CallGraphResult? _callGraph;
  InheritanceTree? _inheritanceTree;
  ApiEndpointResult? _apiEndpoints;
  SecretDetectionResult? _secretResult;
  AntiDebugResult? _antiDebugResult;
  FridaScript? _fridaScript;
  List<DexStringEntry>? _dexStrings;
  String? _editResultMessage;
  String? _fridaScriptText;

  // Getters
  ApkInfo? get apkInfo => _apkInfo;
  ManifestInfo? get manifestInfo => _manifestInfo;
  SignatureInfo? get signatureInfo => _signatureInfo;
  SignatureBlockInfo? get signatureBlock => _signatureBlock;
  ResInfo? get resInfo => _resInfo;
  CertInfo? get certInfo => _certInfo;
  ObfuscationResult? get obfuscationResult => _obfuscationResult;
  StringAnalysis? get stringAnalysis => _stringAnalysis;
  SearchResult? get searchResult => _searchResult;
  List<DexClass> get dexClasses => _dexClasses;
  DisassemblyResult? get disassembly => _disassembly;
  List<String> get urls => _urls;
  List<SensitiveApiItem> get sensitiveApis => _sensitiveApis;
  List<FileTreeNode> get fileTree => _fileTree;
  List<ReverseKeywordItem> get reverseKeywords => _reverseKeywords;
  ApkHashInfo? get hashInfo => _hashInfo;
  FileSizeBreakdown? get sizeBreakdown => _sizeBreakdown;
  SecurityReport? get securityReport => _securityReport;
  SdkDetectionResult? get sdkResult => _sdkResult;
  PackerDetectionResult? get packerResult => _packerResult;
  PermissionClassificationResult? get permResult => _permResult;
  NativeLibSummary? get nativeLibSummary => _nativeLibSummary;
  bool get isAnalyzing => _isAnalyzing;
  String? get error => _error;
  double get analysisProgress => _analysisProgress;
  String get analysisStage => _analysisStage;

  // ===== 新增功能 Getters =====
  List<XrefResult>? get xrefResults => _xrefResults;
  CallGraphResult? get callGraph => _callGraph;
  InheritanceTree? get inheritanceTree => _inheritanceTree;
  ApiEndpointResult? get apiEndpoints => _apiEndpoints;
  SecretDetectionResult? get secretResult => _secretResult;
  AntiDebugResult? get antiDebugResult => _antiDebugResult;
  FridaScript? get fridaScript => _fridaScript;
  List<DexStringEntry>? get dexStrings => _dexStrings;
  String? get editResultMessage => _editResultMessage;
  String? get fridaScriptText => _fridaScriptText;

  List<String> get dexTree {
    if (_apkInfo == null) return [];
    final tree = <String>[];
    final packages = <String, List<String>>{};
    for (final cls in _apkInfo!.dexClasses) {
      final parts = cls.replaceAll('L', '').replaceAll(';', '').split('/');
      if (parts.length > 1) {
        final pkg = parts.sublist(0, parts.length - 1).join('.');
        packages.putIfAbsent(pkg, () => []).add(parts.last);
      }
    }
    for (final entry in packages.entries.toList()..sort((a, b) => a.key.compareTo(b.key))) {
      tree.add('📁 ${entry.key}');
      for (final c in entry.value.take(30)) {
        tree.add('  📄 $c');
      }
      if (entry.value.length > 30) {
        tree.add('  ... +${entry.value.length - 30} more');
      }
    }
    return tree;
  }

  Future<void> clear() async {
    _apkInfo = null;
    _manifestInfo = null;
    _signatureInfo = null;
    _signatureBlock = null;
    _resInfo = null;
    _certInfo = null;
    _obfuscationResult = null;
    _stringAnalysis = null;
    _searchResult = null;
    _dexClasses = [];
    _disassembly = null;
    _urls = [];
    _sensitiveApis = [];
    _fileTree = [];
    _reverseKeywords = [];
    _hashInfo = null;
    _sizeBreakdown = null;
    _securityReport = null;
    _sdkResult = null;
    _packerResult = null;
    _permResult = null;
    _nativeLibSummary = null;
    _xrefResults = null;
    _callGraph = null;
    _inheritanceTree = null;
    _apiEndpoints = null;
    _secretResult = null;
    _antiDebugResult = null;
    _fridaScript = null;
    _dexStrings = null;
    _editResultMessage = null;
    _fridaScriptText = null;
    _error = null;
    _analysisProgress = 0.0;
    _analysisStage = '';
    // 内存回收：清理分析结果缓存与应用缓存目录
    ApkAnalyzer.clearAnalysisCache();
    await CacheService.clearCache();
    notifyListeners();
  }

  /// 仅清理（磁盘/临时/分析/内存）缓存，不影响当前已展示的分析结果 UI 状态。
  /// 返回 (释放的字节数, 删除的条目数)，供 UI 反馈。
  Future<(int freedBytes, int removedCount)> clearCaches() async {
    final before = await CacheService.cacheSize();
    // 清空解析结果 LRU 缓存（不影响 _apkInfo 等已展示结果）
    ApkAnalyzer.clearAnalysisCache();
    // 解除已登记的大缓冲强引用，交由 Dart VM GC
    MemoryManager().collectAll();
    // 删除缓存目录与残留临时文件
    final removed = await CacheService.clearCache();
    final removedTemp = await CacheService.clearTemp();
    final after = await CacheService.cacheSize();
    return (before - after, removed + removedTemp);
  }

  Future<void> analyzeApk(String path) async {
    _isAnalyzing = true;
    _error = null;
    _analysisProgress = 0.0;
    _analysisStage = '正在读取 APK 文件...';
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _analysisStage = '解析 APK 基本信息...';
      _analysisProgress = 0.05;
      notifyListeners();
      _apkInfo = await analyzer.analyze();

      // Manifest 详细解析（包含组件、深度链接、XML 文本等）
      _analysisStage = '解析 AndroidManifest.xml...';
      _analysisProgress = 0.15;
      notifyListeners();
      _manifestInfo = await analyzer.parseManifestInfo();

      // 签名检测
      _analysisStage = '检测 APK 签名...';
      _analysisProgress = 0.25;
      notifyListeners();
      _signatureInfo = ApkSigner.detectSignature(_apkInfo!.entries);

      // V2/V3 签名块检测
      _analysisStage = '解析 V2/V3 签名块...';
      _analysisProgress = 0.32;
      notifyListeners();
      _signatureBlock = await analyzer.detectSignatureBlock();

      // 证书解析
      _analysisStage = '解析签名证书...';
      _analysisProgress = 0.40;
      notifyListeners();
      _certInfo = await analyzer.parseCertificate();

      // APK 文件哈希
      _analysisStage = '计算文件哈希...';
      _analysisProgress = 0.50;
      notifyListeners();
      _hashInfo = await analyzer.calculateHash();

      // 文件大小分类统计
      _analysisStage = '统计文件大小分布...';
      _analysisProgress = 0.58;
      notifyListeners();
      _sizeBreakdown = await analyzer.getFileSizeBreakdown();

      // 权限风险分类
      _analysisStage = '分类权限风险...';
      _analysisProgress = 0.65;
      notifyListeners();
      _permResult = await analyzer.classifyPermissions();

      // 原生库架构摘要
      _analysisStage = '分析 Native 库架构...';
      _analysisProgress = 0.72;
      notifyListeners();
      _nativeLibSummary = await analyzer.getNativeLibSummary();

      // 加壳检测
      _analysisStage = '检测加壳保护...';
      _analysisProgress = 0.82;
      notifyListeners();
      _packerResult = await analyzer.detectPacker();

      // 资源解析：实际解析 resources.arsc 的基本结构
      _analysisStage = '解析资源表...';
      _analysisProgress = 0.92;
      notifyListeners();
      _resInfo = await analyzer.parseResources();

      _analysisStage = '分析完成';
      _analysisProgress = 1.0;
      notifyListeners();
    } catch (e, st) {
      _error = 'APK 分析失败: $e';
      _analysisStage = '分析失败';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> searchInDex(String path, String query) async {
    if (query.trim().isEmpty) return;
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _searchResult = await analyzer.searchInDex(query);
    } catch (e, st) {
      _error = '搜索失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> analyzeStrings(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _stringAnalysis = await analyzer.analyzeStrings();
    } catch (e, st) {
      _error = '字符串分析失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> detectObfuscation(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _obfuscationResult = await analyzer.detectObfuscation();
    } catch (e, st) {
      _error = '混淆检测失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> disassembleDex(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _disassembly = await analyzer.disassembleDex();
    } catch (e, st) {
      _error = 'DEX 反汇编失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> extractUrls(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _urls = await analyzer.extractUrls();
    } catch (e, st) {
      _error = 'URL 提取失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> detectSensitiveApis(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _sensitiveApis = await analyzer.detectSensitiveApis();
    } catch (e, st) {
      _error = '敏感 API 检测失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> loadFileTree(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _fileTree = await analyzer.getFileTree();
    } catch (e, st) {
      _error = '文件树加载失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> detectReverseKeywords(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _reverseKeywords = await analyzer.detectReverseKeywords();
    } catch (e, st) {
      _error = '逆向关键词检测失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<String?> generateReport(String path) async {
    try {
      final analyzer = ApkAnalyzer(path);
      return await analyzer.generateReport();
    } catch (e) {
      return null;
    }
  }

  Future<void> assessSecurity(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _securityReport = await analyzer.assessSecurity();
    } catch (e, st) {
      _error = '安全评估失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> detectSdks(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();

    try {
      final analyzer = ApkAnalyzer(path);
      _sdkResult = await analyzer.detectSdks();
    } catch (e, st) {
      _error = 'SDK 检测失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<String?> exportAsJson(String path) async {
    try {
      final analyzer = ApkAnalyzer(path);
      return await analyzer.exportAsJson();
    } catch (e) {
      return null;
    }
  }

  // ==================== 新增功能方法 ====================

  /// 交叉引用分析
  Future<void> analyzeXref(String path, String query, {XrefType type = XrefType.method}) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();
    try {
      final bytes = MemoryManager().track(await File(path).readAsBytes());
      final entries = _parseZipEntriesForProvider(bytes);
      final dexList = <Uint8List>[];
      for (final e in entries.where((e) => e.name.endsWith('.dex'))) {
        dexList.add(_extractFileForProvider(bytes, e));
      }
      _xrefResults = await XrefAnalyzer.analyze(dexList, query, type: type);
      MemoryManager().release(bytes);
    } catch (e, st) {
      _error = '交叉引用分析失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 方法调用图分析
  Future<void> analyzeCallGraph(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();
    try {
      final bytes = MemoryManager().track(await File(path).readAsBytes());
      final entries = _parseZipEntriesForProvider(bytes);
      final dexList = <Uint8List>[];
      for (final e in entries.where((e) => e.name.endsWith('.dex'))) {
        dexList.add(_extractFileForProvider(bytes, e));
      }
      _callGraph = await CallGraphAnalyzer.analyze(dexList);
      MemoryManager().release(bytes);
    } catch (e, st) {
      _error = '调用图分析失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 类继承关系树
  Future<void> analyzeInheritance(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();
    try {
      final bytes = MemoryManager().track(await File(path).readAsBytes());
      final entries = _parseZipEntriesForProvider(bytes);
      final dexList = <Uint8List>[];
      for (final e in entries.where((e) => e.name.endsWith('.dex'))) {
        dexList.add(_extractFileForProvider(bytes, e));
      }
      _inheritanceTree = await InheritanceAnalyzer.analyze(dexList);
      MemoryManager().release(bytes);
    } catch (e, st) {
      _error = '继承树分析失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 网络API端点提取
  Future<void> extractApiEndpoints(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();
    try {
      final analyzer = ApkAnalyzer(path);
      final strings = await analyzer.extractAllDexStrings();
      _apiEndpoints = ApiEndpointExtractor.extract(strings);
    } catch (e, st) {
      _error = 'API端点提取失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 硬编码密钥/Token检测
  Future<void> detectSecrets(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();
    try {
      final analyzer = ApkAnalyzer(path);
      final (strings, classes) = await analyzer.extractDexStringsAndClasses();
      _secretResult = SecretDetector.detect(strings, classes);
    } catch (e, st) {
      _error = '密钥检测失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 反调试/反Root检测
  Future<void> detectAntiDebug(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();
    try {
      final analyzer = ApkAnalyzer(path);
      final (strings, classes) = await analyzer.extractDexStringsAndClasses();
      _antiDebugResult = AntiDebugDetector.detect(strings, classes);
    } catch (e, st) {
      _error = '反调试检测失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// Frida Hook脚本生成
  Future<void> generateFridaScript(String path, {String? filter}) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();
    try {
      final analyzer = ApkAnalyzer(path);
      final classes = await analyzer.extractAllDexClassesDetailed();
      _fridaScript = FridaGenerator.generate(classes, filter: filter);
      _fridaScriptText = _fridaScript!.content;
    } catch (e, st) {
      _error = 'Frida脚本生成失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 列出DEX字符串（用于编辑功能）
  Future<void> listDexStrings(String path) async {
    _isAnalyzing = true;
    _error = null;
    notifyListeners();
    try {
      final bytes = MemoryManager().track(await File(path).readAsBytes());
      final entries = _parseZipEntriesForProvider(bytes);
      final dexEntry = entries.where((e) => e.name == 'classes.dex').firstOrNull;
      if (dexEntry != null) {
        final dexBytes = _extractFileForProvider(bytes, dexEntry);
        _dexStrings = DexEditor.listStrings(dexBytes);
      }
      MemoryManager().release(bytes);
    } catch (e, st) {
      _error = 'DEX字符串列表失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// 修改DEX字符串并重新打包APK
  Future<void> modifyDexStringAndRepack(
    String apkPath,
    String oldString,
    String newString,
    String outputPath,
  ) async {
    _isAnalyzing = true;
    _error = null;
    _editResultMessage = null;
    notifyListeners();
    try {
      // 1. 读取原始APK
      final bytes = await File(apkPath).readAsBytes();
      final entries = _parseZipEntriesForProvider(bytes);
      final dexEntry = entries.where((e) => e.name == 'classes.dex').firstOrNull;
      if (dexEntry == null) {
        _editResultMessage = '未找到 classes.dex';
        return;
      }

      // 2. 修改DEX字符串
      final dexBytes = _extractFileForProvider(bytes, dexEntry);
      final editResult = DexEditor.modifyStringByValue(dexBytes, oldString, newString);
      if (!editResult.success) {
        _editResultMessage = editResult.error ?? '修改失败';
        return;
      }

      // 3. 重新打包
      final modifiedDex = DexEditor.modifyString(dexBytes, editResult.stringIndex!, newString);
      final repackResult = await ApkRepacker.repackage(
        apkPath,
        {'classes.dex': modifiedDex},
        outputPath,
      );

      if (repackResult.success) {
        _editResultMessage = '修改并打包成功: ${repackResult.outputPath} (${repackResult.entryCount} 条目, ${(repackResult.totalSize / 1024 / 1024).toStringAsFixed(2)} MB)';
      } else {
        _editResultMessage = '打包失败: ${repackResult.error}';
      }
    } catch (e, st) {
      _editResultMessage = '操作失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  /// APK V1重新签名
  Future<void> signApkV1(String apkPath, String outputPath) async {
    _isAnalyzing = true;
    _error = null;
    _editResultMessage = null;
    notifyListeners();
    try {
      final result = await ApkResigner.signV1(apkPath, outputPath);
      if (result.success) {
        _editResultMessage = 'V1签名完成: $outputPath\nMANIFEST.MF 和 CERT.SF 已生成。\n注意: CERT.RSA 为占位文件，需用 jarsigner 完成最终签名。';
      } else {
        _editResultMessage = '签名失败: ${result.error}';
      }
    } catch (e, st) {
      _editResultMessage = '签名失败: $e';
      if (kDebugMode) print(st);
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  // ==================== 内部辅助方法 ====================

  List<_ProviderZipEntry> _parseZipEntriesForProvider(Uint8List bytes) {
    final entries = <_ProviderZipEntry>[];
    int offset = bytes.length - 22;
    if (offset < 0) return entries;
    final searchStart = bytes.length > 65557 ? bytes.length - 65557 : 0;
    while (offset >= searchStart) {
      if (bytes[offset] == 0x50 && bytes[offset + 1] == 0x4B &&
          bytes[offset + 2] == 0x05 && bytes[offset + 3] == 0x06) {
        final commentLen = bytes[offset + 20] | (bytes[offset + 21] << 8);
        if (offset + 22 + commentLen == bytes.length) break;
      }
      offset--;
    }
    if (offset < searchStart) return entries;
    final cdOffset = bytes[offset + 16] | (bytes[offset + 17] << 8) |
        (bytes[offset + 18] << 16) | (bytes[offset + 19] << 24);
    final entryCount = bytes[offset + 10] | (bytes[offset + 11] << 8);
    int pos = cdOffset;
    for (int i = 0; i < entryCount && pos < bytes.length - 46; i++) {
      if (bytes[pos] != 0x50 || bytes[pos + 1] != 0x4B) break;
      final nameLen = bytes[pos + 28] | (bytes[pos + 29] << 8);
      final extraLen = bytes[pos + 30] | (bytes[pos + 31] << 8);
      final commentLen = bytes[pos + 32] | (bytes[pos + 33] << 8);
      final localOffset = bytes[pos + 42] | (bytes[pos + 43] << 8) |
          (bytes[pos + 44] << 16) | (bytes[pos + 45] << 24);
      final compSize = bytes[pos + 20] | (bytes[pos + 21] << 8) |
          (bytes[pos + 22] << 16) | (bytes[pos + 23] << 24);
      final uncompSize = bytes[pos + 24] | (bytes[pos + 25] << 8) |
          (bytes[pos + 26] << 16) | (bytes[pos + 27] << 24);
      final method = bytes[pos + 10] | (bytes[pos + 11] << 8);
      if (pos + 46 + nameLen > bytes.length) break;
      final name = utf8.decode(bytes.sublist(pos + 46, pos + 46 + nameLen), allowMalformed: true);
      entries.add(_ProviderZipEntry(name, localOffset, compSize, uncompSize, method));
      pos += 46 + nameLen + extraLen + commentLen;
    }
    return entries;
  }

  Uint8List _extractFileForProvider(Uint8List zipBytes, _ProviderZipEntry entry) {
    int pos = entry.localHeaderOffset;
    if (pos + 30 > zipBytes.length) return Uint8List(0);
    final nameLen = zipBytes[pos + 26] | (zipBytes[pos + 27] << 8);
    final extraLen = zipBytes[pos + 28] | (zipBytes[pos + 29] << 8);
    int dataStart = pos + 30 + nameLen + extraLen;
    if (entry.compressionMethod == 0) {
      final end = (dataStart + entry.uncompressedSize).clamp(0, zipBytes.length);
      return Uint8List.fromList(zipBytes.sublist(dataStart, end));
    } else if (entry.compressionMethod == 8) {
      final end = (dataStart + entry.compressedSize).clamp(0, zipBytes.length);
      try {
        final codec = ZLibCodec(raw: true);
        return Uint8List.fromList(codec.decoder.convert(zipBytes.sublist(dataStart, end)));
      } catch (_) {
        return Uint8List(0);
      }
    }
    return Uint8List(0);
  }
}

class _ProviderZipEntry {
  final String name;
  final int localHeaderOffset;
  final int compressedSize;
  final int uncompressedSize;
  final int compressionMethod;
  const _ProviderZipEntry(this.name, this.localHeaderOffset,
      this.compressedSize, this.uncompressedSize, this.compressionMethod);
}
