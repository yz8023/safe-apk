import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';
import '../models/so_symbol.dart';

/// ELF/SO 文件解析器 - 纯 Dart 实现
/// 参考 SOMCP 项目的 analyze_elf 能力，在纯 Dart 中实现完整的 ELF 静态分析。
class SoAnalyzer {
  final String path;
  late Uint8List _bytes;
  late bool _is64;
  late bool _isLE;

  SoAnalyzer(this.path);

  /// 解析 ELF 文件 — 完整分析
  Future<ElfInfo> analyze() async {
    _bytes = await _readFile(path);
    if (_bytes.length < 64) throw Exception('文件太小，不是有效的 ELF');

    // 验证 ELF 魔数
    if (_bytes[0] != 0x7F || _bytes[1] != 0x45 || _bytes[2] != 0x4C || _bytes[3] != 0x46) {
      throw Exception('不是有效的 ELF 文件');
    }

    _is64 = _bytes[4] == 2;
    _isLE = _bytes[5] == 1;

    final eType = _readU16(16);
    final eMachine = _readU16(18);
    final eEntry = _is64 ? _readU64(24) : _readU32(24);
    final eFlags = _is64 ? _readU32(48) : _readU32(36);
    final eEhSize = _readU16(_is64 ? 52 : 40);
    final eiOsAbi = _bytes[7];

    // 架构
    final arch = _getArchName(eMachine, _is64, _isLE);
    final fileType = _getFileType(eType);
    final abi = _getAbiName(eiOsAbi);

    // 解析 Section Headers
    final (sections, shStrTable) = _parseSectionHeaders();
    // 解析 Program Headers
    final programHeaders = _parseProgramHeaders();
    // 解析符号表
    final (symbols, dynsyms) = _parseSymbols(sections);
    // 解析动态段
    final (dynamicEntries, dependencies, soname, runpath) = _parseDynamicSection(sections, shStrTable);
    // 解析重定位表
    final relocations = _parseRelocations(sections, dynsyms);
    // 解析 init/fini 数组
    final (initArray, finiArray) = _parseInitFiniArrays(sections);
    // 提取 Build ID
    final buildId = _extractBuildId(sections);
    // 检测安全特性
    final securityFeatures = _detectSecurityFeatures(eType, programHeaders, sections, dynsyms);

    final exports = dynsyms.where((s) => s.value != 0 && s.binding != 'LOCAL').toList();
    final imports = dynsyms.where((s) => s.value == 0 && s.binding != 'LOCAL').toList();

    return ElfInfo(
      arch: arch,
      fileType: fileType,
      is64Bit: _is64,
      isLittleEndian: _isLE,
      entryPoint: eEntry,
      elfHeaderSize: eEhSize,
      flags: eFlags,
      abi: abi,
      sections: sections,
      programHeaders: programHeaders,
      symbols: symbols,
      dynamicSymbols: dynsyms,
      exports: exports,
      imports: imports,
      dependencies: dependencies,
      dynamicEntries: dynamicEntries,
      relocations: relocations,
      initArray: initArray,
      finiArray: finiArray,
      soname: soname,
      runpath: runpath,
      buildId: buildId,
      securityFeatures: securityFeatures,
      fileSize: _bytes.length,
    );
  }

  /// 提取 SO 文件中的字符串
  Future<List<SoString>> extractStrings({int minLength = 4}) async {
    if (_bytes.isEmpty) {
      _bytes = await _readFile(path);
    }
    final results = <SoString>[];

    // 从 .rodata、.data、.data.rel.ro、.text 等段提取字符串
    final targetSections = <String>['.rodata', '.data', '.data.rel.ro', '.text', '.comment'];
    final (parsedSections, shStrTable) = _parseSectionHeaders();

    for (final sec in parsedSections) {
      if (!targetSections.any((s) => sec.name == s || sec.name.startsWith('.rodata'))) continue;
      if (sec.size == 0 || sec.offset == 0) continue;

      _extractStringsFromRange(_bytes, sec.offset, sec.size, sec.name, minLength, results, sec.address);
      if (results.length > 50000) break; // 防止过多
    }

    return results;
  }

  /// 搜索字符串
  Future<List<SoString>> searchStrings(String pattern, {bool useRegex = false}) async {
    final allStrings = await extractStrings();
    if (useRegex) {
      try {
        final regex = RegExp(pattern, caseSensitive: false);
        return allStrings.where((s) => regex.hasMatch(s.value)).toList();
      } catch (_) {
        return allStrings.where((s) => s.value.toLowerCase().contains(pattern.toLowerCase())).toList();
      }
    }
    return allStrings.where((s) => s.value.toLowerCase().contains(pattern.toLowerCase())).toList();
  }

  /// 查找字符串的交叉引用（哪些地址引用了这个字符串）
  Future<List<XrefResult>> findStringXrefs(SoString target) async {
    if (_bytes.isEmpty) _bytes = await _readFile(path);
    final results = <XrefResult>[];
    final (sections, _) = _parseSectionHeaders();

    // 将字符串地址转换为字节序列进行搜索
    final strAddr = target.address;
    if (strAddr == 0) return results;

    // 搜索地址的字节表示 (小端)
    final addrBytes = <int>[];
    if (_is64) {
      for (int i = 0; i < 8; i++) {
        addrBytes.add((strAddr >> (i * 8)) & 0xFF);
      }
    } else {
      for (int i = 0; i < 4; i++) {
        addrBytes.add((strAddr >> (i * 8)) & 0xFF);
      }
    }

    // 在 .text 和 .data 段中搜索地址引用
    final searchSections = sections.where((s) =>
        s.name == '.text' || s.name == '.data' || s.name == '.data.rel.ro' ||
        s.name == '.rodata' || s.isAlloc);

    for (final sec in searchSections) {
      if (sec.size == 0 || sec.offset == 0) continue;
      final end = sec.offset + sec.size;
      if (end > _bytes.length) continue;

      for (int i = sec.offset; i <= end - addrBytes.length; i++) {
        bool match = true;
        for (int j = 0; j < addrBytes.length; j++) {
          if (_bytes[i + j] != addrBytes[j]) {
            match = false;
            break;
          }
        }
        if (match) {
          final refAddr = sec.address + (i - sec.offset);
          // 尝试找到所属函数名
          final (_, dynsyms) = _parseSymbols(sections);
          String? funcName;
          for (final sym in dynsyms) {
            if (sym.type == 'FUNC' && sym.value > 0 && sym.value <= refAddr && sym.value + sym.size > refAddr) {
              funcName = sym.name;
              break;
            }
          }
          results.add(XrefResult(
            fileOffset: i,
            address: refAddr,
            section: sec.name,
            referencedBy: funcName,
            context: _formatHex(i, 16),
          ));
          if (results.length >= 200) return results;
        }
      }
    }

    return results;
  }

  /// 修改 SO 文件中的字符串（就地覆盖，要求新字符串长度 <= 原长度）
  Future<String> modifyString(SoString target, String newString) async {
    if (_bytes.isEmpty) _bytes = await _readFile(path);

    if (newString.length > target.value.length) {
      return '错误: 新字符串长度 (${newString.length}) 不能超过原字符串长度 (${target.value.length})';
    }

    final strStart = target.offset;
    final strEnd = strStart + target.value.length;

    if (strEnd > _bytes.length) {
      return '错误: 字符串偏移超出文件范围';
    }

    // 写入新字符串
    final newBytes = utf8.encode(newString);
    for (int i = 0; i < newBytes.length; i++) {
      _bytes[strStart + i] = newBytes[i];
    }
    // 如果新字符串更短，用 null 填充剩余部分
    for (int i = newBytes.length; i < target.value.length; i++) {
      _bytes[strStart + i] = 0;
    }

    // 写回文件
    await File(path).writeAsBytes(_bytes);

    return '成功: 已将 "${target.value}" 修改为 "$newString" (偏移: 0x${strStart.toRadixString(16)})';
  }

  /// 搜索字节模式
  Future<List<ByteSearchResult>> searchBytes(String pattern) async {
    if (_bytes.isEmpty) _bytes = await _readFile(path);
    final normalized = _normalizeHexPattern(pattern);
    if (normalized.isEmpty) return [];

    final results = <ByteSearchResult>[];
    final (sections, _) = _parseSectionHeaders();

    // 在整个文件中搜索
    for (int i = 0; i <= _bytes.length - normalized.length; i++) {
      bool match = true;
      for (int j = 0; j < normalized.length; j++) {
        if (normalized[j] < 0) continue; // 通配符
        if (_bytes[i + j] != normalized[j]) {
          match = false;
          break;
        }
      }
      if (match) {
        final section = _findSectionByOffset(sections, i);
        final addr = section != null ? section.address + (i - section.offset) : i;
        final hexDump = _formatHex(i, 16);
        results.add(ByteSearchResult(
          offset: i,
          address: addr,
          section: section?.name ?? 'unknown',
          hexDump: hexDump,
        ));
        if (results.length >= 500) break; // 上限
      }
    }
    return results;
  }

  /// 获取指定偏移的 Hex Dump
  Future<String> getHexDump(int offset, int length) async {
    if (_bytes.isEmpty) _bytes = await _readFile(path);
    final end = (offset + length).clamp(0, _bytes.length);
    final actualOffset = offset.clamp(0, _bytes.length);
    final actualLength = end - actualOffset;
    if (actualLength <= 0) return '';

    final sb = StringBuffer();
    for (int i = 0; i < actualLength; i += 16) {
      final rowEnd = (i + 16).clamp(0, actualLength);
      final addr = actualOffset + i;
      sb.write('0x${addr.toRadixString(16).padLeft(8, '0')}  ');

      // Hex 部分
      for (int j = 0; j < 16; j++) {
        if (j < rowEnd - i) {
          sb.write('${_bytes[actualOffset + i + j].toRadixString(16).padLeft(2, '0')} ');
        } else {
          sb.write('   ');
        }
        if (j == 7) sb.write(' ');
      }
      sb.write(' |');

      // ASCII 部分
      for (int j = 0; j < 16; j++) {
        if (j < rowEnd - i) {
          final b = _bytes[actualOffset + i + j];
          sb.write(b >= 0x20 && b < 0x7F ? String.fromCharCode(b) : '.');
        }
      }
      sb.writeln('|');
    }
    return sb.toString();
  }

  /// 检测 JNI 函数
  Future<List<JniFunction>> detectJniFunctions() async {
    if (_bytes.isEmpty) _bytes = await _readFile(path);
    final results = <JniFunction>[];
    final (sections, _) = _parseSectionHeaders();
    final (_, dynsyms) = _parseSymbols(sections);

    // 检测静态注册的 JNI 函数 (Java_ 前缀)
    for (final sym in dynsyms) {
      if (sym.name.startsWith('Java_')) {
        results.add(JniFunction(
          name: sym.name,
          address: sym.value,
          type: 'static',
        ));
      }
    }

    // 检测 JNI_OnLoad
    for (final sym in dynsyms) {
      if (sym.name == 'JNI_OnLoad' || sym.name == 'JNI_OnUnload') {
        results.add(JniFunction(
          name: sym.name,
          address: sym.value,
          type: 'onload',
        ));
      }
    }

    // 检测 RegisterNatives 相关的字符串引用
    final jniStrings = await searchStrings('RegisterNatives');
    if (jniStrings.isNotEmpty) {
      results.add(JniFunction(
        name: 'RegisterNatives (dynamic registration detected)',
        address: 0,
        type: 'registered',
      ));
    }

    return results;
  }

  // ==================== 内部解析方法 ====================

  (List<ElfSection>, StringTable?) _parseSectionHeaders() {
    int shOff, shSize, shNum, shStrNdx;

    if (_is64) {
      shOff = _readU64(40);
      shSize = _readU16(58);
      shNum = _readU16(60);
      shStrNdx = _readU16(62);
    } else {
      shOff = _readU32(32);
      shSize = _readU16(46);
      shNum = _readU16(48);
      shStrNdx = _readU16(50);
    }

    StringTable? shStrTable;
    if (shStrNdx > 0 && shStrNdx < shNum) {
      final strShOff = _is64
          ? _readU64(shOff + shStrNdx * shSize + 24)
          : _readU32(shOff + shStrNdx * shSize + 16);
      final strShSz = _is64
          ? _readU64(shOff + shStrNdx * shSize + 32)
          : _readU32(shOff + shStrNdx * shSize + 20);
      shStrTable = StringTable(_bytes, strShOff, strShSz);
    }

    final sections = <ElfSection>[];
    for (int i = 0; i < shNum; i++) {
      final off = shOff + i * shSize;
      if (off + shSize > _bytes.length) break;

      final shName = _readU32(off);
      final shType = _readU32(off + 4);
      final shFlags = _is64 ? _readU64(off + 8) : _readU32(off + 8);
      final shAddr = _is64 ? _readU64(off + 16) : _readU32(off + 12);
      final shOffset = _is64 ? _readU64(off + 24) : _readU32(off + 16);
      final shSz = _is64 ? _readU64(off + 32) : _readU32(off + 20);
      final shLink = _readU32(off + (_is64 ? 40 : 24));
      final shInfo = _readU32(off + (_is64 ? 44 : 28));
      final shAlign = _is64 ? _readU64(off + 48) : _readU32(off + 32);
      final shEntSize = _is64 ? _readU64(off + 56) : _readU32(off + 36);

      final name = shStrTable?.getString(shName) ?? 'section_$i';

      sections.add(ElfSection(
        index: i,
        name: name,
        type: shType,
        address: shAddr,
        offset: shOffset,
        size: shSz,
        flags: shFlags.toInt(),
        link: shLink,
        info: shInfo,
        addrAlign: shAlign,
        entSize: shEntSize,
      ));
    }

    return (sections, shStrTable);
  }

  List<ProgramHeader> _parseProgramHeaders() {
    int phOff, phSize, phNum;

    if (_is64) {
      phOff = _readU64(32);
      phSize = _readU16(54);
      phNum = _readU16(56);
    } else {
      phOff = _readU32(28);
      phSize = _readU16(42);
      phNum = _readU16(44);
    }

    final headers = <ProgramHeader>[];
    for (int i = 0; i < phNum; i++) {
      final off = phOff + i * phSize;
      if (off + phSize > _bytes.length) break;

      int type, flags, offset, vaddr, paddr, filesz, memsz, align;

      if (_is64) {
        type = _readU32(off);
        flags = _readU32(off + 4);
        offset = _readU64(off + 8);
        vaddr = _readU64(off + 16);
        paddr = _readU64(off + 24);
        filesz = _readU64(off + 32);
        memsz = _readU64(off + 40);
        align = _readU64(off + 48);
      } else {
        type = _readU32(off);
        offset = _readU32(off + 4);
        vaddr = _readU32(off + 8);
        paddr = _readU32(off + 12);
        filesz = _readU32(off + 16);
        memsz = _readU32(off + 20);
        flags = _readU32(off + 24);
        align = _readU32(off + 28);
      }

      headers.add(ProgramHeader(
        type: type,
        flags: flags,
        offset: offset,
        vaddr: vaddr,
        paddr: paddr,
        filesz: filesz,
        memsz: memsz,
        align: align,
      ));
    }
    return headers;
  }

  (List<ElfSymbol>, List<ElfSymbol>) _parseSymbols(List<ElfSection> sections) {
    final symbols = <ElfSymbol>[];
    final dynsyms = <ElfSymbol>[];

    for (final sec in sections) {
      if (sec.type != 2 && sec.type != 11) continue;

      final isDyn = sec.type == 11;
      final targetList = isDyn ? dynsyms : symbols;
      final entrySize = _is64 ? 24 : 16;
      final count = sec.size ~/ entrySize;

      // 获取关联字符串表
      StringTable? symStrTable;
      if (sec.link > 0 && sec.link < sections.length) {
        final linkSec = sections[sec.link];
        symStrTable = StringTable(_bytes, linkSec.offset, linkSec.size);
      }

      final maxSymbols = 10000; // 提高上限
      for (int j = 0; j < count && j < maxSymbols; j++) {
        final eOff = sec.offset + j * entrySize;
        if (eOff + entrySize > _bytes.length) break;

        final stName = _readU32(eOff);
        final stInfo = _is64 ? _bytes[eOff + 4] : _bytes[eOff + 12];
        final stOther = _is64 ? _bytes[eOff + 5] : _bytes[eOff + 13];
        final stValue = _is64 ? _readU64(eOff + 8) : _readU32(eOff + 4);
        final stSize = _is64 ? _readU64(eOff + 16) : _readU32(eOff + 8);
        final stShndx = _is64 ? _readU16(eOff + 6) : _readU16(eOff + 14);

        final bind = stInfo >> 4;
        final type = stInfo & 0xF;
        final vis = stOther & 0x3;

        final name = symStrTable?.getString(stName) ?? '';
        if (name.isEmpty && j > 0) continue;

        targetList.add(ElfSymbol(
          name: name.isEmpty ? '<null>' : name,
          value: stValue,
          size: stSize,
          binding: _getBindingName(bind),
          type: _getTypeName(type),
          visibility: _getVisibilityName(vis),
          sectionIndex: stShndx,
        ));
      }
    }

    return (symbols, dynsyms);
  }

  (List<DynamicEntry>, List<String>, String?, String?) _parseDynamicSection(
      List<ElfSection> sections, StringTable? shStrTable) {
    final entries = <DynamicEntry>[];
    final dependencies = <String>[];
    String? soname;
    String? runpath;

    final dynSection = sections.where((s) => s.name == '.dynamic').firstOrNull;
    if (dynSection == null) return (entries, dependencies, soname, runpath);

    // 查找 .dynstr 字符串表
    final dynStrSection = sections.where((s) => s.name == '.dynstr').firstOrNull;
    StringTable? dynStrTable;
    if (dynStrSection != null) {
      dynStrTable = StringTable(_bytes, dynStrSection.offset, dynStrSection.size);
    }

    final entrySize = _is64 ? 16 : 8;
    final count = dynSection.size ~/ entrySize;

    for (int i = 0; i < count; i++) {
      final off = dynSection.offset + i * entrySize;
      if (off + entrySize > _bytes.length) break;

      final dTag = _is64 ? _readU64(off) : _readU32(off);
      final dVal = _is64 ? _readU64(off + 8) : _readU32(off + 4);

      final (tagName, stringVal) = _getDynamicTagName(dTag, dVal, dynStrTable);

      entries.add(DynamicEntry(
        tag: dTag,
        value: dVal,
        tagName: tagName,
        stringVal: stringVal,
      ));

      switch (dTag) {
        case 1: // DT_NEEDED
          if (stringVal != null && stringVal.isNotEmpty) dependencies.add(stringVal);
          break;
        case 14: // DT_SONAME
          soname = stringVal;
          break;
        case 29: // DT_RUNPATH
        case 15: // DT_RPATH
          runpath = stringVal;
          break;
      }
    }

    return (entries, dependencies, soname, runpath);
  }

  List<RelocationEntry> _parseRelocations(List<ElfSection> sections, List<ElfSymbol> dynsyms) {
    final relocations = <RelocationEntry>[];

    for (final sec in sections) {
      if (sec.type != 9 && sec.type != 4) continue; // SHT_REL (9) or SHT_RELA (4)

      final isRela = sec.type == 4;
      final entrySize = _is64
          ? (isRela ? 24 : 16)
          : (isRela ? 12 : 8);
      final count = sec.size ~/ entrySize;
      final maxRelocs = 5000;

      // 获取关联符号表
      List<ElfSymbol> symList = [];
      if (sec.link > 0 && sec.link < sections.length) {
        final symSec = sections[sec.link];
        if (symSec.type == 11) {
          symList = dynsyms;
        } else {
          // 重新解析静态符号表
          final (staticSyms, _) = _parseSymbols(sections);
          if (sec.link < sections.length && sections[sec.link].type == 2) {
            symList = staticSyms;
          }
        }
      }

      for (int j = 0; j < count && j < maxRelocs; j++) {
        final off = sec.offset + j * entrySize;
        if (off + entrySize > _bytes.length) break;

        final rOffset = _is64 ? _readU64(off) : _readU32(off);
        final rInfo = _is64 ? _readU64(off + 8) : _readU32(off + 4);

        final symIndex = _is64 ? (rInfo >> 32).toInt() : (rInfo >> 8);
        final relocType = _is64 ? (rInfo & 0xFFFFFFFF).toInt() : (rInfo & 0xFF);

        final symName = symIndex > 0 && symIndex < symList.length ? symList[symIndex].name : null;

        relocations.add(RelocationEntry(
          offset: rOffset,
          info: rInfo,
          symIndex: symIndex,
          relocType: relocType,
          symbolName: symName,
          relocTypeStr: _getRelocTypeName(relocType, _is64),
          isAddend: isRela,
        ));
      }
    }

    return relocations;
  }

  (List<int>, List<int>) _parseInitFiniArrays(List<ElfSection> sections) {
    final initArray = <int>[];
    final finiArray = <int>[];

    for (final sec in sections) {
      if (sec.type == 14 && sec.name.contains('init_array')) {
        // INIT_ARRAY
        final entrySize = _is64 ? 8 : 4;
        final count = sec.size ~/ entrySize;
        for (int i = 0; i < count && i < 100; i++) {
          final off = sec.offset + i * entrySize;
          if (off + entrySize > _bytes.length) break;
          final addr = _is64 ? _readU64(off) : _readU32(off);
          initArray.add(addr);
        }
      } else if (sec.type == 15 && sec.name.contains('fini_array')) {
        // FINI_ARRAY
        final entrySize = _is64 ? 8 : 4;
        final count = sec.size ~/ entrySize;
        for (int i = 0; i < count && i < 100; i++) {
          final off = sec.offset + i * entrySize;
          if (off + entrySize > _bytes.length) break;
          final addr = _is64 ? _readU64(off) : _readU32(off);
          finiArray.add(addr);
        }
      }
    }

    return (initArray, finiArray);
  }

  String? _extractBuildId(List<ElfSection> sections) {
    for (final sec in sections) {
      if (sec.type == 7 && sec.name.contains('build-id')) {
        // NOTE section with build-id
        if (sec.offset + 16 <= _bytes.length) {
          final nameSize = _readU32(sec.offset + 4);
          final descSize = _readU32(sec.offset + 8);
          final descOffset = sec.offset + 12 + nameSize;
          if (descOffset + descSize <= _bytes.length) {
            final sb = StringBuffer();
            for (int i = 0; i < descSize && i < 20; i++) {
              sb.write(_bytes[descOffset + i].toRadixString(16).padLeft(2, '0'));
            }
            return sb.toString();
          }
        }
      }
    }
    return null;
  }

  SoSecurityFeatures _detectSecurityFeatures(
      int eType, List<ProgramHeader> programHeaders, List<ElfSection> sections, List<ElfSymbol> dynsyms) {
    // NX: GNU_STACK 段不可执行
    bool hasNX = true;
    for (final ph in programHeaders) {
      if (ph.type == 0x6474e551) {
        // GNU_STACK
        hasNX = !ph.isExecutable;
        break;
      }
    }

    // RELRO: 存在 GNU_RELRO 段
    bool hasRELRO = programHeaders.any((ph) => ph.type == 0x6474e552);
    // Full RELRO: .got.plt 是只读的 (DT_FLAGS 中有 DF_BIND_NOW)
    bool hasFullRELRO = false;
    final dynSection = sections.where((s) => s.name == '.dynamic').firstOrNull;
    if (dynSection != null) {
      final entrySize = _is64 ? 16 : 8;
      final count = dynSection.size ~/ entrySize;
      for (int i = 0; i < count; i++) {
        final off = dynSection.offset + i * entrySize;
        if (off + entrySize > _bytes.length) break;
        final dTag = _is64 ? _readU64(off) : _readU32(off);
        final dVal = _is64 ? _readU64(off + 8) : _readU32(off + 4);
        if (dTag == 30) {
          // DT_FLAGS
          if ((dVal & 0x8) != 0) {
            // DF_BIND_NOW
            hasFullRELRO = true;
          }
        }
        if (dTag == 0x6ffffffb) {
          // DT_FLAGS_1
          if ((dVal & 0x1) != 0) {
            // DF_1_NOW
            hasFullRELRO = true;
          }
        }
      }
    }

    // PIE: 文件类型是 DYN
    final isPIE = eType == 3;

    // Stack Canary: 检测 __stack_chk_fail 符号
    final hasStackCanary = dynsyms.any((s) =>
        s.name.contains('__stack_chk_fail') || s.name.contains('__stack_chk_guard'));

    // FORTIFY: 检测 __chk 相关符号
    final hasFORTIFY = dynsyms.any((s) =>
        s.name.contains('__sprintf_chk') ||
        s.name.contains('__memcpy_chk') ||
        s.name.contains('__strcpy_chk') ||
        s.name.contains('__strncpy_chk'));

    return SoSecurityFeatures(
      hasNX: hasNX,
      hasRELRO: hasRELRO,
      hasFullRELRO: hasFullRELRO,
      isPIE: isPIE,
      hasStackCanary: hasStackCanary,
      hasFORTIFY: hasFORTIFY,
    );
  }

  // ==================== 辅助方法 ====================

  String _getArchName(int eMachine, bool is64, bool isLE) {
    switch (eMachine) {
      case 0x28: return is64 ? 'ARM64' : 'ARM';
      case 0x03: return 'x86';
      case 0x3E: return 'x86_64';
      case 0xB7: return 'AArch64';
      case 0xF3: return 'RISC-V';
      case 0x8E: return 'MIPS';
      case 0xB6: return 'AArch64 (BE)';
      default: return 'Unknown (0x${eMachine.toRadixString(16)})';
    }
  }

  String _getFileType(int eType) {
    switch (eType) {
      case 0: return 'NONE';
      case 1: return 'REL (Relocatable)';
      case 2: return 'EXEC (Executable)';
      case 3: return 'DYN (Shared Object)';
      case 4: return 'CORE';
      default: return 'Unknown ($eType)';
    }
  }

  String _getAbiName(int abi) {
    switch (abi) {
      case 0: return 'ELFOSABI_NONE';
      case 1: return 'ELFOSABI_HPUX';
      case 2: return 'ELFOSABI_NETBSD';
      case 3: return 'ELFOSABI_LINUX';
      case 6: return 'ELFOSABI_SOLARIS';
      case 7: return 'ELFOSABI_AIX';
      case 8: return 'ELFOSABI_IRIX';
      case 9: return 'ELFOSABI_FREEBSD';
      case 12: return 'ELFOSABI_ARM';
      case 64: return 'ELFOSABI_ARM_AEABI';
      case 97: return 'ELFOSABI_ARM';
      default: return 'ABI_$abi';
    }
  }

  String _getBindingName(int bind) {
    switch (bind) {
      case 0: return 'LOCAL';
      case 1: return 'GLOBAL';
      case 2: return 'WEAK';
      case 10: return 'GNU_UNIQUE';
      default: return 'UNKNOWN($bind)';
    }
  }

  String _getTypeName(int type) {
    switch (type) {
      case 0: return 'NOTYPE';
      case 1: return 'OBJECT';
      case 2: return 'FUNC';
      case 3: return 'SECTION';
      case 4: return 'FILE';
      case 5: return 'COMMON';
      case 6: return 'TLS';
      default: return 'OTHER($type)';
    }
  }

  String _getVisibilityName(int vis) {
    switch (vis) {
      case 0: return 'DEFAULT';
      case 1: return 'INTERNAL';
      case 2: return 'HIDDEN';
      case 3: return 'PROTECTED';
      default: return 'UNKNOWN($vis)';
    }
  }

  (String, String?) _getDynamicTagName(int tag, int value, StringTable? strTab) {
    String? strVal;
    // 需要字符串的 tag
    if ([1, 14, 15, 29, 5, 6].contains(tag)) {
      strVal = strTab?.getString(value);
    }

    switch (tag) {
      case 0: return ('NULL', null);
      case 1: return ('NEEDED', strVal);
      case 2: return ('PLTRELSZ', null);
      case 3: return ('PLTGOT', null);
      case 4: return ('HASH', null);
      case 5: return ('STRTAB', null);
      case 6: return ('SYMTAB', null);
      case 7: return ('RELA', null);
      case 8: return ('RELASZ', null);
      case 9: return ('RELAENT', null);
      case 10: return ('STRSZ', null);
      case 11: return ('SYMENT', null);
      case 12: return ('INIT', null);
      case 13: return ('FINI', null);
      case 14: return ('SONAME', strVal);
      case 15: return ('RPATH', strVal);
      case 16: return ('SYMBOLIC', null);
      case 17: return ('REL', null);
      case 18: return ('RELSZ', null);
      case 19: return ('RELENT', null);
      case 20: return ('PLTREL', null);
      case 21: return ('DEBUG', null);
      case 22: return ('TEXTREL', null);
      case 23: return ('JMPREL', null);
      case 24: return ('BIND_NOW', null);
      case 25: return ('INIT_ARRAY', null);
      case 26: return ('FINI_ARRAY', null);
      case 27: return ('INIT_ARRAYSZ', null);
      case 28: return ('FINI_ARRAYSZ', null);
      case 29: return ('RUNPATH', strVal);
      case 30: return ('FLAGS', null);
      case 32: return ('PREINIT_ARRAY', null);
      case 33: return ('PREINIT_ARRAYSZ', null);
      case 0x6ffffef5: return ('GNU_HASH', null);
      case 0x6ffffef6: return ('GNU_XHASH', null);
      case 0x6ffffff0: return ('VERSYM', null);
      case 0x6ffffff9: return ('RELACOUNT', null);
      case 0x6ffffffa: return ('RELCOUNT', null);
      case 0x6ffffffb: return ('FLAGS_1', null);
      case 0x6ffffffc: return ('VERDEF', null);
      case 0x6ffffffd: return ('VERDEFNUM', null);
      case 0x6ffffffe: return ('VERNEED', null);
      case 0x6fffffff: return ('VERNEEDNUM', null);
      default: return ('0x${tag.toRadixString(16)}', null);
    }
  }

  String _getRelocTypeName(int type, bool is64) {
    if (is64) {
      // AArch64 relocation types
      switch (type) {
        case 257: return 'R_AARCH64_ABS64';
        case 258: return 'R_AARCH64_ABS32';
        case 259: return 'R_AARCH64_ABS16';
        case 262: return 'R_AARCH64_PREL64';
        case 263: return 'R_AARCH64_PREL32';
        case 274: return 'R_AARCH64_JUMP_SLOT';
        case 275: return 'R_AARCH64_RELATIVE';
        case 282: return 'R_AARCH64_TLS_TPREL64';
        case 1024: return 'R_AARCH64_COPY';
        case 1025: return 'R_AARCH64_GLOB_DAT';
        default: return 'R_AARCH64_$type';
      }
    } else {
      // ARM relocation types
      switch (type) {
        case 2: return 'R_ARM_ABS32';
        case 3: return 'R_ARM_REL32';
        case 21: return 'R_ARM_THM_CALL';
        case 22: return 'R_ARM_JUMP_SLOT';
        case 160: return 'R_ARM_IRELATIVE';
        case 20: return 'R_ARM_COPY';
        case 21: return 'R_ARM_GLOB_DAT';
        default: return 'R_ARM_$type';
      }
    }
  }

  void _extractStringsFromRange(Uint8List bytes, int offset, int size, String sectionName,
      int minLength, List<SoString> results, int sectionAddr) {
    final end = offset + size;
    if (end > bytes.length) return;

    int start = offset;
    final sb = StringBuffer();

    for (int i = offset; i < end; i++) {
      final b = bytes[i];
      if (b >= 0x20 && b < 0x7F) {
        sb.writeCharCode(b);
      } else {
        if (sb.length >= minLength) {
          final strOffset = start;
          final strAddr = sectionAddr + (start - offset);
          results.add(SoString(
            offset: strOffset,
            value: sb.toString(),
            section: sectionName,
            address: strAddr,
          ));
        }
        sb.clear();
        start = i + 1;
      }
    }
    if (sb.length >= minLength) {
      final strAddr = sectionAddr + (start - offset);
      results.add(SoString(
        offset: start,
        value: sb.toString(),
        section: sectionName,
        address: strAddr,
      ));
    }
  }

  List<int> _normalizeHexPattern(String pattern) {
    // 支持 "5F2403D5", "5F 24 03 D5", "5F24..D5", "5F 24 ?? D5", "5F2403D5:FFFF00FF"
    String cleaned = pattern.replaceAll(RegExp(r'[\s,]'), '');

    // 处理 mask 语法 (bytes:mask)
    if (cleaned.contains(':')) {
      cleaned = cleaned.split(':')[0];
    }

    // 替换 ?? 为通配符
    cleaned = cleaned.replaceAll('??', '..');

    if (cleaned.length % 2 != 0) return [];

    final result = <int>[];
    for (int i = 0; i < cleaned.length; i += 2) {
      final hex = cleaned.substring(i, i + 2);
      if (hex == '..') {
        result.add(-1); // 通配符
      } else {
        try {
          result.add(int.parse(hex, radix: 16));
        } catch (_) {
          return [];
        }
      }
    }
    return result;
  }

  ElfSection? _findSectionByOffset(List<ElfSection> sections, int offset) {
    for (final sec in sections) {
      if (sec.offset <= offset && offset < sec.offset + sec.size) {
        return sec;
      }
    }
    return null;
  }

  String _formatHex(int offset, int length) {
    final sb = StringBuffer();
    final end = (offset + length).clamp(0, _bytes.length);
    for (int i = offset; i < end; i++) {
      sb.write('${_bytes[i].toRadixString(16).padLeft(2, '0')} ');
    }
    return sb.toString().trim();
  }

  // ==================== 基础读取方法 ====================

  int _readU16(int off) {
    if (off + 1 >= _bytes.length) return 0;
    return _isLE
        ? (_bytes[off] | (_bytes[off + 1] << 8))
        : (_bytes[off + 1] | (_bytes[off] << 8));
  }

  int _readU32(int off) {
    if (off + 3 >= _bytes.length) return 0;
    return _isLE
        ? (_bytes[off] | (_bytes[off + 1] << 8) | (_bytes[off + 2] << 16) | (_bytes[off + 3] << 24))
        : (_bytes[off + 3] | (_bytes[off + 2] << 8) | (_bytes[off + 1] << 16) | (_bytes[off] << 24));
  }

  int _readU64(int off) {
    if (off + 7 >= _bytes.length) return 0;
    int lo = _readU32(off);
    int hi = _readU32(off + 4);
    return (hi.toUnsigned(32) << 32) | lo.toUnsigned(32);
  }

  Future<Uint8List> _readFile(String path) async {
    return Uint8List.fromList(await File(path).readAsBytes());
  }
}

/// ELF 字符串表辅助类
class StringTable {
  final Uint8List bytes;
  final int offset;
  final int size;

  StringTable(this.bytes, this.offset, this.size);

  String? getString(int nameOff) {
    if (nameOff == 0) return null;
    final start = offset + nameOff;
    if (start >= bytes.length) return null;
    final end = bytes.indexOf(0, start);
    if (end == -1 || end > offset + size) return null;
    try {
      return utf8.decode(bytes.sublist(start, end));
    } catch (_) {
      return null;
    }
  }
}
