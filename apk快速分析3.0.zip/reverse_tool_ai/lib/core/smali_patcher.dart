import 'dart:io';
import 'package:path/path.dart' as p;
import '../models/smali_method.dart';

/// Smali 补丁工具 - 修改 smali 文件中的方法实现
class SmaliPatcher {
  final String smaliDir;

  SmaliPatcher(this.smaliDir);

  /// 查找 smali 文件
  Future<String?> findSmaliFile(String className) async {
    // Lcom/example/MyClass; -> com/example/MyClass.smali
    final smaliPath = className
        .replaceFirst(RegExp(r'^L'), '')
        .replaceAll(';', '')
        .replaceAll('.', '/');
    final targetName = '$smaliPath.smali';

    // 在 smali 和 smali_classes* 目录中搜索
    final dir = Directory(smaliDir);
    if (!await dir.exists()) return null;

    await for (final entity in dir.list(recursive: true, followLinks: false)) {
      if (entity is File && p.basename(entity.path) == p.basename(targetName)) {
        return entity.path;
      }
    }
    return null;
  }

  /// 替换方法体
  Future<PatchResult> patchMethod(String className, String methodName, String newBody) async {
    final filePath = await findSmaliFile(className);
    if (filePath == null) {
      return PatchResult(success: false, error: 'Smali file not found for $className');
    }

    final file = File(filePath);
    final content = await file.readAsString();

    // 匹配 .method ... methodName ... 到 .end method
    final methodPattern = RegExp(
      r'(\.method\s+.*?\b' + RegExp.escape(methodName) + r'\b.*?\n)(.*?)(\.end\s+method)',
      dotAll: true,
    );

    final match = methodPattern.firstMatch(content);
    if (match == null) {
      return PatchResult(success: false, error: 'Method $methodName not found in ${p.basename(filePath)}');
    }

    final newContent = content.replaceRange(
      match.start,
      match.end,
      '${match.group(1)}$newBody\n.end method',
    );

    await file.writeAsString(newContent);
    return PatchResult(
      success: true,
      filePath: filePath,
      originalCode: match.group(2) ?? '',
      newCode: newBody,
    );
  }

  /// 常用补丁模板
  static String boolReturnTrue(String returnType) {
    if (returnType == 'Z') return '    const/4 v0, 0x1\n    return v0';
    if (returnType == 'I' || returnType == 'J') return '    const/4 v0, 0x1\n    return v0';
    return '    return-void';
  }

  static String boolReturnFalse(String returnType) {
    if (returnType == 'Z') return '    const/4 v0, 0x0\n    return v0';
    if (returnType == 'I' || returnType == 'J') return '    const/4 v0, 0x0\n    return v0';
    return '    return-void';
  }

  /// 搜索 smali 文件中的内容
  Future<List<SmaliSearchResult>> searchInSmali(String query) async {
    final results = <SmaliSearchResult>[];
    final dir = Directory(smaliDir);
    if (!await dir.exists()) return results;

    await for (final entity in dir.list(recursive: true, followLinks: false)) {
      if (entity is File && entity.path.endsWith('.smali')) {
        final lines = await entity.readAsLines();
        for (int i = 0; i < lines.length; i++) {
          if (lines[i].toLowerCase().contains(query.toLowerCase())) {
            results.add(SmaliSearchResult(
              filePath: entity.path,
              lineNumber: i + 1,
              content: lines[i].trim(),
            ));
          }
        }
      }
    }
    return results;
  }
}