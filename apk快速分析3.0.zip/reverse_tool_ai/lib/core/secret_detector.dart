/// 硬编码密钥/Token 检测器 - 纯 Dart 实现
///
/// 扫描 DEX 字符串与类名，发现应用中泄露的敏感凭据，包括 AWS 凭据、Google API Key、
/// Stripe 密钥、GitHub Token、JWT、Slack Token、Telegram Bot Token、AES/RSA 密钥，
/// 以及 password/secret 等通用硬编码密码模式。
///
/// 所有检测均基于正则表达式完成，不依赖任何平台原生代码。
///
/// 用法：
/// ```dart
/// final result = SecretDetector.detect(dexStrings, classNames);
/// if (result.highCount > 0) {
///   print('发现 ${result.highCount} 个高危泄露凭据');
/// }
/// ```
library;

// ========== 风险等级 ==========

/// 密钥泄露风险等级
enum SecretRiskLevel {
  /// 高危 - 直接可利用的凭据（AWS/Stripe/GitHub/JWT 等）
  high,

  /// 中危 - 可能可利用或需结合上下文判断（AES 密钥、通用密码等）
  medium,

  /// 低危 - 辅助信息或弱信号（疑似密钥、提示性字符串等）
  low,
}

/// 风险等级对应的中文标签
extension SecretRiskLevelLabel on SecretRiskLevel {
  String get label {
    switch (this) {
      case SecretRiskLevel.high:
        return '高危';
      case SecretRiskLevel.medium:
        return '中危';
      case SecretRiskLevel.low:
        return '低危';
    }
  }
}

/// 来源类型：命中对象是 DEX 字符串还是类名
enum SecretSourceType {
  /// 命中于 DEX 字符串
  string,

  /// 命中于类名
  class_,
}

extension SecretSourceTypeLabel on SecretSourceType {
  String get label {
    switch (this) {
      case SecretSourceType.string:
        return 'DEX字符串';
      case SecretSourceType.class_:
        return '类名';
    }
  }
}

// ========== 结果模型 ==========

/// 单条密钥/Token 泄露发现
class SecretFinding {
  /// 密钥类型（中文，如 "AWS Access Key"、"JWT"、"AES密钥(32位)"）
  final String type;

  /// 脱敏后的匹配值（仅显示前6位与后4位，中间以 * 代替）
  final String maskedValue;

  /// 完整匹配值（用于进一步分析，展示时请优先使用 [maskedValue]）
  final String fullMatch;

  /// 风险等级
  final SecretRiskLevel riskLevel;

  /// 发现描述（中文）
  final String description;

  /// 来源类型（string/class）
  final SecretSourceType sourceType;

  /// 命中该凭据的具体来源值（类名或字符串原文，便于定位）
  final String source;

  const SecretFinding({
    required this.type,
    required this.maskedValue,
    required this.fullMatch,
    required this.riskLevel,
    required this.description,
    required this.sourceType,
    required this.source,
  });

  /// 风险等级中文标签
  String get riskLabel => riskLevel.label;

  /// 来源类型中文标签
  String get sourceLabel => sourceType.label;

  /// 简要摘要
  String get summary => '[$riskLabel] $type: $maskedValue (来源: $sourceLabel)';
}

/// 密钥检测汇总结果
class SecretDetectionResult {
  /// 全部发现明细
  final List<SecretFinding> findings;

  /// 高危数量
  final int highCount;

  /// 中危数量
  final int mediumCount;

  /// 低危数量
  final int lowCount;

  const SecretDetectionResult({
    required this.findings,
    required this.highCount,
    required this.mediumCount,
    required this.lowCount,
  });

  /// 未检测到任何泄露的空结果
  static const SecretDetectionResult empty = SecretDetectionResult(
    findings: [],
    highCount: 0,
    mediumCount: 0,
    lowCount: 0,
  );

  /// 总发现数
  int get totalCount => findings.length;

  /// 是否存在任意泄露
  bool get hasFinding => findings.isNotEmpty;

  /// 是否存在高危泄露
  bool get hasHighRisk => highCount > 0;

  /// 仅高危发现
  List<SecretFinding> get highFindings =>
      findings.where((f) => f.riskLevel == SecretRiskLevel.high).toList();

  /// 整体摘要
  String get summary {
    if (findings.isEmpty) return '未检测到硬编码密钥/Token';
    return '发现 $totalCount 个泄露凭据（高危 $highCount / 中危 $mediumCount / 低危 $lowCount）';
  }
}

// ========== 检测模式定义（内部使用） ==========

/// 单个密钥检测模式定义
class _SecretPattern {
  /// 密钥类型（中文）
  final String type;

  /// 正则表达式字符串
  final String pattern;

  /// 风险等级
  final SecretRiskLevel riskLevel;

  /// 描述（中文）
  final String description;

  /// 是否仅做子串匹配（false 表示用 contains 简单判断，如 RSA 私钥头）
  final bool isRegex;

  /// 是否区分大小写（默认区分；对 AWS Secret 等需不区分大小写的模式设为 false）
  final bool caseSensitive;

  const _SecretPattern({
    required this.type,
    required this.pattern,
    required this.riskLevel,
    required this.description,
    this.isRegex = true,
    this.caseSensitive = true,
  });
}

// ========== 检测器 ==========

/// 硬编码密钥/Token 检测器
///
/// 基于正则表达式扫描 DEX 字符串与类名，识别泄露的各类敏感凭据。
/// 所有方法均为静态方法，无需实例化。
class SecretDetector {
  SecretDetector._();

  /// 已知密钥/Token 检测模式库
  static const List<_SecretPattern> _patterns = [
    _SecretPattern(
      type: 'AWS Access Key',
      pattern: r'AKIA[0-9A-Z]{16}',
      riskLevel: SecretRiskLevel.high,
      description: 'AWS Access Key ID，可直接访问对应的 AWS 资源，存在严重泄露风险',
    ),
    _SecretPattern(
      type: 'AWS Secret Key',
      pattern: r'aws_secret_access_key',
      riskLevel: SecretRiskLevel.high,
      description: 'AWS Secret Access Key 标识，疑似硬编码 AWS 密钥，存在严重泄露风险',
      caseSensitive: false,
    ),
    _SecretPattern(
      type: 'Google API Key',
      pattern: r'AIza[0-9A-Za-z\-_]{35}',
      riskLevel: SecretRiskLevel.high,
      description: 'Google API Key，可用于调用 Google Cloud 服务，泄露后可能被滥用',
    ),
    _SecretPattern(
      type: 'Stripe Secret Key',
      pattern: r'sk_live_[0-9a-zA-Z]{24}',
      riskLevel: SecretRiskLevel.high,
      description: 'Stripe 生产环境 Secret Key，可直接操作支付账户，存在严重资金风险',
    ),
    _SecretPattern(
      type: 'Stripe Publishable Key',
      pattern: r'pk_live_[0-9a-zA-Z]{24}',
      riskLevel: SecretRiskLevel.medium,
      description: 'Stripe 生产环境 Publishable Key，常用于前端，泄露风险相对较低',
    ),
    _SecretPattern(
      type: 'GitHub Token',
      pattern: r'gh[ps]_[0-9a-zA-Z]{36}',
      riskLevel: SecretRiskLevel.high,
      description: 'GitHub Personal Access / Secret Token，可访问私有仓库与代码',
    ),
    _SecretPattern(
      type: 'JWT',
      pattern: r'eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*',
      riskLevel: SecretRiskLevel.high,
      description: 'JSON Web Token，可能包含用户身份与权限信息，泄露后可被伪造',
    ),
    _SecretPattern(
      type: 'Slack Token',
      pattern: r'xox[baprs]-[0-9a-zA-Z-]+',
      riskLevel: SecretRiskLevel.high,
      description: 'Slack Token，可访问对应工作区，泄露后可能被用于窃取信息',
    ),
    _SecretPattern(
      type: 'Telegram Bot Token',
      pattern: r'[0-9]{9,10}:[a-zA-Z0-9_-]{35}',
      riskLevel: SecretRiskLevel.high,
      description: 'Telegram Bot Token，可控制对应机器人，泄露后可被冒用',
    ),
    _SecretPattern(
      type: 'RSA Private Key',
      pattern: r'-----BEGIN RSA PRIVATE KEY-----',
      riskLevel: SecretRiskLevel.high,
      description: 'RSA 私钥文件头，疑似硬编码私钥，可直接解密对应通信',
      isRegex: false,
    ),
    _SecretPattern(
      type: 'Private Key',
      pattern: r'-----BEGIN.*PRIVATE KEY-----',
      riskLevel: SecretRiskLevel.high,
      description: '通用私钥文件头（EC/OpenSSL 等），疑似硬编码私钥',
      isRegex: false,
    ),
    _SecretPattern(
      type: 'AES密钥(32位)',
      pattern: r'[a-fA-F0-9]{32}',
      riskLevel: SecretRiskLevel.medium,
      description: '32 位十六进制字符串，疑似 AES-128 密钥（可能存在误报，需结合上下文判断）',
    ),
    _SecretPattern(
      type: 'AES密钥(64位)',
      pattern: r'[a-fA-F0-9]{64}',
      riskLevel: SecretRiskLevel.medium,
      description: '64 位十六进制字符串，疑似 AES-256 密钥（可能存在误报，需结合上下文判断）',
    ),
    _SecretPattern(
      type: '通用密码(password)',
      pattern: r'''password\s*[:=]\s*["']([^"']+)["']''',
      riskLevel: SecretRiskLevel.medium,
      description: '硬编码 password 赋值，疑似明文密码',
    ),
    _SecretPattern(
      type: '通用密码(secret)',
      pattern: r'''secret\s*[:=]\s*["']([^"']+)["']''',
      riskLevel: SecretRiskLevel.medium,
      description: '硬编码 secret 赋值，疑似明文密钥',
    ),
  ];

  /// AES 32/64 位十六进制密钥的最小长度阈值
  /// 长度不足的短字符串不视为有效密钥，降低误报
  static const int _minHexKeyLength = 32;

  /// 检测 DEX 字符串与类名中泄露的敏感凭据
  ///
  /// [dexStrings] DEX 中提取到的字符串集合
  /// [classNames] DEX 中解析到的类名集合
  ///
  /// 返回 [SecretDetectionResult]，包含全部发现、各级风险数量统计。
  static SecretDetectionResult detect(
    Set<String> dexStrings,
    Set<String> classNames,
  ) {
    final findings = <SecretFinding>[];
    final seenMatches = <String>{}; // 用于去重（同一完整匹配值+类型不重复计入）

    // 1. 扫描 DEX 字符串
    for (final str in dexStrings) {
      if (str.isEmpty) continue;
      _scanValue(str, SecretSourceType.string, str, findings, seenMatches);
    }

    // 2. 扫描类名
    for (final cls in classNames) {
      if (cls.isEmpty) continue;
      _scanValue(cls, SecretSourceType.class_, cls, findings, seenMatches);
    }

    // 统计各级风险数量
    var high = 0, medium = 0, low = 0;
    for (final f in findings) {
      switch (f.riskLevel) {
        case SecretRiskLevel.high:
          high++;
          break;
        case SecretRiskLevel.medium:
          medium++;
          break;
        case SecretRiskLevel.low:
          low++;
          break;
      }
    }

    return SecretDetectionResult(
      findings: findings,
      highCount: high,
      mediumCount: medium,
      lowCount: low,
    );
  }

  /// 扫描单个值，匹配所有模式并追加发现
  ///
  /// [value] 待扫描的字符串
  /// [sourceType] 来源类型
  /// [source] 具体来源（与 value 相同或为定位信息）
  /// [findings] 累积发现的列表
  /// [seenMatches] 用于去重的集合（"类型|完整匹配"）
  static void _scanValue(
    String value,
    SecretSourceType sourceType,
    String source,
    List<SecretFinding> findings,
    Set<String> seenMatches,
  ) {
    for (final p in _patterns) {
      if (p.isRegex) {
        _scanRegex(value, sourceType, source, p, findings, seenMatches);
      } else {
        _scanLiteral(value, sourceType, source, p, findings, seenMatches);
      }
    }
  }

  /// 使用正则表达式扫描
  static void _scanRegex(
    String value,
    SecretSourceType sourceType,
    String source,
    _SecretPattern p,
    List<SecretFinding> findings,
    Set<String> seenMatches,
  ) {
    final regex = RegExp(p.pattern, caseSensitive: p.caseSensitive);
    for (final match in regex.allMatches(value)) {
      final matched = match.group(0)!;
      if (matched.isEmpty) continue;

      // AES 十六进制密钥误报过滤：短字符串不视为密钥
      if ((p.type == 'AES密钥(32位)' || p.type == 'AES密钥(64位)') &&
          !_looksLikeAesKey(matched, value)) {
        continue;
      }

      final dedupeKey = '${p.type}|$matched';
      if (!seenMatches.add(dedupeKey)) continue;

      // 提取通用密码模式中的实际密码内容（捕获组1）
      String displayValue = matched;
      String description = p.description;
      if (match.groupCount >= 1) {
        final captured = match.group(1);
        if (captured != null && captured.isNotEmpty) {
          displayValue = captured;
        }
      }

      findings.add(SecretFinding(
        type: p.type,
        maskedValue: _mask(displayValue),
        fullMatch: displayValue,
        riskLevel: p.riskLevel,
        description: description,
        sourceType: sourceType,
        source: source,
      ));
    }
  }

  /// 使用字面子串匹配扫描（如 RSA 私钥头）
  static void _scanLiteral(
    String value,
    SecretSourceType sourceType,
    String source,
    _SecretPattern p,
    List<SecretFinding> findings,
    Set<String> seenMatches,
  ) {
    if (!value.contains(p.pattern)) return;

    final dedupeKey = '${p.type}|${p.pattern}';
    if (!seenMatches.add(dedupeKey)) return;

    findings.add(SecretFinding(
      type: p.type,
      maskedValue: _mask(p.pattern),
      fullMatch: p.pattern,
      riskLevel: p.riskLevel,
      description: p.description,
      sourceType: sourceType,
      source: source,
    ));
  }

  /// 判断十六进制串是否像真实 AES 密钥（降低误报）
  ///
  /// 规则：
  /// - 值本身长度需达到 [_minHexKeyLength]
  /// - 值不能全是同一字符（如 0000... 或 ffff...）
  /// - 值不应是纯数字（常见版本号/ID）
  static bool _looksLikeAesKey(String matched, String context) {
    if (matched.length < _minHexKeyLength) return false;
    // 全部相同字符
    final first = matched[0];
    if (matched.runes.every((c) => c == first.codeUnitAt(0))) return false;
    // 纯数字
    if (RegExp(r'^[0-9]+$').hasMatch(matched)) return false;
    return true;
  }

  /// 对敏感值进行脱敏处理：仅显示前6位与后4位，中间以 ****** 代替
  ///
  /// 长度不足 11 位时仅显示前2位 + 后2位；长度不足 5 位时全部替换为 ******。
  static String _mask(String value) {
    if (value.length <= 4) return '******';
    if (value.length <= 10) {
      final head = value.substring(0, 2);
      final tail = value.substring(value.length - 2);
      return '$head******$tail';
    }
    final head = value.substring(0, 6);
    final tail = value.substring(value.length - 4);
    return '$head******$tail';
  }
}
