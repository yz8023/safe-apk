import 'dart:typed_data';
import 'dart:convert';
import '../utils/hex_utils.dart';

/// 方法调用图分析器 - 构建方法间调用关系图（纯 Dart 实现）
///
/// 解析每个 DEX 中方法的 code_item，提取所有 invoke-* 指令引用的目标方法，
/// 构建方法调用关系图（caller -> callee），统计热点方法（被调用最多）。
/// 所有限制为防止大 DEX 导致 OOM：最多分析 3000 个类，每类 200 个方法。

// ========== 结果模型 ==========

/// 调用图节点：代表一个方法及其调用关系
class CallGraphNode {
  /// 类名（DEX 类型描述符，如 Lcom/example/Foo;）
  final String className;

  /// 方法名
  final String methodName;

  /// 方法签名（原型描述符，如 (Ljava/lang/String;)V）
  final String signature;

  /// 完整方法描述符（类名->方法名签名），作为节点唯一标识
  final String descriptor;

  /// 该方法调用的目标方法描述符列表（去重）
  final List<String> callees;

  /// 调用该方法的方法描述符列表（去重）
  final List<String> callers;

  const CallGraphNode({
    required this.className,
    required this.methodName,
    required this.signature,
    required this.descriptor,
    this.callees = const [],
    this.callers = const [],
  });

  /// 被调用次数（调用者数量）
  int get callerCount => callers.length;

  /// 调用次数（被调用目标数量）
  int get calleeCount => callees.length;
}

/// 调用图分析结果
class CallGraphResult {
  /// 总节点数（已分析的方法数）
  final int totalNodes;

  /// 总边数（调用关系总数）
  final int totalEdges;

  /// 热点方法列表（被调用最多的方法描述符，按被调用次数降序）
  final List<String> hotspotMethods;

  /// 所有调用图节点
  final List<CallGraphNode> nodes;

  const CallGraphResult({
    required this.totalNodes,
    required this.totalEdges,
    required this.hotspotMethods,
    required this.nodes,
  });

  /// 空结果
  static const CallGraphResult empty = CallGraphResult(
    totalNodes: 0,
    totalEdges: 0,
    hotspotMethods: [],
    nodes: [],
  );
}

// ========== DEX 内部引用表 ==========

class _MethodRef {
  final int classIdx;
  final int protoIdx;
  final int nameIdx;
  const _MethodRef(this.classIdx, this.protoIdx, this.nameIdx);
}

class _ProtoRef {
  final int shortyIdx;
  final int returnTypeIdx;
  final int paramsOff;
  const _ProtoRef(this.shortyIdx, this.returnTypeIdx, this.paramsOff);
}

class _DexImage {
  final Uint8List dex;
  final List<String> strings;
  final List<String> types;
  final List<_ProtoRef> protos;
  final List<_MethodRef> methods;

  const _DexImage(this.dex, this.strings, this.types, this.protos, this.methods);

  String typeDesc(int i) => (i >= 0 && i < types.length) ? types[i] : '?';
  String stringAt(int i) => (i >= 0 && i < strings.length) ? strings[i] : '';

  String protoDesc(int i) {
    if (i < 0 || i >= protos.length) return '()V';
    final p = protos[i];
    final ret = typeDesc(p.returnTypeIdx);
    if (p.paramsOff == 0) return '()$ret';
    final buf = StringBuffer('(');
    int pos = p.paramsOff;
    final (size, p1) = _readUleb(dex, pos);
    pos = p1;
    for (int k = 0; k < size && k < 200; k++) {
      if (pos + 2 > dex.length) break;
      final tIdx = HexUtils.readUint16LE(dex, pos);
      pos += 2;
      buf.write(typeDesc(tIdx));
    }
    buf.write(')');
    buf.write(ret);
    return buf.toString();
  }

  /// 方法完整描述符
  String methodDesc(int i) {
    if (i < 0 || i >= methods.length) return '?';
    final m = methods[i];
    return '${typeDesc(m.classIdx)}->${stringAt(m.nameIdx)}${protoDesc(m.protoIdx)}';
  }

  /// 方法所属类名
  String methodClass(int i) {
    if (i < 0 || i >= methods.length) return '?';
    return typeDesc(methods[i].classIdx);
  }

  /// 方法名
  String methodName(int i) {
    if (i < 0 || i >= methods.length) return '?';
    return stringAt(methods[i].nameIdx);
  }

  /// 方法签名（原型）
  String methodSignature(int i) {
    if (i < 0 || i >= methods.length) return '()V';
    return protoDesc(methods[i].protoIdx);
  }
}

// ========== 工具函数 ==========

/// 读取 ULEB128 编码的无符号整数，返回 (值, 下一个读取偏移)
(int, int) _readUleb(Uint8List b, int p) {
  int result = 0;
  int shift = 0;
  while (p < b.length) {
    final byte = b[p++];
    result |= (byte & 0x7F) << shift;
    if ((byte & 0x80) == 0) break;
    shift += 7;
  }
  return (result, p);
}

// ========== 分析器 ==========

class CallGraphAnalyzer {
  CallGraphAnalyzer._(); // 仅提供静态方法，禁止实例化

  /// 分析方法调用图
  ///
  /// [dexBytesList] 所有 DEX 文件字节列表
  ///
  /// 返回 [CallGraphResult]，包含所有方法的调用关系节点、总边数与热点方法。
  /// 限制：最多分析 3000 个类，每类 200 个方法，防止 OOM。
  static Future<CallGraphResult> analyze(List<Uint8List> dexBytesList) async {
    try {
      return _analyzeImpl(dexBytesList);
    } catch (e) {
      // 任何未预期的异常都不向上抛出，返回空结果
      return CallGraphResult.empty;
    }
  }

  static CallGraphResult _analyzeImpl(List<Uint8List> dexBytesList) {
    // 节点描述符 -> 可变节点数据（callees / callers 集合）
    final nodeMap = <String, _MutableNode>{};
    // 所有出现过的边（callerDesc -> calleeDesc），用于统计总边数
    var totalEdges = 0;

    for (final dex in dexBytesList) {
      try {
        final (edges, ) = _analyzeDex(dex, nodeMap);
        totalEdges += edges;
      } catch (_) {
        // 单个 DEX 解析失败不影响其他
      }
    }

    // 构建最终节点列表
    final nodes = <CallGraphNode>[];
    for (final entry in nodeMap.entries) {
      nodes.add(CallGraphNode(
        className: entry.value.className,
        methodName: entry.value.methodName,
        signature: entry.value.signature,
        descriptor: entry.key,
        callees: entry.value.callees.toList(),
        callers: entry.value.callers.toList(),
      ));
    }

    // 计算热点方法（被调用次数最多），取前 20
    final hotspots = nodeMap.entries.toList()
      ..sort((a, b) => b.value.callers.length.compareTo(a.value.callers.length));
    final hotspotMethods = <String>[];
    for (final e in hotspots) {
      if (e.value.callers.isEmpty) break;
      hotspotMethods.add('${e.key} (${e.value.callers.length} callers)');
      if (hotspotMethods.length >= 20) break;
    }

    return CallGraphResult(
      totalNodes: nodes.length,
      totalEdges: totalEdges,
      hotspotMethods: hotspotMethods,
      nodes: nodes,
    );
  }

  /// 分析单个 DEX，返回新增边数
  static (int,) _analyzeDex(Uint8List dex, Map<String, _MutableNode> nodeMap) {
    final img = _parseDex(dex);
    if (img == null) return (0,);

    final typeIdsSize = HexUtils.readUint32LE(dex, 64);
    final classDefsSize = HexUtils.readUint32LE(dex, 96);
    final classDefsOff = HexUtils.readUint32LE(dex, 100);

    const maxClasses = 3000;
    final classLimit = classDefsSize > maxClasses ? maxClasses : classDefsSize;

    var dexEdges = 0;
    for (int i = 0; i < classLimit; i++) {
      final off = classDefsOff + i * 32;
      if (off + 32 > dex.length) break;
      try {
        dexEdges += _analyzeClass(dex, img, off, typeIdsSize, nodeMap);
      } catch (_) {
        // 单个类解析失败跳过
      }
    }
    return (dexEdges,);
  }

  /// 分析单个类中的所有方法，返回新增边数
  static int _analyzeClass(Uint8List dex, _DexImage img, int off,
      int typeIdsSize, Map<String, _MutableNode> nodeMap) {
    final classIdx = HexUtils.readUint32LE(dex, off);
    final classDataOff = HexUtils.readUint32LE(dex, off + 24);
    if (classIdx >= typeIdsSize) return 0;
    final className = img.typeDesc(classIdx);
    if (!className.startsWith('L')) return 0;
    if (classDataOff == 0 || classDataOff >= dex.length) return 0;

    var pos = classDataOff;
    final sf = _readUleb(dex, pos);
    pos = sf.$2;
    final inf = _readUleb(dex, pos);
    pos = inf.$2;
    final dm = _readUleb(dex, pos);
    pos = dm.$2;
    final vm = _readUleb(dex, pos);
    pos = vm.$2;

    // 跳过字段区域
    for (int fi = 0; fi < sf.$1 + inf.$1; fi++) {
      if (pos >= dex.length) return 0;
      final a = _readUleb(dex, pos);
      pos = a.$2;
      final b = _readUleb(dex, pos);
      pos = b.$2;
    }

    const maxMethodsPerClass = 200;
    var edges = 0;

    // direct methods
    int prev = 0;
    final dmLimit = dm.$1 > maxMethodsPerClass ? maxMethodsPerClass : dm.$1;
    for (int mi = 0; mi < dmLimit; mi++) {
      if (pos >= dex.length) break;
      final r = _parseEncodedMethod(dex, pos, prev);
      pos = r.$2;
      prev = r.$3;
      try {
        edges += _scanMethod(dex, img, r.$1, r.$4, nodeMap);
      } catch (_) {}
    }

    // virtual methods
    prev = 0;
    final vmLimit = vm.$1 > maxMethodsPerClass ? maxMethodsPerClass : vm.$1;
    for (int mi = 0; mi < vmLimit; mi++) {
      if (pos >= dex.length) break;
      final r = _parseEncodedMethod(dex, pos, prev);
      pos = r.$2;
      prev = r.$3;
      try {
        edges += _scanMethod(dex, img, r.$1, r.$4, nodeMap);
      } catch (_) {}
    }

    return edges;
  }

  /// 解析 encoded_method 条目
  /// 返回 (methodIdx, 新pos, 新prevMethodIdx, codeOff)
  static (int, int, int, int) _parseEncodedMethod(Uint8List dex, int pos, int prev) {
    final diff = _readUleb(dex, pos);
    pos = diff.$2;
    final access = _readUleb(dex, pos);
    pos = access.$2;
    final codeOff = _readUleb(dex, pos);
    pos = codeOff.$2;
    final methodIdx = prev + diff.$1;
    return (methodIdx, pos, methodIdx, codeOff.$1);
  }

  /// 扫描方法体内的 invoke-* 指令，构建调用关系，返回新增边数
  static int _scanMethod(Uint8List dex, _DexImage img, int methodIdx,
      int codeOff, Map<String, _MutableNode> nodeMap) {
    // 即使无方法体（codeOff==0），也登记节点以便统计被调用
    final callerDesc = img.methodDesc(methodIdx);
    final caller = nodeMap.putIfAbsent(
        callerDesc,
        () => _MutableNode(
              className: img.methodClass(methodIdx),
              methodName: img.methodName(methodIdx),
              signature: img.methodSignature(methodIdx),
            ));

    if (codeOff == 0) return 0;
    if (codeOff + 16 > dex.length) return 0;

    final insnsSize = HexUtils.readUint32LE(dex, codeOff + 12);
    final codeStart = codeOff + 16;
    final safeInsnsSize = insnsSize > 250000 ? 250000 : insnsSize;
    final codeEnd = codeStart + safeInsnsSize * 2;
    if (codeEnd > dex.length) return 0;

    var edges = 0;
    int p = codeStart;
    int count = 0;
    const maxInstructions = 5000;
    while (p < codeEnd && count < maxInstructions) {
      final len = _instructionLength(dex, p);
      if (len <= 0) break;
      try {
        final (calleeDesc, calleeIdx) = _extractInvokeTarget(dex, img, p);
        if (calleeDesc != null && calleeDesc != '?') {
          // 记录调用边：caller -> callee
          if (caller.callees.add(calleeDesc)) {
            edges++;
          }
          // 在被调用方登记 caller（若节点已存在则更新，不存在也创建占位节点）
          final callee = nodeMap.putIfAbsent(
              calleeDesc,
              () => _MutableNode(
                    className: img.methodClass(calleeIdx),
                    methodName: img.methodName(calleeIdx),
                    signature: img.methodSignature(calleeIdx),
                  ));
          callee.callers.add(callerDesc);
        }
      } catch (_) {
        // 单条指令解析失败跳过
      }
      p += len;
      count++;
    }
    return edges;
  }

  /// 提取 invoke-* 指令的目标方法描述符与索引，非 invoke 指令返回 (null, -1)
  static (String?, int) _extractInvokeTarget(Uint8List dex, _DexImage img, int pos) {
    if (pos + 1 >= dex.length) return (null, -1);
    final u0 = HexUtils.readUint16LE(dex, pos);
    final op = u0 & 0xFF;
    // invoke-* 指令（0x60-0x69）
    if (op < 0x60 || op > 0x69) return (null, -1);
    if (pos + 3 >= dex.length) return (null, -1);
    final methodIdx = HexUtils.readUint16LE(dex, pos + 2);
    return (img.methodDesc(methodIdx), methodIdx);
  }

  /// 计算指令长度（字节），用于线性扫描推进
  static int _instructionLength(Uint8List dex, int pos) {
    if (pos + 1 >= dex.length) return 2;
    final u0 = HexUtils.readUint16LE(dex, pos);

    // 数据载荷伪指令
    if (u0 == 0x0100) {
      final size = HexUtils.readUint16LE(dex, pos + 2);
      return 8 + size * 4;
    }
    if (u0 == 0x0200) {
      final size = HexUtils.readUint16LE(dex, pos + 2);
      return 4 + size * 8;
    }
    if (u0 == 0x0300) {
      final width = HexUtils.readUint16LE(dex, pos + 2);
      final size = HexUtils.readUint32LE(dex, pos + 4);
      final len = 8 + size * width;
      return len + (len & 1);
    }

    final op = u0 & 0xFF;
    switch (_opFormat(op)) {
      case '10x':
      case '10t':
      case '11x':
      case '11n':
      case '12x':
        return 2;
      case '20t':
      case '21s':
      case '21h':
      case '21c':
      case '22x':
      case '22c':
      case '22b':
      case '22s':
      case '22t':
      case '23x':
        return 4;
      case '30t':
      case '31c':
      case '31i':
      case '31t':
      case '32x':
      case '35c':
      case '3rc':
        return 6;
      case '51l':
        return 10;
      default:
        return 2;
    }
  }

  /// 根据 opcode 返回指令格式标识
  static String _opFormat(int op) {
    const f = _fmtTable;
    return f[op] ?? '??';
  }

  // opcode -> 格式 映射表
  static const Map<int, String> _fmtTable = {
    0x00: '10x', 0x01: '12x', 0x02: '22x', 0x03: '32x', 0x04: '12x',
    0x05: '22x', 0x06: '32x', 0x07: '12x', 0x08: '22x', 0x09: '32x',
    0x0a: '11x', 0x0b: '11x', 0x0c: '11x', 0x0d: '11x', 0x0e: '10x',
    0x0f: '11x', 0x10: '11x', 0x11: '11x', 0x12: '11n', 0x13: '21s',
    0x14: '31i', 0x15: '21h', 0x16: '21s', 0x17: '31i', 0x18: '51l',
    0x19: '21h', 0x1a: '21c', 0x1b: '31c', 0x1c: '21c', 0x1d: '11x',
    0x1e: '11x', 0x1f: '21c', 0x20: '22c', 0x21: '12x', 0x22: '21c',
    0x23: '22c', 0x24: '35c', 0x25: '3rc', 0x26: '31t', 0x27: '11x',
    0x28: '10t', 0x29: '20t', 0x2a: '30t', 0x2b: '31t', 0x2c: '31t',
    0x2d: '23x', 0x2e: '23x', 0x2f: '23x', 0x30: '23x', 0x31: '23x',
    0x32: '22t', 0x33: '22t', 0x34: '22t', 0x35: '22t', 0x36: '22t',
    0x37: '22t', 0x38: '22t', 0x39: '22t', 0x3a: '22t', 0x3b: '22t',
    0x3c: '22t', 0x3d: '22t',
    0x44: '22c', 0x45: '22c', 0x46: '22c', 0x47: '22c', 0x48: '22c',
    0x49: '22c', 0x4a: '22c', 0x4b: '22c', 0x4c: '22c', 0x4d: '22c',
    0x4e: '22c', 0x4f: '22c', 0x50: '22c', 0x51: '22c',
    0x52: '21c', 0x53: '21c', 0x54: '21c', 0x55: '21c', 0x56: '21c',
    0x57: '21c', 0x58: '21c', 0x59: '21c', 0x5a: '21c', 0x5b: '21c',
    0x5c: '21c', 0x5d: '21c', 0x5e: '21c', 0x5f: '21c',
    0x60: '35c', 0x61: '35c', 0x62: '35c', 0x63: '35c', 0x64: '35c',
    0x65: '3rc', 0x66: '3rc', 0x67: '3rc', 0x68: '3rc', 0x69: '3rc',
    0x6a: '12x', 0x6b: '12x', 0x6c: '12x', 0x6d: '12x',
  };

  // ========== DEX 文件解析 ==========

  /// 解析 DEX 文件头与各引用表，构建 _DexImage
  static _DexImage? _parseDex(Uint8List dex) {
    if (dex.length < 112) return null;
    if (dex[0] != 0x64 || dex[1] != 0x65 || dex[2] != 0x78 || dex[3] != 0x0A) {
      return null;
    }

    final stringIdsSize = HexUtils.readUint32LE(dex, 56);
    final stringIdsOff = HexUtils.readUint32LE(dex, 60);
    final typeIdsSize = HexUtils.readUint32LE(dex, 64);
    final typeIdsOff = HexUtils.readUint32LE(dex, 68);
    final protoIdsSize = HexUtils.readUint32LE(dex, 72);
    final protoIdsOff = HexUtils.readUint32LE(dex, 76);
    final methodIdsSize = HexUtils.readUint32LE(dex, 88);
    final methodIdsOff = HexUtils.readUint32LE(dex, 92);

    // 解析字符串池
    final strings = <String>[];
    for (int i = 0; i < stringIdsSize && i < 200000; i++) {
      strings.add(_readDexString(dex, stringIdsOff, i));
    }

    // 解析类型池
    final types = <String>[];
    for (int i = 0; i < typeIdsSize && i < 200000; i++) {
      final strIdx = HexUtils.readUint32LE(dex, typeIdsOff + i * 4);
      types.add(strIdx < strings.length ? strings[strIdx] : '?');
    }

    // 解析原型池
    final protos = <_ProtoRef>[];
    for (int i = 0; i < protoIdsSize && i < 200000; i++) {
      final po = protoIdsOff + i * 12;
      if (po + 12 > dex.length) break;
      protos.add(_ProtoRef(
        HexUtils.readUint32LE(dex, po),
        HexUtils.readUint32LE(dex, po + 4),
        HexUtils.readUint32LE(dex, po + 8),
      ));
    }

    // 解析方法池
    final methods = <_MethodRef>[];
    for (int i = 0; i < methodIdsSize && i < 500000; i++) {
      final mo = methodIdsOff + i * 8;
      if (mo + 8 > dex.length) break;
      methods.add(_MethodRef(
        HexUtils.readUint16LE(dex, mo),
        HexUtils.readUint16LE(dex, mo + 2),
        HexUtils.readUint32LE(dex, mo + 4),
      ));
    }

    return _DexImage(dex, strings, types, protos, methods);
  }

  /// 读取 DEX 字符串池中指定索引的字符串
  static String _readDexString(Uint8List dex, int stringIdsOff, int idx) {
    if (stringIdsOff + idx * 4 + 4 > dex.length) return '';
    final dataOff = HexUtils.readUint32LE(dex, stringIdsOff + idx * 4);
    if (dataOff >= dex.length) return '';
    var pos = dataOff;
    while (pos < dex.length && (dex[pos] & 0x80) != 0) pos++;
    pos++;
    if (pos >= dex.length) return '';
    final start = pos;
    while (pos < dex.length && dex[pos] != 0) pos++;
    if (pos == start) return '';
    try {
      return utf8.decode(dex.sublist(start, pos), allowMalformed: true);
    } catch (_) {
      return '';
    }
  }
}

// ========== 内部可变节点 ==========

/// 构建过程中的可变节点（使用 Set 去重 callees / callers）
class _MutableNode {
  final String className;
  final String methodName;
  final String signature;
  final Set<String> callees = {};
  final Set<String> callers = {};

  _MutableNode({
    required this.className,
    required this.methodName,
    required this.signature,
  });
}
