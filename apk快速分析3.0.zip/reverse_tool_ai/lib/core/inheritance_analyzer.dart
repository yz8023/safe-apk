import 'dart:typed_data';
import 'dart:convert';
import '../utils/hex_utils.dart';

/// 类继承关系树分析器 - 从 DEX 中构建类继承层级树（纯 Dart 实现）
///
/// 从 class_def_item 解析 superclassIdx 与 interfacesOff，构建类继承层级树，
/// 支持查找某类的所有子类。所有解析逻辑均为纯 Dart 实现，不依赖任何外部库。

// ========== 结果模型 ==========

/// 继承树节点：代表一个类及其继承关系
class InheritanceNode {
  /// 类名（DEX 类型描述符，如 Lcom/example/Foo;）
  final String className;

  /// 父类名（DEX 类型描述符），无父类时为 null
  final String? superClassName;

  /// 实现的接口列表（DEX 类型描述符）
  final List<String> interfaces;

  /// 直接子类名列表
  final List<String> children;

  /// 访问标志（ACC_* 位掩码）
  final int accessFlags;

  const InheritanceNode({
    required this.className,
    this.superClassName,
    this.interfaces = const [],
    this.children = const [],
    this.accessFlags = 0,
  });

  /// 是否为接口
  bool get isInterface => (accessFlags & 0x0200) != 0;

  /// 是否为抽象类
  bool get isAbstract => (accessFlags & 0x0400) != 0;

  /// 是否为 final 类
  bool get isFinal => (accessFlags & 0x0010) != 0;

  /// 访问标志可读字符串
  String get accessFlagsStr {
    final parts = <String>[];
    if (accessFlags & 0x0001 != 0) parts.add('public');
    if (accessFlags & 0x0002 != 0) parts.add('private');
    if (accessFlags & 0x0004 != 0) parts.add('protected');
    if (accessFlags & 0x0008 != 0) parts.add('static');
    if (accessFlags & 0x0010 != 0) parts.add('final');
    if (accessFlags & 0x0200 != 0) parts.add('interface');
    if (accessFlags & 0x0400 != 0) parts.add('abstract');
    return parts.join(' ');
  }
}

/// 继承树分析结果
class InheritanceTree {
  /// 总类数
  final int totalClasses;

  /// 根类列表（无父类或父类为 java.lang.Object 的类）
  final List<String> rootClasses;

  /// 类名 -> 继承节点 的映射
  final Map<String, InheritanceNode> tree;

  const InheritanceTree({
    required this.totalClasses,
    required this.rootClasses,
    required this.tree,
  });

  /// 空结果
  static const InheritanceTree empty = InheritanceTree(
    totalClasses: 0,
    rootClasses: [],
    tree: {},
  );

  /// 查找指定类的所有子类（递归，包含间接子类）
  ///
  /// [className] 类名（DEX 类型描述符，如 Lcom/example/Foo;）
  /// 返回所有后代类名列表，若类不存在返回空列表。
  List<String> findSubclasses(String className) {
    try {
      final result = <String>[];
      final visited = <String>{};
      _collectChildren(className, result, visited);
      return result;
    } catch (_) {
      return [];
    }
  }

  void _collectChildren(
      String parent, List<String> result, Set<String> visited) {
    final node = tree[parent];
    if (node == null) return;
    for (final child in node.children) {
      if (visited.add(child)) {
        result.add(child);
        _collectChildren(child, result, visited);
      }
    }
  }

  /// 获取指定类的继承链（从该类到根类的父类路径）
  ///
  /// [className] 类名（DEX 类型描述符）
  /// 返回从该类到根类的父类列表，若类不存在返回空列表。
  List<String> getAncestry(String className) {
    try {
      final result = <String>[];
      var current = className;
      final visited = <String>{};
      while (true) {
        final node = tree[current];
        if (node == null) break;
        final parent = node.superClassName;
        if (parent == null || parent.isEmpty) break;
        if (!visited.add(parent)) break; // 防止循环引用
        result.add(parent);
        current = parent;
      }
      return result;
    } catch (_) {
      return [];
    }
  }
}

// ========== DEX 内部引用表 ==========

class _DexImage {
  final Uint8List dex;
  final List<String> strings;
  final List<String> types;

  const _DexImage(this.dex, this.strings, this.types);

  String typeDesc(int i) => (i >= 0 && i < types.length) ? types[i] : '?';
  String stringAt(int i) => (i >= 0 && i < strings.length) ? strings[i] : '';
}

// ========== 分析器 ==========

class InheritanceAnalyzer {
  InheritanceAnalyzer._(); // 仅提供静态方法，禁止实例化

  /// 分析类继承关系树
  ///
  /// [dexBytesList] 所有 DEX 文件字节列表
  ///
  /// 返回 [InheritanceTree]，包含所有类的继承层级、根类列表与类名映射。
  static Future<InheritanceTree> analyze(List<Uint8List> dexBytesList) async {
    try {
      return _analyzeImpl(dexBytesList);
    } catch (e) {
      // 任何未预期的异常都不向上抛出，返回空结果
      return InheritanceTree.empty;
    }
  }

  static InheritanceTree _analyzeImpl(List<Uint8List> dexBytesList) {
    // 类名 -> 类基本信息（父类、接口、访问标志）
    final classInfoMap = <String, _ClassInfo>{};

    for (final dex in dexBytesList) {
      try {
        _collectClasses(dex, classInfoMap);
      } catch (_) {
        // 单个 DEX 解析失败不影响其他
      }
    }

    // 构建子类映射：父类名 -> 子类名列表
    final childrenMap = <String, List<String>>{};
    for (final entry in classInfoMap.entries) {
      final parent = entry.value.superClassName;
      if (parent != null && parent.isNotEmpty && parent != '?') {
        childrenMap.putIfAbsent(parent, () => []).add(entry.key);
      }
    }

    // 构建继承树节点
    final tree = <String, InheritanceNode>{};
    for (final entry in classInfoMap.entries) {
      final info = entry.value;
      tree[entry.key] = InheritanceNode(
        className: entry.key,
        superClassName: info.superClassName,
        interfaces: info.interfaces,
        children: childrenMap[entry.key] ?? const [],
        accessFlags: info.accessFlags,
      );
    }

    // 计算根类：无父类或父类为 java.lang.Object
    const objectClass = 'Ljava/lang/Object;';
    final rootClasses = <String>[];
    for (final entry in classInfoMap.entries) {
      final parent = entry.value.superClassName;
      if (parent == null || parent.isEmpty || parent == '?' || parent == objectClass) {
        rootClasses.add(entry.key);
      }
    }
    rootClasses.sort();

    return InheritanceTree(
      totalClasses: tree.length,
      rootClasses: rootClasses,
      tree: tree,
    );
  }

  /// 从单个 DEX 收集所有类的继承信息
  static void _collectClasses(Uint8List dex, Map<String, _ClassInfo> classInfoMap) {
    final img = _parseDex(dex);
    if (img == null) return;

    final typeIdsSize = HexUtils.readUint32LE(dex, 64);
    final classDefsSize = HexUtils.readUint32LE(dex, 96);
    final classDefsOff = HexUtils.readUint32LE(dex, 100);

    // 限制处理的类数量，防止大 DEX 导致 OOM
    const maxClasses = 3000;
    final classLimit = classDefsSize > maxClasses ? maxClasses : classDefsSize;

    for (int i = 0; i < classLimit; i++) {
      final off = classDefsOff + i * 32;
      if (off + 32 > dex.length) break;
      try {
        final info = _parseClassDef(dex, img, off, typeIdsSize);
        if (info != null) {
          classInfoMap[info.className] = info;
        }
      } catch (_) {
        // 单个类解析失败跳过
      }
    }
  }

  /// 解析单个 class_def_item
  static _ClassInfo? _parseClassDef(
      Uint8List dex, _DexImage img, int off, int typeIdsSize) {
    final classIdx = HexUtils.readUint32LE(dex, off);
    final accessFlags = HexUtils.readUint32LE(dex, off + 4);
    final superclassIdx = HexUtils.readUint32LE(dex, off + 8);
    final interfacesOff = HexUtils.readUint32LE(dex, off + 12);

    if (classIdx >= typeIdsSize) return null;
    final className = img.typeDesc(classIdx);
    if (!className.startsWith('L') && !className.startsWith('[')) return null;

    // 解析父类
    String? superClassName;
    if (superclassIdx != 0xFFFFFFFF && superclassIdx < typeIdsSize) {
      superClassName = img.typeDesc(superclassIdx);
    }

    // 解析接口列表
    final interfaces = <String>[];
    if (interfacesOff != 0 && interfacesOff + 4 <= dex.length) {
      final typeListSize = HexUtils.readUint32LE(dex, interfacesOff);
      for (int ii = 0; ii < typeListSize && ii < 200; ii++) {
        final typeIdx = HexUtils.readUint16LE(dex, interfacesOff + 4 + ii * 2);
        if (typeIdx < typeIdsSize) {
          interfaces.add(img.typeDesc(typeIdx));
        }
      }
    }

    return _ClassInfo(
      className: className,
      superClassName: superClassName,
      interfaces: interfaces,
      accessFlags: accessFlags,
    );
  }

  // ========== DEX 文件解析 ==========

  /// 解析 DEX 文件头与字符串/类型表，构建 _DexImage
  static _DexImage? _parseDex(Uint8List dex) {
    if (dex.length < 112) return null;
    // 验证 DEX 魔数 'dex\n'
    if (dex[0] != 0x64 || dex[1] != 0x65 || dex[2] != 0x78 || dex[3] != 0x0A) {
      return null;
    }

    final stringIdsSize = HexUtils.readUint32LE(dex, 56);
    final stringIdsOff = HexUtils.readUint32LE(dex, 60);
    final typeIdsSize = HexUtils.readUint32LE(dex, 64);
    final typeIdsOff = HexUtils.readUint32LE(dex, 68);

    // 解析字符串池
    final strings = <String>[];
    for (int i = 0; i < stringIdsSize && i < 200000; i++) {
      strings.add(_readDexString(dex, stringIdsOff, i));
    }

    // 解析类型池
    final types = <String>[];
    for (int i = 0; i < typeIdsSize && i < 200000; i++) {
      final strIdx = HexUtils.readUint32LE(dex, typeIdsOff + i * 4);
      types.add(strIdx < strings.length ? strings[strIdx] : '?');
    }

    return _DexImage(dex, strings, types);
  }

  /// 读取 DEX 字符串池中指定索引的字符串
  static String _readDexString(Uint8List dex, int stringIdsOff, int idx) {
    if (stringIdsOff + idx * 4 + 4 > dex.length) return '';
    final dataOff = HexUtils.readUint32LE(dex, stringIdsOff + idx * 4);
    if (dataOff >= dex.length) return '';
    // string_data_item: utf16_size (uleb128) + mutf8[] + 0x00
    var pos = dataOff;
    while (pos < dex.length && (dex[pos] & 0x80) != 0) pos++;
    pos++; // 跳过 uleb128 最后一个字节
    if (pos >= dex.length) return '';
    final start = pos;
    while (pos < dex.length && dex[pos] != 0) pos++;
    if (pos == start) return '';
    try {
      return utf8.decode(dex.sublist(start, pos), allowMalformed: true);
    } catch (_) {
      return '';
    }
  }
}

// ========== 内部类信息 ==========

/// 解析过程中的类信息载体
class _ClassInfo {
  final String className;
  final String? superClassName;
  final List<String> interfaces;
  final int accessFlags;

  _ClassInfo({
    required this.className,
    required this.superClassName,
    required this.interfaces,
    required this.accessFlags,
  });
}
