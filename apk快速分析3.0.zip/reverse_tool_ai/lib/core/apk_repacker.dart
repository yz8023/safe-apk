import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';
import 'dart:math' as math;
import '../utils/hex_utils.dart';

/// APK 重新打包器 - 纯 Dart 实现
///
/// 读取原始 APK 的所有 ZIP 条目，替换指定条目后重新写入为新的 ZIP/APK 文件。
/// 支持 STORE（无压缩）和 DEFLATE 两种压缩方式，自动重算 CRC-32。
///
/// 用法：
/// ```dart
/// final result = await ApkRepacker.repackage(
///   '/path/to/original.apk',
///   {'classes.dex': modifiedDexBytes},
///   '/path/to/output.apk',
/// );
/// ```

// ========== 结果模型 ==========

/// APK 打包条目
class ApkRepackEntry {
  final String name;
  final Uint8List data;
  final int compressionMethod; // 0=STORE, 8=DEFLATE
  final bool isModified;

  const ApkRepackEntry({
    required this.name,
    required this.data,
    required this.compressionMethod,
    required this.isModified,
  });
}

/// APK 重新打包结果
class ApkRepackResult {
  final bool success;
  final String? outputPath;
  final int entryCount;
  final int totalSize;
  final String? error;

  const ApkRepackResult({
    required this.success,
    this.outputPath,
    this.entryCount = 0,
    this.totalSize = 0,
    this.error,
  });
}

// ========== 内部 ZIP 条目结构 ==========

class _RawZipEntry {
  final String name;
  final int localHeaderOffset;
  final int compressedSize;
  final int uncompressedSize;
  final int compressionMethod;
  final int crc32;
  _RawZipEntry({
    required this.name,
    required this.localHeaderOffset,
    required this.compressedSize,
    required this.uncompressedSize,
    required this.compressionMethod,
    required this.crc32,
  });
}

// ========== 打包器 ==========

class ApkRepacker {
  ApkRepacker._();

  /// 重新打包 APK
  ///
  /// [originalApkPath] 原始 APK 路径
  /// [modifiedEntries] 需要替换的文件条目（路径→新数据）
  /// [outputPath] 输出 APK 路径
  static Future<ApkRepackResult> repackage(
    String originalApkPath,
    Map<String, Uint8List> modifiedEntries,
    String outputPath,
  ) async {
    try {
      final bytes = await File(originalApkPath).readAsBytes();
      final rawEntries = _parseZipCentralDirectory(bytes);

      if (rawEntries.isEmpty) {
        return const ApkRepackResult(success: false, error: '无法解析原始 APK 的 ZIP 结构');
      }

      // 准备输出缓冲
      final output = BytesBuilder();
      final centralDir = BytesBuilder();
      int entryCount = 0;
      int localOffset = 0;

      for (final entry in rawEntries) {
        // 跳过 META-INF/ 下的签名文件（重新打包时清除旧签名）
        if (entry.name.startsWith('META-INF/') &&
            (entry.name.endsWith('.SF') ||
             entry.name.endsWith('.RSA') ||
             entry.name.endsWith('.DSA') ||
             entry.name == 'META-INF/MANIFEST.MF')) {
          continue;
        }

        // 获取文件数据（优先使用修改后的数据）
        Uint8List fileData;
        if (modifiedEntries.containsKey(entry.name)) {
          fileData = modifiedEntries[entry.name]!;
        } else {
          fileData = _extractFile(bytes, entry);
        }

        // 计算压缩
        Uint8List compressedData;
        int compressionMethod;
        if (entry.compressionMethod == 8 && fileData.length > 0) {
          try {
            final codec = ZLibCodec(raw: true);
            compressedData = Uint8List.fromList(codec.encoder.convert(fileData));
            // 如果压缩后反而更大，用 STORE
            if (compressedData.length >= fileData.length) {
              compressionMethod = 0;
              compressedData = fileData;
            } else {
              compressionMethod = 8;
            }
          } catch (_) {
            compressionMethod = 0;
            compressedData = fileData;
          }
        } else {
          compressionMethod = 0;
          compressedData = fileData;
        }

        final crc = _calculateCrc32(fileData);
        final nameBytes = utf8.encode(entry.name);
        final currentLocalOffset = localOffset;

        // 写入 Local File Header
        final localHeader = ByteData(30 + nameBytes.length);
        localHeader.setUint32(0, 0x04034b50, Endian.little); // 签名
        localHeader.setUint16(4, 20, Endian.little); // 版本
        localHeader.setUint16(6, 0, Endian.little); // 标志
        localHeader.setUint16(8, compressionMethod, Endian.little);
        localHeader.setUint16(10, 0, Endian.little); // 修改时间
        localHeader.setUint16(12, 0x0021, Endian.little); // 修改日期 (1980-01-01)
        localHeader.setUint32(14, crc, Endian.little);
        localHeader.setUint32(18, compressedData.length, Endian.little); // 压缩大小
        localHeader.setUint32(22, fileData.length, Endian.little); // 未压缩大小
        localHeader.setUint16(26, nameBytes.length, Endian.little);
        localHeader.setUint16(28, 0, Endian.little); // 额外字段长度

        output.add(localHeader.buffer.asUint8List());
        output.add(nameBytes);
        output.add(compressedData);
        localOffset += 30 + nameBytes.length + compressedData.length;

        // 写入 Central Directory Entry
        final cdEntry = ByteData(46 + nameBytes.length);
        cdEntry.setUint32(0, 0x02014b50, Endian.little);
        cdEntry.setUint16(4, 20, Endian.little); // 版本制作
        cdEntry.setUint16(6, 20, Endian.little); // 版本需要
        cdEntry.setUint16(8, 0, Endian.little); // 标志
        cdEntry.setUint16(10, compressionMethod, Endian.little);
        cdEntry.setUint16(12, 0, Endian.little); // 时间
        cdEntry.setUint16(14, 0x0021, Endian.little); // 日期
        cdEntry.setUint32(16, crc, Endian.little);
        cdEntry.setUint32(20, compressedData.length, Endian.little);
        cdEntry.setUint32(24, fileData.length, Endian.little);
        cdEntry.setUint16(28, nameBytes.length, Endian.little);
        cdEntry.setUint16(30, 0, Endian.little); // 额外字段长度
        cdEntry.setUint16(32, 0, Endian.little); // 注释长度
        cdEntry.setUint16(34, 0, Endian.little); // 磁盘号
        cdEntry.setUint16(36, 0, Endian.little); // 内部属性
        cdEntry.setUint32(38, 0, Endian.little); // 外部属性
        cdEntry.setUint32(42, currentLocalOffset, Endian.little);

        centralDir.add(cdEntry.buffer.asUint8List());
        centralDir.add(nameBytes);
        entryCount++;
      }

      final cdStart = localOffset;
      final cdBytes = centralDir.takeBytes();
      final cdSize = cdBytes.length;

      // 写入 Central Directory
      output.add(cdBytes);

      // 写入 End of Central Directory Record
      final eocd = ByteData(22);
      eocd.setUint32(0, 0x06054b50, Endian.little);
      eocd.setUint16(4, 0, Endian.little); // 磁盘号
      eocd.setUint16(6, 0, Endian.little); // 中央目录磁盘号
      eocd.setUint16(8, entryCount, Endian.little);
      eocd.setUint16(10, entryCount, Endian.little);
      eocd.setUint32(12, cdSize, Endian.little);
      eocd.setUint32(16, cdStart, Endian.little);
      eocd.setUint16(20, 0, Endian.little); // 注释长度

      output.add(eocd.buffer.asUint8List());

      // 写入文件
      final result = output.takeBytes();
      await File(outputPath).writeAsBytes(result);

      return ApkRepackResult(
        success: true,
        outputPath: outputPath,
        entryCount: entryCount,
        totalSize: result.length,
      );
    } catch (e) {
      return ApkRepackResult(success: false, error: '打包失败: $e');
    }
  }

  // ========== ZIP 解析 ==========

  static List<_RawZipEntry> _parseZipCentralDirectory(Uint8List bytes) {
    final entries = <_RawZipEntry>[];
    int offset = bytes.length - 22;
    if (offset < 0) return entries;

    final searchStart = math.max(0, bytes.length - 22 - 65535);
    while (offset >= searchStart) {
      if (bytes[offset] == 0x50 && bytes[offset + 1] == 0x4B &&
          bytes[offset + 2] == 0x05 && bytes[offset + 3] == 0x06) {
        final commentLen = HexUtils.readUint16LE(bytes, offset + 20);
        if (offset + 22 + commentLen == bytes.length) break;
      }
      offset--;
    }
    if (offset < searchStart) return entries;

    final cdOffset = HexUtils.readUint32LE(bytes, offset + 16);
    final entryCount = HexUtils.readUint16LE(bytes, offset + 10);

    int pos = cdOffset;
    for (int i = 0; i < entryCount && pos < bytes.length - 46; i++) {
      if (bytes[pos] != 0x50 || bytes[pos + 1] != 0x4B) break;
      final nameLen = HexUtils.readUint16LE(bytes, pos + 28);
      final extraLen = HexUtils.readUint16LE(bytes, pos + 30);
      final commentLen = HexUtils.readUint16LE(bytes, pos + 32);
      final localOffset = HexUtils.readUint32LE(bytes, pos + 42);
      final compSize = HexUtils.readUint32LE(bytes, pos + 20);
      final uncompSize = HexUtils.readUint32LE(bytes, pos + 24);
      final method = HexUtils.readUint16LE(bytes, pos + 10);
      final crc32 = HexUtils.readUint32LE(bytes, pos + 16);

      if (pos + 46 + nameLen > bytes.length) break;
      final name = utf8.decode(bytes.sublist(pos + 46, pos + 46 + nameLen), allowMalformed: true);
      entries.add(_RawZipEntry(
        name: name,
        localHeaderOffset: localOffset,
        compressedSize: compSize,
        uncompressedSize: uncompSize,
        compressionMethod: method,
        crc32: crc32,
      ));
      pos += 46 + nameLen + extraLen + commentLen;
    }
    return entries;
  }

  static Uint8List _extractFile(Uint8List zipBytes, _RawZipEntry entry) {
    int pos = entry.localHeaderOffset;
    if (pos + 30 > zipBytes.length) return Uint8List(0);
    final nameLen = HexUtils.readUint16LE(zipBytes, pos + 26);
    final extraLen = HexUtils.readUint16LE(zipBytes, pos + 28);
    int dataStart = pos + 30 + nameLen + extraLen;

    if (entry.compressionMethod == 0) {
      final end = math.min(dataStart + entry.uncompressedSize, zipBytes.length);
      return Uint8List.fromList(zipBytes.sublist(dataStart, end));
    } else if (entry.compressionMethod == 8) {
      final end = math.min(dataStart + entry.compressedSize, zipBytes.length);
      final compressed = zipBytes.sublist(dataStart, end);
      try {
        final codec = ZLibCodec(raw: true);
        return Uint8List.fromList(codec.decoder.convert(compressed));
      } catch (_) {
        return Uint8List.fromList(compressed);
      }
    }
    return Uint8List(0);
  }

  // ========== CRC-32 ==========

  static final List<int> _crcTable = _buildCrcTable();

  static List<int> _buildCrcTable() {
    final table = List<int>.filled(256, 0);
    for (int i = 0; i < 256; i++) {
      int crc = i;
      for (int j = 0; j < 8; j++) {
        if (crc & 1 != 0) {
          crc = 0xEDB88320 ^ (crc >> 1);
        } else {
          crc >>= 1;
        }
      }
      table[i] = crc;
    }
    return table;
  }

  static int _calculateCrc32(Uint8List data) {
    int crc = 0xFFFFFFFF;
    for (final byte in data) {
      crc = _crcTable[(crc ^ byte) & 0xFF] ^ (crc >> 8);
    }
    return (crc ^ 0xFFFFFFFF) & 0xFFFFFFFF;
  }
}
