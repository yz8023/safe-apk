import 'dart:typed_data';
import 'dart:convert';

/// APK 证书/签名解析器
class CertParser {
  /// 从 RSA/DSA 证书数据中提取信息
  static CertInfo? parse(Uint8List data) {
    if (data.length < 20) return null;

    // 尝试解析 PKCS#7 / X.509 证书
    // 简化实现：查找常见的证书字段
    final text = String.fromCharCodes(data.where((b) => b >= 32 && b < 127).toList());

    String? subject;
    String? issuer;
    String? serialNumber;
    DateTime? validFrom;
    DateTime? validTo;
    String? fingerprint;
    String? algorithm;

    // 尝试提取 Subject
    final subjectMatch = RegExp(r'CN=([^,\n]+)').firstMatch(text);
    if (subjectMatch != null) subject = subjectMatch.group(1)?.trim();

    // 尝试提取算法
    if (text.contains('SHA256')) algorithm = 'SHA256withRSA';
    else if (text.contains('SHA1')) algorithm = 'SHA1withRSA';
    else if (text.contains('MD5')) algorithm = 'MD5withRSA';

    // 尝试计算简单指纹（SHA-256 的前几位）
    // 实际应使用 crypto 库计算哈希，这里仅做标记
    fingerprint = '(${data.length} bytes)';

    return CertInfo(
      subject: subject ?? 'Unknown',
      issuer: issuer ?? 'Unknown',
      serialNumber: serialNumber ?? 'Unknown',
      validFrom: validFrom,
      validTo: validTo,
      fingerprint: fingerprint,
      algorithm: algorithm ?? 'Unknown',
    );
  }

  /// 检测 APK 使用的签名版本
  static List<int> detectSignatureVersion(List<String> entryNames) {
    final versions = <int>[];
    // V1 签名：存在 META-INF/*.SF 和 META-INF/*.RSA/DSA/EC
    if (entryNames.any((e) => e.startsWith('META-INF/') && (e.endsWith('.SF') || e.endsWith('.RSA') || e.endsWith('.DSA') || e.endsWith('.EC')))) {
      versions.add(1);
    }
    // V2/V3 签名：存在 APK Signing Block（在 ZIP central directory 之前）
    // 无法仅从文件名判断，标记为可能
    if (entryNames.contains('META-INF/MANIFEST.MF')) {
      if (!versions.contains(1)) versions.add(1);
    }
    return versions.isEmpty ? [0] : versions;
  }
}

class CertInfo {
  final String subject;
  final String issuer;
  final String serialNumber;
  final DateTime? validFrom;
  final DateTime? validTo;
  final String fingerprint;
  final String algorithm;

  const CertInfo({
    required this.subject,
    required this.issuer,
    required this.serialNumber,
    this.validFrom,
    this.validTo,
    required this.fingerprint,
    required this.algorithm,
  });
}
