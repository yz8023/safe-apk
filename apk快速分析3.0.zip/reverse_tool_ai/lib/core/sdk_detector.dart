/// 第三方 SDK 检测器 - 通过扫描 DEX 类名与字符串识别已知第三方 SDK/库
///
/// 维护一份常见 Android 第三方 SDK 的包名/路径特征表，对 APK 中提取出的
/// DEX 类名集合与字符串集合做包含匹配，归纳出应用集成的 SDK 列表及分类统计。
/// 检测基于子串匹配（package path / 类名前缀），不依赖外部依赖，纯 Dart 实现。

// ========== 结果模型 ==========

/// 单个第三方 SDK 的识别信息
class SdkInfo {
  /// SDK 名称
  final String name;

  /// 分类，如 '广告'、'统计'、'推送'、'社交'、'支付'、'地图'、'安全'、'框架'、'其他'
  final String category;

  /// SDK 描述
  final String description;

  /// 实际命中的特征串列表
  final List<String> matchedPatterns;

  const SdkInfo({
    required this.name,
    required this.category,
    required this.description,
    required this.matchedPatterns,
  });
}

/// SDK 检测汇总结果
class SdkDetectionResult {
  /// 所有检测到的 SDK
  final List<SdkInfo> sdks;

  /// 检测到的 SDK 总数
  final int totalSdkCount;

  /// 按分类统计的数量分布
  final Map<String, int> categories;

  const SdkDetectionResult({
    required this.sdks,
    required this.totalSdkCount,
    required this.categories,
  });
}

// ========== 内部特征定义 ==========

/// 一条 SDK 特征定义（名称 / 分类 / 描述 / 命中特征串集合）
class _SdkDefinition {
  final String name;
  final String category;
  final String description;
  final List<String> patterns;

  const _SdkDefinition(this.name, this.category, this.description, this.patterns);
}

// ========== 检测器 ==========

class SdkDetector {
  SdkDetector._(); // 仅提供静态方法，禁止实例化

  /// 检测已知第三方 SDK
  ///
  /// 遍历内置 SDK 特征表，对每条特征串检查是否被 [classNames] 或 [dexStrings]
  /// 中的任意字符串包含。命中则记录该 SDK 及其实际匹配到的特征串，最终汇总为
  /// [SdkDetectionResult]（含 SDK 列表、总数与分类统计）。
  static SdkDetectionResult detect(Set<String> dexStrings, Set<String> classNames) {
    final sdks = <SdkInfo>[];

    for (final def in _sdkRegistry) {
      final matched = <String>[];
      for (final pattern in def.patterns) {
        final hit = classNames.any((c) => c.contains(pattern)) ||
            dexStrings.any((s) => s.contains(pattern));
        if (hit) matched.add(pattern);
      }
      if (matched.isNotEmpty) {
        sdks.add(SdkInfo(
          name: def.name,
          category: def.category,
          description: def.description,
          matchedPatterns: matched,
        ));
      }
    }

    // 按分类汇总数量
    final categories = <String, int>{};
    for (final sdk in sdks) {
      categories[sdk.category] = (categories[sdk.category] ?? 0) + 1;
    }

    return SdkDetectionResult(
      sdks: sdks,
      totalSdkCount: sdks.length,
      categories: categories,
    );
  }

  /// 已知 SDK 特征表（按分类分组，特征串为 DEX 中常见的包路径或全限定类名片段）
  static const _sdkRegistry = <_SdkDefinition>[
    // -------- 广告 --------
    _SdkDefinition('AdMob', '广告', 'Google AdMob 广告 SDK',
        ['com/google/ads', 'com.google.ads']),
    _SdkDefinition('Unity Ads', '广告', 'Unity 广告 SDK',
        ['com/unity3d/ads']),
    _SdkDefinition('IronSource', '广告', 'IronSource 广告聚合 SDK',
        ['com/ironsource']),
    _SdkDefinition('Vungle', '广告', 'Vungle 视频广告 SDK',
        ['com/vungle/warren']),
    _SdkDefinition('AppLovin', '广告', 'AppLovin 广告 SDK',
        ['com/applovin']),
    _SdkDefinition('MoPub', '广告', 'Twitter MoPub 广告 SDK',
        ['com/mopub']),
    _SdkDefinition('Chartboost', '广告', 'Chartboost 游戏广告 SDK',
        ['com/chartboost']),
    _SdkDefinition('AdColony', '广告', 'AdColony 视频广告 SDK',
        ['com/adcolony']),
    _SdkDefinition('Tapjoy', '广告', 'Tapjoy 广告与激励 SDK',
        ['com/tapjoy']),
    _SdkDefinition('Pangle', '广告', '字节跳动 Pangle (穿山甲) 广告 SDK',
        ['com/bytedance/sdk/openadsdk']),

    // -------- 统计 --------
    _SdkDefinition('Umeng (友盟)', '统计', '友盟统计/推送综合 SDK',
        ['com/umeng', 'com.umeng', 'com/uc']),
    _SdkDefinition('Baidu Statistics', '统计', '百度移动统计 SDK',
        ['com/baidu/mobstat']),
    _SdkDefinition('Tencent Bugly', '统计', '腾讯 Bugly 崩溃与性能监控 SDK',
        ['com/tencent/bugly', 'com.tencent.bugly']),

    // -------- 推送 --------
    _SdkDefinition('JPush (极光推送)', '推送', '极光推送 SDK',
        ['cn/jpush/android', 'cn.jpush.android']),
    _SdkDefinition('Getui (个推)', '推送', '个推推送 SDK',
        ['com/igexin/sdk', 'com.igexin.sdk']),
    _SdkDefinition('MiPush (小米推送)', '推送', '小米推送服务 SDK',
        ['com/xiaomi/mipush/sdk']),
    _SdkDefinition('Huawei Push', '推送', '华为推送服务 SDK',
        ['com/huawei/android/push']),
    _SdkDefinition('Baidu Push', '推送', '百度云推送 SDK',
        ['com/baidu/android/pushservice']),

    // -------- 社交 / 通讯 --------
    _SdkDefinition('Facebook SDK', '社交', 'Facebook 开发者 SDK',
        ['com/facebook', 'com.facebook']),
    _SdkDefinition('WeChat SDK', '社交', '微信开放平台 SDK',
        ['com/tencent/mm/opensdk', 'com.tencent.mm.opensdk']),
    _SdkDefinition('QQ SDK', '社交', 'QQ 互联 SDK',
        ['com/tencent/connect', 'com.tencent.connect']),
    _SdkDefinition('Weibo SDK', '社交', '新浪微博 SDK',
        ['com/sina/weibo/sdk']),
    _SdkDefinition('Twitter SDK', '社交', 'Twitter 开发者 SDK',
        ['com/twitter/sdk', 'com.twitter.sdk']),
    _SdkDefinition('Instagram', '社交', 'Instagram SDK',
        ['com/instagram']),
    _SdkDefinition('Tencent IMSDK', '社交', '腾讯云即时通信 IM SDK',
        ['com/tencent/imsdk', 'com.tencent.imsdk']),
    _SdkDefinition('JMessage', '社交', '极光 IM 即时通讯 SDK',
        ['cn/jmessage/android']),
    _SdkDefinition('NetEase IM', '社交', '网易云信即时通讯 SDK',
        ['com/netease/nimlib']),
    _SdkDefinition('RongCloud (融云)', '社交', '融云即时通讯 SDK',
        ['io/rong/imkit', 'io.rong.imkit']),
    _SdkDefinition('Agora (声网)', '社交', '声网实时音视频 SDK',
        ['io/agora/rtc']),
    _SdkDefinition('TikTok SDK', '社交', '字节跳动 TikTok SDK',
        ['com/bytedance/sdk']),

    // -------- 支付 --------
    _SdkDefinition('Alipay', '支付', '支付宝支付 SDK',
        ['com/alipay/sdk', 'com.alipay.sdk']),

    // -------- 地图 --------
    _SdkDefinition('Google Maps', '地图', 'Google 地图 SDK',
        ['com/google/android/gms/maps']),
    _SdkDefinition('AMap (高德地图)', '地图', '高德地图 SDK',
        ['com/amap/api', 'com.autonavi']),
    _SdkDefinition('Baidu Map', '地图', '百度地图 SDK',
        ['com/baidu/mapapi', 'com.baidu.mapapi']),
    _SdkDefinition('Tencent Map', '地图', '腾讯地图 SDK',
        ['com/tencent/map', 'com.tencent.map']),

    // -------- 框架 / 基础库 --------
    _SdkDefinition('Firebase', '框架', 'Firebase 移动开发平台',
        ['com/google/firebase', 'com.google.firebase']),
    _SdkDefinition('Google Play Services', '框架', 'Google Play 服务框架',
        ['com/google/android/gms', 'com.google.android.gms']),
    _SdkDefinition('Tencent TBS (X5 WebView)', '框架', '腾讯 X5 浏览服务 WebView 内核',
        ['com/tencent/smtt', 'com.tencent.smtt']),
    _SdkDefinition('Glide', '框架', 'Google 图片加载库',
        ['com/bumptech/glide', 'com.bumptech.glide']),
    _SdkDefinition('OkHttp', '框架', 'Square 网络请求库',
        ['okhttp3', 'com/squareup/okhttp']),
    _SdkDefinition('Retrofit', '框架', 'Square RESTful 网络请求库',
        ['retrofit2', 'retrofit/']),
    _SdkDefinition('RxJava', '框架', '响应式编程库',
        ['io/reactivex', 'io.reactivex']),
    _SdkDefinition('EventBus', '框架', '事件总线通信库',
        ['org/greenrobot/eventbus', 'de/greenrobot/eventbus']),
    _SdkDefinition('ButterKnife', '框架', 'View 注入框架',
        ['butterknife']),
    _SdkDefinition('Dagger', '框架', '依赖注入框架',
        ['dagger']),
    _SdkDefinition('LeakCanary', '框架', 'Square 内存泄漏检测工具',
        ['com/squareup/leakcanary', 'leakcanary']),
    _SdkDefinition('Gson', '框架', 'Google JSON 解析库',
        ['com/google/gson', 'com.google.gson']),
    _SdkDefinition('FastJSON', '框架', '阿里巴巴 JSON 解析库',
        ['com/alibaba/fastjson', 'com.alibaba.fastjson']),
    _SdkDefinition('Jackson', '框架', 'Jackson JSON 处理库',
        ['com/fasterxml/jackson']),
    _SdkDefinition('Picasso', '框架', 'Square 图片加载库',
        ['com/squareup/picasso']),
    _SdkDefinition('Fresco', '框架', 'Facebook 图片加载库',
        ['com/facebook/drawee', 'com/facebook/imagepipeline']),
    _SdkDefinition('Volley', '框架', 'Google 网络请求库',
        ['com/android/volley', 'com.android.volley']),
    _SdkDefinition('XUtils', '框架', 'Android 工具集合框架',
        ['org/xutils', 'com/lidroid/xutils']),
    _SdkDefinition('OkDownload', '框架', '文件下载库',
        ['com/liulishuo/okdownload']),
    _SdkDefinition('Alibaba Arouter', '框架', '阿里巴巴路由框架',
        ['com/alibaba/android/arouter']),
    _SdkDefinition('Flutter', '框架', 'Google Flutter 跨平台框架',
        ['io/flutter']),
    _SdkDefinition('React Native', '框架', 'Facebook React Native 跨平台框架',
        ['com/facebook/react']),
    _SdkDefinition('Cordova', '框架', 'Apache Cordova 混合开发框架',
        ['org/apache/cordova']),
    _SdkDefinition('Ionic', '框架', 'Ionic 混合开发框架',
        ['com/ionicframework']),
    _SdkDefinition('Tencent Shadow', '框架', '腾讯 Shadow 插件化框架',
        ['com/tencent/shadow']),
    _SdkDefinition('VirtualApp', '框架', 'VirtualApp 虚拟化框架',
        ['com/lody/virtual']),
    _SdkDefinition('Xposed', '框架', 'Xposed Hook 框架',
        ['de/robv/android/xposed']),
  ];
}
