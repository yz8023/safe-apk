import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';
import 'package:crypto/crypto.dart' as crypto;
import '../models/apk_info.dart';
import '../models/dex_class.dart';
import '../utils/hex_utils.dart';
import '../utils/string_utils.dart';
import '../utils/crypto_utils.dart';
import 'dart:math' as math;
import 'manifest_parser.dart';
import 'memory_manager.dart';
import 'dex_disassembler.dart';
import 'cert_parser.dart';
import 'sdk_detector.dart';
import 'permission_classifier.dart';
import 'packer_detector.dart';
import 'res_analyzer.dart';

/// APK 文件解析器 - 纯 Dart 实现
/// 解析 ZIP 结构、AndroidManifest.xml、DEX 文件
class ApkAnalyzer {
  final String path;

  ApkAnalyzer(this.path);

  /// 解析结果 LRU 缓存（内存回收：限制驻留分析结果数量，淘汰时释放引用）
  static final LruCache<String, dynamic> _resultCache =
      LruCache<String, dynamic>(maxEntries: 4);

  /// 生成带文件指纹的缓存键，避免文件变更后命中旧结果
  static String _cacheKey(String path, String kind) {
    try {
      final stat = File(path).statSync();
      return '$path#$kind#${stat.size}#${stat.modified.millisecondsSinceEpoch}';
    } catch (_) {
      return '$path#$kind';
    }
  }

  /// 清空分析结果缓存并触发内存回收（切换文件 / 退出时调用）
  static void clearAnalysisCache() {
    _resultCache.clear();
    MemoryManager().collectAll();
  }

  /// 解析 APK 基本信息
  Future<ApkInfo> analyze() async {
    final cacheKey = _cacheKey(path, 'analyze');
    final cached = _resultCache.get(cacheKey);
    if (cached is ApkInfo) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    if (bytes.length < 4) throw Exception('Invalid APK file');

    // 验证 ZIP 魔数
    if (bytes[0] != 0x50 || bytes[1] != 0x4B) {
      throw Exception('Not a valid ZIP/APK file');
    }

    final entries = _parseZipCentralDirectory(bytes);
    final manifestEntry = entries.where((e) => e.name == 'AndroidManifest.xml').firstOrNull;

    String? packageName, versionName, mainActivity, applicationName, minSdk, targetSdk;
    List<String> permissions = [];
    int versionCode = 1;

    if (manifestEntry != null) {
      final manifestBytes = _extractFile(bytes, manifestEntry);
      // 使用基于元素/属性结构的 ManifestParser（而非脆弱的字符串池相邻猜测）
      final manifest = ManifestParser.parse(manifestBytes);
      packageName = manifest.packageName.isNotEmpty ? manifest.packageName : null;
      versionName = manifest.versionName.isNotEmpty ? manifest.versionName : null;
      versionCode = manifest.versionCode;
      mainActivity = manifest.mainActivity.isNotEmpty ? manifest.mainActivity : null;
      applicationName = manifest.applicationClass;
      minSdk = manifest.minSdkVersion;
      targetSdk = manifest.targetSdkVersion;
      permissions = manifest.permissions;
    }

    // 解析 DEX
    final dexEntries = entries.where((e) => e.name.endsWith('.dex')).toList();
    final dexClasses = <String>[];
    for (final dex in dexEntries) {
      dexClasses.addAll(_parseDexClasses(_extractFile(bytes, dex)));
    }

    MemoryManager().release(bytes); // 解析完成，主动释放整包缓冲
    final info = ApkInfo(
      packageName: packageName ?? 'unknown',
      versionName: versionName ?? '1.0',
      versionCode: versionCode,
      permissions: permissions,
      mainActivity: mainActivity ?? '',
      dexClasses: dexClasses,
      fileSize: bytes.length,
      entries: entries.map((e) => e.name).toList(),
      applicationName: applicationName,
      minSdkVersion: minSdk,
      targetSdkVersion: targetSdk,
    );
    _resultCache.put(cacheKey, info);
    return info;
  }

  /// 解析并返回完整的 ManifestInfo（包含组件、深度链接、XML 文本等）
  Future<ManifestInfo> parseManifestInfo() async {
    final cacheKey = _cacheKey(path, 'manifest');
    final cached = _resultCache.get(cacheKey);
    if (cached is ManifestInfo) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    if (bytes.length < 4) return ManifestInfo.empty();

    final entries = _parseZipCentralDirectory(bytes);
    final manifestEntry = entries
        .where((e) => e.name == 'AndroidManifest.xml')
        .firstOrNull;

    ManifestInfo result;
    if (manifestEntry != null) {
      final manifestBytes = _extractFile(bytes, manifestEntry);
      result = ManifestParser.parse(manifestBytes);
    } else {
      result = ManifestInfo.empty();
    }

    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 检测 APK Signing Block（V2/V3 签名）
  /// 通过解析 ZIP 结构中 Central Directory 前的签名块来判断
  Future<SignatureBlockInfo> detectSignatureBlock() async {
    final cacheKey = _cacheKey(path, 'sigblock');
    final cached = _resultCache.get(cacheKey);
    if (cached is SignatureBlockInfo) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    SignatureBlockInfo result;

    // 找到 EOCD
    int eocdOffset = bytes.length - 22;
    final searchStart = math.max(0, bytes.length - 22 - 65535);
    while (eocdOffset >= searchStart) {
      if (eocdOffset + 4 <= bytes.length &&
          bytes[eocdOffset] == 0x50 &&
          bytes[eocdOffset + 1] == 0x4B &&
          bytes[eocdOffset + 2] == 0x05 &&
          bytes[eocdOffset + 3] == 0x06) {
        final commentLen = HexUtils.readUint16LE(bytes, eocdOffset + 20);
        if (eocdOffset + 22 + commentLen == bytes.length) break;
      }
      eocdOffset--;
    }

    bool v2 = false, v3 = false, hasSigningBlock = false;
    int blockSize = 0;

    if (eocdOffset >= searchStart) {
      final cdOffset = HexUtils.readUint32LE(bytes, eocdOffset + 16);

      // 检查 CD 前是否有 APK Signing Block
      // APK Signing Block 的最后 24 字节: uint64(blockSize) + 16字节 magic "APK Sig Block 42"
      if (cdOffset >= 32) {
        final magicOff = cdOffset - 16;
        // 验证 magic: "APK Sig Block 42"
        final magic = 'APK Sig Block 42'.codeUnits;
        bool magicMatch = true;
        for (int i = 0; i < 16; i++) {
          if (magicOff + i >= bytes.length ||
              bytes[magicOff + i] != magic[i]) {
            magicMatch = false;
            break;
          }
        }

        if (magicMatch) {
          hasSigningBlock = true;
          // 读取 blockSize（magic 前 8 字节）
          blockSize = HexUtils.readUint64LE(bytes, magicOff - 8);
          // 签名块起始位置
          final blockStart = cdOffset - blockSize - 8;

          // 遍历 ID-value pairs
          int pos = blockStart;
          final blockEnd = magicOff - 8; // 到第二个 blockSize 之前
          while (pos + 12 <= blockEnd) {
            final pairLen = HexUtils.readUint64LE(bytes, pos);
            if (pairLen < 4 || pos + 8 + pairLen > blockEnd) break;
            final pairId = HexUtils.readUint32LE(bytes, pos + 8);
            if (pairId == 0x7109871a) {
              v2 = true;
            } else if (pairId == 0xf05368c0) {
              v3 = true;
            }
            pos += 8 + pairLen;
          }
        }
      }
    }

    result = SignatureBlockInfo(
      hasSigningBlock: hasSigningBlock,
      v2: v2,
      v3: v3,
      blockSize: blockSize,
    );

    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 搜索 DEX 中的类和方法
  Future<SearchResult> searchInDex(String query) async {
    final cacheKey = _cacheKey(path, 'search:$query');
    final cached = _resultCache.get(cacheKey);
    if (cached is SearchResult) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final dexEntries = entries.where((e) => e.name.endsWith('.dex')).toList();
    final results = <SearchMatch>[];
    final lowerQuery = query.toLowerCase();

    for (final dex in dexEntries) {
      final dexBytes = _extractFile(bytes, dex);
      final classes = _parseDexClassesDetailed(dexBytes);
      for (final cls in classes) {
        if (cls.name.toLowerCase().contains(lowerQuery)) {
          results.add(SearchMatch(
            type: 'class',
            name: cls.simpleName,
            fullName: cls.name,
            className: cls.name,
          ));
        }
        for (final method in cls.methods) {
          if (method.name.toLowerCase().contains(lowerQuery)) {
            results.add(SearchMatch(
              type: 'method',
              name: method.name,
              fullName: '${cls.name}->${method.name}',
              className: cls.name,
            ));
          }
        }
      }
    }
    final result = SearchResult(query: query, matches: results);
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 提取字符串并检测加密
  Future<StringAnalysis> analyzeStrings() async {
    final cacheKey = _cacheKey(path, 'strings');
    final cached = _resultCache.get(cacheKey);
    if (cached is StringAnalysis) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final allStrings = <String>{};

    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      allStrings.addAll(_extractStrings(_extractFile(bytes, dex)));
    }

    final decrypted = <DecryptedString>[];
    for (final s in allStrings) {
      // Base64 检测
      final base64Result = CryptoUtils.tryBase64Decode(s);
      if (base64Result != null) {
        decrypted.add(DecryptedString(original: s, decoded: base64Result, method: 'base64'));
        continue;
      }
      // Hex 检测
      final hexResult = CryptoUtils.tryHexDecode(s);
      if (hexResult != null) {
        decrypted.add(DecryptedString(original: s, decoded: hexResult, method: 'hex'));
        continue;
      }
      // XOR 检测
      final xorResult = CryptoUtils.tryXorDecode(s);
      if (xorResult != null) {
        decrypted.add(DecryptedString(original: s, decoded: xorResult, method: 'xor'));
        continue;
      }
      // ROT13
      final rot13Result = CryptoUtils.tryRot13(s);
      if (rot13Result != null) {
        decrypted.add(DecryptedString(original: s, decoded: rot13Result, method: 'rot13'));
        continue;
      }
      // URL decode
      final urlResult = CryptoUtils.tryUrlDecode(s);
      if (urlResult != null) {
        decrypted.add(DecryptedString(original: s, decoded: urlResult, method: 'url'));
      }
    }

    final result = StringAnalysis(
      totalStrings: allStrings.length,
      sampleStrings: allStrings.take(50).toList(),
      decryptedCount: decrypted.length,
      decryptedSamples: decrypted.take(30).toList(),
    );
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 混淆检测
  Future<ObfuscationResult> detectObfuscation() async {
    final cacheKey = _cacheKey(path, 'obfuscation');
    final cached = _resultCache.get(cacheKey);
    if (cached is ObfuscationResult) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final allNames = <String>[];
    final classNames = <String>[];
    final methodNames = <String>[];

    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      final classes = _parseDexClassesDetailed(_extractFile(bytes, dex));
      for (final cls in classes) {
        allNames.add(cls.name);
        classNames.add(cls.name);
        for (final m in cls.methods) {
          allNames.add(m.name);
          methodNames.add(m.name);
        }
      }
    }

    if (allNames.isEmpty) {
      return const ObfuscationResult(
        totalNames: 0,
        shortNameRatio: 0,
        averageEntropy: 0,
        singleCharClassRatio: 0,
        suspicionLevel: 'Unknown',
        sampleClasses: [],
      );
    }

    final shortCount = allNames.where((n) => n.replaceAll(RegExp(r'[/$;L<>()]'), '').length <= 3).length;
    final shortRatio = shortCount / allNames.length;
    final singleChar = classNames.where((n) => n.replaceAll(RegExp(r'[/$;L]'), '').length == 1).length;
    final singleCharRatio = classNames.isEmpty ? 0.0 : singleChar / classNames.length;

    double avgEntropy = 0;
    for (final name in allNames) {
      final clean = name.replaceAll(RegExp(r'[/$;L<>()]'), '');
      if (clean.isEmpty) continue;
      avgEntropy += StringUtils.entropy(clean);
    }
    avgEntropy /= allNames.length;

    String level;
    if (shortRatio > 0.3 || avgEntropy > 4.5) {
      level = 'High';
    } else if (shortRatio > 0.15 || avgEntropy > 3.5) {
      level = 'Medium';
    } else {
      level = 'Low';
    }

    final result = ObfuscationResult(
      totalNames: allNames.length,
      shortNameRatio: shortRatio,
      averageEntropy: avgEntropy,
      singleCharClassRatio: singleCharRatio,
      suspicionLevel: level,
      sampleClasses: classNames.take(15).toList(),
      sampleMethods: methodNames.take(15).toList(),
    );
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// DEX 指令反汇编（纯 Dart 解码器 -> smali 汇编级）
  /// 反汇编第一个 .dex（classes.dex），返回类/方法的汇编文本。
  Future<DisassemblyResult> disassembleDex() async {
    final cacheKey = _cacheKey(path, 'disasm');
    final cached = _resultCache.get(cacheKey);
    if (cached is DisassemblyResult) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final dexEntries = entries.where((e) => e.name.endsWith('.dex')).toList();
    if (dexEntries.isEmpty) {
      MemoryManager().release(bytes);
      return const DisassemblyResult(
          classes: [], totalMethods: 0, totalInstructions: 0);
    }

    final dexBytes = _extractFile(bytes, dexEntries.first);
    final result = DexDisassembler.disassemble(dexBytes);
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 提取 DEX 中的 URL 和 IP 地址
  Future<List<String>> extractUrls() async {
    final cacheKey = _cacheKey(path, 'urls');
    final cached = _resultCache.get(cacheKey);
    if (cached is List<String>) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final urls = <String>{};

    final urlRegex = RegExp(r'''https?://[^\s<>"'\x00-\x1f]+''');
    final ipRegex = RegExp(r'\b(\d{1,3}\.){3}\d{1,3}\b');

    // 1. 从 DEX 字符串池提取
    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      final dexBytes = _extractFile(bytes, dex);
      final strings = _extractStrings(dexBytes);
      for (final s in strings) {
        for (final m in urlRegex.allMatches(s)) {
          urls.add(m.group(0)!);
        }
        for (final m in ipRegex.allMatches(s)) {
          final ip = m.group(0)!;
          // 过滤版本号等误报
          if (!ip.startsWith('0.') && !ip.startsWith('127.') &&
              !ip.startsWith('255.') && !ip.endsWith('.0')) {
            urls.add(ip);
          }
        }
      }
    }

    // 2. 从 resources.arsc、XML、assets 等文本文件提取
    for (final entry in entries) {
      final name = entry.name.toLowerCase();
      // 跳过已处理的 DEX 和非文本文件
      if (name.endsWith('.dex')) continue;
      if (name.endsWith('.png') || name.endsWith('.jpg') ||
          name.endsWith('.jpeg') || name.endsWith('.gif') ||
          name.endsWith('.webp') || name.endsWith('.so') ||
          name.endsWith('.ttf') || name.endsWith('.otf')) continue;

      try {
        final fileBytes = _extractFile(bytes, entry);
        if (fileBytes.isEmpty) continue;
        // 将二进制数据转为字符串（允许畸形 UTF-8）
        final content = utf8.decode(fileBytes, allowMalformed: true);
        for (final m in urlRegex.allMatches(content)) {
          final url = m.group(0)!;
          // 过滤过长或含乱码的匹配
          if (url.length < 500) urls.add(url);
        }
        for (final m in ipRegex.allMatches(content)) {
          final ip = m.group(0)!;
          if (!ip.startsWith('0.') && !ip.startsWith('127.') &&
              !ip.startsWith('255.') && !ip.endsWith('.0')) {
            urls.add(ip);
          }
        }
      } catch (_) {
        // 跳过无法解码的文件
      }
    }

    final result = urls.toList()..sort();
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 检测敏感 API 调用
  Future<List<SensitiveApiItem>> detectSensitiveApis() async {
    final cacheKey = _cacheKey(path, 'sensitive');
    final cached = _resultCache.get(cacheKey);
    if (cached is List<SensitiveApiItem>) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    final sensitivePatterns = <String, String>{
      'exec': '命令执行 (Runtime.exec)',
      'getRuntime': '获取运行时实例',
      'System/loadLibrary': '动态加载 Native 库',
      'System/load': '动态加载代码',
      'DexClassLoader': '动态加载 DEX',
      'PathClassLoader': '类加载器',
      'Reflection': '反射调用',
      'forName': '反射类加载',
      'getDeclaredMethod': '反射获取方法',
      'setAccessible': '反射绕过访问控制',
      'getSharedPreferences': '读取 SharedPreferences',
      'MODE_WORLD_READABLE': '世界可读存储',
      'MODE_WORLD_WRITEABLE': '世界可写存储',
      'openFileOutput': '文件写入',
      'getExternalStorage': '外部存储访问',
      'TelephonyManager': '电话信息服务',
      'getDeviceId': '获取设备 ID',
      'getSubscriberId': '获取 SIM 卡 ID (IMSI)',
      'getLine1Number': '获取手机号码',
      'SmsManager': '短信管理',
      'sendTextMessage': '发送短信',
      'LocationManager': '定位服务',
      'getLastKnownLocation': '获取位置',
      'AudioRecord': '录音',
      'MediaRecorder': '媒体录制',
      'Camera': '相机访问',
      'WifiManager': 'WiFi 管理',
      'getConnectionInfo': '获取 WiFi 连接信息',
      'getScanResults': 'WiFi 扫描结果',
      'BluetoothAdapter': '蓝牙适配器',
      'PackageManager': '包管理器',
      'getInstalledPackages': '获取已安装应用列表',
      'Crypto': '加密相关',
      'Cipher': '加密相关',
      'MessageDigest': '哈希摘要',
      'Mac': 'HMAC 消息认证',
      'KeyGenerator': '密钥生成',
      'SecretKey': '密钥',
      'SSLContext': 'SSL 上下文',
      'TrustAllCerts': '信任所有证书',
      'TrustManager': '信任管理器',
      'setCookie': '设置 Cookie',
      'getCookie': '读取 Cookie',
      'WebView': 'WebView 组件',
      'addJavascriptInterface': 'JS 桥接',
      'setJavaScriptEnabled': '启用 JS',
      'loadUrl': '加载 URL',
      'ContentResolver': '内容提供者',
      'getContentResolver': '获取内容提供者',
      'AccountManager': '账户管理',
      'getAccounts': '获取账户列表',
      'KeyStore': '密钥存储',
      'PackageManagerGET_SIGNATURES': '获取签名信息',
      'NotificationManager': '通知管理',
      'AlarmManager': '闹钟管理',
      'ActivityManager': '活动管理',
      'killBackgroundProcesses': '杀后台进程',
      'ACCESSIBILITY': '无障碍服务',
    };

    final found = <String, SensitiveApiItem>{};
    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      final dexBytes = _extractFile(bytes, dex);
      final strings = _extractStrings(dexBytes);
      final classes = _parseDexClassesDetailed(dexBytes);

      // 检查类名
      for (final cls in classes) {
        for (final entry in sensitivePatterns.entries) {
          if (cls.name.contains(entry.key)) {
            found.putIfAbsent(entry.key, () => SensitiveApiItem(
              keyword: entry.key,
              description: entry.value,
              matchType: 'class',
              context: cls.name,
            ));
          }
        }
        // 检查方法名
        for (final m in cls.methods) {
          for (final entry in sensitivePatterns.entries) {
            if (m.name == entry.key || m.name.contains(entry.key)) {
              found.putIfAbsent('${entry.key}#${cls.name}', () => SensitiveApiItem(
                keyword: entry.key,
                description: entry.value,
                matchType: 'method',
                context: '${cls.name}->${m.name}',
              ));
            }
          }
        }
      }

      // 检查字符串
      for (final s in strings) {
        for (final entry in sensitivePatterns.entries) {
          if (s.contains(entry.key)) {
            found.putIfAbsent('${entry.key}#str', () => SensitiveApiItem(
              keyword: entry.key,
              description: entry.value,
              matchType: 'string',
              context: s.length > 100 ? '${s.substring(0, 100)}...' : s,
            ));
          }
        }
      }
    }

    final result = found.values.toList()
      ..sort((a, b) => a.keyword.compareTo(b.keyword));
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 解析 APK 文件结构树
  Future<List<FileTreeNode>> getFileTree() async {
    final cacheKey = _cacheKey(path, 'filetree');
    final cached = _resultCache.get(cacheKey);
    if (cached is List<FileTreeNode>) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    // 构建树形结构
    final root = <String, dynamic>{};
    for (final entry in entries) {
      final parts = entry.name.split('/');
      var current = root;
      for (int i = 0; i < parts.length; i++) {
        final part = parts[i];
        final isFile = i == parts.length - 1;
        if (isFile) {
          current['__files__'] ??= <FileTreeNode>[];
          (current['__files__'] as List<FileTreeNode>).add(FileTreeNode(
            name: part,
            path: entry.name,
            size: entry.uncompressedSize,
            compressedSize: entry.compressedSize,
            isFile: true,
          ));
        } else {
          current[part] ??= <String, dynamic>{};
          current = current[part] as Map<String, dynamic>;
        }
      }
    }

    // 展平为树节点列表
    final result = <FileTreeNode>[];
    void buildTree(Map<String, dynamic> node, String prefix) {
      final dirs = node.keys.where((k) => k != '__files__').toList()..sort();
      for (final dir in dirs) {
        final path = prefix.isEmpty ? dir : '$prefix/$dir';
        result.add(FileTreeNode(name: dir, path: path, isFile: false));
        buildTree(node[dir] as Map<String, dynamic>, path);
      }
      if (node['__files__'] != null) {
        result.addAll(node['__files__'] as List<FileTreeNode>);
      }
    }

    buildTree(root, '');
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 列出 APK 内所有 .so 文件
  Future<List<ApkSoEntry>> listSoFiles() async {
    final cacheKey = _cacheKey(path, 'so_list');
    final cached = _resultCache.get(cacheKey);
    if (cached is List<ApkSoEntry>) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    final soEntries = <ApkSoEntry>[];
    for (final e in entries) {
      if (e.name.endsWith('.so') && e.name.startsWith('lib/')) {
        // 解析 ABI: lib/<abi>/xxx.so
        final parts = e.name.split('/');
        String abi = '';
        if (parts.length >= 3) abi = parts[1];
        soEntries.add(ApkSoEntry(
          name: parts.last,
          fullPath: e.name,
          abi: abi,
          size: e.uncompressedSize,
        ));
      }
    }

    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, soEntries);
    return soEntries;
  }

  /// 从 APK 中提取指定 SO 文件的字节
  Future<Uint8List> extractSoFile(String soPath) async {
    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    final entry = entries.where((e) => e.name == soPath).firstOrNull;
    if (entry == null) throw Exception('SO 文件不存在: $soPath');

    final soBytes = _extractFile(bytes, entry);
    MemoryManager().release(bytes);
    return soBytes;
  }

  /// 从 APK 中提取指定 SO 文件到临时文件并返回路径
  Future<String> extractSoToTemp(String soPath) async {
    final soBytes = await extractSoFile(soPath);
    final tempDir = await Directory.systemTemp.createTemp('so_extract_');
    final fileName = soPath.split('/').last;
    final tempFile = File('${tempDir.path}/$fileName');
    await tempFile.writeAsBytes(soBytes);
    return tempFile.path;
  }

  /// 解析 APK 证书信息
  Future<CertInfo?> parseCertificate() async {
    final cacheKey = _cacheKey(path, 'cert');
    final cached = _resultCache.get(cacheKey);
    if (cached is CertInfo?) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    // 查找 META-INF/*.RSA / *.DSA / *.EC
    _ZipEntry? certEntry;
    for (final e in entries) {
      if (e.name.startsWith('META-INF/') &&
          (e.name.endsWith('.RSA') || e.name.endsWith('.DSA') || e.name.endsWith('.EC'))) {
        certEntry = e;
        break;
      }
    }

    CertInfo? result;
    if (certEntry != null) {
      final certBytes = _extractFile(bytes, certEntry);
      result = CertParser.parse(certBytes);
    }

    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 计算 APK 文件哈希 (MD5 / SHA1 / SHA256)
  Future<ApkHashInfo> calculateHash() async {
    final cacheKey = _cacheKey(path, 'hash');
    final cached = _resultCache.get(cacheKey);
    if (cached is ApkHashInfo) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final result = ApkHashInfo(
      md5: _bytesToHex(crypto.md5.convert(bytes).bytes),
      sha1: _bytesToHex(crypto.sha1.convert(bytes).bytes),
      sha256: _bytesToHex(crypto.sha256.convert(bytes).bytes),
      fileSize: bytes.length,
    );
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  String _bytesToHex(List<int> bytes) {
    return bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  /// 文件大小分类统计
  Future<FileSizeBreakdown> getFileSizeBreakdown() async {
    final cacheKey = _cacheKey(path, 'sizebreakdown');
    final cached = _resultCache.get(cacheKey);
    if (cached is FileSizeBreakdown) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    int dexSize = 0, resourcesSize = 0, nativeLibSize = 0;
    int assetsSize = 0, metaInfSize = 0, otherSize = 0;

    for (final e in entries) {
      final size = e.uncompressedSize;
      if (e.name.endsWith('.dex')) {
        dexSize += size;
      } else if (e.name.startsWith('lib/') && e.name.endsWith('.so')) {
        nativeLibSize += size;
      } else if (e.name.startsWith('assets/')) {
        assetsSize += size;
      } else if (e.name.startsWith('META-INF/')) {
        metaInfSize += size;
      } else if (e.name.startsWith('res/') ||
          e.name == 'resources.arsc' ||
          e.name == 'AndroidManifest.xml') {
        resourcesSize += size;
      } else {
        otherSize += size;
      }
    }

    final result = FileSizeBreakdown(
      dexSize: dexSize,
      resourcesSize: resourcesSize,
      nativeLibSize: nativeLibSize,
      assetsSize: assetsSize,
      metaInfSize: metaInfSize,
      otherSize: otherSize,
      totalSize: bytes.length,
    );
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 安全评估
  Future<SecurityReport> assessSecurity() async {
    final cacheKey = _cacheKey(path, 'security');
    final cached = _resultCache.get(cacheKey);
    if (cached is SecurityReport) return cached;

    final info = await analyze();
    final manifest = await parseManifestInfo();
    final sigBlock = await detectSignatureBlock();

    final items = <SecurityAssessmentItem>[];

    // debuggable 检测
    if (manifest.debuggable) {
      items.add(const SecurityAssessmentItem(
        category: '配置安全',
        title: 'debuggable=true',
        description: '应用可被调试，生产环境存在严重安全风险',
        level: SecurityLevel.high,
      ));
    }

    // allowBackup 检测
    if (manifest.allowBackup) {
      items.add(const SecurityAssessmentItem(
        category: '数据安全',
        title: 'allowBackup=true',
        description: '应用数据可被 adb backup 导出，敏感数据可能泄露',
        level: SecurityLevel.medium,
      ));
    }

    // 导出组件检测
    final exportedNoPerm = manifest.exportedComponents.where((c) =>
        c.permission == null && !c.isLauncher).toList();
    if (exportedNoPerm.isNotEmpty) {
      items.add(SecurityAssessmentItem(
        category: '组件安全',
        title: '${exportedNoPerm.length} 个无权限保护的导出组件',
        description: '导出组件无权限保护，可被第三方应用恶意调用',
        level: SecurityLevel.high,
      ));
    }

    // 签名检测
    if (!sigBlock.hasSigningBlock) {
      items.add(const SecurityAssessmentItem(
        category: '签名安全',
        title: '仅使用 V1 签名',
        description: '未使用 V2/V3 签名方案，存在安装劫持风险',
        level: SecurityLevel.medium,
      ));
    }

    // 明文流量检测
    final hasHttpUrl = (await extractUrls())
        .any((u) => u.startsWith('http://'));
    if (hasHttpUrl) {
      items.add(const SecurityAssessmentItem(
        category: '网络安全',
        title: '检测到 HTTP 明文流量',
        description: '存在不加密的 HTTP 请求，数据可能被中间人截获',
        level: SecurityLevel.medium,
      ));
    }

    // minSdkVersion 检测
    final minSdk = int.tryParse(manifest.minSdkVersion ?? '');
    if (minSdk != null && minSdk < 21) {
      items.add(SecurityAssessmentItem(
        category: '兼容性安全',
        title: 'minSdkVersion=$minSdk 过低',
        description: '支持 Android 5.0 以下版本，存在 WebView 和存储安全风险',
        level: SecurityLevel.low,
      ));
    }

    // targetSdkVersion 检测
    final targetSdk = int.tryParse(manifest.targetSdkVersion ?? '');
    if (targetSdk != null && targetSdk < 30) {
      items.add(SecurityAssessmentItem(
        category: '兼容性安全',
        title: 'targetSdkVersion=$targetSdk 偏低',
        description: '未达到 Android 11 (API 30) 目标，缺少现代安全限制',
        level: SecurityLevel.low,
      ));
    }

    // 清单文件存在检测
    if (info.packageName == 'unknown' || info.packageName.isEmpty) {
      items.add(const SecurityAssessmentItem(
        category: '完整性',
        title: '无法解析包名',
        description: 'Manifest 解析异常，APK 可能已损坏或被加壳',
        level: SecurityLevel.medium,
      ));
    }

    // 深度链接检测
    if (manifest.deepLinks.isNotEmpty) {
      items.add(SecurityAssessmentItem(
        category: '组件安全',
        title: '${manifest.deepLinks.length} 个深度链接',
        description: '存在 Deep Link 配置，需验证 URI 方案安全性',
        level: SecurityLevel.low,
      ));
    }

    final highCount = items.where((i) => i.level == SecurityLevel.high).length;
    final medCount = items.where((i) => i.level == SecurityLevel.medium).length;
    final lowCount = items.where((i) => i.level == SecurityLevel.low).length;

    final result = SecurityReport(
      items: items,
      highCount: highCount,
      mediumCount: medCount,
      lowCount: lowCount,
    );
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 检测逆向关键词（VIP/Pro/Premium/订阅/广告去除等）
  Future<List<ReverseKeywordItem>> detectReverseKeywords() async {
    final cacheKey = _cacheKey(path, 'reverse_kw');
    final cached = _resultCache.get(cacheKey);
    if (cached is List<ReverseKeywordItem>) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    // 逆向关键词列表（不区分大小写匹配）
    const keywords = [
      'isvip', 'ispro', 'premium', 'ispremium', 'removeads', 'removead',
      'pro', 'vip', 'paid', 'purchased', 'subscri', 'gold',
      'proversion', 'islogin', 'getvip', 'isplus', 'plus',
      'unlocked', 'isunlocked', 'unlock', 'trial', 'istrial',
      'license', 'islicensed', 'activation', 'activate',
      'crack', 'patched', 'modded', 'ismodded',
      'adfree', 'noads', 'adblock', 'adremoved',
      'donate', 'donated', 'isdonated',
      'membership', 'ismember', 'subscribed', 'issubscribed',
      'premiumenabled', 'ispremiumuser', 'premiumuser',
      'proenabled', 'ispremiumversion', 'premiumversion',
      'fullversion', 'isfullversion',
      'lifetime', 'forever', 'permanent',
      'premium_mode', 'pro_mode',
    ];

    final results = <ReverseKeywordItem>[];
    final seen = <String>{};

    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      final dexBytes = _extractFile(bytes, dex);

      // 从字符串池搜索
      final strings = _extractStrings(dexBytes);
      for (final s in strings) {
        final lower = s.toLowerCase();
        for (final kw in keywords) {
          if (lower.contains(kw)) {
            final key = '${kw}#str#$s';
            if (seen.add(key)) {
              results.add(ReverseKeywordItem(
                keyword: kw,
                matchType: 'string',
                className: '',
                memberName: s.length > 120 ? '${s.substring(0, 120)}...' : s,
                fullContext: s,
              ));
            }
            break; // 每个字符串只匹配第一个关键词
          }
        }
      }

      // 从类/方法名搜索
      final classes = _parseDexClassesDetailed(dexBytes);
      for (final cls in classes) {
        final clsLower = cls.name.toLowerCase();
        for (final kw in keywords) {
          if (clsLower.contains(kw)) {
            final key = '${kw}#class#${cls.name}';
            if (seen.add(key)) {
              results.add(ReverseKeywordItem(
                keyword: kw,
                matchType: 'class',
                className: cls.name,
                memberName: cls.simpleName,
                fullContext: cls.name,
              ));
            }
            break;
          }
        }
        for (final m in cls.methods) {
          final mLower = m.name.toLowerCase();
          for (final kw in keywords) {
            if (mLower.contains(kw)) {
              final key = '${kw}#method#${cls.name}#${m.name}';
              if (seen.add(key)) {
                results.add(ReverseKeywordItem(
                  keyword: kw,
                  matchType: 'method',
                  className: cls.name,
                  memberName: m.name,
                  fullContext: '${cls.name}->${m.name}${m.descriptor}',
                ));
              }
              break;
            }
          }
        }
      }
    }

    results.sort((a, b) {
      final cmp = a.keyword.compareTo(b.keyword);
      if (cmp != 0) return cmp;
      return a.memberName.compareTo(b.memberName);
    });

    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, results);
    return results;
  }

  /// 生成分析报告
  Future<String> generateReport() async {
    final info = await analyze();
    final manifest = await parseManifestInfo();
    final sigBlock = await detectSignatureBlock();
    final cert = await parseCertificate();
    final obf = await detectObfuscation();
    final urls = await extractUrls();
    final sensitive = await detectSensitiveApis();

    final buf = StringBuffer();
    buf.writeln('========== 智能逆向助手 分析报告 ==========');
    buf.writeln('生成时间: ${DateTime.now()}');
    buf.writeln('');
    buf.writeln('【基本信息】');
    buf.writeln('  包名: ${info.packageName}');
    buf.writeln('  版本: ${info.versionName} (${info.versionCode})');
    buf.writeln('  文件大小: ${(info.fileSize / 1024 / 1024).toStringAsFixed(2)} MB');
    buf.writeln('  主 Activity: ${info.mainActivity}');
    if (info.minSdkVersion != null) buf.writeln('  minSdk: ${info.minSdkVersion}');
    if (info.targetSdkVersion != null) buf.writeln('  targetSdk: ${info.targetSdkVersion}');
    if (info.applicationName != null) buf.writeln('  Application: ${info.applicationName}');
    buf.writeln('  DEX 类数: ${info.dexClasses.length}');
    buf.writeln('  文件条目: ${info.entries.length}');
    buf.writeln('  debuggable: ${manifest.debuggable}');
    buf.writeln('  allowBackup: ${manifest.allowBackup}');
    if (manifest.supportsRtl) buf.writeln('  supportsRtl: true');
    if (manifest.installLocation != null) buf.writeln('  installLocation: ${manifest.installLocation}');
    buf.writeln('');
    buf.writeln('【组件统计】');
    buf.writeln('  Activity: ${manifest.activityList.length}');
    buf.writeln('  Service: ${manifest.serviceList.length}');
    buf.writeln('  Receiver: ${manifest.receiverList.length}');
    buf.writeln('  Provider: ${manifest.providerList.length}');
    buf.writeln('  导出组件: ${manifest.exportedComponents.length}');
    if (manifest.deepLinks.isNotEmpty) {
      buf.writeln('');
      buf.writeln('【深度链接 (${manifest.deepLinks.length})】');
      for (final link in manifest.deepLinks) {
        buf.writeln('  ${link.uri}');
      }
    }
    if (manifest.features.isNotEmpty) {
      buf.writeln('');
      buf.writeln('【硬件/软件特性 (${manifest.features.length})】');
      for (final f in manifest.features) {
        buf.writeln('  $f');
      }
    }
    buf.writeln('');
    buf.writeln('【权限列表 (${info.permissions.length})】');
    for (final p in info.permissions) {
      buf.writeln('  $p');
    }
    buf.writeln('');
    buf.writeln('【签名信息】');
    buf.writeln('  V1签名: ${info.entries.any((e) => e.startsWith('META-INF/') && (e.endsWith('.SF') || e.endsWith('.RSA') || e.endsWith('.DSA'))) ? "是" : "否"}');
    if (sigBlock.hasSigningBlock) {
      buf.writeln('  V2签名: ${sigBlock.v2 ? "是" : "否"}');
      buf.writeln('  V3签名: ${sigBlock.v3 ? "是" : "否"}');
    }
    if (cert != null) {
      buf.writeln('  主题: ${cert.subject}');
      buf.writeln('  签发者: ${cert.issuer}');
      buf.writeln('  序列号: ${cert.serialNumber}');
      buf.writeln('  算法: ${cert.algorithm}');
      buf.writeln('  指纹: ${cert.fingerprint}');
    } else {
      buf.writeln('  未找到证书');
    }
    buf.writeln('');
    buf.writeln('【混淆检测】');
    buf.writeln('  等级: ${obf.suspicionLevel}');
    buf.writeln('  名称总数: ${obf.totalNames}');
    buf.writeln('  短名比例: ${(obf.shortNameRatio * 100).toStringAsFixed(1)}%');
    buf.writeln('  平均熵值: ${obf.averageEntropy.toStringAsFixed(3)}');
    buf.writeln('');
    buf.writeln('【URL/IP 地址 (${urls.length})】');
    for (final u in urls.take(50)) {
      buf.writeln('  $u');
    }
    if (urls.length > 50) buf.writeln('  ... +${urls.length - 50} more');
    buf.writeln('');
    buf.writeln('【敏感 API (${sensitive.length})】');
    for (final s in sensitive) {
      buf.writeln('  [${s.matchType}] ${s.keyword}: ${s.description}');
      buf.writeln('    -> ${s.context}');
    }
    buf.writeln('');
    buf.writeln('==========================================');
    return buf.toString();
  }

  // ========== 新增功能辅助方法 ==========

  /// 提取所有 DEX 的字符串集合（供 SecretDetector / AntiDebugDetector / ApiEndpointExtractor 使用）
  Future<Set<String>> extractAllDexStrings() async {
    final cacheKey = _cacheKey(path, 'allStrings');
    final cached = _resultCache.get(cacheKey);
    if (cached is Set<String>) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final allStrings = <String>{};
    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      allStrings.addAll(_extractStrings(_extractFile(bytes, dex)));
    }
    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, allStrings);
    return allStrings;
  }

  /// 提取所有 DEX 的字符串集合和类名集合（元组返回）
  Future<(Set<String>, Set<String>)> extractDexStringsAndClasses() async {
    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final allStrings = <String>{};
    final allClasses = <String>{};
    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      final dexBytes = _extractFile(bytes, dex);
      allStrings.addAll(_extractStrings(dexBytes));
      allClasses.addAll(_parseDexClasses(dexBytes).toSet());
    }
    MemoryManager().release(bytes);
    return (allStrings, allClasses);
  }

  /// 提取所有 DEX 的详细类结构（供 FridaGenerator 使用）
  Future<List<DexClass>> extractAllDexClassesDetailed() async {
    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final allClasses = <DexClass>[];
    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      allClasses.addAll(_parseDexClassesDetailed(_extractFile(bytes, dex)));
    }
    MemoryManager().release(bytes);
    return allClasses;
  }

  // ========== ZIP 解析（纯 Dart） ==========

  List<_ZipEntry> _parseZipCentralDirectory(Uint8List bytes) {
    final entries = <_ZipEntry>[];
    int offset = bytes.length - 22;
    if (offset < 0) return entries;

    // 查找 End of Central Directory (EOCD)
    // 支持 ZIP comment，最大 65535 字节
    final searchStart = math.max(0, bytes.length - 22 - 65535);
    while (offset >= searchStart) {
      if (bytes[offset] == 0x50 && bytes[offset + 1] == 0x4B &&
          bytes[offset + 2] == 0x05 && bytes[offset + 3] == 0x06) {
        // 验证 comment length 是否合理
        final commentLen = HexUtils.readUint16LE(bytes, offset + 20);
        if (offset + 22 + commentLen == bytes.length) {
          break;
        }
      }
      offset--;
    }
    if (offset < searchStart) return entries;

    final cdOffset = HexUtils.readUint32LE(bytes, offset + 16);
    final entryCount = HexUtils.readUint16LE(bytes, offset + 10);

    int pos = cdOffset;
    for (int i = 0; i < entryCount && pos < bytes.length - 46; i++) {
      if (bytes[pos] != 0x50 || bytes[pos + 1] != 0x4B) break;
      final nameLen = HexUtils.readUint16LE(bytes, pos + 28);
      final extraLen = HexUtils.readUint16LE(bytes, pos + 30);
      final commentLen = HexUtils.readUint16LE(bytes, pos + 32);
      final localOffset = HexUtils.readUint32LE(bytes, pos + 42);
      final compSize = HexUtils.readUint32LE(bytes, pos + 20);
      final uncompSize = HexUtils.readUint32LE(bytes, pos + 24);
      final method = HexUtils.readUint16LE(bytes, pos + 10);
      final crc32 = HexUtils.readUint32LE(bytes, pos + 16);

      if (pos + 46 + nameLen > bytes.length) break;
      final name = utf8.decode(bytes.sublist(pos + 46, pos + 46 + nameLen), allowMalformed: true);
      entries.add(_ZipEntry(
        name: name,
        localHeaderOffset: localOffset,
        compressedSize: compSize,
        uncompressedSize: uncompSize,
        compressionMethod: method,
        crc32: crc32,
      ));
      pos += 46 + nameLen + extraLen + commentLen;
    }
    return entries;
  }

  Uint8List _extractFile(Uint8List zipBytes, _ZipEntry entry) {
    int pos = entry.localHeaderOffset;
    if (pos + 30 > zipBytes.length) return Uint8List(0);
    final nameLen = HexUtils.readUint16LE(zipBytes, pos + 26);
    final extraLen = HexUtils.readUint16LE(zipBytes, pos + 28);
    int dataStart = pos + 30 + nameLen + extraLen;

    if (entry.compressionMethod == 0) {
      // STORE - 无压缩
      final end = math.min(dataStart + entry.uncompressedSize, zipBytes.length);
      return Uint8List.fromList(zipBytes.sublist(dataStart, end));
    } else if (entry.compressionMethod == 8) {
      // DEFLATE - 使用原始 deflate 解压
      final end = math.min(dataStart + entry.compressedSize, zipBytes.length);
      final compressed = zipBytes.sublist(dataStart, end);
      try {
        final codec = ZLibCodec(raw: true);
        return Uint8List.fromList(codec.decoder.convert(compressed));
      } catch (e) {
        // 解压失败，返回原始压缩数据
        return Uint8List.fromList(compressed);
      }
    }
    return Uint8List(0);
  }

  // ========== DEX 解析 ==========

  /// 解析 DEX 文件中的类名列表（仅类名）
  List<String> _parseDexClasses(Uint8List dexBytes) {
    final classes = <String>[];
    if (dexBytes.length < 112) return classes;

    final stringIdsSize = HexUtils.readUint32LE(dexBytes, 56);
    final typeIdsSize = HexUtils.readUint32LE(dexBytes, 64);
    final stringIdsOff = HexUtils.readUint32LE(dexBytes, 60);
    final typeIdsOff = HexUtils.readUint32LE(dexBytes, 68);

    // 读取 type_ids 对应的字符串
    for (int i = 0; i < typeIdsSize && i < 50000; i++) {
      final strIdx = HexUtils.readUint32LE(dexBytes, typeIdsOff + i * 4);
      final str = _readDexString(dexBytes, stringIdsOff, strIdx);
      if (str.startsWith('L') && str.endsWith(';')) {
        classes.add(str);
      }
    }
    return classes;
  }

  /// 详细解析 DEX 类结构（类名、方法、字段）
  List<DexClass> _parseDexClassesDetailed(Uint8List dexBytes) {
    final classes = <DexClass>[];
    if (dexBytes.length < 112) return classes;

    final stringIdsSize = HexUtils.readUint32LE(dexBytes, 56);
    final typeIdsSize = HexUtils.readUint32LE(dexBytes, 64);
    final stringIdsOff = HexUtils.readUint32LE(dexBytes, 60);
    final typeIdsOff = HexUtils.readUint32LE(dexBytes, 68);
    final protoIdsOff = HexUtils.readUint32LE(dexBytes, 76);
    final fieldIdsSize = HexUtils.readUint32LE(dexBytes, 80);
    final fieldIdsOff = HexUtils.readUint32LE(dexBytes, 84);
    final methodIdsSize = HexUtils.readUint32LE(dexBytes, 88);
    final methodIdsOff = HexUtils.readUint32LE(dexBytes, 92);
    final classDefsSize = HexUtils.readUint32LE(dexBytes, 96);
    final classDefsOff = HexUtils.readUint32LE(dexBytes, 100);

    for (int i = 0; i < classDefsSize && i < 10000; i++) {
      final off = classDefsOff + i * 32; // class_def_item = 32 bytes
      if (off + 32 > dexBytes.length) break;

      final classIdx = HexUtils.readUint32LE(dexBytes, off);
      final accessFlags = HexUtils.readUint32LE(dexBytes, off + 4);
      final superclassIdx = HexUtils.readUint32LE(dexBytes, off + 8);
      final interfacesOff = HexUtils.readUint32LE(dexBytes, off + 12);
      // source_file_idx at off+16
      // annotations_off at off+20
      final classDataOff = HexUtils.readUint32LE(dexBytes, off + 24);
      // static_values_off at off+28

      if (classIdx >= typeIdsSize) continue;
      final className = _readDexString(
        dexBytes, stringIdsOff,
        HexUtils.readUint32LE(dexBytes, typeIdsOff + classIdx * 4),
      );
      if (!className.startsWith('L')) continue;

      // 解析父类
      String? superClass;
      if (superclassIdx != 0xFFFFFFFF && superclassIdx < typeIdsSize) {
        superClass = _readDexString(
          dexBytes, stringIdsOff,
          HexUtils.readUint32LE(dexBytes, typeIdsOff + superclassIdx * 4),
        );
      }

      // 解析接口
      final interfaces = <String>[];
      if (interfacesOff != 0 && interfacesOff + 4 <= dexBytes.length) {
        final typeListSize = HexUtils.readUint32LE(dexBytes, interfacesOff);
        for (int ii = 0; ii < typeListSize && ii < 50; ii++) {
          final typeIdx = HexUtils.readUint16LE(dexBytes, interfacesOff + 4 + ii * 2);
          if (typeIdx < typeIdsSize) {
            final iface = _readDexString(
              dexBytes, stringIdsOff,
              HexUtils.readUint32LE(dexBytes, typeIdsOff + typeIdx * 4),
            );
            interfaces.add(iface);
          }
        }
      }

      // 解析 class_data_item
      final methods = <DexMethod>[];
      final fields = <DexField>[];
      if (classDataOff != 0 && classDataOff < dexBytes.length) {
        var pos = classDataOff;
        final staticFieldsSize = _readULEB128(dexBytes, pos);
        pos = staticFieldsSize.$2;
        final instanceFieldsSize = _readULEB128(dexBytes, pos);
        pos = instanceFieldsSize.$2;
        final directMethodsSize = _readULEB128(dexBytes, pos);
        pos = directMethodsSize.$2;
        final virtualMethodsSize = _readULEB128(dexBytes, pos);
        pos = virtualMethodsSize.$2;

        // 解析字段（static + instance），填充 fields 列表
        int prevFieldIdx = 0;
        for (int fi = 0; fi < staticFieldsSize.$1 + instanceFieldsSize.$1; fi++) {
          final fieldIdxDiff = _readULEB128(dexBytes, pos);
          pos = fieldIdxDiff.$2;
          final fieldAccess = _readULEB128(dexBytes, pos);
          pos = fieldAccess.$2;
          prevFieldIdx += fieldIdxDiff.$1;
          // 从 field_ids 表读取字段名和类型
          if (prevFieldIdx < fieldIdsSize && fieldIdsOff + prevFieldIdx * 8 + 8 <= dexBytes.length) {
            final typeIdx = HexUtils.readUint16LE(dexBytes, fieldIdsOff + prevFieldIdx * 8 + 2);
            final nameIdx = HexUtils.readUint32LE(dexBytes, fieldIdsOff + prevFieldIdx * 8 + 4);
            String fieldName = '';
            String fieldType = '';
            if (nameIdx < stringIdsSize) {
              fieldName = _readDexString(dexBytes, stringIdsOff, nameIdx);
            }
            if (typeIdx < typeIdsSize) {
              final typeStrIdx = HexUtils.readUint32LE(dexBytes, typeIdsOff + typeIdx * 4);
              if (typeStrIdx < stringIdsSize) {
                fieldType = _readDexString(dexBytes, stringIdsOff, typeStrIdx);
              }
            }
            fields.add(DexField(
              name: fieldName,
              type: fieldType,
              accessFlags: fieldAccess.$1,
            ));
          }
        }

        // 读取方法。DEX 规范中 direct_methods 与 virtual_methods 是两条独立列表，
        // 各自的方法索引从 0 开始累积，两组之间必须重置 prevMethodIdx，否则虚方法索引全部偏移。
        int prevMethodIdx = 0;
        for (int mi = 0; mi < directMethodsSize.$1; mi++) {
          final entry = _parseEncodedMethod(dexBytes, pos, prevMethodIdx,
              methodIdsOff, stringIdsOff, typeIdsOff, protoIdsOff, methodIdsSize, stringIdsSize, typeIdsSize);
          pos = entry.$2;
          prevMethodIdx = entry.$3;
          if (entry.$1 != null) methods.add(entry.$1!);
        }
        prevMethodIdx = 0; // 重置：virtual 方法索引独立累积
        for (int mi = 0; mi < virtualMethodsSize.$1; mi++) {
          final entry = _parseEncodedMethod(dexBytes, pos, prevMethodIdx,
              methodIdsOff, stringIdsOff, typeIdsOff, protoIdsOff, methodIdsSize, stringIdsSize, typeIdsSize);
          pos = entry.$2;
          prevMethodIdx = entry.$3;
          if (entry.$1 != null) methods.add(entry.$1!);
        }
      }

      classes.add(DexClass(
        name: className,
        methods: methods,
        fields: fields,
        superClass: superClass,
        interfaces: interfaces,
        accessFlags: accessFlags,
      ));
    }
    return classes;
  }

  /// 从 DEX 提取所有可读字符串
  List<String> _extractStrings(Uint8List dexBytes) {
    final strings = <String>{};
    if (dexBytes.length < 112) return strings.toList();
    final stringIdsSize = HexUtils.readUint32LE(dexBytes, 56);
    final stringIdsOff = HexUtils.readUint32LE(dexBytes, 60);

    for (int i = 0; i < stringIdsSize && i < 100000; i++) {
      final s = _readDexString(dexBytes, stringIdsOff, i);
      if (s.length > 2 && s.length < 500) {
        // 允许 ASCII 可打印字符和中文字符
        if (StringUtils.isPrintable(s) || StringUtils.hasChinese(s) ||
            RegExp(r'^[\x20-\x7E\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]+$').hasMatch(s)) {
          strings.add(s);
        }
      }
    }
    return strings.toList();
  }

  /// 读取 DEX 字符串池中指定索引的字符串
  String _readDexString(Uint8List dex, int stringIdsOff, int idx) {
    if (stringIdsOff + idx * 4 + 4 > dex.length) return '';
    final dataOff = HexUtils.readUint32LE(dex, stringIdsOff + idx * 4);
    if (dataOff >= dex.length) return '';

    // string_data_item: utf16_size (uleb128) + mutf8[] + 0x00
    var pos = dataOff;
    // 跳过 utf16_size (uleb128)
    while (pos < dex.length && (dex[pos] & 0x80) != 0) pos++;
    pos++; // 最后一个字节
    if (pos >= dex.length) return '';

    // 读取 MUTF-8 字符串直到 0x00
    final start = pos;
    while (pos < dex.length && dex[pos] != 0) pos++;
    if (pos == start) return '';

    try {
      return utf8.decode(dex.sublist(start, pos), allowMalformed: true);
    } catch (_) {
      return '';
    }
  }

  /// 读取 ULEB128 编码的无符号整数
  (int value, int nextOffset) _readULEB128(Uint8List bytes, int offset) {
    int result = 0;
    int shift = 0;
    int pos = offset;
    while (pos < bytes.length) {
      final byte = bytes[pos++];
      result |= (byte & 0x7F) << shift;
      if ((byte & 0x80) == 0) break;
      shift += 7;
    }
    return (result, pos);
  }

  /// 解析单个 encoded_method 条目，返回 (方法, 下一读取偏移, 累积后的 method_idx)
  (DexMethod?, int, int) _parseEncodedMethod(
    Uint8List dexBytes,
    int pos,
    int prevMethodIdx,
    int methodIdsOff,
    int stringIdsOff,
    int typeIdsOff,
    int protoIdsOff,
    int methodIdsSize,
    int stringIdsSize,
    int typeIdsSize,
  ) {
    final methodIdxDiff = _readULEB128(dexBytes, pos);
    pos = methodIdxDiff.$2;
    final methodAccess = _readULEB128(dexBytes, pos);
    pos = methodAccess.$2;
    final codeOff = _readULEB128(dexBytes, pos);
    pos = codeOff.$2;

    final methodIdx = prevMethodIdx + methodIdxDiff.$1;

    DexMethod? method;
    if (methodIdx < methodIdsSize) {
      final methodItemOff = methodIdsOff + methodIdx * 8; // method_id_item = 8 bytes
      final protoIdx = HexUtils.readUint16LE(dexBytes, methodItemOff + 2);
      final nameIdx = HexUtils.readUint32LE(dexBytes, methodItemOff + 4);

      if (nameIdx < stringIdsSize) {
        final methodName = _readDexString(dexBytes, stringIdsOff, nameIdx);
        // 完整方法描述符：返回类型 + 参数类型列表
        String descriptor = '()V';
        if (protoIdsOff > 0 && protoIdx * 12 + 12 <= dexBytes.length) {
          final protoOff = protoIdsOff + protoIdx * 12;
          // proto_id_item: shorty_idx[4], return_type_idx[4], parameters_off[4]
          final returnTypeIdx = HexUtils.readUint32LE(dexBytes, protoOff + 4);
          final paramsOff = HexUtils.readUint32LE(dexBytes, protoOff + 8);
          final retType = returnTypeIdx < typeIdsSize
              ? _readDexString(dexBytes, stringIdsOff,
                  HexUtils.readUint32LE(dexBytes, typeIdsOff + returnTypeIdx * 4))
              : 'V';
          final paramBuf = StringBuffer('(');
          if (paramsOff != 0 && paramsOff + 4 <= dexBytes.length) {
            final typeListSize = HexUtils.readUint32LE(dexBytes, paramsOff);
            for (int pi = 0; pi < typeListSize && pi < 200; pi++) {
              final pTypeIdx = HexUtils.readUint16LE(dexBytes, paramsOff + 4 + pi * 2);
              if (pTypeIdx < typeIdsSize) {
                paramBuf.write(_readDexString(dexBytes, stringIdsOff,
                    HexUtils.readUint32LE(dexBytes, typeIdsOff + pTypeIdx * 4)));
              }
            }
          }
          paramBuf.write(')');
          descriptor = '$paramBuf$retType';
        }
        method = DexMethod(
          name: methodName,
          descriptor: descriptor,
          accessFlags: methodAccess.$1,
          codeSize: codeOff.$1,
        );
      }
    }
    return (method, pos, methodIdx);
  }


  // ========== 新增分析功能 ==========

  /// 收集所有 DEX 文件中的字符串和类名（供 SDK 检测和加壳检测使用）
  Future<({Set<String> strings, Set<String> classNames})> collectDexData() async {
    final cacheKey = _cacheKey(path, 'dexdata');
    final cached = _resultCache.get(cacheKey);
    if (cached != null) {
      return (strings: cached.$1 as Set<String>, classNames: cached.$2 as Set<String>);
    }

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);
    final allStrings = <String>{};
    final allClassNames = <String>{};

    for (final dex in entries.where((e) => e.name.endsWith('.dex'))) {
      final dexBytes = _extractFile(bytes, dex);
      allStrings.addAll(_extractStrings(dexBytes));
      final classes = _parseDexClassesDetailed(dexBytes);
      for (final cls in classes) {
        allClassNames.add(cls.name);
      }
    }

    MemoryManager().release(bytes);
    final result = (strings: allStrings, classNames: allClassNames);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 检测第三方 SDK / 库
  Future<SdkDetectionResult> detectSdks() async {
    final cacheKey = _cacheKey(path, 'sdks');
    final cached = _resultCache.get(cacheKey);
    if (cached is SdkDetectionResult) return cached;

    final dexData = await collectDexData();
    final result = SdkDetector.detect(dexData.strings, dexData.classNames);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 检测加壳/加固
  Future<PackerDetectionResult> detectPacker() async {
    final cacheKey = _cacheKey(path, 'packer');
    final cached = _resultCache.get(cacheKey);
    if (cached is PackerDetectionResult) return cached;

    final info = await analyze();
    final dexData = await collectDexData();
    final result = PackerDetector.detect(info.entries, dexData.classNames, dexData.strings);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 权限风险分类
  Future<PermissionClassificationResult> classifyPermissions() async {
    final cacheKey = _cacheKey(path, 'permclass');
    final cached = _resultCache.get(cacheKey);
    if (cached is PermissionClassificationResult) return cached;

    final info = await analyze();
    final result = PermissionClassifier.classify(info.permissions);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 原生库架构摘要
  Future<NativeLibSummary> getNativeLibSummary() async {
    final cacheKey = _cacheKey(path, 'nativelib');
    final cached = _resultCache.get(cacheKey);
    if (cached is NativeLibSummary) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    final abiMap = <String, List<NativeLibEntry>>{};
    for (final e in entries) {
      if (e.name.startsWith('lib/') && e.name.endsWith('.so')) {
        final parts = e.name.split('/');
        String abi = parts.length >= 3 ? parts[1] : 'unknown';
        abiMap.putIfAbsent(abi, () => []).add(NativeLibEntry(
          name: parts.last,
          fullPath: e.name,
          abi: abi,
          size: e.uncompressedSize,
        ));
      }
    }

    final result = NativeLibSummary(
      abis: abiMap.keys.toList()..sort(),
      abiCount: abiMap.length,
      libsByAbi: abiMap,
      totalLibCount: abiMap.values.expand((l) => l).length,
      totalSize: abiMap.values.expand((l) => l).fold(0, (sum, e) => sum + e.size),
    );

    MemoryManager().release(bytes);
    _resultCache.put(cacheKey, result);
    return result;
  }

  /// 解析 resources.arsc 资源表
  Future<ResInfo?> parseResources() async {
    final cacheKey = _cacheKey(path, 'resources');
    final cached = _resultCache.get(cacheKey);
    if (cached is ResInfo) return cached;

    final bytes = MemoryManager().track(await _readFile(path));
    final entries = _parseZipCentralDirectory(bytes);

    final arscEntry = entries.where((e) => e.name == 'resources.arsc').firstOrNull;
    ResInfo? result;
    if (arscEntry != null) {
      final arscBytes = _extractFile(bytes, arscEntry);
      result = ResAnalyzer.parse(arscBytes);
    }

    MemoryManager().release(bytes);
    if (result != null) {
      _resultCache.put(cacheKey, result);
    }
    return result;
  }

  /// 导出完整分析结果为 JSON 字符串
  Future<String> exportAsJson() async {
    final info = await analyze();
    final manifest = await parseManifestInfo();
    final sigBlock = await detectSignatureBlock();
    final cert = await parseCertificate();
    final hash = await calculateHash();
    final sizeBreakdown = await getFileSizeBreakdown();
    final obf = await detectObfuscation();
    final sdkResult = await detectSdks();
    final packerResult = await detectPacker();
    final permResult = await classifyPermissions();
    final nativeLib = await getNativeLibSummary();

    final buf = StringBuffer();
    buf.writeln('{');
    buf.writeln('  "basicInfo": {');
    buf.writeln('    "packageName": "${_escapeJson(info.packageName)}",');
    buf.writeln('    "versionName": "${_escapeJson(info.versionName)}",');
    buf.writeln('    "versionCode": ${info.versionCode},');
    buf.writeln('    "fileSize": ${info.fileSize},');
    buf.writeln('    "fileSizeMB": ${(info.fileSize / 1024 / 1024).toStringAsFixed(2)},');
    buf.writeln('    "mainActivity": "${_escapeJson(info.mainActivity)}",');
    buf.writeln('    "applicationName": "${_escapeJson(info.applicationName ?? '')}",');
    buf.writeln('    "minSdkVersion": "${_escapeJson(info.minSdkVersion ?? '')}",');
    buf.writeln('    "targetSdkVersion": "${_escapeJson(info.targetSdkVersion ?? '')}",');
    buf.writeln('    "manifestParseMethod": "${_escapeJson(manifest.parseMethod ?? 'unknown')}",');
    buf.writeln('    "dexClassCount": ${info.dexClasses.length},');
    buf.writeln('    "entryCount": ${info.entries.length}');
    buf.writeln('  },');

    // 权限分类
    buf.writeln('  "permissions": {');
    buf.writeln('    "total": ${permResult.classifications.length},');
    buf.writeln('    "dangerous": ${permResult.dangerousCount},');
    buf.writeln('    "normal": ${permResult.normalCount},');
    buf.writeln('    "signature": ${permResult.signatureCount},');
    buf.writeln('    "unknown": ${permResult.unknownCount},');
    buf.writeln('    "items": [');
    for (int i = 0; i < permResult.classifications.length; i++) {
      final p = permResult.classifications[i];
      buf.write('      {"permission": "${_escapeJson(p.permission)}", "level": "${p.level.name}", "riskLabel": "${p.riskLabel}", "description": "${_escapeJson(p.description)}"}');
      buf.writeln(i < permResult.classifications.length - 1 ? ',' : '');
    }
    buf.writeln('    ]');
    buf.writeln('  },');

    // 签名信息
    buf.writeln('  "signature": {');
    buf.writeln('    "v1": ${info.entries.any((e) => e.startsWith('META-INF/') && (e.endsWith('.RSA') || e.endsWith('.DSA') || e.endsWith('.EC')))},');
    buf.writeln('    "v2": ${sigBlock.v2},');
    buf.writeln('    "v3": ${sigBlock.v3}');
    buf.writeln('  },');

    // 证书信息
    if (cert != null) {
      buf.writeln('  "certificate": {');
      buf.writeln('    "subject": "${_escapeJson(cert.subject)}",');
      buf.writeln('    "issuer": "${_escapeJson(cert.issuer)}",');
      buf.writeln('    "serialNumber": "${_escapeJson(cert.serialNumber)}",');
      buf.writeln('    "algorithm": "${_escapeJson(cert.algorithm)}"');
      buf.writeln('  },');
    }

    // 哈希
    buf.writeln('  "hash": {');
    buf.writeln('    "md5": "${hash.md5}",');
    buf.writeln('    "sha1": "${hash.sha1}",');
    buf.writeln('    "sha256": "${hash.sha256}"');
    buf.writeln('  },');

    // 混淆检测
    buf.writeln('  "obfuscation": {');
    buf.writeln('    "level": "${obf.suspicionLevel}",');
    buf.writeln('    "totalNames": ${obf.totalNames},');
    buf.writeln('    "shortNameRatio": ${obf.shortNameRatio.toStringAsFixed(4)},');
    buf.writeln('    "averageEntropy": ${obf.averageEntropy.toStringAsFixed(4)}');
    buf.writeln('  },');

    // SDK 检测
    buf.writeln('  "sdks": {');
    buf.writeln('    "total": ${sdkResult.totalSdkCount},');
    buf.writeln('    "categories": {');
    int ci = 0;
    for (final entry in sdkResult.categories.entries) {
      buf.write('      "${entry.key}": ${entry.value}');
      buf.writeln(ci < sdkResult.categories.length - 1 ? ',' : '');
      ci++;
    }
    buf.writeln('    },');
    buf.writeln('    "items": [');
    for (int i = 0; i < sdkResult.sdks.length; i++) {
      final s = sdkResult.sdks[i];
      buf.write('      {"name": "${_escapeJson(s.name)}", "category": "${_escapeJson(s.category)}", "description": "${_escapeJson(s.description)}"}');
      buf.writeln(i < sdkResult.sdks.length - 1 ? ',' : '');
    }
    buf.writeln('    ]');
    buf.writeln('  },');

    // 加壳检测
    buf.writeln('  "packer": {');
    buf.writeln('    "isPacked": ${packerResult.isPacked},');
    buf.writeln('    "name": "${_escapeJson(packerResult.packerName ?? '')}"');
    buf.writeln('  },');

    // 组件统计
    buf.writeln('  "components": {');
    buf.writeln('    "activity": ${manifest.activityList.length},');
    buf.writeln('    "service": ${manifest.serviceList.length},');
    buf.writeln('    "receiver": ${manifest.receiverList.length},');
    buf.writeln('    "provider": ${manifest.providerList.length},');
    buf.writeln('    "exported": ${manifest.exportedComponents.length},');
    buf.writeln('    "deepLinks": ${manifest.deepLinks.length}');
    buf.writeln('  },');

    // 文件大小分布
    buf.writeln('  "sizeBreakdown": {');
    buf.writeln('    "dex": ${sizeBreakdown.dexSize},');
    buf.writeln('    "resources": ${sizeBreakdown.resourcesSize},');
    buf.writeln('    "nativeLib": ${sizeBreakdown.nativeLibSize},');
    buf.writeln('    "assets": ${sizeBreakdown.assetsSize},');
    buf.writeln('    "other": ${sizeBreakdown.otherSize}');
    buf.writeln('  },');

    // 原生库
    buf.writeln('  "nativeLibraries": {');
    buf.writeln('    "abiCount": ${nativeLib.abiCount},');
    buf.writeln('    "abis": ${nativeLib.abis.map((a) => '"$a"').toList()},');
    buf.writeln('    "totalLibCount": ${nativeLib.totalLibCount},');
    buf.writeln('    "totalSize": ${nativeLib.totalSize}');
    buf.writeln('  }');

    buf.writeln('}');
    return buf.toString();
  }

  String _escapeJson(String s) {
    return s.replaceAll('\\', '\\\\').replaceAll('"', '\\"').replaceAll('\n', '\\n').replaceAll('\r', '\\r');
  }


  Future<Uint8List> _readFile(String path) async {
    final file = File(path);
    return Uint8List.fromList(await file.readAsBytes());
  }
}

/// APK Signing Block 检测结果
class SignatureBlockInfo {
  final bool hasSigningBlock;
  final bool v2;
  final bool v3;
  final int blockSize;

  const SignatureBlockInfo({
    required this.hasSigningBlock,
    required this.v2,
    required this.v3,
    required this.blockSize,
  });

  String get summary {
    final parts = <String>[];
    if (v2) parts.add('V2');
    if (v3) parts.add('V3');
    return parts.isEmpty ? (hasSigningBlock ? '签名块(未知版本)' : '无签名块') : parts.join(' + ');
  }
}

/// ZIP 中央目录条目
class _ZipEntry {
  final String name;
  final int localHeaderOffset;
  final int compressedSize;
  final int uncompressedSize;
  final int compressionMethod;
  final int crc32;

  _ZipEntry({
    required this.name,
    required this.localHeaderOffset,
    required this.compressedSize,
    required this.uncompressedSize,
    required this.compressionMethod,
    this.crc32 = 0,
  });
}

/// 原生库条目
class NativeLibEntry {
  final String name;
  final String fullPath;
  final String abi;
  final int size;

  const NativeLibEntry({
    required this.name,
    required this.fullPath,
    required this.abi,
    required this.size,
  });

  String get sizeStr {
    if (size >= 1024 * 1024) return '${(size / 1024 / 1024).toStringAsFixed(2)} MB';
    if (size >= 1024) return '${(size / 1024).toStringAsFixed(1)} KB';
    return '$size B';
  }
}

/// 原生库架构摘要
class NativeLibSummary {
  final List<String> abis;
  final int abiCount;
  final Map<String, List<NativeLibEntry>> libsByAbi;
  final int totalLibCount;
  final int totalSize;

  const NativeLibSummary({
    required this.abis,
    required this.abiCount,
    required this.libsByAbi,
    required this.totalLibCount,
    required this.totalSize,
  });

  String get totalSizeStr {
    if (totalSize >= 1024 * 1024) return '${(totalSize / 1024 / 1024).toStringAsFixed(2)} MB';
    if (totalSize >= 1024) return '${(totalSize / 1024).toStringAsFixed(1)} KB';
    return '$totalSize B';
  }

  /// 获取 ABI 的中文描述
  static String abiDescription(String abi) {
    switch (abi) {
      case 'arm64-v8a': return 'ARM 64位 (主流)';
      case 'armeabi-v7a': return 'ARM 32位';
      case 'armeabi': return 'ARM 旧版32位';
      case 'x86': return 'x86 32位 (模拟器)';
      case 'x86_64': return 'x86 64位 (模拟器)';
      case 'mips': return 'MIPS';
      case 'mips64': return 'MIPS 64位';
      default: return abi;
    }
  }
}
