import 'dart:collection';
import 'dart:typed_data';

/// 内存回收与管理机制
///
/// 提供两类能力：
/// 1. [MemoryManager] 单例：跟踪大块缓冲占用（预算），并在需要时主动释放引用，
///    交由 Dart VM 垃圾回收，避免大文件（APK/DEX/SO）分析时内存只增不减。
/// 2. [LruCache] 泛型 LRU 缓存：带条目数上限，淘汰时回调 [onEvict] 以便释放引用，
///    用于缓存解析结果，避免对同一个大文件重复解析造成的内存与 CPU 浪费。
class MemoryManager {
  static final MemoryManager _instance = MemoryManager._internal();
  factory MemoryManager() => _instance;
  MemoryManager._internal();

  /// 内存预算上限（字节）。默认 256MB，可在构造时按需调整。
  final int maxBudgetBytes = 256 * 1024 * 1024;

  int _usedBytes = 0;
  final Set<_TrackedBuffer> _tracked = {};

  /// 当前已登记缓冲占用字节数
  int get usedBytes => _usedBytes;

  /// 预算使用比例 0..1（可能 >1 表示已超预算）
  double get usageRatio => _usedBytes / maxBudgetBytes;

  /// 登记一块缓冲，计入预算。返回原缓冲以便链式使用。
  /// 当累计占用超过预算时触发一次软回收。
  Uint8List track(Uint8List buf, {String? tag}) {
    _usedBytes += buf.lengthInBytes;
    _tracked.add(_TrackedBuffer(buf, buf.lengthInBytes, tag));
    if (_usedBytes > maxBudgetBytes) {
      _softCollect();
    }
    return buf;
  }

  /// 主动释放一块缓冲的登记（仅解除跟踪引用，真正的回收由 Dart VM GC 完成）。
  void release(Uint8List? buf) {
    if (buf == null) return;
    _usedBytes -= buf.lengthInBytes;
    if (_usedBytes < 0) _usedBytes = 0;
    _tracked.removeWhere((e) => identical(e.buffer, buf));
  }

  /// 软回收：清空已登记引用（解除强引用，交由 GC），并复位计数。
  void _softCollect() {
    _tracked.clear();
    _usedBytes = 0;
  }

  /// 硬回收：清空所有登记引用，触发一次软回收。
  /// 注：Dart 没有强制 GC 的公开 API，这里通过解除全部大缓冲强引用来帮助 VM 及时回收。
  void collectAll() {
    _softCollect();
  }
}

class _TrackedBuffer {
  final Uint8List buffer;
  final int size;
  final String? tag;
  _TrackedBuffer(this.buffer, this.size, this.tag);
}

/// 泛型 LRU 缓存（带条目数上限淘汰，最近使用移到末尾）
class LruCache<K, V> {
  final int maxEntries;
  final void Function(K key, V value)? onEvict;
  final LinkedHashMap<K, V> _map = LinkedHashMap<K, V>();

  LruCache({this.maxEntries = 4, this.onEvict});

  /// 读取并标记为最近使用；未命中返回 null
  V? get(K key) {
    final v = _map[key];
    if (v == null) return null;
    _map.remove(key);
    _map[key] = v;
    return v;
  }

  /// 写入；若超上限则淘汰最久未使用项（并触发 onEvict）
  void put(K key, V value) {
    if (_map.containsKey(key)) {
      _map.remove(key);
    }
    _map[key] = value;
    while (_map.length > maxEntries) {
      final oldest = _map.keys.first;
      final removed = _map.remove(oldest);
      if (removed != null && onEvict != null) onEvict!(oldest, removed);
    }
  }

  void remove(K key) {
    final removed = _map.remove(key);
    if (removed != null && onEvict != null) onEvict!(key, removed);
  }

  /// 清空全部并触发 onEvict（用于主动内存回收）
  void clear() {
    if (onEvict != null) {
      for (final e in _map.entries) {
        onEvict!(e.key, e.value);
      }
    }
    _map.clear();
  }

  int get length => _map.length;
  Iterable<K> get keys => _map.keys;
}
