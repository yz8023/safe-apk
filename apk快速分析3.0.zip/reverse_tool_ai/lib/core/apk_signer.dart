import 'dart:typed_data';

/// APK 签名验证工具
class ApkSigner {
  /// 验证 APK v1 签名（JAR 签名）
  static bool verifyV1(List<String> entries, Map<String, Uint8List> entryData) {
    final hasManifest = entries.contains('META-INF/MANIFEST.MF');
    final hasSignature = entries.any((e) =>
        e.startsWith('META-INF/') &&
        (e.endsWith('.SF') || e.endsWith('.RSA') || e.endsWith('.DSA') || e.endsWith('.EC')));
    return hasManifest && hasSignature;
  }

  /// 检测 APK 签名版本
  static SignatureInfo detectSignature(List<String> entries) {
    bool v1 = false, v2 = false, v3 = false;

    // V1: JAR 签名
    if (entries.any((e) => e.startsWith('META-INF/') &&
        (e.endsWith('.SF') || e.endsWith('.RSA') || e.endsWith('.DSA')))) {
      v1 = true;
    }

    // V2/V3: 从文件列表无法直接判断，需要解析 APK Signing Block
    // 简化处理：如果有 v1 签名但没有明显的 JAR 特征，可能有 v2/v3
    if (entries.contains('META-INF/MANIFEST.MF')) {
      v1 = true;
    }

    return SignatureInfo(v1: v1, v2: v2, v3: v3);
  }
}

class SignatureInfo {
  final bool v1;
  final bool v2;
  final bool v3;

  const SignatureInfo({this.v1 = false, this.v2 = false, this.v3 = false});

  String get summary {
    final parts = <String>[];
    if (v1) parts.add('V1');
    if (v2) parts.add('V2');
    if (v3) parts.add('V3');
    return parts.isEmpty ? 'Unsigned' : parts.join(' + ');
  }
}
