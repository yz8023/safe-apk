/// APK 加固/加壳/保护方案检测器 - 纯 Dart 实现
///
/// 通过检查 APK 文件条目、DEX 类名与 DEX 字符串中的特征指纹，
/// 识别常见的 Android 应用加固（壳）方案，如 360 加固、腾讯乐固、
/// 梆梆加固、爱加密等，并检测通用的加壳保护特征。
///
/// 用法：
/// ```dart
/// final result = PackerDetector.detect(entries, classNames, dexStrings);
/// if (result.isPacked) {
///   print('检测到加固: ${result.packerName}');
/// }
/// ```

// ========== 结果模型 ==========

/// 单个加固方案检测结果
class PackerInfo {
  /// 加固方案名称（中文）
  final String name;

  /// 英文名称
  final String englishName;

  /// 命中的特征列表（描述具体匹配到了什么）
  final List<String> matchedIndicators;

  /// 加固方案描述（中文）
  final String description;

  /// 是否检测到该加固
  final bool isPacked;

  const PackerInfo({
    required this.name,
    required this.englishName,
    required this.matchedIndicators,
    required this.description,
    required this.isPacked,
  });

  /// 命中特征数量
  int get matchCount => matchedIndicators.length;

  /// 简要摘要
  String get summary {
    if (!isPacked) return '$name (未检测到)';
    return '$name (${englishName}) - 命中 $matchCount 项特征';
  }
}

/// 加固检测汇总结果
class PackerDetectionResult {
  /// 是否检测到任意加固/加壳
  final bool isPacked;

  /// 检测到的加固方案名称，未检测到时为 null
  final String? packerName;

  /// 所有命中的加固方案详情
  final List<PackerInfo> allMatches;

  /// 所有命中的特征字符串（扁平列表）
  final List<String> indicators;

  const PackerDetectionResult({
    required this.isPacked,
    required this.packerName,
    required this.allMatches,
    required this.indicators,
  });

  /// 未检测到加固的空结果
  static const PackerDetectionResult empty = PackerDetectionResult(
    isPacked: false,
    packerName: null,
    allMatches: [],
    indicators: [],
  );

  /// 整体摘要
  String get summary {
    if (!isPacked) return '未检测到加固/加壳';
    final names = allMatches.map((m) => m.name).join('、');
    return '检测到加固: $names (共 ${indicators.length} 项特征)';
  }
}

// ========== 加固方案定义 ==========

/// 加固方案特征定义（内部使用）
class _PackerDef {
  /// 中文名称
  final String name;

  /// 英文名称
  final String englishName;

  /// 描述
  final String description;

  /// 文件条目特征（.so / .dat 等文件名片段）
  final List<String> entries;

  /// 类名特征（点分形式，如 com.stub.StubApp）
  final List<String> classes;

  /// DEX 字符串特征
  final List<String> strings;

  const _PackerDef({
    required this.name,
    required this.englishName,
    required this.description,
    this.entries = const [],
    this.classes = const [],
    this.strings = const [],
  });
}

// ========== 检测器 ==========

/// APK 加固/加壳检测器
///
/// 基于已知加固方案的特征指纹（文件、类名、字符串）进行匹配，
/// 并检测通用的加壳保护特征。所有方法均为静态方法，无需实例化。
class PackerDetector {
  PackerDetector._();

  /// 已知加固方案特征库
  static const List<_PackerDef> _packers = [
    _PackerDef(
      name: '360加固',
      englishName: '360 Jiagu',
      description: '奇虎360推出的移动应用加固方案，通过 DEX 抽取与加密、SO 加密、'
          'VMP 虚拟化等技术保护代码，运行时由 libjiagu 系列 SO 动态解密还原并加载真实 DEX。',
      entries: [
        'libjiagu.so',
        'libjiagu_a64.so',
        'libjiagu_x86.so',
        'libjiagu_x64.so',
      ],
      classes: ['com.stub.StubApp', 'com.qihoo.util'],
      strings: ['com.qihoo360.mobilesafe', 'jiagu'],
    ),
    _PackerDef(
      name: '腾讯乐固',
      englishName: 'Tencent Legu',
      description: '腾讯云移动应用安全加固方案，通过 DEX 加密、SO 混淆及反调试等手段保护应用，'
          '运行时由 libshell 系列 SO 负责解密加载原始代码。',
      entries: [
        'libshell.so',
        'libshella.so',
        'libshellx.so',
        'libtup.so',
      ],
      classes: ['com.tencent.StubShell.TxAppEntry', 'com.tencent.bugly.legu'],
      strings: ['com.tencent.legu', 'legu'],
    ),
    _PackerDef(
      name: '梆梆加固',
      englishName: 'Bangcle',
      description: '梆梆安全推出的应用加固方案，提供 DEX 加壳、SO 加密、反调试与防篡改能力，'
          '通过 libsecexe/libDexHelper 等 SO 完成运行时解密。',
      entries: [
        'libsecexe.so',
        'libsecmain.so',
        'libDexHelper.so',
        'libDexHelperX.so',
      ],
      classes: [
        'com.bangcle.protect',
        'com.secapk.wrapper.ApplicationWrapper',
      ],
      strings: ['com.bangcle', 'secapk'],
    ),
    _PackerDef(
      name: '爱加密',
      englishName: 'IJm',
      description: '爱加密移动应用加固方案，通过对 DEX 加壳加密、SO 保护及运行时自解密机制保护代码，'
          '特征文件为 ijiami.dat 及 libexec 系列 SO。',
      entries: ['libexec.so', 'libexecmain.so', 'ijiami.dat'],
      classes: ['com.ijm.protect', 'com.secneo.apkwrapper'],
      strings: ['com.ijiami', 'ijiami'],
    ),
    _PackerDef(
      name: '娜迦',
      englishName: 'Nagapt',
      description: '娜迦(Nagapt)应用加固方案，通过 libnaga 系列 SO 对 DEX 进行加密保护，'
          '运行时动态解密还原原始代码。',
      entries: ['libnaga.so', 'libnaga_protect.so'],
      classes: ['com.nagapt.protect'],
    ),
    _PackerDef(
      name: '通付盾',
      englishName: 'TPS',
      description: '通付盾应用加固方案，通过 libtosprotection 系列 SO 对应用进行加壳保护与反逆向。',
      entries: ['libtosprotection.so', 'libtosprotection-x86.so'],
      classes: ['com.tongfudun.android'],
    ),
    _PackerDef(
      name: '百度加固',
      englishName: 'Baidu',
      description: '百度移动安全加固方案，通过 libbaiduprotect.so 对 DEX 进行加密抽取，'
          '运行时解密还原。',
      entries: ['libbaiduprotect.so'],
      classes: ['com.baidu.protect'],
    ),
    _PackerDef(
      name: '阿里聚安全',
      englishName: 'Alibaba',
      description: '阿里巴巴聚安全移动应用加固方案，通过 libmobisec/libsgmain 等 SO '
          '提供代码加密与安全防护。',
      entries: ['libmobisec.so', 'libsgmain.so'],
      classes: ['com.alibaba.wireless.security'],
    ),
    _PackerDef(
      name: '梆梆企业版',
      englishName: 'Bangcle Enterprise',
      description: '梆梆安全企业版加固方案，特征为 libsecshell.so，提供企业级代码保护能力。',
      entries: ['libsecshell.so'],
    ),
    _PackerDef(
      name: '海云安',
      englishName: 'Haiyunan',
      description: '海云安应用加固方案，特征为 libitsec.so，对 DEX 进行加壳保护。',
      entries: ['libitsec.so'],
    ),
    _PackerDef(
      name: '网易易盾',
      englishName: 'NetEase Yidun',
      description: '网易易盾移动应用加固方案，通过 libnesec.so 对代码进行加密保护与反逆向。',
      entries: ['libnesec.so'],
      classes: ['com.netease.mobsec'],
    ),
    _PackerDef(
      name: '顶象',
      englishName: 'Dingxiang',
      description: '顶象应用加固方案，特征为 libx3g.so，提供代码加密与运行时保护。',
      entries: ['libx3g.so'],
    ),
    _PackerDef(
      name: '几维安全',
      englishName: 'Kiwisec',
      description: '几维安全移动应用加固方案，通过 libkwscmm/libkwscr/libkwslinker 等 SO '
          '提供代码混淆、加密与反调试。',
      entries: ['libkwscmm.so', 'libkwscr.so', 'libkwslinker.so'],
    ),
    _PackerDef(
      name: 'Virbox',
      englishName: 'Virbox (深思数盾)',
      description: '深思数盾 Virbox 应用保护方案，通过 libDexHelper.so 对 DEX 进行加壳保护'
          '（与梆梆加固共用部分特征文件，需结合其他特征综合判断）。',
      entries: ['libDexHelper.so'],
    ),
  ];

  /// 通用加壳特征方案名称
  static const String _generalName = '通用加壳特征';
  static const String _generalEnglishName = 'General Packing Indicators';
  static const String _generalDescription =
      '检测到通用的加壳/保护特征，包括 DEX 类数量异常偏少、assets 目录存在疑似加密文件、'
      'NativeActivity 配合 native 库加载等。此类特征为辅助判断，建议结合已知加固方案特征综合分析。';

  /// 检测 APK 是否被加固/加壳
  ///
  /// [entries] APK 内全部文件条目路径（如 lib/arm64-v8a/libjiagu.so）
  /// [classNames] DEX 中解析到的类名集合（如 Lcom/stub/StubApp; 或 com.stub.StubApp）
  /// [dexStrings] DEX 中提取到的字符串集合
  ///
  /// 返回 [PackerDetectionResult]，包含是否加固、加固名称、全部匹配项与特征列表。
  static PackerDetectionResult detect(
    List<String> entries,
    Set<String> classNames,
    Set<String> dexStrings,
  ) {
    final allMatches = <PackerInfo>[];
    final allIndicators = <String>[];

    // 检测已知加固方案
    for (final def in _packers) {
      final matched = <String>[];

      // 文件条目特征
      for (final indicator in def.entries) {
        if (_matchEntry(entries, indicator)) {
          matched.add('文件: $indicator');
          allIndicators.add('$indicator (文件)');
        }
      }

      // 类名特征
      for (final indicator in def.classes) {
        if (_matchClass(classNames, indicator)) {
          matched.add('类名: $indicator');
          allIndicators.add('$indicator (类名)');
        }
      }

      // DEX 字符串特征
      for (final indicator in def.strings) {
        if (_matchString(dexStrings, indicator)) {
          matched.add('字符串: $indicator');
          allIndicators.add('$indicator (DEX字符串)');
        }
      }

      if (matched.isNotEmpty) {
        allMatches.add(PackerInfo(
          name: def.name,
          englishName: def.englishName,
          description: def.description,
          matchedIndicators: matched,
          isPacked: true,
        ));
      }
    }

    // 检测通用加壳特征
    final generalIndicators =
        _detectGeneralIndicators(entries, classNames, dexStrings);
    if (generalIndicators.isNotEmpty) {
      allIndicators.addAll(generalIndicators);
      allMatches.add(PackerInfo(
        name: _generalName,
        englishName: _generalEnglishName,
        description: _generalDescription,
        matchedIndicators: generalIndicators,
        isPacked: true,
      ));
    }

    final isPacked = allMatches.isNotEmpty;

    // 优先返回已知加固方案名称；若仅命中通用特征则标记为疑似加壳
    String? packerName;
    if (isPacked) {
      final known =
          allMatches.where((m) => m.englishName != _generalEnglishName).toList();
      if (known.isNotEmpty) {
        packerName = known.length == 1
            ? known.first.name
            : known.map((m) => m.name).join(' / ');
      } else {
        packerName = '疑似加壳';
      }
    }

    // 特征列表去重（保序），部分特征文件（如 libDexHelper.so）可能被多个方案共用
    final dedupedIndicators = _dedupePreserveOrder(allIndicators);

    return PackerDetectionResult(
      isPacked: isPacked,
      packerName: packerName,
      allMatches: allMatches,
      indicators: dedupedIndicators,
    );
  }

  // ==================== 通用加壳特征检测 ====================

  /// 检测通用加壳/保护特征
  static List<String> _detectGeneralIndicators(
    List<String> entries,
    Set<String> classNames,
    Set<String> dexStrings,
  ) {
    final indicators = <String>[];

    // 判断是否存在 native 库
    final hasNativeLib =
        entries.any((e) => e.startsWith('lib/') && e.endsWith('.so'));
    // 判断是否存在 assets 资源（APK 有实质内容的信号）
    final hasAssets = entries.any((e) => e.startsWith('assets/'));

    // 1. DEX 类数量极少（< 10），真实代码可能被加壳隐藏
    //    需配合 native 库或 assets 等「APK 有实质内容」的信号，避免空输入/极小样本误报
    if (classNames.length < 10 && (hasNativeLib || hasAssets)) {
      if (hasNativeLib) {
        indicators.add(
            'DEX 类数量极少 (${classNames.length}) 且存在 native 库，真实代码疑似被加壳隐藏');
      } else {
        indicators.add(
            'DEX 类数量极少 (${classNames.length}) 且存在 assets 资源，真实代码疑似被加壳隐藏');
      }
    }

    // 2. assets/ 目录存在疑似加密文件
    final encryptedAsset = _detectEncryptedAssets(entries);
    if (encryptedAsset != null) {
      indicators.add(encryptedAsset);
    }

    // 3. NativeActivity 作为主 Activity 且加载 native 库（常见壳入口）
    final hasNativeActivity = classNames.any((c) =>
        c.contains('com/android/NativeActivity') ||
        c.contains('com.android.NativeActivity'));
    if (hasNativeActivity && hasNativeLib) {
      indicators.add('使用 NativeActivity 配合 native 库加载，疑似壳入口');
    }

    return indicators;
  }

  /// 检测 assets/ 目录中的疑似加密文件
  ///
  /// 加固方案常将加密后的 DEX/数据存放在 assets 目录，特征为：
  /// .dat/.bin/.enc/.db 等扩展名，或无扩展名的二进制文件。
  static String? _detectEncryptedAssets(List<String> entries) {
    final suspicious = <String>[];
    for (final e in entries) {
      if (!e.startsWith('assets/')) continue;
      final basename = e.substring(e.lastIndexOf('/') + 1);
      if (basename.isEmpty) continue; // 目录
      final lower = basename.toLowerCase();
      final dotIdx = basename.lastIndexOf('.');
      final hasExt = dotIdx > 0 && dotIdx < basename.length - 1;
      final isSuspicious = !hasExt ||
          lower.endsWith('.dat') ||
          lower.endsWith('.bin') ||
          lower.endsWith('.enc') ||
          lower.endsWith('.db') ||
          lower.endsWith('.jar') ||
          lower.endsWith('.zip');
      if (isSuspicious) {
        suspicious.add(basename);
        if (suspicious.length >= 5) break;
      }
    }
    if (suspicious.isEmpty) return null;
    final preview = suspicious.take(3).join(', ');
    final extra = suspicious.length > 3 ? ' 等 ${suspicious.length} 个' : '';
    return 'assets/ 目录存在疑似加密文件 ($preview$extra)';
  }

  // ==================== 特征匹配辅助方法 ====================

  /// 检查文件条目中是否包含指定特征文件（不区分大小写）
  static bool _matchEntry(List<String> entries, String indicator) {
    final needle = indicator.toLowerCase();
    return entries.any((e) => e.toLowerCase().contains(needle));
  }

  /// 检查类名集合中是否包含指定类（同时支持 Lcom/pkg/Class; 与 com.pkg.Class 两种形式）
  static bool _matchClass(Set<String> classNames, String indicator) {
    final slashed = indicator.replaceAll('.', '/').toLowerCase();
    final dotted = indicator.toLowerCase();
    return classNames.any((c) {
      final cl = c.toLowerCase();
      return cl.contains(slashed) || cl.contains(dotted);
    });
  }

  /// 检查 DEX 字符串集合中是否包含指定字符串（不区分大小写）
  static bool _matchString(Set<String> dexStrings, String indicator) {
    final needle = indicator.toLowerCase();
    return dexStrings.any((s) => s.toLowerCase().contains(needle));
  }

  /// 列表去重并保持原始顺序
  static List<String> _dedupePreserveOrder(List<String> items) {
    final seen = <String>{};
    return items.where((i) => seen.add(i)).toList();
  }
}
