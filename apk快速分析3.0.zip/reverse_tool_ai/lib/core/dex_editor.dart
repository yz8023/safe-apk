import 'dart:typed_data';
import 'dart:convert';
import 'package:crypto/crypto.dart' as crypto;
import '../utils/hex_utils.dart';

/// DEX 字符串就地修改器 - 纯 Dart 实现
///
/// 支持 DEX 文件中字符串的就地修改（当新字符串长度 ≤ 原字符串长度时），
/// 修改后自动重算 DEX 校验和（Adler32）与 SHA-1 签名，确保 DEX 格式合法。
///
/// 用法：
/// ```dart
/// final entries = DexEditor.listStrings(dexBytes);
/// final modified = DexEditor.modifyStringByValue(dexBytes, 'old_url', 'new_url');
/// ```

// ========== 结果模型 ==========

/// DEX 字符串条目
class DexStringEntry {
  /// 字符串在 string_ids 表中的索引
  final int index;

  /// string_data_item 在 DEX 文件中的字节偏移
  final int offset;

  /// 字符串值的字节长度（不含尾 0 和 uleb128 长度前缀）
  final int length;

  /// 字符串值
  final String value;

  const DexStringEntry({
    required this.index,
    required this.offset,
    required this.length,
    required this.value,
  });
}

/// DEX 修改结果
class DexEditResult {
  /// 是否成功
  final bool success;

  /// 修改的字符串索引
  final int? stringIndex;

  /// 原字符串
  final String? oldString;

  /// 新字符串
  final String? newString;

  /// 错误信息
  final String? error;

  const DexEditResult({
    required this.success,
    this.stringIndex,
    this.oldString,
    this.newString,
    this.error,
  });
}

// ========== 修改器 ==========

class DexEditor {
  DexEditor._();

  /// 列出 DEX 文件中的所有字符串
  static List<DexStringEntry> listStrings(Uint8List dexBytes) {
    final entries = <DexStringEntry>[];
    try {
      if (dexBytes.length < 112) return entries;
      final stringIdsSize = HexUtils.readUint32LE(dexBytes, 56);
      final stringIdsOff = HexUtils.readUint32LE(dexBytes, 60);

      for (int i = 0; i < stringIdsSize && i < 200000; i++) {
        final entry = _readStringEntry(dexBytes, stringIdsOff, i);
        if (entry != null) entries.add(entry);
      }
    } catch (_) {
      // 解析失败返回已收集的条目
    }
    return entries;
  }

  /// 修改指定索引的字符串
  ///
  /// 要求新字符串的 UTF-8 字节长度 ≤ 原字符串的 UTF-8 字节长度。
  /// 修改后自动重算 Adler32 校验和与 SHA-1 签名。
  static Uint8List modifyString(Uint8List dexBytes, int stringIndex, String newString) {
    try {
      if (dexBytes.length < 112) return dexBytes;

      final stringIdsSize = HexUtils.readUint32LE(dexBytes, 56);
      final stringIdsOff = HexUtils.readUint32LE(dexBytes, 60);

      if (stringIndex < 0 || stringIndex >= stringIdsSize) return dexBytes;

      // 读取原始字符串信息
      final entry = _readStringEntry(dexBytes, stringIdsOff, stringIndex);
      if (entry == null) return dexBytes;

      final oldBytes = utf8.encode(entry.value);
      final newBytes = utf8.encode(newString);

      if (newBytes.length > oldBytes.length) {
        // 新字符串更长，不支持就地修改
        return dexBytes;
      }

      // 就地覆盖字符串数据
      final dataOff = entry.offset;
      // 跳过 uleb128 长度前缀（不修改，因为 UTF-16 长度可能不变或更小）
      var pos = dataOff;
      while (pos < dexBytes.length && (dexBytes[pos] & 0x80) != 0) pos++;
      pos++; // uleb128 最后一个字节

      // 写入新字符串字节
      final result = Uint8List.fromList(dexBytes);
      for (int i = 0; i < newBytes.length; i++) {
        result[pos + i] = newBytes[i];
      }
      // 剩余部分填 0x00
      for (int i = newBytes.length; i < oldBytes.length; i++) {
        result[pos + i] = 0;
      }

      // 重新计算校验和和签名
      _fixChecksums(result);

      return result;
    } catch (_) {
      return dexBytes;
    }
  }

  /// 按值查找并修改字符串
  static DexEditResult modifyStringByValue(Uint8List dexBytes, String oldString, String newString) {
    try {
      final entries = listStrings(dexBytes);
      for (final entry in entries) {
        if (entry.value == oldString) {
          final oldBytes = utf8.encode(oldString);
          final newBytes = utf8.encode(newString);
          if (newBytes.length > oldBytes.length) {
            return DexEditResult(
              success: false,
              error: '新字符串长度 (${newBytes.length}) 超过原字符串长度 (${oldBytes.length})，不支持就地扩展',
            );
          }
          modifyString(dexBytes, entry.index, newString);
          return DexEditResult(
            success: true,
            stringIndex: entry.index,
            oldString: oldString,
            newString: newString,
          );
        }
      }
      return DexEditResult(success: false, error: '未找到字符串: $oldString');
    } catch (e) {
      return DexEditResult(success: false, error: '修改失败: $e');
    }
  }

  // ========== 内部方法 ==========

  /// 读取指定索引的字符串条目
  static DexStringEntry? _readStringEntry(Uint8List dex, int stringIdsOff, int idx) {
    if (stringIdsOff + idx * 4 + 4 > dex.length) return null;
    final dataOff = HexUtils.readUint32LE(dex, stringIdsOff + idx * 4);
    if (dataOff == 0 || dataOff >= dex.length) return null;

    var pos = dataOff;
    // 跳过 uleb128 utf16_size
    while (pos < dex.length && (dex[pos] & 0x80) != 0) pos++;
    pos++;
    if (pos >= dex.length) return null;

    final start = pos;
    while (pos < dex.length && dex[pos] != 0) pos++;
    if (pos == start) return null;

    try {
      final value = utf8.decode(dex.sublist(start, pos), allowMalformed: true);
      return DexStringEntry(
        index: idx,
        offset: dataOff,
        length: pos - start,
        value: value,
      );
    } catch (_) {
      return null;
    }
  }

  /// 重新计算 DEX 的 Adler32 校验和与 SHA-1 签名
  static void _fixChecksums(Uint8List dex) {
    if (dex.length < 32) return;

    // Adler32 校验和：覆盖偏移 12 到文件末尾，写入偏移 8
    final adler = _calculateAdler32(dex, 12);
    _writeUint32LE(dex, 8, adler);

    // SHA-1 签名：覆盖偏移 32 到文件末尾，写入偏移 12
    final sha1 = crypto.sha1.convert(dex.sublist(32));
    final sha1Bytes = sha1.bytes;
    for (int i = 0; i < 20 && i < sha1Bytes.length; i++) {
      dex[12 + i] = sha1Bytes[i];
    }
  }

  /// 计算 Adler32 校验和
  static int _calculateAdler32(Uint8List data, [int start = 0]) {
    int a = 1, b = 0;
    final modAdler = 65521;
    for (int i = start; i < data.length; i++) {
      a = (a + data[i]) % modAdler;
      b = (b + a) % modAdler;
    }
    return (b << 16) | a;
  }

  /// 写入小端序 32 位整数
  static void _writeUint32LE(Uint8List data, int offset, int value) {
    if (offset + 4 > data.length) return;
    data[offset] = value & 0xFF;
    data[offset + 1] = (value >> 8) & 0xFF;
    data[offset + 2] = (value >> 16) & 0xFF;
    data[offset + 3] = (value >> 24) & 0xFF;
  }
}
