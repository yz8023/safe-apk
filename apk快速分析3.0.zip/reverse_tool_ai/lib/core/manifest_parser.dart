import 'dart:convert';
import 'dart:typed_data';
import '../utils/hex_utils.dart';

/// AndroidManifest.xml 详细解析器
class ManifestParser {
  /// 解析二进制 XML 并返回详细的 Manifest 信息
  /// 优先使用结构化解析，失败时自动回退到原始字节扫描
  static ManifestInfo parse(Uint8List data) {
    if (data.length < 8) return ManifestInfo.empty();

    // 验证二进制 XML 文件头 (type = 0x0003)
    final fileType = HexUtils.readUint16LE(data, 0);
    if (fileType != 0x0003) {
      // 不是标准二进制 XML，尝试回退解析
      return _parseFallback(data);
    }

    final strings = <String>[];
    final nsMap = <String, String>{}; // 命名空间 URI -> 前缀 (如 'android')

    // 构建元素树以正确还原嵌套结构
    final rootElements = <_TreeNode>[];
    final stack = <_TreeNode>[];

    int pos = 8; // 跳过文件级 chunk header

    while (pos + 8 <= data.length) {
      final chunkType = HexUtils.readUint16LE(data, pos);
      final headerSize = HexUtils.readUint16LE(data, pos + 2);
      final chunkSize = HexUtils.readUint32LE(data, pos + 4);
      // chunkSize 必须大于等于 headerSize，且不能越界
      if (chunkSize == 0 || chunkSize < headerSize || pos + chunkSize > data.length) break;

      if (chunkType == 0x0001) {
        // RES_STRING_POOL_TYPE
        _parseStringPool(data, pos, headerSize, strings);
      } else if (chunkType == 0x0100) {
        // RES_XML_START_NAMESPACE_TYPE — 先检查边界再读取
        if (pos + headerSize + 8 <= data.length) {
          final prefixIdx = HexUtils.readUint32LE(data, pos + headerSize);
          final uriIdx = HexUtils.readUint32LE(data, pos + headerSize + 4);
          if (prefixIdx < strings.length && uriIdx < strings.length) {
            nsMap[strings[uriIdx]] = strings[prefixIdx];
          }
        }
      } else if (chunkType == 0x0102) {
        // RES_XML_START_ELEMENT_TYPE
        final elem = _parseStartElement(data, pos, strings, nsMap);
        if (elem != null) {
          final node = _TreeNode(element: elem);
          if (stack.isNotEmpty) {
            stack.last.children.add(node);
          } else {
            rootElements.add(node);
          }
          stack.add(node);
        }
      } else if (chunkType == 0x0103) {
        // RES_XML_END_ELEMENT_TYPE — 弹出栈
        if (stack.isNotEmpty) stack.removeLast();
      }
      pos += chunkSize;
    }

    // 提取信息
    final result = _extractInfo(rootElements);

    // 如果结构化解析未获取到包名，尝试回退解析
    if (result.packageName.isEmpty) {
      final fallback = _parseFallback(data);
      return ManifestInfo(
        packageName: fallback.packageName.isNotEmpty ? fallback.packageName : result.packageName,
        versionName: fallback.versionName.isNotEmpty ? fallback.versionName : result.versionName,
        versionCode: fallback.versionCode > 1 ? fallback.versionCode : result.versionCode,
        mainActivity: result.mainActivity.isNotEmpty ? result.mainActivity : fallback.mainActivity,
        applicationClass: result.applicationClass ?? fallback.applicationClass,
        minSdkVersion: result.minSdkVersion ?? fallback.minSdkVersion,
        targetSdkVersion: result.targetSdkVersion ?? fallback.targetSdkVersion,
        compileSdkVersion: result.compileSdkVersion,
        debuggable: result.debuggable,
        allowBackup: result.allowBackup,
        supportsRtl: result.supportsRtl,
        isPersistent: result.isPersistent,
        installLocation: result.installLocation,
        permissions: result.permissions.isNotEmpty ? result.permissions : fallback.permissions,
        features: result.features,
        components: result.components,
        deepLinks: result.deepLinks,
        metaData: result.metaData,
        xmlContent: result.xmlContent.isNotEmpty ? result.xmlContent : fallback.xmlContent,
        parseMethod: result.packageName.isNotEmpty ? 'structured' : 'fallback',
      );
    }

    return result;
  }

  // ============ 回退解析：原始字节扫描 ============

  /// 从原始二进制数据中提取所有可打印字符串（UTF-8 和 UTF-16LE）
  static List<String> _extractAllStrings(Uint8List data) {
    final strings = <String>[];
    final seen = <String>{};

    // 1. 扫描 UTF-8 字符串（连续可打印字节后跟 0x00）
    int i = 0;
    while (i < data.length) {
      if (data[i] >= 0x20 && data[i] < 0x7F) {
        final start = i;
        while (i < data.length && data[i] != 0 && data[i] >= 0x20 && data[i] < 0x80) {
          i++;
        }
        if (i > start + 2 && i < data.length && data[i] == 0) {
          final s = String.fromCharCodes(data.sublist(start, i));
          if (seen.add(s)) strings.add(s);
        }
      } else if (data[i] >= 0x80) {
        // 可能是 UTF-8 多字节字符，尝试解码
        final start = i;
        int byteCount = 0;
        if ((data[i] & 0xE0) == 0xC0) byteCount = 2;
        else if ((data[i] & 0xF0) == 0xE0) byteCount = 3;
        else if ((data[i] & 0xF8) == 0xF0) byteCount = 4;

        if (byteCount > 0 && i + byteCount <= data.length) {
          try {
            final s = utf8.decode(data.sublist(start, start + byteCount), allowMalformed: true);
            if (s.isNotEmpty && seen.add(s)) strings.add(s);
          } catch (_) {}
          i += byteCount;
        } else {
          i++;
        }
      } else {
        i++;
      }
    }

    // 2. 扫描 UTF-16LE 字符串（可打印 ASCII + 0x00 高字节）
    i = 0;
    while (i + 1 < data.length) {
      if (data[i] >= 0x20 && data[i] < 0x7F && data[i + 1] == 0) {
        final start = i;
        final codeUnits = <int>[];
        while (i + 1 < data.length && data[i] != 0 && data[i + 1] == 0 &&
               data[i] >= 0x20 && data[i] < 0x80) {
          codeUnits.add(data[i]);
          i += 2;
        }
        if (codeUnits.length >= 3 && i + 1 < data.length && data[i] == 0 && data[i + 1] == 0) {
          final s = String.fromCharCodes(codeUnits);
          if (seen.add(s)) strings.add(s);
        }
      } else {
        i++;
      }
    }

    return strings;
  }

  /// 回退解析：当结构化解析失败时，从原始字节中提取关键信息
  static ManifestInfo _parseFallback(Uint8List data) {
    final allStrings = _extractAllStrings(data);

    String? packageName;
    String? versionName;
    int versionCode = 1;
    String? minSdk;
    String? targetSdk;
    final permissions = <String>[];
    final features = <String>[];

    // 包名正则：至少两段 dot 分隔，每段以字母开头
    final pkgRegex = RegExp(r'^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){2,}$');
    // 版本号正则：x.y 或 x.y.z 格式
    final versionRegex = RegExp(r'^\d+\.\d+[\.\d]*(-[a-zA-Z0-9]+)?$');
    // 纯数字（可能是 versionCode / SDK 版本）
    final numRegex = RegExp(r'^\d{1,3}$');

    // 用于追踪 uses-sdk 附近的数字
    int? sdkMinCandidate;
    int? sdkTargetCandidate;
    bool foundUsesSdk = false;

    // 遍历所有字符串，按特征分类
    for (final s in allStrings) {
      // 权限
      if (s.contains('.permission.') || s.startsWith('android.permission.')) {
        if (s.length > 10 && s.length < 100 && !permissions.contains(s)) {
          permissions.add(s);
        }
        continue;
      }

      // 硬件特性
      if (s.startsWith('android.hardware.') || s.startsWith('android.software.')) {
        if (!features.contains(s)) features.add(s);
        continue;
      }

      // SDK 版本号候选（1-33 的纯数字，排除常见误报）
      if (numRegex.hasMatch(s)) {
        final n = int.tryParse(s);
        if (n != null && n >= 1 && n <= 35) {
          // 第一个合理数字可能是 minSdk
          if (sdkMinCandidate == null) {
            sdkMinCandidate = n;
          } else if (sdkTargetCandidate == null && n > sdkMinCandidate) {
            sdkTargetCandidate = n;
          }
        }
      }

      // 包名候选（排除常见误报）
      if (packageName == null && pkgRegex.hasMatch(s) &&
          !s.contains('android.') && !s.contains('java.') &&
          !s.contains('sun.') && !s.contains('com.android.') &&
          s.length < 100) {
        // 倾向于选择包含 'app' 或看起来像应用包名的字符串
        if (s.split('.').length >= 2) {
          packageName = s;
        }
      }

      // 版本名候选
      if (versionName == null && versionRegex.hasMatch(s) && s.length < 20) {
        versionName = s;
      }
    }

    // 赋值 SDK 版本
    if (sdkMinCandidate != null) {
      minSdk = sdkMinCandidate.toString();
    }
    if (sdkTargetCandidate != null) {
      targetSdk = sdkTargetCandidate.toString();
    } else if (sdkMinCandidate != null) {
      targetSdk = sdkMinCandidate.toString();
    }

    // 如果还没找到包名，放宽条件再找一次
    if (packageName == null || packageName.isEmpty) {
      for (final s in allStrings) {
        if (s.contains('.') && !s.contains('/') && !s.contains(' ') &&
            !s.contains('android') && !s.contains('java') &&
            !s.contains('http') && !s.contains('com.google') &&
            pkgRegex.hasMatch(s) && s.length < 80) {
          packageName = s;
          break;
        }
      }
    }

    // 构建 XML 内容
    final xmlBuf = StringBuffer();
    xmlBuf.writeln('<?xml version="1.0" encoding="utf-8"?>');
    xmlBuf.writeln('<!-- 通过回退解析生成，结构可能不完整 -->');
    if (packageName != null) {
      xmlBuf.writeln('<manifest package="$packageName">');
    } else {
      xmlBuf.writeln('<manifest>');
    }
    if (permissions.isNotEmpty) {
      xmlBuf.writeln('  <!-- 权限 (${permissions.length}) -->');
      for (final p in permissions) {
        xmlBuf.writeln('  <uses-permission android:name="$p" />');
      }
    }
    xmlBuf.writeln('</manifest>');

    return ManifestInfo(
      packageName: packageName ?? '',
      versionName: versionName ?? '',
      versionCode: versionCode,
      mainActivity: '',
      permissions: permissions,
      features: features,
      minSdkVersion: minSdk,
      targetSdkVersion: targetSdk,
      xmlContent: xmlBuf.toString(),
      parseMethod: 'fallback',
    );
  }

  /// 从元素树提取 ManifestInfo
  static ManifestInfo _extractInfo(List<_TreeNode> roots) {
    String? packageName;
    String? versionName;
    int? versionCode;
    String? mainActivity;
    String? applicationClass;
    String? minSdk;
    String? targetSdk;
    String? compileSdk;
    bool debuggable = false;
    bool allowBackup = false;
    bool supportsRtl = false;
    bool isPersistent = false;
    String? installLocation;
    final permissions = <String>[];
    final features = <String>[];
    final components = <ComponentInfo>[];
    final deepLinks = <DeepLink>[];
    final metaData = <String, String>{};

    // 找到 manifest 根节点
    _TreeNode? manifestNode;
    for (final node in roots) {
      if (node.element.name == 'manifest') {
        manifestNode = node;
        break;
      }
    }
    if (manifestNode == null && roots.isNotEmpty) {
      manifestNode = roots.first;
    }

    if (manifestNode != null) {
      final mAttrs = manifestNode.element.attributes;
      packageName = mAttrs['package'];
      versionName = mAttrs['android:versionName'] ?? mAttrs['versionName'];
      versionCode = int.tryParse(
          mAttrs['android:versionCode'] ?? mAttrs['versionCode'] ?? '');
      compileSdk = mAttrs['android:compileSdkVersion'] ??
          mAttrs['compileSdkVersion'];
      installLocation = mAttrs['android:installLocation'];

      for (final child in manifestNode.children) {
        final name = child.element.name;
        switch (name) {
          case 'uses-permission':
            final perm = child.element.attributes['android:name'] ??
                child.element.attributes['name'];
            if (perm != null && !permissions.contains(perm)) {
              permissions.add(perm);
            }
            break;
          case 'uses-feature':
            final feat = child.element.attributes['android:name'] ??
                child.element.attributes['name'];
            if (feat != null) features.add(feat);
            break;
          case 'uses-sdk':
            minSdk = child.element.attributes['android:minSdkVersion'] ??
                child.element.attributes['minSdkVersion'];
            targetSdk = child.element.attributes['android:targetSdkVersion'] ??
                child.element.attributes['targetSdkVersion'];
            break;
          case 'application':
            final aAttrs = child.element.attributes;
            applicationClass = aAttrs['android:name'] ?? aAttrs['name'];
            debuggable =
                (aAttrs['android:debuggable'] ?? '').toLowerCase() == 'true';
            allowBackup = (aAttrs['android:allowBackup'] ?? 'true')
                .toLowerCase() == 'true';
            supportsRtl =
                (aAttrs['android:supportsRtl'] ?? '').toLowerCase() == 'true';
            isPersistent =
                (aAttrs['android:persistent'] ?? '').toLowerCase() == 'true';

            // 解析 application 下的 meta-data
            for (final appChild in child.children) {
              if (appChild.element.name == 'meta-data') {
                final mdName = appChild.element.attributes['android:name'] ??
                    appChild.element.attributes['name'];
                final mdValue = appChild.element.attributes['android:value'] ??
                    appChild.element.attributes['value'];
                if (mdName != null && mdValue != null) {
                  metaData[mdName] = mdValue;
                }
              }
            }

            // 解析四大组件
            for (final compNode in child.children) {
              final compName = compNode.element.name;
              if (['activity', 'service', 'receiver', 'provider']
                  .contains(compName)) {
                final comp = _parseComponent(compNode);
                components.add(comp);
                if (compName == 'activity' && comp.isLauncher) {
                  mainActivity ??= comp.name;
                }
                // 提取深度链接
                deepLinks.addAll(_extractDeepLinks(compNode));
              }
            }
            break;
        }
      }
    }

    // 重建 XML 文本
    final xmlContent = _buildXml(manifestNode);

    return ManifestInfo(
      packageName: packageName ?? '',
      versionName: versionName ?? '',
      versionCode: versionCode ?? 1,
      mainActivity: mainActivity ?? '',
      applicationClass: applicationClass,
      minSdkVersion: minSdk,
      targetSdkVersion: targetSdk,
      compileSdkVersion: compileSdk,
      debuggable: debuggable,
      allowBackup: allowBackup,
      supportsRtl: supportsRtl,
      isPersistent: isPersistent,
      installLocation: installLocation,
      permissions: permissions,
      features: features,
      components: components,
      deepLinks: deepLinks,
      metaData: metaData,
      xmlContent: xmlContent,
      parseMethod: 'structured',
    );
  }

  /// 解析单个组件节点
  static ComponentInfo _parseComponent(_TreeNode node) {
    final attrs = node.element.attributes;
    final name = attrs['android:name'] ?? attrs['name'] ?? '';
    final exported =
        (attrs['android:exported'] ?? '').toLowerCase() == 'true';
    final enabled =
        (attrs['android:enabled'] ?? 'true').toLowerCase() != 'false';
    final permission = attrs['android:permission'];
    final process = attrs['android:process'];

    final intentFilters = <IntentFilterInfo>[];
    bool isLauncher = false;

    for (final child in node.children) {
      if (child.element.name == 'intent-filter') {
        final actions = <String>[];
        final categories = <String>[];
        final dataSchemes = <String>[];
        final dataHosts = <String>[];
        final dataPaths = <String>[];

        for (final ifChild in child.children) {
          final ifName = ifChild.element.name;
          final ifVal = ifChild.element.attributes['android:name'] ??
              ifChild.element.attributes['name'] ??
              '';
          switch (ifName) {
            case 'action':
              actions.add(ifVal);
              if (ifVal == 'android.intent.action.MAIN') isLauncher = true;
              break;
            case 'category':
              categories.add(ifVal);
              if (ifVal == 'android.intent.category.LAUNCHER') {
                isLauncher = true;
              }
              break;
            case 'data':
              final scheme = ifChild.element.attributes['android:scheme'];
              final host = ifChild.element.attributes['android:host'];
              final path = ifChild.element.attributes['android:path'] ??
                  ifChild.element.attributes['android:pathPrefix'] ??
                  ifChild.element.attributes['android:pathPattern'];
              if (scheme != null && !dataSchemes.contains(scheme)) {
                dataSchemes.add(scheme);
              }
              if (host != null && !dataHosts.contains(host)) {
                dataHosts.add(host);
              }
              if (path != null && !dataPaths.contains(path)) {
                dataPaths.add(path);
              }
              break;
          }
        }

        intentFilters.add(IntentFilterInfo(
          actions: actions,
          categories: categories,
          dataSchemes: dataSchemes,
          dataHosts: dataHosts,
          dataPaths: dataPaths,
        ));
      }
    }

    return ComponentInfo(
      name: name,
      type: node.element.name,
      exported: exported,
      enabled: enabled,
      permission: permission,
      process: process,
      isLauncher: isLauncher,
      intentFilters: intentFilters,
    );
  }

  /// 从组件的 intent-filter 提取深度链接
  static List<DeepLink> _extractDeepLinks(_TreeNode compNode) {
    final links = <DeepLink>[];
    for (final child in compNode.children) {
      if (child.element.name != 'intent-filter') continue;
      final schemes = <String>{};
      final hosts = <String>{};
      final paths = <String>{};
      for (final ifChild in child.children) {
        if (ifChild.element.name == 'data') {
          final s = ifChild.element.attributes['android:scheme'];
          final h = ifChild.element.attributes['android:host'];
          final p = ifChild.element.attributes['android:path'] ??
              ifChild.element.attributes['android:pathPrefix'] ??
              ifChild.element.attributes['android:pathPattern'];
          if (s != null) schemes.add(s);
          if (h != null) hosts.add(h);
          if (p != null) paths.add(p);
        }
      }
      // 组合 scheme + host + path
      if (schemes.isNotEmpty) {
        for (final scheme in schemes) {
          if (hosts.isNotEmpty) {
            for (final host in hosts) {
              final pathStr = paths.isNotEmpty ? paths.first : '';
              links.add(DeepLink(
                scheme: scheme,
                host: host,
                path: pathStr,
                uri: '$scheme://$host${pathStr.isNotEmpty ? pathStr : ''}',
              ));
            }
          } else {
            links.add(DeepLink(
              scheme: scheme,
              host: '',
              path: '',
              uri: '$scheme://',
            ));
          }
        }
      }
    }
    return links;
  }

  /// 重建可读的 XML 文本
  static String _buildXml(_TreeNode? node, [int indent = 0]) {
    if (node == null) return '<!-- Manifest 解析失败 -->';
    final buf = StringBuffer();

    void writeNode(_TreeNode n, int level) {
      final p = '  ' * level;
      final elem = n.element;
      final nsDecls = <String>[];
      // 如果是 manifest 根节点，添加 xmlns:android 声明
      if (level == 0 && elem.name == 'manifest') {
        nsDecls.add('xmlns:android="http://schemas.android.com/apk/res/android"');
      }
      final allAttrs = <String>[];
      // 先写命名空间声明
      allAttrs.addAll(nsDecls);
      // 再写普通属性
      for (final entry in elem.attributes.entries) {
        // 跳过空命名空间前缀的属性中的特殊字符
        final val = entry.value
            .replaceAll('&', '&amp;')
            .replaceAll('"', '&quot;')
            .replaceAll('<', '&lt;')
            .replaceAll('>', '&gt;');
        allAttrs.add('${entry.key}="$val"');
      }
      if (n.children.isEmpty) {
        buf.writeln('$p<${elem.name}${allAttrs.isNotEmpty ? ' ' + allAttrs.join(' ') : ''} />');
      } else {
        buf.writeln('$p<${elem.name}${allAttrs.isNotEmpty ? ' ' + allAttrs.join(' ') : ''}>');
        for (final child in n.children) {
          writeNode(child, level + 1);
        }
        buf.writeln('$p</${elem.name}>');
      }
    }

    writeNode(node, 0);
    return buf.toString();
  }

  // ============ 字符串池解析 ============

  static void _parseStringPool(Uint8List data, int pos, int headerSize, List<String> strings) {
    if (pos + 28 > data.length) return;
    // 使用实际的 headerSize（标准为 28，但某些 APK 可能不同）
    final actualHeaderSize = headerSize > 0 && headerSize < 1024 ? headerSize : 28;
    final strCount = HexUtils.readUint32LE(data, pos + 8);
    final flags = HexUtils.readUint32LE(data, pos + 16);
    final stringsStart = HexUtils.readUint32LE(data, pos + 20);
    final isUtf8 = (flags & 0x100) != 0;

    // 验证 stringsStart 的合理性
    final expectedMin = actualHeaderSize + strCount * 4;
    final actualStringsStart = stringsStart >= expectedMin ? stringsStart : expectedMin;

    final offsetsStart = pos + actualHeaderSize;
    for (int i = 0; i < strCount && i < 100000; i++) {
      if (offsetsStart + i * 4 + 4 > data.length) {
        // 必须添加空字符串以保持索引对齐
        strings.add('');
        continue;
      }
      final strOff = HexUtils.readUint32LE(data, offsetsStart + i * 4);
      final absOff = pos + actualStringsStart + strOff;
      if (absOff >= data.length) {
        strings.add('');
        continue;
      }

      if (isUtf8) {
        // UTF-8 字符串池条目格式:
        //   u16Len (1或2字节): 若高位为1则2字节: (b0 & 0x7F) << 8 | b1
        //   u8Len  (1或2字节): 同上编码
        //   u8[u8Len]: UTF-8 字节数据
        //   0x00: null 终止符
        try {
          int cur = absOff;
          // 解码 u16Len（跳过）
          final (u16Len, u16Bytes) = _decodeStrPoolLen(data, cur);
          cur += u16Bytes;
          // 解码 u8Len（实际字节数）
          final (u8Len, u8Bytes) = _decodeStrPoolLen(data, cur);
          cur += u8Bytes;

          if (u8Len > 0 && cur + u8Len <= data.length) {
            final s = utf8.decode(data.sublist(cur, cur + u8Len),
                allowMalformed: true);
            strings.add(s);
          } else {
            // 空字符串 — 必须添加以保持索引对齐！
            strings.add('');
          }
        } catch (_) {
          strings.add('');
        }
      } else {
        // UTF-16 字符串池条目
        int len = HexUtils.readUint16LE(data, absOff);
        int dataOff = absOff + 2;
        if ((len & 0x8000) != 0) {
          // 扩展长度: ((len & 0x7FFF) << 16) | next_u16
          if (absOff + 4 <= data.length) {
            final next = HexUtils.readUint16LE(data, absOff + 2);
            len = ((len & 0x7FFF) << 16) | next;
            dataOff = absOff + 4;
          }
        }
        if (len > 0 && dataOff + len * 2 <= data.length) {
          try {
            final codeUnits = <int>[];
            for (int j = 0; j < len; j++) {
              codeUnits.add(
                  data[dataOff + j * 2] | (data[dataOff + j * 2 + 1] << 8));
            }
            strings.add(String.fromCharCodes(codeUnits));
          } catch (_) {
            strings.add('');
          }
        } else {
          // 空字符串 — 必须添加以保持索引对齐！
          strings.add('');
        }
      }
    }
  }

  /// 解码 Android 字符串池长度编码（1或2字节）
  /// 格式: 若首字节高位为0，长度=首字节(0-127)
  ///       若首字节高位为1，长度=((b0 & 0x7F) << 8) | b1 (128-32767)
  static (int, int) _decodeStrPoolLen(List<int> data, int offset) {
    if (offset >= data.length) return (0, 0);
    final b0 = data[offset];
    if ((b0 & 0x80) != 0) {
      if (offset + 1 >= data.length) return (0, 1);
      final len = ((b0 & 0x7F) << 8) | data[offset + 1];
      return (len, 2);
    }
    return (b0, 1);
  }

  // ============ 元素解析 ============

  static XmlElement? _parseStartElement(
      Uint8List data, int pos, List<String> strings, Map<String, String> nsMap) {
    if (pos + 20 > data.length) return null;
    final headerSize = HexUtils.readUint16LE(data, pos + 2);
    if (headerSize == 0 || pos + headerSize + 16 > data.length) return null;

    // ResXMLTree_attrExt body layout (offsets from pos + headerSize):
    //   +0: nsIdx (uint32) — 元素命名空间
    //   +4: nameIdx (uint32) — 元素名称
    //   +8: attributeStart (uint16)
    //  +10: attributeSize (uint16)
    //  +12: attributeCount (uint16)
    final elemNameIdx = HexUtils.readUint32LE(data, pos + headerSize + 4);
    final attrStartField = HexUtils.readUint16LE(data, pos + headerSize + 8);
    final attrSize = HexUtils.readUint16LE(data, pos + headerSize + 10);
    final attrCount = HexUtils.readUint16LE(data, pos + headerSize + 12);
    final actualAttrSize = attrSize > 0 ? attrSize : 20;

    if (elemNameIdx >= strings.length) return null;
    final elemName = strings[elemNameIdx];
    final attrs = <String, String>{};

    final attrStart = pos + headerSize + attrStartField;
    for (int a = 0; a < attrCount && a < 60; a++) {
      final attrOff = attrStart + a * actualAttrSize;
      if (attrOff + 20 > data.length) break;

      final nsIdx = HexUtils.readUint32LE(data, attrOff);
      final nameIdx = HexUtils.readUint32LE(data, attrOff + 4);
      // 属性布局(每20字节): ns@0, name@4, rawValue@8, valueSize@12, res0@14, dataType@15, data@16
      final rawValueIdx = HexUtils.readUint32LE(data, attrOff + 8);
      final dataType = data[attrOff + 15];
      final attrData = HexUtils.readUint32LE(data, attrOff + 16);

      if (nameIdx >= strings.length) continue;
      final attrName = strings[nameIdx];

      String? attrValue;

      // 优先使用 rawValue 字符串索引（适用于 TYPE_STRING 和有原始字符串的属性）
      if (rawValueIdx != 0xFFFFFFFF && rawValueIdx < strings.length) {
        attrValue = strings[rawValueIdx];
      }

      // 如果 rawValue 无效，尝试根据 dataType 解析
      if (attrValue == null) {
        if (dataType == 0x03) {
          // TYPE_STRING: data 字段也包含字符串索引
          if (attrData != 0xFFFFFFFF && attrData < strings.length) {
            attrValue = strings[attrData];
          }
        } else {
          attrValue = _resolveTypedValue(dataType & 0xFF, attrData);
        }
      }

      if (attrValue != null) {
        // 解析命名空间前缀
        final nsStr = nsIdx != 0xFFFFFFFF && nsIdx < strings.length
            ? strings[nsIdx]
            : null;
        final prefix = (nsStr != null && nsMap.containsKey(nsStr))
            ? nsMap[nsStr]!
            : null;
        final key = (prefix != null && prefix.isNotEmpty)
            ? '$prefix:$attrName'
            : attrName;
        // 避免覆盖已存在的同名属性
        if (!attrs.containsKey(key)) {
          attrs[key] = attrValue;
        }
      }
    }

    return XmlElement(name: elemName, attributes: attrs);
  }

  static String? _resolveTypedValue(int type, int data) {
    switch (type) {
      case 0x10: // TYPE_INT_DEC
      case 0x11: // TYPE_INT_HEX
        return data.toString();
      case 0x12: // TYPE_INT_BOOLEAN
        return data != 0 ? 'true' : 'false';
      case 0x01: // TYPE_REFERENCE
        return '@${data.toRadixString(16)}';
      case 0x02: // TYPE_ATTRIBUTE
        return '?${data.toRadixString(16)}';
      case 0x04: // TYPE_FLOAT
        // 将 int 位模式转回 float
        final bytes = ByteData(4)..setInt32(0, data, Endian.little);
        final floatVal = bytes.getFloat32(0, Endian.little);
        return floatVal.toStringAsFixed(2);
      default:
        return null;
    }
  }
}

// ============ 内部树节点 ============

class _TreeNode {
  final XmlElement element;
  final List<_TreeNode> children = [];

  _TreeNode({required this.element});
}

// ============ 数据模型 ============

class ManifestInfo {
  final String packageName;
  final String versionName;
  final int versionCode;
  final String mainActivity;
  final String? applicationClass;
  final String? minSdkVersion;
  final String? targetSdkVersion;
  final String? compileSdkVersion;
  final bool debuggable;
  final bool allowBackup;
  final bool supportsRtl;
  final bool isPersistent;
  final String? installLocation;
  final List<String> permissions;
  final List<String> features;
  final List<ComponentInfo> components;
  final List<DeepLink> deepLinks;
  final Map<String, String> metaData;
  final String xmlContent;
  final String? parseMethod;

  const ManifestInfo({
    required this.packageName,
    required this.versionName,
    required this.versionCode,
    required this.mainActivity,
    this.applicationClass,
    this.minSdkVersion,
    this.targetSdkVersion,
    this.compileSdkVersion,
    this.debuggable = false,
    this.allowBackup = false,
    this.supportsRtl = false,
    this.isPersistent = false,
    this.installLocation,
    this.permissions = const [],
    this.features = const [],
    this.components = const [],
    this.deepLinks = const [],
    this.metaData = const {},
    this.xmlContent = '',
    this.parseMethod,
  });

  factory ManifestInfo.empty() => const ManifestInfo(
        packageName: '',
        versionName: '',
        versionCode: 1,
        mainActivity: '',
      );

  /// 获取所有导出组件
  List<ComponentInfo> get exportedComponents =>
      components.where((c) => c.exported).toList();

  /// 获取所有 Activity
  List<ComponentInfo> get activityList =>
      components.where((c) => c.type == 'activity').toList();

  /// 获取所有 Service
  List<ComponentInfo> get serviceList =>
      components.where((c) => c.type == 'service').toList();

  /// 获取所有 Receiver
  List<ComponentInfo> get receiverList =>
      components.where((c) => c.type == 'receiver').toList();

  /// 获取所有 Provider
  List<ComponentInfo> get providerList =>
      components.where((c) => c.type == 'provider').toList();
}

/// 组件信息
class ComponentInfo {
  final String name;
  final String type; // activity | service | receiver | provider
  final bool exported;
  final bool enabled;
  final String? permission;
  final String? process;
  final bool isLauncher;
  final List<IntentFilterInfo> intentFilters;

  const ComponentInfo({
    required this.name,
    required this.type,
    required this.exported,
    required this.enabled,
    this.permission,
    this.process,
    this.isLauncher = false,
    this.intentFilters = const [],
  });

  String get shortName {
    final parts = name.split('.');
    return parts.length > 2 ? parts.last : name;
  }
}

/// Intent Filter 信息
class IntentFilterInfo {
  final List<String> actions;
  final List<String> categories;
  final List<String> dataSchemes;
  final List<String> dataHosts;
  final List<String> dataPaths;

  const IntentFilterInfo({
    this.actions = const [],
    this.categories = const [],
    this.dataSchemes = const [],
    this.dataHosts = const [],
    this.dataPaths = const [],
  });
}

/// 深度链接
class DeepLink {
  final String scheme;
  final String host;
  final String path;
  final String uri;

  const DeepLink({
    required this.scheme,
    required this.host,
    required this.path,
    required this.uri,
  });
}

class XmlElement {
  final String name;
  final Map<String, String> attributes;

  const XmlElement({required this.name, required this.attributes});
}
