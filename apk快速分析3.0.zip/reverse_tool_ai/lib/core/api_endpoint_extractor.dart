/// 网络 API 端点提取器 - 从 DEX 字符串中提取 REST API 路径（纯 Dart 实现）
///
/// 使用正则表达式匹配常见的 API 路径模式：
/// - 版本化路径：/api/v1/xxx, /v2/xxx, /rest/xxx
/// - GraphQL 端点：/graphql
/// - Retrofit 注解：@GET, @POST, @PUT, @DELETE
/// - 带后缀的路径：.json, .php, .do, .action
/// 并根据路径关键词推测 HTTP 方法。

// ========== 结果模型 ==========

/// 单个 API 端点
class ApiEndpoint {
  /// API 路径，如 /api/v1/users
  final String path;

  /// 推测的 HTTP 方法（GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS）
  final String httpMethod;

  /// 来源字符串（提取该端点的原始 DEX 字符串）
  final String sourceString;

  /// 匹配模式名称（描述命中了哪种规则）
  final String matchPattern;

  const ApiEndpoint({
    required this.path,
    required this.httpMethod,
    required this.sourceString,
    required this.matchPattern,
  });
}

/// API 端点提取结果
class ApiEndpointResult {
  /// 总端点数
  final int totalEndpoints;

  /// 所有提取到的 API 端点
  final List<ApiEndpoint> endpoints;

  /// 按路径分组统计（路径 -> 出现次数）
  final Map<String, int> pathStats;

  const ApiEndpointResult({
    required this.totalEndpoints,
    required this.endpoints,
    required this.pathStats,
  });

  /// 空结果
  static const ApiEndpointResult empty = ApiEndpointResult(
    totalEndpoints: 0,
    endpoints: [],
    pathStats: {},
  );
}

// ========== 提取器 ==========

class ApiEndpointExtractor {
  ApiEndpointExtractor._(); // 仅提供静态方法，禁止实例化

  // ---------- 正则规则 ----------

  /// Retrofit 注解：@GET("path"), @POST("path") 等
  static final RegExp _retrofitRegex = RegExp(
    r'@(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS)\s*\(\s*"([^"]+)"\s*\)',
    caseSensitive: false,
  );

  /// 版本化 API 路径：/api/v1/xxx, /rest/v2/xxx, /api/1/xxx
  static final RegExp _versionedApiRegex = RegExp(
    r'/(?:api|rest)/v?\d+(?:/[a-zA-Z0-9_./-]+)*',
  );

  /// 直接版本路径：/v1/xxx, /v2/xxx
  static final RegExp _directVersionRegex = RegExp(
    r'/v\d+/[a-zA-Z0-9_./-]+',
  );

  /// REST 基础路径：/api/xxx, /rest/xxx（不含版本号）
  static final RegExp _restBaseRegex = RegExp(
    r'/(?:api|rest)/[a-zA-Z0-9_./-]+',
  );

  /// GraphQL 端点
  static final RegExp _graphqlRegex = RegExp(
    r'/graphql\b',
    caseSensitive: false,
  );

  /// 带后缀的路径：/xxx.json, /xxx.php, /xxx.do, /xxx.action
  static final RegExp _suffixRegex = RegExp(
    r'/[a-zA-Z0-9_/-]+\.(?:json|php|do|action)\b',
    caseSensitive: false,
  );

  /// 从 DEX 字符串集合中提取 REST API 端点
  ///
  /// [dexStrings] 所有 DEX 文件中提取的字符串集合
  ///
  /// 返回 [ApiEndpointResult]，包含所有匹配的 API 端点及按路径分组统计。
  static ApiEndpointResult extract(Set<String> dexStrings) {
    try {
      return _extractImpl(dexStrings);
    } catch (e) {
      // 任何未预期的异常都不向上抛出，返回空结果
      return ApiEndpointResult.empty;
    }
  }

  static ApiEndpointResult _extractImpl(Set<String> dexStrings) {
    final endpoints = <ApiEndpoint>[];
    // 去重键：(路径, 来源字符串, 匹配模式)
    final seen = <String>{};
    // 按路径统计出现次数
    final pathStats = <String, int>{};

    for (final source in dexStrings) {
      try {
        // 短字符串或纯数字跳过，减少无意义匹配
        if (source.length < 3) continue;

        // 1. 优先匹配 Retrofit 注解（可提取明确的 HTTP 方法）
        for (final match in _retrofitRegex.allMatches(source)) {
          final method = match.group(1)!.toUpperCase();
          final path = match.group(2)!;
          final key = '$path#$source#Retrofit注解';
          if (seen.add(key)) {
            endpoints.add(ApiEndpoint(
              path: path,
              httpMethod: method,
              sourceString: source,
              matchPattern: 'Retrofit注解(@$method)',
            ));
            pathStats[path] = (pathStats[path] ?? 0) + 1;
          }
        }

        // 2. 版本化 API 路径
        _matchPattern(
          regex: _versionedApiRegex,
          source: source,
          patternName: '版本化API路径(/api/vN/)',
          endpoints: endpoints,
          seen: seen,
          pathStats: pathStats,
        );

        // 3. 直接版本路径
        _matchPattern(
          regex: _directVersionRegex,
          source: source,
          patternName: '版本路径(/vN/)',
          endpoints: endpoints,
          seen: seen,
          pathStats: pathStats,
        );

        // 4. REST 基础路径
        _matchPattern(
          regex: _restBaseRegex,
          source: source,
          patternName: 'REST基础路径(/api/)',
          endpoints: endpoints,
          seen: seen,
          pathStats: pathStats,
        );

        // 5. GraphQL 端点
        _matchPattern(
          regex: _graphqlRegex,
          source: source,
          patternName: 'GraphQL端点',
          endpoints: endpoints,
          seen: seen,
          pathStats: pathStats,
        );

        // 6. 带后缀的路径
        _matchPattern(
          regex: _suffixRegex,
          source: source,
          patternName: '路径后缀(.json/.php/.do/.action)',
          endpoints: endpoints,
          seen: seen,
          pathStats: pathStats,
        );
      } catch (_) {
        // 单个字符串处理失败跳过
      }
    }

    // 按路径排序，便于查看
    endpoints.sort((a, b) {
      final cmp = a.path.compareTo(b.path);
      if (cmp != 0) return cmp;
      return a.matchPattern.compareTo(b.matchPattern);
    });

    return ApiEndpointResult(
      totalEndpoints: endpoints.length,
      endpoints: endpoints,
      pathStats: pathStats,
    );
  }

  /// 通用模式匹配辅助：对单个源字符串执行正则匹配，提取所有命中路径
  static void _matchPattern({
    required RegExp regex,
    required String source,
    required String patternName,
    required List<ApiEndpoint> endpoints,
    required Set<String> seen,
    required Map<String, int> pathStats,
  }) {
    for (final match in regex.allMatches(source)) {
      final path = match.group(0)!;
      final key = '$path#$source#$patternName';
      if (seen.add(key)) {
        endpoints.add(ApiEndpoint(
          path: path,
          httpMethod: _inferHttpMethod(path),
          sourceString: source,
          matchPattern: patternName,
        ));
        pathStats[path] = (pathStats[path] ?? 0) + 1;
      }
    }
  }

  /// 根据路径关键词推测 HTTP 方法
  static String _inferHttpMethod(String path) {
    final lower = path.toLowerCase();
    // DELETE：删除/移除相关
    if (lower.contains('delete') ||
        lower.contains('remove') ||
        lower.contains('drop') ||
        lower.contains('destroy') ||
        lower.contains('cancel')) {
      return 'DELETE';
    }
    // POST：创建/提交/上传相关
    if (lower.contains('create') ||
        lower.contains('add') ||
        lower.contains('post') ||
        lower.contains('submit') ||
        lower.contains('register') ||
        lower.contains('login') ||
        lower.contains('signup') ||
        lower.contains('upload') ||
        lower.contains('save') ||
        lower.contains('insert') ||
        lower.contains('send')) {
      return 'POST';
    }
    // PUT：更新/编辑相关
    if (lower.contains('update') ||
        lower.contains('put') ||
        lower.contains('edit') ||
        lower.contains('modify') ||
        lower.contains('set') ||
        lower.contains('change') ||
        lower.contains('reset')) {
      return 'PUT';
    }
    // PATCH：部分更新
    if (lower.contains('patch') || lower.contains('toggle') || lower.contains('switch')) {
      return 'PATCH';
    }
    // 默认 GET
    return 'GET';
  }
}
