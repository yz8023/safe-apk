import 'dart:typed_data';
import 'dart:convert';
import '../utils/hex_utils.dart';

/// DEX 指令解码器 / smali 反汇编器（纯 Dart，无第三方依赖）
///
/// 解析 DEX 文件结构（string/type/proto/field/method/class_def/code_item），
/// 对方法体内的 Dalvik 字节码做线性反汇编，输出近似 smali 的汇编文本。
/// 注：只到「指令/汇编」级，不反编译成 Java/Kotlin 源码。
/// 未知 opcode 或暂未覆盖的格式会回退显示原始 16 进制，保证不崩溃。

// ========== 结果模型 ==========

class DisassembledMethod {
  final String name;
  final String descriptor;
  final int accessFlags;
  final int registers;
  final int insSize;
  final int outsSize;
  final int codeSize; // 指令区字节数
  final List<String> smali;

  const DisassembledMethod({
    required this.name,
    required this.descriptor,
    required this.accessFlags,
    required this.registers,
    required this.insSize,
    required this.outsSize,
    required this.codeSize,
    required this.smali,
  });
}

class DisassembledClass {
  final String name;
  final String? superClass;
  final List<String> interfaces;
  final int accessFlags;
  final List<DisassembledMethod> methods;

  const DisassembledClass({
    required this.name,
    this.superClass,
    this.interfaces = const [],
    this.accessFlags = 0,
    this.methods = const [],
  });
}

class DisassemblyResult {
  final List<DisassembledClass> classes;
  final int totalMethods;
  final int totalInstructions;

  const DisassemblyResult({
    required this.classes,
    required this.totalMethods,
    required this.totalInstructions,
  });
}

// ========== DEX 内部引用表 ==========

class _MethodRef {
  final int classIdx;
  final int protoIdx;
  final int nameIdx;
  _MethodRef(this.classIdx, this.protoIdx, this.nameIdx);
}

class _FieldRef {
  final int classIdx;
  final int typeIdx;
  final int nameIdx;
  _FieldRef(this.classIdx, this.typeIdx, this.nameIdx);
}

class _ProtoRef {
  final int shortyIdx;
  final int returnTypeIdx;
  final int paramsOff;
  _ProtoRef(this.shortyIdx, this.returnTypeIdx, this.paramsOff);
}

class _DexImage {
  final List<String> strings;
  final List<String> types;
  final List<_ProtoRef> protos;
  final List<_FieldRef> fields;
  final List<_MethodRef> methods;
  final Uint8List dex;

  _DexImage(this.dex, this.strings, this.types, this.protos,
      this.fields, this.methods);

  String typeDesc(int i) => (i >= 0 && i < types.length) ? types[i] : '?';
  String stringAt(int i) => (i >= 0 && i < strings.length) ? strings[i] : '?';

  String protoDesc(int i) {
    if (i < 0 || i >= protos.length) return '?';
    final p = protos[i];
    final ret = typeDesc(p.returnTypeIdx);
    if (p.paramsOff == 0) return '()$ret';
    final buf = StringBuffer();
    int pos = p.paramsOff;
    final (size, p1) = _readUleb(dex, pos);
    pos = p1;
    for (int k = 0; k < size; k++) {
      final tIdx = HexUtils.readUint16LE(dex, pos);
      pos += 2;
      buf.write(typeDesc(tIdx));
    }
    return '(${buf.toString()})$ret';
  }

  String methodDesc(int i) {
    if (i < 0 || i >= methods.length) return '?';
    final m = methods[i];
    return '${typeDesc(m.classIdx)}->${stringAt(m.nameIdx)}${protoDesc(m.protoIdx)}';
  }

  String fieldDesc(int i) {
    if (i < 0 || i >= fields.length) return '?';
    final f = fields[i];
    return '${typeDesc(f.classIdx)}->${stringAt(f.nameIdx)}:${typeDesc(f.typeIdx)}';
  }
}

// ========== 工具 ==========

(int, int) _readUleb(Uint8List b, int p) {
  int result = 0;
  int shift = 0;
  while (p < b.length) {
    final byte = b[p++];
    result |= (byte & 0x7F) << shift;
    if ((byte & 0x80) == 0) break;
    shift += 7;
  }
  return (result, p);
}

int _sign4(int v) => (v & 0x8) != 0 ? v - 16 : v;
int _sign8(int v) => (v & 0x80) != 0 ? v - 256 : v;
int _sign16(int v) => (v & 0x8000) != 0 ? v - 0x10000 : v;
int _sign32(int v) =>
    (v & 0x80000000) != 0 ? (v - 0x100000000) : v;

String _hex(int v) => '0x${v.toRadixString(16)}';
String _reg(int v) => 'v$v';

String _methodAccess(int f) {
  final parts = <String>[];
  if (f & 0x1 != 0) parts.add('public');
  if (f & 0x2 != 0) parts.add('private');
  if (f & 0x4 != 0) parts.add('protected');
  if (f & 0x8 != 0) parts.add('static');
  if (f & 0x10 != 0) parts.add('final');
  if (f & 0x100 != 0) parts.add('native');
  if (f & 0x200 != 0) parts.add('abstract');
  return parts.join(' ');
}

String _classAccess(int f) {
  final parts = <String>[];
  if (f & 0x1 != 0) parts.add('public');
  if (f & 0x2 != 0) parts.add('private');
  if (f & 0x4 != 0) parts.add('protected');
  if (f & 0x8 != 0) parts.add('static');
  if (f & 0x10 != 0) parts.add('final');
  if (f & 0x200 != 0) parts.add('interface');
  if (f & 0x400 != 0) parts.add('abstract');
  return parts.join(' ');
}

// ========== 反汇编器 ==========

class DexDisassembler {
  /// 解析 dex 字节并反汇编所有类的方法体
  static DisassemblyResult disassemble(Uint8List dex) {
    try {
      return _disassembleImpl(dex);
    } catch (e) {
      // 任何未预期的异常都不应导致应用闪退
      return const DisassemblyResult(classes: [], totalMethods: 0, totalInstructions: 0);
    }
  }

  static DisassemblyResult _disassembleImpl(Uint8List dex) {
    final img = _parseDex(dex);
    if (img == null) {
      return const DisassemblyResult(classes: [], totalMethods: 0, totalInstructions: 0);
    }

    final classes = <DisassembledClass>[];
    int totalMethods = 0;
    int totalInstructions = 0;

    final typeIdsSize = HexUtils.readUint32LE(dex, 64);
    final classDefsSize = HexUtils.readUint32LE(dex, 96);
    final classDefsOff = HexUtils.readUint32LE(dex, 100);

    // 限制处理的类数量，防止大 DEX 导致 OOM 闪退
    const maxClasses = 3000;
    const maxMethodsPerClass = 200;
    const maxInstructionsPerMethod = 5000;

    final classLimit = classDefsSize > maxClasses ? maxClasses : classDefsSize;

    for (int i = 0; i < classLimit; i++) {
      final off = classDefsOff + i * 32;
      if (off + 32 > dex.length) break;

      final classIdx = HexUtils.readUint32LE(dex, off);
      final accessFlags = HexUtils.readUint32LE(dex, off + 4);
      final superclassIdx = HexUtils.readUint32LE(dex, off + 8);
      final interfacesOff = HexUtils.readUint32LE(dex, off + 12);
      final classDataOff = HexUtils.readUint32LE(dex, off + 24);

      if (classIdx >= typeIdsSize) continue;
      final className = img.typeDesc(classIdx);
      if (!className.startsWith('L')) continue;

      String? superClass;
      if (superclassIdx != 0xFFFFFFFF && superclassIdx < typeIdsSize) {
        superClass = img.typeDesc(superclassIdx);
      }

      final interfaces = <String>[];
      if (interfacesOff != 0 && interfacesOff + 4 <= dex.length) {
        final typeListSize = HexUtils.readUint32LE(dex, interfacesOff);
        for (int ii = 0; ii < typeListSize && ii < 200; ii++) {
          final typeIdx =
              HexUtils.readUint16LE(dex, interfacesOff + 4 + ii * 2);
          if (typeIdx < typeIdsSize) interfaces.add(img.typeDesc(typeIdx));
        }
      }

      final methods = <DisassembledMethod>[];
      if (classDataOff != 0 && classDataOff < dex.length) {
        try {
          var pos = classDataOff;
          final sf = _readUleb(dex, pos); pos = sf.$2;
          final inf = _readUleb(dex, pos); pos = inf.$2;
          final dm = _readUleb(dex, pos); pos = dm.$2;
          final vm = _readUleb(dex, pos); pos = vm.$2;

          // 跳过字段
          for (int fi = 0; fi < sf.$1 + inf.$1; fi++) {
            if (pos >= dex.length) break;
            final a = _readUleb(dex, pos); pos = a.$2;
            final b = _readUleb(dex, pos); pos = b.$2;
          }

          int prev = 0;
          final dmLimit = dm.$1 > maxMethodsPerClass ? maxMethodsPerClass : dm.$1;
          for (int mi = 0; mi < dmLimit; mi++) {
            if (pos >= dex.length) break;
            final r = _parseEncodedMethod(dex, pos, prev);
            pos = r.$2;
            prev = r.$3;
            try {
              final dm2 = _disasmMethod(dex, img, r.$1, maxInstructionsPerMethod);
              if (dm2 != null) {
                methods.add(dm2);
                totalMethods++;
                totalInstructions += dm2.smali.length;
              }
            } catch (_) {
              // 单个方法反汇编失败不影响整体
            }
          }
          prev = 0;
          final vmLimit = vm.$1 > maxMethodsPerClass ? maxMethodsPerClass : vm.$1;
          for (int mi = 0; mi < vmLimit; mi++) {
            if (pos >= dex.length) break;
            final r = _parseEncodedMethod(dex, pos, prev);
            pos = r.$2;
            prev = r.$3;
            try {
              final dm2 = _disasmMethod(dex, img, r.$1, maxInstructionsPerMethod);
              if (dm2 != null) {
                methods.add(dm2);
                totalMethods++;
                totalInstructions += dm2.smali.length;
              }
            } catch (_) {
              // 单个方法反汇编失败不影响整体
            }
          }
        } catch (_) {
          // class_data 解析失败，跳过该类
        }
      }

      classes.add(DisassembledClass(
        name: className,
        superClass: superClass,
        interfaces: interfaces,
        accessFlags: accessFlags,
        methods: methods,
      ));
    }

    return DisassemblyResult(
      classes: classes,
      totalMethods: totalMethods,
      totalInstructions: totalInstructions,
    );
  }

  static _DexImage? _parseDex(Uint8List dex) {
    if (dex.length < 112) return null;
    if (dex[0] != 0x64 || dex[1] != 0x65 || dex[2] != 0x78 || dex[3] != 0x0A) {
      // 不是 'dex\n'
      return null;
    }

    final stringIdsSize = HexUtils.readUint32LE(dex, 56);
    final stringIdsOff = HexUtils.readUint32LE(dex, 60);
    final typeIdsSize = HexUtils.readUint32LE(dex, 64);
    final typeIdsOff = HexUtils.readUint32LE(dex, 68);
    final protoIdsSize = HexUtils.readUint32LE(dex, 72);
    final protoIdsOff = HexUtils.readUint32LE(dex, 76);
    final fieldIdsSize = HexUtils.readUint32LE(dex, 80);
    final fieldIdsOff = HexUtils.readUint32LE(dex, 84);
    final methodIdsSize = HexUtils.readUint32LE(dex, 88);
    final methodIdsOff = HexUtils.readUint32LE(dex, 92);

    final strings = <String>[];
    for (int i = 0; i < stringIdsSize && i < 200000; i++) {
      strings.add(_readDexString(dex, stringIdsOff, i));
    }

    final types = <String>[];
    for (int i = 0; i < typeIdsSize && i < 200000; i++) {
      final strIdx = HexUtils.readUint32LE(dex, typeIdsOff + i * 4);
      types.add(strIdx < strings.length ? strings[strIdx] : '?');
    }

    final protos = <_ProtoRef>[];
    for (int i = 0; i < protoIdsSize && i < 200000; i++) {
      final po = protoIdsOff + i * 12;
      if (po + 12 > dex.length) break;
      protos.add(_ProtoRef(
        HexUtils.readUint32LE(dex, po),
        HexUtils.readUint32LE(dex, po + 4),
        HexUtils.readUint32LE(dex, po + 8),
      ));
    }

    final fields = <_FieldRef>[];
    for (int i = 0; i < fieldIdsSize && i < 500000; i++) {
      final fo = fieldIdsOff + i * 8;
      if (fo + 8 > dex.length) break;
      fields.add(_FieldRef(
        HexUtils.readUint16LE(dex, fo),
        HexUtils.readUint16LE(dex, fo + 2),
        HexUtils.readUint32LE(dex, fo + 4),
      ));
    }

    final methods = <_MethodRef>[];
    for (int i = 0; i < methodIdsSize && i < 500000; i++) {
      final mo = methodIdsOff + i * 8;
      if (mo + 8 > dex.length) break;
      methods.add(_MethodRef(
        HexUtils.readUint16LE(dex, mo),
        HexUtils.readUint16LE(dex, mo + 2),
        HexUtils.readUint32LE(dex, mo + 4),
      ));
    }

    return _DexImage(dex, strings, types, protos, fields, methods);
  }

  static String _readDexString(Uint8List dex, int stringIdsOff, int idx) {
    if (stringIdsOff + idx * 4 + 4 > dex.length) return '';
    final dataOff = HexUtils.readUint32LE(dex, stringIdsOff + idx * 4);
    if (dataOff >= dex.length) return '';
    var pos = dataOff;
    while (pos < dex.length && (dex[pos] & 0x80) != 0) pos++;
    pos++;
    if (pos >= dex.length) return '';
    final start = pos;
    while (pos < dex.length && dex[pos] != 0) pos++;
    if (pos == start) return '';
    try {
      return utf8.decode(dex.sublist(start, pos), allowMalformed: true);
    } catch (_) {
      return '';
    }
  }

  /// 解析 encoded_method：返回 (MethodRef, 新pos, 新prevMethodIdx)
  static (MethodRef, int, int) _parseEncodedMethod(
      Uint8List dex, int pos, int prev) {
    final diff = _readUleb(dex, pos);
    final access = _readUleb(dex, diff.$2);
    final codeOff = _readUleb(dex, access.$2);
    final methodIdx = prev + diff.$1;
    final ref = MethodRef(methodIdx, access.$1, codeOff.$1);
    return (ref, codeOff.$2, methodIdx);
  }

  static DisassembledMethod? _disasmMethod(
      Uint8List dex, _DexImage img, MethodRef ref, int maxInstructions) {
    if (ref.codeOff == 0) return null;
    final co = ref.codeOff;
    if (co + 16 > dex.length) return null;

    final registers = HexUtils.readUint16LE(dex, co);
    final insSize = HexUtils.readUint16LE(dex, co + 2);
    final outsSize = HexUtils.readUint16LE(dex, co + 4);
    final insnsSize = HexUtils.readUint32LE(dex, co + 12);
    final codeStart = co + 16;
    // 限制指令区大小，防止异常值导致越界
    final safeInsnsSize = insnsSize > 250000 ? 250000 : insnsSize;
    final codeEnd = codeStart + safeInsnsSize * 2;
    if (codeEnd > dex.length) return null;

    final lines = <String>[];
    lines.add('.registers $registers');
    if (insSize > 0) lines.add('.param $insSize  # ins');
    if (outsSize > 0) lines.add('.outs $outsSize');

    // Pass A：线性扫描得到指令起点与跳转目标
    final starts = <int>[];
    final targets = <int>{};
    int p = codeStart;
    int instructionCount = 0;
    while (p < codeEnd && instructionCount < maxInstructions) {
      starts.add(p);
      final (_, len, tgts) = _decode(dex, img, p, null);
      for (final t in tgts) targets.add(t);
      p += len;
      instructionCount++;
      if (len <= 0) break; // 防御
    }

    String labelAt(int off) {
      if (targets.contains(off)) return 'L0x${off.toRadixString(16)}';
      return _hex(off);
    }

    for (final s in starts) {
      final (text, _, _) = _decode(dex, img, s, labelAt);
      final prefix = targets.contains(s) ? ':L0x${s.toRadixString(16)}  ' : '    ';
      lines.add('$prefix$text');
    }

    return DisassembledMethod(
      name: _methodName(img, ref.idx),
      descriptor: _methodProto(img, ref.idx),
      accessFlags: ref.access,
      registers: registers,
      insSize: insSize,
      outsSize: outsSize,
      codeSize: insnsSize * 2,
      smali: lines,
    );
  }

  static String _methodName(_DexImage img, int idx) {
    if (idx < 0 || idx >= img.methods.length) return '';
    return img.stringAt(img.methods[idx].nameIdx);
  }

  static String _methodProto(_DexImage img, int idx) {
    if (idx < 0 || idx >= img.methods.length) return '';
    return img.protoDesc(img.methods[idx].protoIdx);
  }

  /// 解码单条指令：返回 (文本, 长度字节, 跳转目标绝对偏移列表)
  static (String, int, List<int>) _decode(Uint8List dex, _DexImage img, int pos,
      String? Function(int)? labelAt) {
    if (pos + 1 >= dex.length) {
      return ('nop', 2, const []);
    }
    final u0 = HexUtils.readUint16LE(dex, pos);
    final u1 = pos + 3 < dex.length ? HexUtils.readUint16LE(dex, pos + 2) : 0;
    final u2 = pos + 5 < dex.length ? HexUtils.readUint16LE(dex, pos + 4) : 0;

    // 数据载荷（packed/sparse-switch / fill-array-data）
    if (u0 == 0x0100) {
      final size = HexUtils.readUint16LE(dex, pos + 2);
      final len = 8 + size * 4;
      return ('packed-switch-data ($size entries)', len, const []);
    }
    if (u0 == 0x0200) {
      final size = HexUtils.readUint16LE(dex, pos + 2);
      final len = 4 + size * 8;
      return ('sparse-switch-data ($size entries)', len, const []);
    }
    if (u0 == 0x0300) {
      final width = HexUtils.readUint16LE(dex, pos + 2);
      final size = HexUtils.readUint32LE(dex, pos + 4);
      final len = 8 + size * width;
      final padded = len + (len & 1);
      return ('fill-array-data (w=$width, n=$size)', padded, const []);
    }

    final op = u0 & 0xFF;
    final name = _opName(op);
    final fmt = _opFormat(op);

    switch (fmt) {
      case '10x':
        return (name, 2, const []);
      case '10t': // goto
        final off = _sign8((u0 >> 8) & 0xFF);
        final tgt = pos + 2 + off * 2;
        final lbl = labelAt != null ? labelAt(tgt) : _hex(tgt);
        return ('goto $lbl', 2, [tgt]);
      case '20t': // goto/16
        final off = _sign16(u1);
        final tgt = pos + 4 + off * 2;
        final lbl = labelAt != null ? labelAt(tgt) : _hex(tgt);
        return ('goto/16 $lbl', 4, [tgt]);
      case '30t': // goto/32
        final off = _sign32(u1 | (u2 << 16));
        final tgt = pos + 6 + off * 2;
        final lbl = labelAt != null ? labelAt(tgt) : _hex(tgt);
        return ('goto/32 $lbl', 6, [tgt]);
      case '11x':
        final a = (u0 >> 8) & 0xFF;
        return ('$name ${_reg(a)}', 2, const []);
      case '11n':
        final a = (u0 >> 8) & 0xF;
        final b = _sign4((u0 >> 12) & 0xF);
        return ('$name ${_reg(a)}, #+$b', 2, const []);
      case '12x':
        final a = (u0 >> 8) & 0xF;
        final b = (u0 >> 12) & 0xF;
        return ('$name ${_reg(a)}, ${_reg(b)}', 2, const []);
      case '22x':
        final a = (u0 >> 8) & 0xFF;
        final b = u1;
        return ('$name ${_reg(a)}, ${_reg(b)}', 4, const []);
      case '32x':
        final a = u1;
        final b = u2;
        return ('$name ${_reg(a)}, ${_reg(b)}', 6, const []);
      case '21s':
        final a = (u0 >> 8) & 0xFF;
        final b = _sign16(u1);
        return ('$name ${_reg(a)}, #+$b', 4, const []);
      case '21h':
        final a = (u0 >> 8) & 0xFF;
        final b = u1 << 16;
        return ('$name ${_reg(a)}, #+${_hex(b)}', 4, const []);
      case '21c':
        final a = (u0 >> 8) & 0xFF;
        final b = u1;
        return (_op21c(name, op, img, a, b), 4, const []);
      case '31c':
        final a = (u0 >> 8) & 0xFF;
        final b = u1 | (u2 << 16);
        return ('$name ${_reg(a)}, "${img.stringAt(b)}"', 6, const []);
      case '22c':
        final a = (u0 >> 8) & 0xF;
        final b = (u0 >> 12) & 0xF;
        final c = u1;
        return (_op22c(name, op, img, a, b, c), 4, const []);
      case '22b':
        final a = (u0 >> 8) & 0xFF;
        final b = u1 & 0xFF;
        final c = _sign8((u1 >> 8) & 0xFF);
        return ('$name ${_reg(a)}, ${_reg(b)}, #+$c', 4, const []);
      case '22s':
        // B|A|op CCCC — 2 units = 4 bytes
        // A = (u0 >> 8) & 0xF: register A
        // B = (u0 >> 12) & 0xF: register B
        // CCCC = u1: signed 16-bit literal
        final sa = (u0 >> 8) & 0xF;
        final sb = (u0 >> 12) & 0xF;
        final sc = _sign16(u1);
        return ('$name ${_reg(sa)}, ${_reg(sb)}, #+$sc', 4, const []);
      case '22t':
        final a = (u0 >> 8) & 0xF;
        final b = (u0 >> 12) & 0xF;
        final off = _sign16(u1);
        final tgt = pos + 4 + off * 2;
        final lbl = labelAt != null ? labelAt(tgt) : _hex(tgt);
        return ('$name ${_reg(a)}, ${_reg(b)}, $lbl', 4, [tgt]);
      case '23x':
        final a = (u0 >> 8) & 0xFF;
        final b = u1 & 0xFF;
        final c = (u1 >> 8) & 0xFF;
        return ('$name ${_reg(a)}, ${_reg(b)}, ${_reg(c)}', 4, const []);
      case '31i':
        final a = (u0 >> 8) & 0xFF;
        final b = _sign32(u1 | (u2 << 16));
        return ('$name ${_reg(a)}, #+$b', 6, const []);
      case '31t':
        final a = (u0 >> 8) & 0xFF;
        final off = _sign32(u1 | (u2 << 16));
        final tgt = pos + off * 2;
        final lbl = labelAt != null ? labelAt(tgt) : _hex(tgt);
        return ('$name ${_reg(a)}, $lbl', 6, [tgt]);
      case '35c':
        final a = (u0 >> 8) & 0xF;
        final g = (u0 >> 12) & 0xF;
        final b = u1;
        final c = (u2 >> 12) & 0xF;
        final d = (u2 >> 8) & 0xF;
        final e = (u2 >> 4) & 0xF;
        final f = u2 & 0xF;
        final regs = [c, d, e, f, g].take(a).map(_reg).join(', ');
        return ('$name {$regs}, ${img.methodDesc(b)}', 6, const []);
      case '3rc':
        // A|op BBBB CCCC — 3 units = 6 bytes
        // A = (u0 >> 8) & 0xFF: register count
        // BBBB = u1: method/constant index
        // CCCC = u2: start register
        final rcA = (u0 >> 8) & 0xFF;
        final rcB = u1;
        final rcC = u2;
        final rcRegs = <String>[];
        for (int k = 0; k < rcA; k++) rcRegs.add(_reg(rcC + k));
        return ('$name {${rcRegs.join(', ')}}, ${img.methodDesc(rcB)}', 6, const []);
      case '51l':
        final a = (u0 >> 8) & 0xFF;
        final u3 = HexUtils.readUint16LE(dex, pos + 6);
        final u4 = HexUtils.readUint16LE(dex, pos + 8);
        final wide = u1 | (u2 << 16) | (u3 << 32) | (u4 << 48);
        return ('$name ${_reg(a)}, #+${_hex(wide)}', 10, const []);
      default:
        final raw = HexUtils.readUint16LE(dex, pos);
        return ('unknown op=0x${op.toRadixString(16)} (raw ${_hex(raw)})', 2, const []);
    }
  }

  static String _op21c(String name, int op, _DexImage img, int a, int b) {
    switch (op) {
      case 0x1a:
        return '$name ${_reg(a)}, "${img.stringAt(b)}"';
      case 0x1c:
      case 0x1f:
      case 0x22:
        return '$name ${_reg(a)}, ${img.typeDesc(b)}';
      default:
        return '$name ${_reg(a)}, #$b';
    }
  }

  static String _op22c(String name, int op, _DexImage img, int a, int b, int c) {
    switch (op) {
      case 0x20: // instance-of
      case 0x23: // new-array
      case 0x44:
      case 0x45:
      case 0x46:
      case 0x47:
      case 0x48:
      case 0x49:
      case 0x4a: // iget*
      case 0x4b:
      case 0x4c:
      case 0x4d:
      case 0x4e:
      case 0x4f:
      case 0x50:
      case 0x51: // iput*
        return '$name ${_reg(a)}, ${_reg(b)}, ${img.fieldDesc(c)}';
      default:
        return '$name ${_reg(a)}, ${_reg(b)}, #$c';
    }
  }

  // ========== opcode 表 ==========
  static String _opName(int op) => _opTable[op] ?? 'unknown';
  static String _opFormat(int op) => _fmtTable[op] ?? '??';

  static final Map<int, String> _opTable = _buildOpTable();
  static final Map<int, String> _fmtTable = _buildFmtTable();

  static Map<int, String> _buildOpTable() {
    final m = <int, String>{};
    m[0x00] = 'nop';
    m[0x01] = 'move';
    m[0x02] = 'move/from16';
    m[0x03] = 'move/16';
    m[0x04] = 'move-wide';
    m[0x05] = 'move-wide/from16';
    m[0x06] = 'move-wide/16';
    m[0x07] = 'move-object';
    m[0x08] = 'move-object/from16';
    m[0x09] = 'move-object/16';
    m[0x0a] = 'move-result';
    m[0x0b] = 'move-result-wide';
    m[0x0c] = 'move-result-object';
    m[0x0d] = 'move-exception';
    m[0x0e] = 'return-void';
    m[0x0f] = 'return';
    m[0x10] = 'return-wide';
    m[0x11] = 'return-object';
    m[0x12] = 'const/4';
    m[0x13] = 'const/16';
    m[0x14] = 'const';
    m[0x15] = 'const/high16';
    m[0x16] = 'const-wide/16';
    m[0x17] = 'const-wide/32';
    m[0x18] = 'const-wide';
    m[0x19] = 'const-wide/high16';
    m[0x1a] = 'const-string';
    m[0x1b] = 'const-string/jumbo';
    m[0x1c] = 'const-class';
    m[0x1d] = 'monitor-enter';
    m[0x1e] = 'monitor-exit';
    m[0x1f] = 'check-cast';
    m[0x20] = 'instance-of';
    m[0x21] = 'array-length';
    m[0x22] = 'new-instance';
    m[0x23] = 'new-array';
    m[0x24] = 'filled-new-array';
    m[0x25] = 'filled-new-array/range';
    m[0x26] = 'fill-array-data';
    m[0x27] = 'throw';
    m[0x28] = 'goto';
    m[0x29] = 'goto/16';
    m[0x2a] = 'goto/32';
    m[0x2b] = 'packed-switch';
    m[0x2c] = 'sparse-switch';
    m[0x2d] = 'cmpl-float';
    m[0x2e] = 'cmpg-float';
    m[0x2f] = 'cmpl-double';
    m[0x30] = 'cmpg-double';
    m[0x31] = 'cmp-long';
    m[0x32] = 'if-eq';
    m[0x33] = 'if-ne';
    m[0x34] = 'if-lt';
    m[0x35] = 'if-ge';
    m[0x36] = 'if-gt';
    m[0x37] = 'if-le';
    m[0x38] = 'if-eqz';
    m[0x39] = 'if-nez';
    m[0x3a] = 'if-ltz';
    m[0x3b] = 'if-gez';
    m[0x3c] = 'if-gtz';
    m[0x3d] = 'if-lez';
    // 0x3e-0x43 unused
    m[0x44] = 'iget';
    m[0x45] = 'iget-wide';
    m[0x46] = 'iget-object';
    m[0x47] = 'iget-boolean';
    m[0x48] = 'iget-byte';
    m[0x49] = 'iget-char';
    m[0x4a] = 'iget-short';
    m[0x4b] = 'iput';
    m[0x4c] = 'iput-wide';
    m[0x4d] = 'iput-object';
    m[0x4e] = 'iput-boolean';
    m[0x4f] = 'iput-byte';
    m[0x50] = 'iput-char';
    m[0x51] = 'iput-short';
    m[0x52] = 'sget';
    m[0x53] = 'sget-wide';
    m[0x54] = 'sget-object';
    m[0x55] = 'sget-boolean';
    m[0x56] = 'sget-byte';
    m[0x57] = 'sget-char';
    m[0x58] = 'sget-short';
    m[0x59] = 'sput';
    m[0x5a] = 'sput-wide';
    m[0x5b] = 'sput-object';
    m[0x5c] = 'sput-boolean';
    m[0x5d] = 'sput-byte';
    m[0x5e] = 'sput-char';
    m[0x5f] = 'sput-short';
    m[0x60] = 'invoke-virtual';
    m[0x61] = 'invoke-super';
    m[0x62] = 'invoke-direct';
    m[0x63] = 'invoke-static';
    m[0x64] = 'invoke-interface';
    m[0x65] = 'invoke-virtual/range';
    m[0x66] = 'invoke-super/range';
    m[0x67] = 'invoke-direct/range';
    m[0x68] = 'invoke-static/range';
    m[0x69] = 'invoke-interface/range';
    // 0x6a-0x6d neg/not
    m[0x6a] = 'neg-int';
    m[0x6b] = 'not-int';
    m[0x6c] = 'neg-long';
    m[0x6d] = 'not-long';
    // 算术 23x
    const arith23 = [
      'add', 'sub', 'mul', 'div', 'rem', 'and', 'or', 'xor', 'shl', 'shr', 'ushr'
    ];
    int base = 0x7b;
    for (final op in arith23) m[base++] = '$op-int';
    for (final op in arith23) m[base++] = '$op-long';
    for (final op in ['add', 'sub', 'mul', 'div', 'rem']) m[base++] = '$op-float';
    for (final op in ['add', 'sub', 'mul', 'div', 'rem']) m[base++] = '$op-double';
    // 2addr 12x
    int base2 = 0x9b;
    for (final op in arith23) m[base2++] = '$op-int/2addr';
    for (final op in arith23) m[base2++] = '$op-long/2addr';
    for (final op in ['add', 'sub', 'mul', 'div', 'rem']) m[base2++] = '$op-float/2addr';
    for (final op in ['add', 'sub', 'mul', 'div', 'rem']) m[base2++] = '$op-double/2addr';
    // lit16 22s
    int base16 = 0xbb;
    for (final op in arith23) m[base16++] = '$op-int/lit16';
    for (final op in arith23) m[base16++] = '$op-long/lit16';
    for (final op in ['add', 'sub', 'mul', 'div', 'rem']) m[base16++] = '$op-float/lit16';
    for (final op in ['add', 'sub', 'mul', 'div', 'rem']) m[base16++] = '$op-double/lit16';
    // lit8 22b
    int base8 = 0xdb;
    for (final op in arith23) m[base8++] = '$op-int/lit8';
    for (final op in arith23) m[base8++] = '$op-long/lit8';
    for (final op in ['add', 'sub', 'mul', 'div', 'rem']) m[base8++] = '$op-float/lit8';
    for (final op in ['add', 'sub', 'mul', 'div', 'rem']) m[base8++] = '$op-double/lit8';
    return m;
  }

  static Map<int, String> _buildFmtTable() {
    final m = <int, String>{};
    m[0x00] = '10x';
    m[0x01] = '12x';
    m[0x02] = '22x';
    m[0x03] = '32x';
    m[0x04] = '12x';
    m[0x05] = '22x';
    m[0x06] = '32x';
    m[0x07] = '12x';
    m[0x08] = '22x';
    m[0x09] = '32x';
    m[0x0a] = '11x';
    m[0x0b] = '11x';
    m[0x0c] = '11x';
    m[0x0d] = '11x';
    m[0x0e] = '10x';
    m[0x0f] = '11x';
    m[0x10] = '11x';
    m[0x11] = '11x';
    m[0x12] = '11n';
    m[0x13] = '21s';
    m[0x14] = '31i';
    m[0x15] = '21h';
    m[0x16] = '21s';
    m[0x17] = '31i';
    m[0x18] = '51l';
    m[0x19] = '21h';
    m[0x1a] = '21c';
    m[0x1b] = '31c';
    m[0x1c] = '21c';
    m[0x1d] = '11x';
    m[0x1e] = '11x';
    m[0x1f] = '21c';
    m[0x20] = '22c';
    m[0x21] = '12x';
    m[0x22] = '21c';
    m[0x23] = '22c';
    m[0x24] = '35c';
    m[0x25] = '3rc';
    m[0x26] = '31t';
    m[0x27] = '11x';
    m[0x28] = '10t';
    m[0x29] = '20t';
    m[0x2a] = '30t';
    m[0x2b] = '31t';
    m[0x2c] = '31t';
    m[0x2d] = '23x';
    m[0x2e] = '23x';
    m[0x2f] = '23x';
    m[0x30] = '23x';
    m[0x31] = '23x';
    m[0x32] = '22t';
    m[0x33] = '22t';
    m[0x34] = '22t';
    m[0x35] = '22t';
    m[0x36] = '22t';
    m[0x37] = '22t';
    m[0x38] = '22t';
    m[0x39] = '22t';
    m[0x3a] = '22t';
    m[0x3b] = '22t';
    m[0x3c] = '22t';
    m[0x3d] = '22t';
    m[0x44] = '22c';
    m[0x45] = '22c';
    m[0x46] = '22c';
    m[0x47] = '22c';
    m[0x48] = '22c';
    m[0x49] = '22c';
    m[0x4a] = '22c';
    m[0x4b] = '22c';
    m[0x4c] = '22c';
    m[0x4d] = '22c';
    m[0x4e] = '22c';
    m[0x4f] = '22c';
    m[0x50] = '22c';
    m[0x51] = '22c';
    m[0x52] = '21c';
    m[0x53] = '21c';
    m[0x54] = '21c';
    m[0x55] = '21c';
    m[0x56] = '21c';
    m[0x57] = '21c';
    m[0x58] = '21c';
    m[0x59] = '21c';
    m[0x5a] = '21c';
    m[0x5b] = '21c';
    m[0x5c] = '21c';
    m[0x5d] = '21c';
    m[0x5e] = '21c';
    m[0x5f] = '21c';
    m[0x60] = '35c';
    m[0x61] = '35c';
    m[0x62] = '35c';
    m[0x63] = '35c';
    m[0x64] = '35c';
    m[0x65] = '3rc';
    m[0x66] = '3rc';
    m[0x67] = '3rc';
    m[0x68] = '3rc';
    m[0x69] = '3rc';
    m[0x6a] = '12x';
    m[0x6b] = '12x';
    m[0x6c] = '12x';
    m[0x6d] = '12x';
    // 算术 23x
    for (int i = 0x7b; i <= 0x9a; i++) m[i] = '23x';
    // 2addr 12x
    for (int i = 0x9b; i <= 0xba; i++) m[i] = '12x';
    // lit16 22s
    for (int i = 0xbb; i <= 0xda; i++) m[i] = '22s';
    // lit8 22b
    for (int i = 0xdb; i <= 0xfa; i++) m[i] = '22b';
    return m;
  }
}

/// 方法引用（内部传输用）
class MethodRef {
  final int idx;
  final int access;
  final int codeOff;
  const MethodRef(this.idx, this.access, this.codeOff);
}
