import 'dart:typed_data';
import 'dart:convert';
import '../utils/hex_utils.dart';

/// 交叉引用分析器 - 查找方法/字段/字符串被谁引用（纯 Dart 实现）
///
/// 遍历所有 DEX 的 code_item，解析 invoke-* / iget|iput|sget|sput / const-string
/// 指令，按方法名、字段名或字符串内容搜索交叉引用，输出每个被引用目标的引用列表。
/// 所有解析逻辑均为纯 Dart 实现，不依赖任何外部库。

// ========== 结果模型 ==========

/// 交叉引用类型
enum XrefType {
  /// 方法引用（invoke-* 系列指令）
  method,
  /// 字段引用（iget/iput/sget/sput 系列指令）
  field,
  /// 字符串引用（const-string / const-string/jumbo 指令）
  string,
}

/// 单条交叉引用记录：描述一处对目标的引用
class XrefEntry {
  /// 引用者所在类名（DEX 类型描述符，如 Lcom/example/Foo;）
  final String referrerClass;

  /// 引用者方法名
  final String referrerMethod;

  /// 引用类型（method/field/string）
  final XrefType type;

  /// 被引用名称（方法描述符 / 字段描述符 / 字符串内容）
  final String targetName;

  /// 指令在 DEX 文件中的字节偏移
  final int offset;

  const XrefEntry({
    required this.referrerClass,
    required this.referrerMethod,
    required this.type,
    required this.targetName,
    required this.offset,
  });
}

/// 交叉引用结果：某个被引用目标的所有引用集合
class XrefResult {
  /// 被引用目标名称
  final String targetName;

  /// 引用类型
  final XrefType type;

  /// 所有引用条目
  final List<XrefEntry> references;

  /// 引用总数
  final int totalReferences;

  const XrefResult({
    required this.targetName,
    required this.type,
    required this.references,
    required this.totalReferences,
  });
}

// ========== DEX 内部引用表 ==========

class _MethodRef {
  final int classIdx;
  final int protoIdx;
  final int nameIdx;
  const _MethodRef(this.classIdx, this.protoIdx, this.nameIdx);
}

class _FieldRef {
  final int classIdx;
  final int typeIdx;
  final int nameIdx;
  const _FieldRef(this.classIdx, this.typeIdx, this.nameIdx);
}

class _ProtoRef {
  final int shortyIdx;
  final int returnTypeIdx;
  final int paramsOff;
  const _ProtoRef(this.shortyIdx, this.returnTypeIdx, this.paramsOff);
}

class _DexImage {
  final Uint8List dex;
  final List<String> strings;
  final List<String> types;
  final List<_ProtoRef> protos;
  final List<_FieldRef> fields;
  final List<_MethodRef> methods;

  const _DexImage(this.dex, this.strings, this.types, this.protos, this.fields,
      this.methods);

  String typeDesc(int i) => (i >= 0 && i < types.length) ? types[i] : '?';
  String stringAt(int i) => (i >= 0 && i < strings.length) ? strings[i] : '';

  /// 构造方法原型描述符，如 (Ljava/lang/String;)V
  String protoDesc(int i) {
    if (i < 0 || i >= protos.length) return '()V';
    final p = protos[i];
    final ret = typeDesc(p.returnTypeIdx);
    if (p.paramsOff == 0) return '()$ret';
    final buf = StringBuffer('(');
    int pos = p.paramsOff;
    final (size, p1) = _readUleb(dex, pos);
    pos = p1;
    for (int k = 0; k < size && k < 200; k++) {
      if (pos + 2 > dex.length) break;
      final tIdx = HexUtils.readUint16LE(dex, pos);
      pos += 2;
      buf.write(typeDesc(tIdx));
    }
    buf.write(')');
    buf.write(ret);
    return buf.toString();
  }

  /// 构造方法完整描述符，如 Lcom/example/Foo;->bar(Ljava/lang/String;)V
  String methodDesc(int i) {
    if (i < 0 || i >= methods.length) return '?';
    final m = methods[i];
    return '${typeDesc(m.classIdx)}->${stringAt(m.nameIdx)}${protoDesc(m.protoIdx)}';
  }

  /// 构造字段完整描述符，如 Lcom/example/Foo;->fieldName:I
  String fieldDesc(int i) {
    if (i < 0 || i >= fields.length) return '?';
    final f = fields[i];
    return '${typeDesc(f.classIdx)}->${stringAt(f.nameIdx)}:${typeDesc(f.typeIdx)}';
  }
}

// ========== 工具函数 ==========

/// 读取 ULEB128 编码的无符号整数，返回 (值, 下一个读取偏移)
(int, int) _readUleb(Uint8List b, int p) {
  int result = 0;
  int shift = 0;
  while (p < b.length) {
    final byte = b[p++];
    result |= (byte & 0x7F) << shift;
    if ((byte & 0x80) == 0) break;
    shift += 7;
  }
  return (result, p);
}

// ========== 分析器 ==========

class XrefAnalyzer {
  XrefAnalyzer._(); // 仅提供静态方法，禁止实例化

  /// 分析交叉引用
  ///
  /// [dexBytesList] 所有 DEX 文件字节列表
  /// [query] 搜索关键词（方法名/字段名/字符串内容，不区分大小写包含匹配）
  /// [type] 引用类型，默认为方法引用
  ///
  /// 返回每个被引用目标的 [XrefResult] 列表，按引用总数降序排列。
  static Future<List<XrefResult>> analyze(
    List<Uint8List> dexBytesList,
    String query, {
    XrefType type = XrefType.method,
  }) async {
    try {
      return _analyzeImpl(dexBytesList, query, type);
    } catch (e) {
      // 任何未预期的异常都不向上抛出，返回空结果
      return [];
    }
  }

  static List<XrefResult> _analyzeImpl(
      List<Uint8List> dexBytesList, String query, XrefType type) {
    if (query.isEmpty) return [];
    final lowerQuery = query.toLowerCase();

    // 目标名称 -> 引用列表
    final resultMap = <String, List<XrefEntry>>{};

    for (final dex in dexBytesList) {
      try {
        _analyzeDex(dex, type, lowerQuery, resultMap);
      } catch (_) {
        // 单个 DEX 解析失败不影响其他 DEX
      }
    }

    // 构建结果列表，按引用总数降序排列
    final results = <XrefResult>[];
    resultMap.forEach((target, refs) {
      results.add(XrefResult(
        targetName: target,
        type: type,
        references: refs,
        totalReferences: refs.length,
      ));
    });
    results.sort((a, b) => b.totalReferences.compareTo(a.totalReferences));
    return results;
  }

  /// 分析单个 DEX 文件
  static void _analyzeDex(Uint8List dex, XrefType type, String lowerQuery,
      Map<String, List<XrefEntry>> resultMap) {
    final img = _parseDex(dex);
    if (img == null) return;

    final typeIdsSize = HexUtils.readUint32LE(dex, 64);
    final classDefsSize = HexUtils.readUint32LE(dex, 96);
    final classDefsOff = HexUtils.readUint32LE(dex, 100);

    // 限制处理的类数量，防止大 DEX 导致 OOM
    const maxClasses = 3000;
    final classLimit = classDefsSize > maxClasses ? maxClasses : classDefsSize;

    for (int i = 0; i < classLimit; i++) {
      final off = classDefsOff + i * 32;
      if (off + 32 > dex.length) break;
      try {
        _analyzeClass(dex, img, off, typeIdsSize, type, lowerQuery, resultMap);
      } catch (_) {
        // 单个类解析失败跳过
      }
    }
  }

  /// 分析单个类中的所有方法
  static void _analyzeClass(
      Uint8List dex,
      _DexImage img,
      int off,
      int typeIdsSize,
      XrefType type,
      String lowerQuery,
      Map<String, List<XrefEntry>> resultMap) {
    final classIdx = HexUtils.readUint32LE(dex, off);
    final classDataOff = HexUtils.readUint32LE(dex, off + 24);
    if (classIdx >= typeIdsSize) return;
    final className = img.typeDesc(classIdx);
    if (!className.startsWith('L')) return;
    if (classDataOff == 0 || classDataOff >= dex.length) return;

    var pos = classDataOff;
    // class_data_item 头部：4 个 ULEB128
    final sf = _readUleb(dex, pos);
    pos = sf.$2; // static_fields_size
    final inf = _readUleb(dex, pos);
    pos = inf.$2; // instance_fields_size
    final dm = _readUleb(dex, pos);
    pos = dm.$2; // direct_methods_size
    final vm = _readUleb(dex, pos);
    pos = vm.$2; // virtual_methods_size

    // 跳过字段区域
    for (int fi = 0; fi < sf.$1 + inf.$1; fi++) {
      if (pos >= dex.length) return;
      final a = _readUleb(dex, pos);
      pos = a.$2; // field_idx_diff
      final b = _readUleb(dex, pos);
      pos = b.$2; // access_flags
    }

    const maxMethodsPerClass = 200;

    // 解析 direct methods
    int prev = 0;
    final dmLimit = dm.$1 > maxMethodsPerClass ? maxMethodsPerClass : dm.$1;
    for (int mi = 0; mi < dmLimit; mi++) {
      if (pos >= dex.length) break;
      final r = _parseEncodedMethod(dex, pos, prev);
      pos = r.$2;
      prev = r.$3;
      try {
        _scanMethod(dex, img, className, r.$1, r.$4, type, lowerQuery, resultMap);
      } catch (_) {
        // 单个方法扫描失败跳过
      }
    }

    // 解析 virtual methods（索引独立从 0 累积，需重置 prev）
    prev = 0;
    final vmLimit = vm.$1 > maxMethodsPerClass ? maxMethodsPerClass : vm.$1;
    for (int mi = 0; mi < vmLimit; mi++) {
      if (pos >= dex.length) break;
      final r = _parseEncodedMethod(dex, pos, prev);
      pos = r.$2;
      prev = r.$3;
      try {
        _scanMethod(dex, img, className, r.$1, r.$4, type, lowerQuery, resultMap);
      } catch (_) {
        // 单个方法扫描失败跳过
      }
    }
  }

  /// 解析 encoded_method 条目
  /// 返回 (methodIdx, 新pos, 新prevMethodIdx, codeOff)
  static (int, int, int, int) _parseEncodedMethod(Uint8List dex, int pos, int prev) {
    final diff = _readUleb(dex, pos);
    pos = diff.$2;
    final access = _readUleb(dex, pos);
    pos = access.$2;
    final codeOff = _readUleb(dex, pos);
    pos = codeOff.$2;
    final methodIdx = prev + diff.$1;
    return (methodIdx, pos, methodIdx, codeOff.$1);
  }

  /// 扫描单个方法体内的指令，提取交叉引用
  static void _scanMethod(
      Uint8List dex,
      _DexImage img,
      String className,
      int methodIdx,
      int codeOff,
      XrefType type,
      String lowerQuery,
      Map<String, List<XrefEntry>> resultMap) {
    if (codeOff == 0) return;
    if (codeOff + 16 > dex.length) return;

    final insnsSize = HexUtils.readUint32LE(dex, codeOff + 12);
    final codeStart = codeOff + 16;
    // 限制指令区大小，防止异常值导致越界
    final safeInsnsSize = insnsSize > 250000 ? 250000 : insnsSize;
    final codeEnd = codeStart + safeInsnsSize * 2;
    if (codeEnd > dex.length) return;

    // 获取引用者方法名
    final referrerMethod =
        (methodIdx >= 0 && methodIdx < img.methods.length)
            ? img.stringAt(img.methods[methodIdx].nameIdx)
            : '<unknown>';

    int p = codeStart;
    int count = 0;
    const maxInstructions = 5000;
    while (p < codeEnd && count < maxInstructions) {
      final len = _instructionLength(dex, p);
      if (len <= 0) break;
      try {
        _checkInstruction(dex, img, p, className, referrerMethod, type,
            lowerQuery, resultMap);
      } catch (_) {
        // 单条指令解析失败跳过
      }
      p += len;
      count++;
    }
  }

  /// 检查单条指令是否构成对查询目标的引用
  static void _checkInstruction(
      Uint8List dex,
      _DexImage img,
      int pos,
      String className,
      String referrerMethod,
      XrefType type,
      String lowerQuery,
      Map<String, List<XrefEntry>> resultMap) {
    if (pos + 1 >= dex.length) return;
    final u0 = HexUtils.readUint16LE(dex, pos);
    final op = u0 & 0xFF;

    // invoke-* 指令（0x60-0x69）：方法引用
    if (op >= 0x60 && op <= 0x69) {
      if (type != XrefType.method) return;
      if (pos + 3 >= dex.length) return;
      final methodIdx = HexUtils.readUint16LE(dex, pos + 2);
      final target = img.methodDesc(methodIdx);
      if (target.toLowerCase().contains(lowerQuery)) {
        resultMap.putIfAbsent(target, () => []).add(XrefEntry(
          referrerClass: className,
          referrerMethod: referrerMethod,
          type: XrefType.method,
          targetName: target,
          offset: pos,
        ));
      }
      return;
    }

    // iget/iput/sget/sput 指令（0x44-0x5f）：字段引用
    if (op >= 0x44 && op <= 0x5f) {
      if (type != XrefType.field) return;
      if (pos + 3 >= dex.length) return;
      final fieldIdx = HexUtils.readUint16LE(dex, pos + 2);
      final target = img.fieldDesc(fieldIdx);
      if (target.toLowerCase().contains(lowerQuery)) {
        resultMap.putIfAbsent(target, () => []).add(XrefEntry(
          referrerClass: className,
          referrerMethod: referrerMethod,
          type: XrefType.field,
          targetName: target,
          offset: pos,
        ));
      }
      return;
    }

    // const-string（0x1a）：字符串引用
    if (op == 0x1a) {
      if (type != XrefType.string) return;
      if (pos + 3 >= dex.length) return;
      final stringIdx = HexUtils.readUint16LE(dex, pos + 2);
      final target = img.stringAt(stringIdx);
      if (target.toLowerCase().contains(lowerQuery)) {
        resultMap.putIfAbsent(target, () => []).add(XrefEntry(
          referrerClass: className,
          referrerMethod: referrerMethod,
          type: XrefType.string,
          targetName: target,
          offset: pos,
        ));
      }
      return;
    }

    // const-string/jumbo（0x1b）：字符串引用（32 位索引）
    if (op == 0x1b) {
      if (type != XrefType.string) return;
      if (pos + 5 >= dex.length) return;
      final stringIdx = HexUtils.readUint32LE(dex, pos + 2);
      final target = img.stringAt(stringIdx);
      if (target.toLowerCase().contains(lowerQuery)) {
        resultMap.putIfAbsent(target, () => []).add(XrefEntry(
          referrerClass: className,
          referrerMethod: referrerMethod,
          type: XrefType.string,
          targetName: target,
          offset: pos,
        ));
      }
      return;
    }
  }

  /// 计算指令长度（字节），用于线性扫描推进
  static int _instructionLength(Uint8List dex, int pos) {
    if (pos + 1 >= dex.length) return 2;
    final u0 = HexUtils.readUint16LE(dex, pos);

    // 数据载荷伪指令（需特殊处理，长度可变）
    if (u0 == 0x0100) {
      // packed-switch-data
      final size = HexUtils.readUint16LE(dex, pos + 2);
      return 8 + size * 4;
    }
    if (u0 == 0x0200) {
      // sparse-switch-data
      final size = HexUtils.readUint16LE(dex, pos + 2);
      return 4 + size * 8;
    }
    if (u0 == 0x0300) {
      // fill-array-data
      final width = HexUtils.readUint16LE(dex, pos + 2);
      final size = HexUtils.readUint32LE(dex, pos + 4);
      final len = 8 + size * width;
      return len + (len & 1); // 对齐到 2 字节边界
    }

    final op = u0 & 0xFF;
    switch (_opFormat(op)) {
      case '10x':
      case '10t':
      case '11x':
      case '11n':
      case '12x':
        return 2;
      case '20t':
      case '21s':
      case '21h':
      case '21c':
      case '22x':
      case '22c':
      case '22b':
      case '22s':
      case '22t':
      case '23x':
        return 4;
      case '30t':
      case '31c':
      case '31i':
      case '31t':
      case '32x':
      case '35c':
      case '3rc':
        return 6;
      case '51l':
        return 10;
      default:
        return 2;
    }
  }

  /// 根据 opcode 返回指令格式标识
  static String _opFormat(int op) {
    const f = _fmtTable;
    return f[op] ?? '??';
  }

  // opcode -> 格式 映射表
  static const Map<int, String> _fmtTable = {
    0x00: '10x', 0x01: '12x', 0x02: '22x', 0x03: '32x', 0x04: '12x',
    0x05: '22x', 0x06: '32x', 0x07: '12x', 0x08: '22x', 0x09: '32x',
    0x0a: '11x', 0x0b: '11x', 0x0c: '11x', 0x0d: '11x', 0x0e: '10x',
    0x0f: '11x', 0x10: '11x', 0x11: '11x', 0x12: '11n', 0x13: '21s',
    0x14: '31i', 0x15: '21h', 0x16: '21s', 0x17: '31i', 0x18: '51l',
    0x19: '21h', 0x1a: '21c', 0x1b: '31c', 0x1c: '21c', 0x1d: '11x',
    0x1e: '11x', 0x1f: '21c', 0x20: '22c', 0x21: '12x', 0x22: '21c',
    0x23: '22c', 0x24: '35c', 0x25: '3rc', 0x26: '31t', 0x27: '11x',
    0x28: '10t', 0x29: '20t', 0x2a: '30t', 0x2b: '31t', 0x2c: '31t',
    0x2d: '23x', 0x2e: '23x', 0x2f: '23x', 0x30: '23x', 0x31: '23x',
    0x32: '22t', 0x33: '22t', 0x34: '22t', 0x35: '22t', 0x36: '22t',
    0x37: '22t', 0x38: '22t', 0x39: '22t', 0x3a: '22t', 0x3b: '22t',
    0x3c: '22t', 0x3d: '22t',
    // iget/iput/sget/sput 22c
    0x44: '22c', 0x45: '22c', 0x46: '22c', 0x47: '22c', 0x48: '22c',
    0x49: '22c', 0x4a: '22c', 0x4b: '22c', 0x4c: '22c', 0x4d: '22c',
    0x4e: '22c', 0x4f: '22c', 0x50: '22c', 0x51: '22c',
    0x52: '21c', 0x53: '21c', 0x54: '21c', 0x55: '21c', 0x56: '21c',
    0x57: '21c', 0x58: '21c', 0x59: '21c', 0x5a: '21c', 0x5b: '21c',
    0x5c: '21c', 0x5d: '21c', 0x5e: '21c', 0x5f: '21c',
    // invoke-* 35c / 3rc
    0x60: '35c', 0x61: '35c', 0x62: '35c', 0x63: '35c', 0x64: '35c',
    0x65: '3rc', 0x66: '3rc', 0x67: '3rc', 0x68: '3rc', 0x69: '3rc',
    0x6a: '12x', 0x6b: '12x', 0x6c: '12x', 0x6d: '12x',
  };

  // ========== DEX 文件解析 ==========

  /// 解析 DEX 文件头与各引用表，构建 _DexImage
  static _DexImage? _parseDex(Uint8List dex) {
    if (dex.length < 112) return null;
    // 验证 DEX 魔数 'dex\n'
    if (dex[0] != 0x64 || dex[1] != 0x65 || dex[2] != 0x78 || dex[3] != 0x0A) {
      return null;
    }

    final stringIdsSize = HexUtils.readUint32LE(dex, 56);
    final stringIdsOff = HexUtils.readUint32LE(dex, 60);
    final typeIdsSize = HexUtils.readUint32LE(dex, 64);
    final typeIdsOff = HexUtils.readUint32LE(dex, 68);
    final protoIdsSize = HexUtils.readUint32LE(dex, 72);
    final protoIdsOff = HexUtils.readUint32LE(dex, 76);
    final fieldIdsSize = HexUtils.readUint32LE(dex, 80);
    final fieldIdsOff = HexUtils.readUint32LE(dex, 84);
    final methodIdsSize = HexUtils.readUint32LE(dex, 88);
    final methodIdsOff = HexUtils.readUint32LE(dex, 92);

    // 解析字符串池
    final strings = <String>[];
    for (int i = 0; i < stringIdsSize && i < 200000; i++) {
      strings.add(_readDexString(dex, stringIdsOff, i));
    }

    // 解析类型池
    final types = <String>[];
    for (int i = 0; i < typeIdsSize && i < 200000; i++) {
      final strIdx = HexUtils.readUint32LE(dex, typeIdsOff + i * 4);
      types.add(strIdx < strings.length ? strings[strIdx] : '?');
    }

    // 解析原型池
    final protos = <_ProtoRef>[];
    for (int i = 0; i < protoIdsSize && i < 200000; i++) {
      final po = protoIdsOff + i * 12;
      if (po + 12 > dex.length) break;
      protos.add(_ProtoRef(
        HexUtils.readUint32LE(dex, po),
        HexUtils.readUint32LE(dex, po + 4),
        HexUtils.readUint32LE(dex, po + 8),
      ));
    }

    // 解析字段池
    final fields = <_FieldRef>[];
    for (int i = 0; i < fieldIdsSize && i < 500000; i++) {
      final fo = fieldIdsOff + i * 8;
      if (fo + 8 > dex.length) break;
      fields.add(_FieldRef(
        HexUtils.readUint16LE(dex, fo),
        HexUtils.readUint16LE(dex, fo + 2),
        HexUtils.readUint32LE(dex, fo + 4),
      ));
    }

    // 解析方法池
    final methods = <_MethodRef>[];
    for (int i = 0; i < methodIdsSize && i < 500000; i++) {
      final mo = methodIdsOff + i * 8;
      if (mo + 8 > dex.length) break;
      methods.add(_MethodRef(
        HexUtils.readUint16LE(dex, mo),
        HexUtils.readUint16LE(dex, mo + 2),
        HexUtils.readUint32LE(dex, mo + 4),
      ));
    }

    return _DexImage(dex, strings, types, protos, fields, methods);
  }

  /// 读取 DEX 字符串池中指定索引的字符串
  static String _readDexString(Uint8List dex, int stringIdsOff, int idx) {
    if (stringIdsOff + idx * 4 + 4 > dex.length) return '';
    final dataOff = HexUtils.readUint32LE(dex, stringIdsOff + idx * 4);
    if (dataOff >= dex.length) return '';
    // string_data_item: utf16_size (uleb128) + mutf8[] + 0x00
    var pos = dataOff;
    while (pos < dex.length && (dex[pos] & 0x80) != 0) pos++;
    pos++; // 跳过 uleb128 最后一个字节
    if (pos >= dex.length) return '';
    final start = pos;
    while (pos < dex.length && dex[pos] != 0) pos++;
    if (pos == start) return '';
    try {
      return utf8.decode(dex.sublist(start, pos), allowMalformed: true);
    } catch (_) {
      return '';
    }
  }
}
