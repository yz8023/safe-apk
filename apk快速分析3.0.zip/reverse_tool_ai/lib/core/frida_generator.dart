/// Frida Hook 脚本生成器 - 纯 Dart 实现
///
/// 根据 DEX 类名与方法签名，自动生成可用于 Frida 动态插桩的 JavaScript Hook 脚本。
/// 支持按类生成、按方法覆写 implementation、打印参数与返回值，以及处理重载方法；
/// 亦可针对 Native（SO 导出符号）生成 Interceptor.attach 脚本。
///
/// 所有逻辑均为纯 Dart 实现，不依赖任何平台原生代码。
///
/// 用法：
/// ```dart
/// final script = FridaGenerator.generate(dexClasses, filter: 'com.example');
/// print(script.content);
/// ```
library;

import '../models/dex_class.dart';

// ========== 结果模型 ==========

/// 生成的 Frida 脚本结果
class FridaScript {
  /// 脚本内容（JavaScript）
  final String content;

  /// 涵盖的类数
  final int classCount;

  /// 涵盖的方法数
  final int methodCount;

  /// 生成时间
  final DateTime generatedAt;

  const FridaScript({
    required this.content,
    required this.classCount,
    required this.methodCount,
    required this.generatedAt,
  });

  /// 空脚本
  static FridaScript empty() => FridaScript(
        content: '// 无符合条件的类/方法，未生成 Hook 脚本\n',
        classCount: 0,
        methodCount: 0,
        generatedAt: DateTime.now(),
      );

  /// 简要摘要
  String get summary =>
      '已生成 Frida 脚本：覆盖 $classCount 个类 / $methodCount 个方法';
}

// ========== 内部辅助类型 ==========

/// 单个类生成的脚本块结果（内部使用）
class _ClassBlock {
  final String code;
  final int methods;
  const _ClassBlock(this.code, this.methods);
}

// ========== 检测器 ==========

/// Frida Hook 脚本生成器
///
/// 根据 [DexClass] 列表自动生成 Frida Hook 脚本。所有方法均为静态方法，无需实例化。
class FridaGenerator {
  FridaGenerator._();

  // ---------- DEX 访问标志位 ----------
  static const int _accStatic = 0x0008;
  static const int _accNative = 0x0100;
  static const int _accAbstract = 0x0400;
  static const int _accSynthetic = 0x1000;
  static const int _accBridge = 0x4000;

  // ---------- 主入口 ----------

  /// 根据 DEX 类列表生成 Frida Hook 脚本
  ///
  /// [classes] 解析得到的 DEX 类列表
  /// [filter] 可选的过滤关键词，仅生成类名包含该关键词的类（不区分大小写）
  /// [maxClasses] 最多生成的类数量，避免脚本过大（默认 50）
  /// [maxMethodsPerClass] 每个类最多生成的方法数量（默认 20）
  static FridaScript generate(
    List<DexClass> classes, {
    String? filter,
    int maxClasses = 50,
    int maxMethodsPerClass = 20,
  }) {
    if (classes.isEmpty) return FridaScript.empty();

    // 1. 过滤类
    Iterable<DexClass> selected = classes;
    if (filter != null && filter.isNotEmpty) {
      final f = filter.toLowerCase();
      selected = classes.where((c) => c.name.toLowerCase().contains(f));
    }

    // 2. 限制类数量
    final picked = selected.take(maxClasses).toList();
    if (picked.isEmpty) return FridaScript.empty();

    final sb = StringBuffer();
    sb.writeln('// ==========================================================');
    sb.writeln('// Frida Hook 脚本 - 自动生成');
    sb.writeln('// 生成时间: ${DateTime.now().toIso8601String()}');
    if (filter != null && filter.isNotEmpty) {
      sb.writeln('// 过滤关键词: $filter');
    }
    sb.writeln('// 覆盖类数: ${picked.length} (上限 $maxClasses)');
    sb.writeln('// ==========================================================');
    sb.writeln();
    sb.writeln('Java.perform(function() {');

    var totalMethods = 0;
    for (final cls in picked) {
      final methodBlocks = _generateClassBlock(cls, maxMethodsPerClass);
      if (methodBlocks.methods == 0) continue;
      sb.write(methodBlocks.code);
      totalMethods += methodBlocks.methods;
    }

    sb.writeln('});');

    return FridaScript(
      content: sb.toString(),
      classCount: picked.length,
      methodCount: totalMethods,
      generatedAt: DateTime.now(),
    );
  }

  /// 为单个类生成 Hook 脚本片段
  ///
  /// [className] 类名（DEX 形式 Lcom/pkg/Class; 或点分形式 com.pkg.Class 均可）
  /// [methods] 该类的方法列表
  static String generateForClass(String className, List<DexMethod> methods) {
    // 统一转换为点分形式，并构造一个临时 DexClass 复用内部逻辑
    final dotted = _toDottedClassName(className);
    final cls = DexClass(name: _toDexForm(className), methods: methods);
    final block = _generateClassBlock(cls, methods.length, forceClassName: dotted);
    if (block.methods == 0) {
      return '// 类 $dotted 无可 Hook 方法\n';
    }
    return 'Java.perform(function() {\n${block.code}});\n';
  }

  /// 为 Native 方法（SO 导出符号）生成 Interceptor.attach 脚本
  ///
  /// [soExports] SO 文件中的导出符号名列表
  /// [soName] SO 文件名（如 libnative.so），用于注释与定位
  static String generateForNativeMethods(List<String> soExports, String soName) {
    final sb = StringBuffer();
    sb.writeln('// ==========================================================');
    sb.writeln('// Frida Native Hook 脚本 - 自动生成');
    sb.writeln('// 目标 SO: $soName');
    sb.writeln('// 导出符号数: ${soExports.length}');
    sb.writeln('// ==========================================================');
    sb.writeln();

    if (soExports.isEmpty) {
      sb.writeln('// 未发现导出符号，请检查 SO 文件');
      return sb.toString();
    }

    for (final sym in soExports) {
      // 跳过常见无意义的链接器符号
      if (_isLinkerSymbol(sym)) continue;
      final varName = _toJsVarName(sym);
      sb.writeln('    // Hook 导出符号: $sym');
      sb.writeln('    var $varName = Module.findExportByName("$soName", "$sym");');
      sb.writeln('    if ($varName) {');
      sb.writeln('        Interceptor.attach($varName, {');
      sb.writeln('            onEnter: function(args) {');
      sb.writeln('                console.log("[*] $sym called");');
      sb.writeln('                console.log("    arg0: " + args[0]);');
      sb.writeln('                console.log("    arg1: " + args[1]);');
      sb.writeln('                console.log("    arg2: " + args[2]);');
      sb.writeln('            },');
      sb.writeln('            onLeave: function(retval) {');
      sb.writeln('                console.log("    retval: " + retval);');
      sb.writeln('            }');
      sb.writeln('        });');
      sb.writeln('    } else {');
      sb.writeln('        console.log("[!] 符号 $sym 未找到");');
      sb.writeln('    }');
      sb.writeln();
    }

    return sb.toString();
  }

  // ==================== 内部实现 ====================

  /// 生成单个类的 Hook 代码块
  ///
  /// [forceClassName] 若提供，则使用该名称作为 Java.use 的参数（覆盖默认推断）
  static _ClassBlock _generateClassBlock(
    DexClass cls,
    int maxMethods, {
    String? forceClassName,
  }) {
    final javaName = forceClassName ?? _toDottedClassName(cls.name);
    final jsVar = _toJsVarName(cls.simpleName);

    // 过滤并选取可 Hook 的方法
    final hookable = <DexMethod>[];
    for (final m in cls.methods) {
      if (!_isHookable(m)) continue;
      hookable.add(m);
      if (hookable.length >= maxMethods) break;
    }
    if (hookable.isEmpty) return const _ClassBlock('', 0);

    final sb = StringBuffer();
    sb.writeln();
    sb.writeln('    // ---------- 类: $javaName ----------');
    sb.writeln('    var $jsVar = Java.use("$javaName");');

    // 按方法名分组，判断是否需要 overload 语法
    final byName = <String, List<DexMethod>>{};
    for (final m in hookable) {
      byName.putIfAbsent(m.name, () => []).add(m);
    }

    for (final entry in byName.entries) {
      final methodName = entry.key;
      final overloads = entry.value;
      for (final m in overloads) {
        sb.write(_generateMethodBlock(jsVar, javaName, methodName, m,
            isOverloaded: overloads.length > 1));
      }
    }

    return _ClassBlock(sb.toString(), hookable.length);
  }

  /// 生成单个方法的 Hook 代码块
  static String _generateMethodBlock(
    String classVar,
    String className,
    String methodName,
    DexMethod method, {
    required bool isOverloaded,
  }) {
    final paramTypes = method.paramTypes;
    final paramCount = paramTypes.length;
    final isStatic = (method.accessFlags & _accStatic) != 0;

    // 生成参数名：arg1, arg2, ...
    final argNames = <String>[];
    for (var i = 0; i < paramCount; i++) {
      argNames.add('arg${i + 1}');
    }
    final argsStr = argNames.join(', ');

    // 构造方法引用表达式（处理重载）
    String methodRef;
    if (isOverloaded) {
      final overloadTypes =
          paramTypes.map(_dexTypeToFridaOverloadType).join(', ');
      methodRef = '$classVar.$methodName.overload($overloadTypes)';
    } else {
      methodRef = '$classVar.$methodName';
    }

    final sb = StringBuffer();
    sb.writeln();
    sb.writeln('    $methodRef.implementation = function($argsStr) {');
    sb.writeln('        console.log("[*] $className.$methodName called");');

    // 打印各参数
    for (var i = 0; i < paramCount; i++) {
      final an = argNames[i];
      final typeHint = _dexTypeToDisplay(paramTypes[i]);
      sb.writeln('        console.log("    $an ($typeHint): " + $an);');
    }

    // 调用原方法获取返回值（void 方法不打印返回值）
    final isVoid = method.returnType == 'V';
    if (isVoid) {
      sb.writeln('        this.$methodName($argsStr);');
      sb.writeln('        console.log("    return: void");');
      sb.writeln('        return;');
    } else {
      sb.writeln('        var ret = this.$methodName($argsStr);');
      sb.writeln('        console.log("    return: " + ret);');
      sb.writeln('        return ret;');
    }
    sb.writeln('    };');
    // 静态方法补充注释
    if (isStatic) {
      sb.writeln('    // 注: $methodName 为静态方法');
    }
    // Native 方法补充注释（覆写后会脱离原生绑定，请谨慎使用）
    final isNative = (method.accessFlags & _accNative) != 0;
    if (isNative) {
      sb.writeln('    // 注: $methodName 为 native 方法，覆写 implementation 会脱离原生绑定');
    }
    return sb.toString();
  }

  // ==================== 工具方法 ====================

  /// 判断方法是否可 Hook（跳过构造器、抽象、合成、桥接方法）
  static bool _isHookable(DexMethod m) {
    // 跳过构造器与类初始化器（Frida 中需用 $init 特殊处理）
    if (m.name == '<init>' || m.name == '<clinit>') return false;
    // 跳过抽象方法（无实现可覆写）
    if ((m.accessFlags & _accAbstract) != 0) return false;
    // 跳过合成/桥接方法
    if ((m.accessFlags & _accSynthetic) != 0) return false;
    if ((m.accessFlags & _accBridge) != 0) return false;
    return true;
  }

  /// 将 DEX 类名转换为 Java 点分形式
  ///
  /// 'Lcom/example/Foo;' -> 'com.example.Foo'
  /// 'com.example.Foo' -> 'com.example.Foo'
  static String _toDottedClassName(String name) {
    var n = name;
    if (n.startsWith('L') && n.endsWith(';')) {
      n = n.substring(1, n.length - 1);
    } else if (n.endsWith(';')) {
      n = n.substring(0, n.length - 1);
    }
    return n.replaceAll('/', '.');
  }

  /// 将点分类名转换为 DEX 形式（用于构造 DexClass）
  static String _toDexForm(String name) {
    if (name.startsWith('L') && name.endsWith(';')) return name;
    return 'L${name.replaceAll('.', '/')};';
  }

  /// 将标识符转换为合法的 JavaScript 变量名
  ///
  /// 例如 'Activity$Inner' -> 'Activity_Inner'
  static String _toJsVarName(String name) {
    final cleaned = name
        .replaceAll(RegExp(r'[^a-zA-Z0-9_]'), '_')
        .replaceAll(RegExp(r'_+'), '_');
    // 避免以数字开头
    if (cleaned.isNotEmpty && RegExp(r'^[0-9]').hasMatch(cleaned)) {
      return '_$cleaned';
    }
    return cleaned.isEmpty ? 'cls' : cleaned;
  }

  /// 将 DEX 类型签名转换为 Frida overload() 所需的 Java 类型字符串
  ///
  /// 'I' -> 'int', 'Ljava/lang/String;' -> 'java.lang.String', '[B' -> '[B'
  static String _dexTypeToFridaOverloadType(String dexType) {
    if (dexType.isEmpty) return 'void';
    // 处理数组前缀
    if (dexType[0] == '[') {
      final prefix = _arrayPrefix(dexType);
      final element = dexType.substring(prefix.length);
      return '$prefix${_dexTypeToFridaOverloadType(element)}';
    }
    switch (dexType) {
      case 'V':
        return 'void';
      case 'Z':
        return 'boolean';
      case 'B':
        return 'byte';
      case 'S':
        return 'short';
      case 'I':
        return 'int';
      case 'J':
        return 'long';
      case 'F':
        return 'float';
      case 'D':
        return 'double';
      case 'C':
        return 'char';
      default:
        // 对象类型 Lcom/pkg/Class; -> com.pkg.Class
        if (dexType.startsWith('L') && dexType.endsWith(';')) {
          return dexType.substring(1, dexType.length - 1).replaceAll('/', '.');
        }
        return dexType;
    }
  }

  /// 提取数组前缀的方括号部分
  static String _arrayPrefix(String dexType) {
    final sb = StringBuffer();
    var i = 0;
    while (i < dexType.length && dexType[i] == '[') {
      sb.write('[');
      i++;
    }
    return sb.toString();
  }

  /// 将 DEX 类型签名转换为人类可读的显示文本（用于注释）
  ///
  /// 'I' -> 'int', 'Ljava/lang/String;' -> 'String', '[B' -> 'byte[]'
  static String _dexTypeToDisplay(String dexType) {
    if (dexType.isEmpty) return 'void';
    if (dexType[0] == '[') {
      final prefix = _arrayPrefix(dexType);
      final element = dexType.substring(prefix.length);
      return '${_dexTypeToDisplay(element)}${']' * prefix.length}';
    }
    switch (dexType) {
      case 'V':
        return 'void';
      case 'Z':
        return 'boolean';
      case 'B':
        return 'byte';
      case 'S':
        return 'short';
      case 'I':
        return 'int';
      case 'J':
        return 'long';
      case 'F':
        return 'float';
      case 'D':
        return 'double';
      case 'C':
        return 'char';
      default:
        if (dexType.startsWith('L') && dexType.endsWith(';')) {
          final dotted =
              dexType.substring(1, dexType.length - 1).replaceAll('/', '.');
          // 取最后一段作为简短名
          final parts = dotted.split('.');
          return parts.isNotEmpty ? parts.last : dotted;
        }
        return dexType;
    }
  }

  /// 判断是否为链接器生成的无意义符号
  static bool _isLinkerSymbol(String sym) {
    return sym.startsWith('_ZN') ||
        sym.startsWith('_ZS') ||
        sym == 'JNI_OnLoad' ||
        sym == '__cxa_atexit' ||
        sym.startsWith('__');
  }
}
