import 'dart:typed_data';
import '../utils/hex_utils.dart';

/// resources.arsc 简化解析器
class ResAnalyzer {
  /// 解析资源表，返回包名和字符串数量
  static ResInfo? parse(Uint8List data) {
    if (data.length < 12) return null;
    if (HexUtils.readUint16LE(data, 0) != 0x0002) return null; // RES_TABLE_TYPE

    final packageCount = HexUtils.readUint32LE(data, 8);
    final strings = <String>[];
    int pos = 12;

    while (pos < data.length - 8) {
      final chunkType = HexUtils.readUint16LE(data, pos);
      final chunkSize = HexUtils.readUint32LE(data, pos + 4);
      if (chunkSize == 0 || pos + chunkSize > data.length) break;

      if (chunkType == 0x0001) { // RES_STRING_POOL_TYPE
        _parseStringPool(data, pos, strings);
      } else if (chunkType == 0x0200) { // RES_TABLE_PACKAGE_TYPE
        // 包信息
      }
      pos += chunkSize;
    }

    return ResInfo(
      packageCount: packageCount,
      stringCount: strings.length,
      sampleStrings: strings.take(20).toList(),
    );
  }

  static void _parseStringPool(Uint8List data, int pos, List<String> strings) {
    if (pos + 28 > data.length) return;
    final strCount = HexUtils.readUint32LE(data, pos + 8);
    final flags = HexUtils.readUint32LE(data, pos + 16);
    final stringsStart = HexUtils.readUint32LE(data, pos + 20);
    final isUtf8 = (flags & 0x100) != 0;

    final offsetsStart = pos + 28;
    for (int i = 0; i < strCount && i < 2000; i++) {
      if (offsetsStart + i * 4 + 4 > data.length) break;
      final strOff = HexUtils.readUint32LE(data, offsetsStart + i * 4);
      final absOff = pos + stringsStart + strOff;
      if (absOff >= data.length - 1) continue;

      if (isUtf8) {
        final end = data.indexOf(0, absOff + 1);
        if (end > absOff) {
          try {
            final s = String.fromCharCodes(data.sublist(absOff + 1, end));
            if (s.isNotEmpty) strings.add(s);
          } catch (_) {}
        }
      } else {
        final len = HexUtils.readUint16LE(data, absOff);
        if (len > 0 && absOff + 2 + len * 2 <= data.length) {
          try {
            final b = data.sublist(absOff + 2, absOff + 2 + len * 2);
            final codeUnits = <int>[];
            for (int j = 0; j < b.length - 1; j += 2) {
              codeUnits.add(b[j] | (b[j + 1] << 8));
            }
            final s = String.fromCharCodes(codeUnits);
            if (s.isNotEmpty) strings.add(s);
          } catch (_) {}
        }
      }
    }
  }
}

class ResInfo {
  final int packageCount;
  final int stringCount;
  final List<String> sampleStrings;

  const ResInfo({
    required this.packageCount,
    required this.stringCount,
    required this.sampleStrings,
  });
}
