import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';
import 'package:crypto/crypto.dart' as crypto;

/// APK 重新签名器 - 纯 Dart 实现（V1 JAR 签名）
///
/// 对修改后的 APK 执行 V1 签名（JAR 签名方案）：
/// 1. 遍历 APK 中所有文件（排除 META-INF/）
/// 2. 计算每个文件的 SHA-1 摘要
/// 3. 生成 MANIFEST.MF
/// 4. 生成 CERT.SF
/// 5. 生成 CERT.RSA（简化版：写入签名信息但不含实际 PKCS#7 签名）
///
/// 注意：由于纯 Dart 生成 PKCS#7 签名极为复杂，本模块生成的 CERT.RSA
/// 为占位文件。实际使用时需用 jarsigner/apksigner 完成最终签名。
/// 但 MANIFEST.MF 和 CERT.SF 的生成是完整的，可直接被 jarsigner 使用。
///
/// 用法：
/// ```dart
/// final result = await ApkResigner.signV1('/path/to/unsigned.apk', '/path/to/signed.apk');
/// ```

// ========== 结果模型 ==========

class ApkSignResult {
  final bool success;
  final String? scheme; // 'v1'
  final String? manifestPath;
  final String? certSfPath;
  final String? error;

  const ApkSignResult({
    required this.success,
    this.scheme,
    this.manifestPath,
    this.certSfPath,
    this.error,
  });
}

// ========== 签名器 ==========

class ApkResigner {
  ApkResigner._();

  /// 对 APK 执行 V1 签名
  ///
  /// 生成 MANIFEST.MF 和 CERT.SF 并写入 APK 的 META-INF/ 目录。
  /// CERT.RSA 为占位文件，需用 jarsigner 完成最终签名。
  static Future<ApkSignResult> signV1(String apkPath, String outputPath) async {
    try {
      final bytes = await File(apkPath).readAsBytes();
      final entries = _parseZipEntries(bytes);

      if (entries.isEmpty) {
        return const ApkSignResult(success: false, error: '无法解析 APK ZIP 结构');
      }

      // 过滤需要签名的文件（排除 META-INF/）
      final filesToSign = <String, Uint8List>{};
      for (final entry in entries) {
        if (entry.name.startsWith('META-INF/')) continue;
        filesToSign[entry.name] = _extractFile(bytes, entry);
      }

      // 生成 MANIFEST.MF
      final manifest = _generateManifest(filesToSign);

      // 生成 CERT.SF
      final certSf = _generateCertSf(manifest);

      // 生成 CERT.RSA（占位）
      final certRsa = _generatePlaceholderCert();

      // 重新打包（添加签名文件）
      final modifiedEntries = <String, Uint8List>{
        'META-INF/MANIFEST.MF': Uint8List.fromList(utf8.encode(manifest)),
        'META-INF/CERT.SF': Uint8List.fromList(utf8.encode(certSf)),
        'META-INF/CERT.RSA': certRsa,
      };

      // 使用 ApkRepacker 重新打包
      // 忽略现有的 META-INF 签名文件
      final repackResult = await _repackWithSignature(
        bytes,
        entries,
        modifiedEntries,
        outputPath,
      );

      if (!repackResult) {
        return const ApkSignResult(success: false, error: '重新打包失败');
      }

      return ApkSignResult(
        success: true,
        scheme: 'v1',
        manifestPath: 'META-INF/MANIFEST.MF',
        certSfPath: 'META-INF/CERT.SF',
      );
    } catch (e) {
      return ApkSignResult(success: false, error: '签名失败: $e');
    }
  }

  /// 仅生成 MANIFEST.MF 内容（不写入文件）
  static String generateManifestContent(Map<String, Uint8List> entries) {
    return _generateManifest(entries);
  }

  /// 仅生成 CERT.SF 内容
  static String generateCertSfContent(String manifestContent) {
    return _generateCertSf(manifestContent);
  }

  // ========== 内部方法 ==========

  static String _generateManifest(Map<String, Uint8List> entries) {
    final sb = StringBuffer();
    sb.writeln('Manifest-Version: 1.0');
    sb.writeln('Created-By: 智能逆向助手 (Reverse Tool AI)');
    sb.writeln('');

    final sortedNames = entries.keys.toList()..sort();
    for (final name in sortedNames) {
      final data = entries[name]!;
      final sha1Base64 = _base64Sha1(data);
      sb.writeln('Name: $name');
      sb.writeln('SHA-1-Digest: $sha1Base64');
      sb.writeln('');
    }

    return sb.toString();
  }

  static String _generateCertSf(String manifestContent) {
    final sb = StringBuffer();
    sb.writeln('Signature-Version: 1.0');
    sb.writeln('SHA-1-Digest-Manifest: ${_base64Sha1(Uint8List.fromList(utf8.encode(manifestContent)))}');
    sb.writeln('Created-By: 智能逆向助手 (Reverse Tool AI)');
    sb.writeln('');

    // 对 MANIFEST.MF 中的每个条目生成摘要
    final sections = manifestContent.split('\r\n\r\n').where((s) => s.trim().isNotEmpty).toList();
    for (final section in sections.skip(1)) {
      // 跳过主属性段
      final nameMatch = RegExp(r'^Name:\s*(.+)$', multiLine: true).firstMatch(section);
      if (nameMatch == null) continue;
      final name = nameMatch.group(1)!;

      // 对 section 内容做 SHA-1
      final sectionBytes = Uint8List.fromList(utf8.encode('$section\r\n\r\n'));
      final sha1Base64 = _base64Sha1(sectionBytes);
      sb.writeln('Name: $name');
      sb.writeln('SHA-1-Digest: $sha1Base64');
      sb.writeln('');
    }

    return sb.toString();
  }

  static Uint8List _generatePlaceholderCert() {
    // 占位 PKCS#7 文件（实际使用时需用 jarsigner 替换）
    final content = 'Placeholder PKCS#7 - Use jarsigner to complete V1 signing.';
    return Uint8List.fromList(utf8.encode(content));
  }

  static String _base64Sha1(Uint8List data) {
    final digest = crypto.sha1.convert(data);
    return base64.encode(digest.bytes);
  }

  // ========== ZIP 解析（简化版，与 ApkRepacker 重复但保持独立性） ==========

  static List<_ZipEntry> _parseZipEntries(Uint8List bytes) {
    final entries = <_ZipEntry>[];
    int offset = bytes.length - 22;
    if (offset < 0) return entries;

    final searchStart = _max(0, bytes.length - 22 - 65535);
    while (offset >= searchStart) {
      if (bytes[offset] == 0x50 && bytes[offset + 1] == 0x4B &&
          bytes[offset + 2] == 0x05 && bytes[offset + 3] == 0x06) {
        final commentLen = bytes[offset + 20] | (bytes[offset + 21] << 8);
        if (offset + 22 + commentLen == bytes.length) break;
      }
      offset--;
    }
    if (offset < searchStart) return entries;

    final cdOffset = bytes[offset + 16] |
        (bytes[offset + 17] << 8) |
        (bytes[offset + 18] << 16) |
        (bytes[offset + 19] << 24);
    final entryCount = bytes[offset + 10] | (bytes[offset + 11] << 8);

    int pos = cdOffset;
    for (int i = 0; i < entryCount && pos < bytes.length - 46; i++) {
      if (bytes[pos] != 0x50 || bytes[pos + 1] != 0x4B) break;
      final nameLen = bytes[pos + 28] | (bytes[pos + 29] << 8);
      final extraLen = bytes[pos + 30] | (bytes[pos + 31] << 8);
      final commentLen = bytes[pos + 32] | (bytes[pos + 33] << 8);
      final localOffset = bytes[pos + 42] |
          (bytes[pos + 43] << 8) |
          (bytes[pos + 44] << 16) |
          (bytes[pos + 45] << 24);
      final compSize = bytes[pos + 20] |
          (bytes[pos + 21] << 8) |
          (bytes[pos + 22] << 16) |
          (bytes[pos + 23] << 24);
      final uncompSize = bytes[pos + 24] |
          (bytes[pos + 25] << 8) |
          (bytes[pos + 26] << 16) |
          (bytes[pos + 27] << 24);
      final method = bytes[pos + 10] | (bytes[pos + 11] << 8);

      if (pos + 46 + nameLen > bytes.length) break;
      final name = utf8.decode(bytes.sublist(pos + 46, pos + 46 + nameLen), allowMalformed: true);
      entries.add(_ZipEntry(
        name: name,
        localHeaderOffset: localOffset,
        compressedSize: compSize,
        uncompressedSize: uncompSize,
        compressionMethod: method,
      ));
      pos += 46 + nameLen + extraLen + commentLen;
    }
    return entries;
  }

  static Uint8List _extractFile(Uint8List zipBytes, _ZipEntry entry) {
    int pos = entry.localHeaderOffset;
    if (pos + 30 > zipBytes.length) return Uint8List(0);
    final nameLen = zipBytes[pos + 26] | (zipBytes[pos + 27] << 8);
    final extraLen = zipBytes[pos + 28] | (zipBytes[pos + 29] << 8);
    int dataStart = pos + 30 + nameLen + extraLen;

    if (entry.compressionMethod == 0) {
      final end = _min(dataStart + entry.uncompressedSize, zipBytes.length);
      return Uint8List.fromList(zipBytes.sublist(dataStart, end));
    } else if (entry.compressionMethod == 8) {
      final end = _min(dataStart + entry.compressedSize, zipBytes.length);
      final compressed = zipBytes.sublist(dataStart, end);
      try {
        final codec = ZLibCodec(raw: true);
        return Uint8List.fromList(codec.decoder.convert(compressed));
      } catch (_) {
        return Uint8List.fromList(compressed);
      }
    }
    return Uint8List(0);
  }

  static int _max(int a, int b) => a > b ? a : b;
  static int _min(int a, int b) => a < b ? a : b;

  /// 使用 ApkRepacker 的逻辑重新打包并添加签名文件
  static Future<bool> _repackWithSignature(
    Uint8List originalBytes,
    List<_ZipEntry> originalEntries,
    Map<String, Uint8List> newFiles,
    String outputPath,
  ) async {
    try {
      // 收集所有文件数据（排除旧 META-INF 签名文件）
      final allFiles = <String, Uint8List>{};
      for (final entry in originalEntries) {
        if (entry.name.startsWith('META-INF/') &&
            (entry.name.endsWith('.SF') ||
             entry.name.endsWith('.RSA') ||
             entry.name.endsWith('.DSA') ||
             entry.name == 'META-INF/MANIFEST.MF')) {
          continue;
        }
        allFiles[entry.name] = _extractFile(originalBytes, entry);
      }
      // 添加新的签名文件
      allFiles.addAll(newFiles);

      // 写入 ZIP
      final output = BytesBuilder();
      final centralDir = BytesBuilder();
      final sortedNames = allFiles.keys.toList()..sort();
      int localOffset = 0;
      int entryCount = 0;

      for (final name in sortedNames) {
        final fileData = allFiles[name]!;
        final crc = _calculateCrc32(fileData);

        // 对非空文件尝试 DEFLATE 压缩
        Uint8List compressedData = fileData;
        int compressionMethod = 0;
        if (fileData.length > 0) {
          try {
            final codec = ZLibCodec(raw: true);
            final deflated = Uint8List.fromList(codec.encoder.convert(fileData));
            if (deflated.length < fileData.length) {
              compressedData = deflated;
              compressionMethod = 8;
            }
          } catch (_) {}
        }

        final nameBytes = utf8.encode(name);
        final currentLocalOffset = localOffset;

        // Local File Header
        final lh = ByteData(30 + nameBytes.length);
        lh.setUint32(0, 0x04034b50, Endian.little);
        lh.setUint16(4, 20, Endian.little);
        lh.setUint16(6, 0, Endian.little);
        lh.setUint16(8, compressionMethod, Endian.little);
        lh.setUint16(10, 0, Endian.little);
        lh.setUint16(12, 0x0021, Endian.little);
        lh.setUint32(14, crc, Endian.little);
        lh.setUint32(18, compressedData.length, Endian.little);
        lh.setUint32(22, fileData.length, Endian.little);
        lh.setUint16(26, nameBytes.length, Endian.little);
        lh.setUint16(28, 0, Endian.little);

        output.add(lh.buffer.asUint8List());
        output.add(nameBytes);
        output.add(compressedData);
        localOffset += 30 + nameBytes.length + compressedData.length;

        // Central Directory Entry
        final cd = ByteData(46 + nameBytes.length);
        cd.setUint32(0, 0x02014b50, Endian.little);
        cd.setUint16(4, 20, Endian.little);
        cd.setUint16(6, 20, Endian.little);
        cd.setUint16(8, 0, Endian.little);
        cd.setUint16(10, compressionMethod, Endian.little);
        cd.setUint16(12, 0, Endian.little);
        cd.setUint16(14, 0x0021, Endian.little);
        cd.setUint32(16, crc, Endian.little);
        cd.setUint32(20, compressedData.length, Endian.little);
        cd.setUint32(24, fileData.length, Endian.little);
        cd.setUint16(28, nameBytes.length, Endian.little);
        cd.setUint16(30, 0, Endian.little);
        cd.setUint16(32, 0, Endian.little);
        cd.setUint16(34, 0, Endian.little);
        cd.setUint16(36, 0, Endian.little);
        cd.setUint32(38, 0, Endian.little);
        cd.setUint32(42, currentLocalOffset, Endian.little);

        centralDir.add(cd.buffer.asUint8List());
        centralDir.add(nameBytes);
        entryCount++;
      }

      final cdStart = localOffset;
      final cdBytes = centralDir.takeBytes();

      output.add(cdBytes);

      // EOCD
      final eocd = ByteData(22);
      eocd.setUint32(0, 0x06054b50, Endian.little);
      eocd.setUint16(4, 0, Endian.little);
      eocd.setUint16(6, 0, Endian.little);
      eocd.setUint16(8, entryCount, Endian.little);
      eocd.setUint16(10, entryCount, Endian.little);
      eocd.setUint32(12, cdBytes.length, Endian.little);
      eocd.setUint32(16, cdStart, Endian.little);
      eocd.setUint16(20, 0, Endian.little);

      output.add(eocd.buffer.asUint8List());

      await File(outputPath).writeAsBytes(output.takeBytes());
      return true;
    } catch (_) {
      return false;
    }
  }

  static final List<int> _crcTable = _buildCrcTable();

  static List<int> _buildCrcTable() {
    final table = List<int>.filled(256, 0);
    for (int i = 0; i < 256; i++) {
      int crc = i;
      for (int j = 0; j < 8; j++) {
        if (crc & 1 != 0) {
          crc = 0xEDB88320 ^ (crc >> 1);
        } else {
          crc >>= 1;
        }
      }
      table[i] = crc;
    }
    return table;
  }

  static int _calculateCrc32(Uint8List data) {
    int crc = 0xFFFFFFFF;
    for (final byte in data) {
      crc = _crcTable[(crc ^ byte) & 0xFF] ^ (crc >> 8);
    }
    return (crc ^ 0xFFFFFFFF) & 0xFFFFFFFF;
  }
}

class _ZipEntry {
  final String name;
  final int localHeaderOffset;
  final int compressedSize;
  final int uncompressedSize;
  final int compressionMethod;
  const _ZipEntry({
    required this.name,
    required this.localHeaderOffset,
    required this.compressedSize,
    required this.uncompressedSize,
    required this.compressionMethod,
  });
}
