/// 反调试/反Root 代码检测器 - 纯 Dart 实现
///
/// 通过扫描 DEX 字符串与类名，识别应用采用的反逆向防护手段，包括反调试、反 Root、
/// 反模拟器、反 Hook、完整性校验、SafetyNet 以及 VPN/代理检测等。
///
/// 所有检测基于关键字与特征字符串匹配完成，不依赖任何平台原生代码。
///
/// 用法：
/// ```dart
/// final result = AntiDebugDetector.detect(dexStrings, classNames);
/// if (result.hasAntiDebug) {
///   print('应用包含反调试代码');
/// }
/// ```
library;

// ========== 风险等级 ==========

/// 反逆向防护风险等级
enum AntiDebugRiskLevel {
  /// 高危 - 强反逆向手段，可能影响动态分析（反调试、反 Hook、完整性校验）
  high,

  /// 中危 - 环境检测手段（反 Root、反模拟器、SafetyNet）
  medium,

  /// 低危 - 辅助检测（VPN/代理检测）
  low,
}

extension AntiDebugRiskLevelLabel on AntiDebugRiskLevel {
  String get label {
    switch (this) {
      case AntiDebugRiskLevel.high:
        return '高危';
      case AntiDebugRiskLevel.medium:
        return '中危';
      case AntiDebugRiskLevel.low:
        return '低危';
    }
  }
}

/// 反逆向防护类别
enum AntiDebugCategory {
  /// 反调试
  antiDebug,

  /// 反 Root
  antiRoot,

  /// 反模拟器
  antiEmulator,

  /// 反 Hook
  antiHook,

  /// 完整性校验
  integrity,

  /// SafetyNet / 认证
  safetynet,

  /// VPN/代理检测
  proxy,
}

extension AntiDebugCategoryLabel on AntiDebugCategory {
  String get label {
    switch (this) {
      case AntiDebugCategory.antiDebug:
        return '反调试';
      case AntiDebugCategory.antiRoot:
        return '反Root';
      case AntiDebugCategory.antiEmulator:
        return '反模拟器';
      case AntiDebugCategory.antiHook:
        return '反Hook';
      case AntiDebugCategory.integrity:
        return '完整性校验';
      case AntiDebugCategory.safetynet:
        return 'SafetyNet';
      case AntiDebugCategory.proxy:
        return 'VPN/代理检测';
    }
  }

  /// 对应的风险等级
  AntiDebugRiskLevel get defaultRiskLevel {
    switch (this) {
      case AntiDebugCategory.antiDebug:
      case AntiDebugCategory.antiHook:
      case AntiDebugCategory.integrity:
        return AntiDebugRiskLevel.high;
      case AntiDebugCategory.antiRoot:
      case AntiDebugCategory.antiEmulator:
      case AntiDebugCategory.safetynet:
        return AntiDebugRiskLevel.medium;
      case AntiDebugCategory.proxy:
        return AntiDebugRiskLevel.low;
    }
  }
}

// ========== 结果模型 ==========

/// 单条反逆向防护发现
class AntiDebugFinding {
  /// 类别（anti_debug/anti_root/anti_emulator/anti_hook/integrity/safetynet/proxy）
  final AntiDebugCategory category;

  /// 命中的关键字/特征
  final String keyword;

  /// 描述（中文）
  final String description;

  /// 匹配上下文（命中该特征的具体字符串原文，便于定位）
  final String context;

  /// 风险等级
  final AntiDebugRiskLevel riskLevel;

  const AntiDebugFinding({
    required this.category,
    required this.keyword,
    required this.description,
    required this.context,
    required this.riskLevel,
  });

  /// 类别中文标签
  String get categoryLabel => category.label;

  /// 风险等级中文标签
  String get riskLabel => riskLevel.label;

  /// 简要摘要
  String get summary => '[$riskLabel][$categoryLabel] $keyword';
}

/// 反逆向防护检测汇总结果
class AntiDebugResult {
  /// 全部发现明细
  final List<AntiDebugFinding> findings;

  /// 各类别命中数量统计
  final Map<AntiDebugCategory, int> categoryCounts;

  const AntiDebugResult({
    required this.findings,
    required this.categoryCounts,
  });

  /// 未检测到任何防护的空结果
  static const AntiDebugResult empty = AntiDebugResult(
    findings: [],
    categoryCounts: {},
  );

  /// 总发现数
  int get totalCount => findings.length;

  /// 是否包含任意反逆向防护
  bool get hasProtection => findings.isNotEmpty;

  /// 是否存在反调试代码
  bool get hasAntiDebug =>
      _count(AntiDebugCategory.antiDebug) > 0;

  /// 是否存在反 Root 代码
  bool get hasAntiRoot =>
      _count(AntiDebugCategory.antiRoot) > 0;

  /// 是否存在反模拟器代码
  bool get hasAntiEmulator =>
      _count(AntiDebugCategory.antiEmulator) > 0;

  /// 是否存在反 Hook 代码
  bool get hasAntiHook =>
      _count(AntiDebugCategory.antiHook) > 0;

  /// 是否存在完整性校验
  bool get hasIntegrityCheck =>
      _count(AntiDebugCategory.integrity) > 0;

  /// 是否存在 SafetyNet 检测
  bool get hasSafetyNet =>
      _count(AntiDebugCategory.safetynet) > 0;

  /// 是否存在 VPN/代理检测
  bool get hasProxyDetection =>
      _count(AntiDebugCategory.proxy) > 0;

  /// 读取指定类别的命中数（不存在则返回 0）
  int _count(AntiDebugCategory c) => categoryCounts[c] ?? 0;

  /// 整体摘要
  String get summary {
    if (findings.isEmpty) return '未检测到反逆向防护代码';
    final parts = <String>[];
    if (hasAntiDebug) parts.add('反调试');
    if (hasAntiRoot) parts.add('反Root');
    if (hasAntiEmulator) parts.add('反模拟器');
    if (hasAntiHook) parts.add('反Hook');
    if (hasIntegrityCheck) parts.add('完整性校验');
    if (hasSafetyNet) parts.add('SafetyNet');
    if (hasProxyDetection) parts.add('VPN/代理检测');
    return '检测到反逆向防护: ${parts.join("、")} (共 $totalCount 项)';
  }
}

// ========== 特征定义（内部使用） ==========

/// 单个反逆向特征定义
class _AntiDebugIndicator {
  /// 类别
  final AntiDebugCategory category;

  /// 关键字
  final String keyword;

  /// 描述（中文）
  final String description;

  const _AntiDebugIndicator({
    required this.category,
    required this.keyword,
    required this.description,
  });
}

// ========== 检测器 ==========

/// 反调试/反Root 代码检测器
///
/// 基于特征字符串匹配扫描 DEX 字符串与类名，识别应用采用的反逆向防护手段。
/// 所有方法均为静态方法，无需实例化。
class AntiDebugDetector {
  AntiDebugDetector._();

  /// 反逆向特征库
  static const List<_AntiDebugIndicator> _indicators = [
    // ---------- 反调试 ----------
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiDebug,
      keyword: 'isDebuggerConnected',
      description: '调用 android.os.Debug.isDebuggerConnected() 检测调试器是否连接',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiDebug,
      keyword: '/proc/self/status',
      description: '读取 /proc/self/status 文件，通过 TracerPid 字段检测调试器附加',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiDebug,
      keyword: 'TracerPid',
      description: '解析 /proc/self/status 中的 TracerPid 字段，非零表示被调试器附加',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiDebug,
      keyword: 'android.os.Debug',
      description: '引用 android.os.Debug 类，可能用于检测调试器或获取调试信息',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiDebug,
      keyword: 'ptrace',
      description: '使用 ptrace 系统调用防止调试器附加（自身附加以阻止其他调试器）',
    ),

    // ---------- 反 Root ----------
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: '/system/app/Superuser',
      description: '检测 Superuser.apk 路径，判断设备是否已 Root',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: '/system/xbin/su',
      description: '检测 su 二进制文件路径，判断设备是否已 Root',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: '/system/bin/su',
      description: '检测 su 二进制文件路径，判断设备是否已 Root',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: 'ro.debuggable',
      description: '读取系统属性 ro.debuggable，判断是否为可调试的系统镜像',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: 'magisk',
      description: '检测 Magisk 框架特征，Magisk 是常用的无系统 Root 方案',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: 'SuperSU',
      description: '检测 SuperSU Root 管理工具特征',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: 'RootBeer',
      description: '引用 RootBeer 库，用于检测设备是否已 Root',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: '/sbin/.magisk',
      description: '检测 Magisk 隐藏目录 /sbin/.magisk，判断设备是否已 Root',

    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiRoot,
      keyword: 'which su',
      description: '执行 which su 命令检测 su 二进制文件是否存在',
    ),

    // ---------- 反模拟器 ----------
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiEmulator,
      keyword: 'qemu',
      description: '检测 QEMU 模拟器特征，判断是否运行于模拟器',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiEmulator,
      keyword: 'goldfish',
      description: '检测 goldfish 设备特征，常见于 Android 模拟器',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiEmulator,
      keyword: 'ranchu',
      description: '检测 ranchu 设备特征，常见于较新的 Android 模拟器',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiEmulator,
      keyword: 'Build.FINGERPRINT',
      description: '读取 Build.FINGERPRINT 判断设备指纹是否为模拟器特征',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiEmulator,
      keyword: 'generic_x86',
      description: '检测 generic_x86 设备型号，常见于 x86 模拟器',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiEmulator,
      keyword: 'sdk_gphone',
      description: '检测 sdk_gphone 设备型号，常见于 Google API 模拟器',
    ),

    // ---------- 反 Hook ----------
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiHook,
      keyword: 'Xposed',
      description: '检测 Xposed 框架，Xposed 可在运行时 Hook Java 方法',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiHook,
      keyword: 'Substrate',
      description: '检测 Substrate(Cydia) 框架，可在运行时 Hook 与修改方法',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiHook,
      keyword: 'Frida',
      description: '检测 Frida 动态插桩框架，Frida 可 Hook Java/Native 方法',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiHook,
      keyword: 'frida-server',
      description: '检测 frida-server 进程或特征文件，判断 Frida 是否运行',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.antiHook,
      keyword: 'riru',
      description: '检测 Riru 模块框架，常作为 Magisk 上的 Hook 注入入口',
    ),

    // ---------- 完整性校验 ----------
    _AntiDebugIndicator(
      category: AntiDebugCategory.integrity,
      keyword: 'GET_SIGNATURES',
      description: '调用 PackageManager.GET_SIGNATURES 获取应用签名，用于校验完整性',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.integrity,
      keyword: 'getPackageInfo',
      description: '调用 getPackageInfo 获取包信息，常用于读取签名进行完整性校验',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.integrity,
      keyword: 'checksum',
      description: '计算文件/数据校验和，用于检测应用是否被篡改',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.integrity,
      keyword: 'md5',
      description: '计算 MD5 摘要，常用于签名或文件完整性校验',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.integrity,
      keyword: 'sha1',
      description: '计算 SHA-1 摘要，常用于签名或文件完整性校验',
    ),

    // ---------- SafetyNet ----------
    _AntiDebugIndicator(
      category: AntiDebugCategory.safetynet,
      keyword: 'com.google.android.gms.safetynet',
      description: '引用 Google SafetyNet API，用于设备完整性认证与兼容性检查',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.safetynet,
      keyword: 'attestation',
      description: '使用 SafetyNet/密钥认证(Attestation)，校验设备与应用真实性',
    ),

    // ---------- VPN/代理检测 ----------
    _AntiDebugIndicator(
      category: AntiDebugCategory.proxy,
      keyword: 'tun0',
      description: '检测 tun0 网络接口，常见于 VPN 连接',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.proxy,
      keyword: 'ppp0',
      description: '检测 ppp0 网络接口，常见于 PPP/VPN 连接',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.proxy,
      keyword: 'ProxySelector',
      description: '使用 ProxySelector 检测系统代理设置',
    ),
    _AntiDebugIndicator(
      category: AntiDebugCategory.proxy,
      keyword: 'http.proxyHost',
      description: '读取 System.getProperty("http.proxyHost") 检测代理设置',
    ),
  ];

  /// 检测 DEX 字符串与类名中的反逆向防护代码
  ///
  /// [dexStrings] DEX 中提取到的字符串集合
  /// [classNames] DEX 中解析到的类名集合
  ///
  /// 返回 [AntiDebugResult]，包含全部发现、各类别命中统计与布尔判断字段。
  static AntiDebugResult detect(
    Set<String> dexStrings,
    Set<String> classNames,
  ) {
    final findings = <AntiDebugFinding>[];
    final seen = <String>{}; // 用于去重（"类别|关键字|来源"）
    final counts = <AntiDebugCategory, int>{};

    // 合并扫描源：字符串与类名
    // 同时扫描字符串与类名，类名单独扫描以保证 source 标注准确
    for (final str in dexStrings) {
      if (str.isEmpty) continue;
      _scanValue(str, str, findings, seen, counts);
    }
    for (final cls in classNames) {
      if (cls.isEmpty) continue;
      _scanValue(cls, cls, findings, seen, counts);
    }

    return AntiDebugResult(
      findings: findings,
      categoryCounts: counts,
    );
  }

  /// 扫描单个值，匹配所有特征并追加发现
  static void _scanValue(
    String value,
    String source,
    List<AntiDebugFinding> findings,
    Set<String> seen,
    Map<AntiDebugCategory, int> counts,
  ) {
    for (final ind in _indicators) {
      if (!_contains(value, ind.keyword)) continue;

      final dedupeKey = '${ind.category}|${ind.keyword}|$source';
      if (!seen.add(dedupeKey)) continue;

      findings.add(AntiDebugFinding(
        category: ind.category,
        keyword: ind.keyword,
        description: ind.description,
        context: source,
        riskLevel: ind.category.defaultRiskLevel,
      ));

      counts[ind.category] = (counts[ind.category] ?? 0) + 1;
    }
  }

  /// 不区分大小写的子串包含判断
  static bool _contains(String value, String keyword) {
    return value.toLowerCase().contains(keyword.toLowerCase());
  }
}
