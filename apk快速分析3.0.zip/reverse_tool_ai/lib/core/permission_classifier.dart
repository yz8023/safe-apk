/// Android 权限风险等级分类器
///
/// 依据 Android 官方权限保护级别将权限划分为普通、危险、签名等级别，
/// 并为每个已知权限提供中文风险说明，便于在逆向分析报告中直观展示风险。
library;

/// Android 权限保护级别
enum PermissionLevel {
  /// 普通权限 - 安装时自动授予，风险较低
  normal,

  /// 危险权限 - 需运行时用户授权，涉及隐私或敏感数据
  dangerous,

  /// 签名权限 - 仅相同签名的应用可自动获取
  signature,

  /// 签名或系统权限 - 签名应用或系统应用可获取
  signatureOrSystem,

  /// 未知权限 - 未收录在已知权限表中，需自行评估
  unknown,
}

/// 单个权限的分类结果
class PermissionClassification {
  /// 权限全名，如 android.permission.READ_CONTACTS
  final String permission;

  /// 风险等级
  final PermissionLevel level;

  /// 中文风险说明
  final String description;

  /// 简短风险标签：'普通' / '危险' / '签名' / '系统' / '未知'
  final String riskLabel;

  const PermissionClassification({
    required this.permission,
    required this.level,
    required this.description,
    required this.riskLabel,
  });
}

/// 权限分类汇总结果
class PermissionClassificationResult {
  /// 全部分类明细
  final List<PermissionClassification> classifications;

  /// 危险权限数量
  final int dangerousCount;

  /// 普通权限数量
  final int normalCount;

  /// 签名/系统权限数量
  final int signatureCount;

  /// 未知权限数量
  final int unknownCount;

  const PermissionClassificationResult({
    required this.classifications,
    required this.dangerousCount,
    required this.normalCount,
    required this.signatureCount,
    required this.unknownCount,
  });

  /// 权限总数
  int get totalCount => classifications.length;

  /// 危险权限明细
  List<PermissionClassification> get dangerousPermissions =>
      classifications
          .where((c) => c.level == PermissionLevel.dangerous)
          .toList();

  /// 普通权限明细
  List<PermissionClassification> get normalPermissions => classifications
      .where((c) => c.level == PermissionLevel.normal)
      .toList();

  /// 签名/系统权限明细
  List<PermissionClassification> get signaturePermissions => classifications
      .where((c) =>
          c.level == PermissionLevel.signature ||
          c.level == PermissionLevel.signatureOrSystem)
      .toList();

  /// 未知权限明细
  List<PermissionClassification> get unknownPermissions => classifications
      .where((c) => c.level == PermissionLevel.unknown)
      .toList();
}

/// Android 权限风险等级分类器
class PermissionClassifier {
  PermissionClassifier._();

  // ============ 危险权限（运行时需授权，涉及隐私/敏感数据） ============

  /// 已知危险权限及其中文风险说明
  static const Map<String, String> _dangerousPermissions = {
    'android.permission.READ_CALENDAR': '读取日历信息，可能导致日程隐私泄露',
    'android.permission.WRITE_CALENDAR': '修改日历信息，可能添加或删除日程',
    'android.permission.READ_CALL_LOG': '读取通话记录，可能导致通话隐私泄露',
    'android.permission.WRITE_CALL_LOG': '修改通话记录，可能删除或伪造通话记录',
    'android.permission.PROCESS_OUTGOING_CALLS': '拦截外拨电话，可能被用于监听通话',
    'android.permission.CAMERA': '访问摄像头，可能被用于偷拍',
    'android.permission.READ_CONTACTS': '读取联系人信息，可能导致隐私泄露',
    'android.permission.WRITE_CONTACTS': '修改联系人信息，可能被恶意篡改',
    'android.permission.GET_ACCOUNTS': '获取设备账户列表，可能泄露账户信息',
    'android.permission.ACCESS_FINE_LOCATION': '获取精确位置信息，可能泄露行踪',
    'android.permission.ACCESS_COARSE_LOCATION': '获取大致位置信息，可能泄露行踪',
    'android.permission.ACCESS_BACKGROUND_LOCATION': '后台获取位置信息，可持续追踪行踪',
    'android.permission.RECORD_AUDIO': '录制音频，可能被用于窃听',
    'android.permission.READ_PHONE_STATE': '读取手机状态(IMEI 等)，可能泄露设备标识',
    'android.permission.READ_PHONE_NUMBERS': '读取手机号码，可能泄露隐私',
    'android.permission.CALL_PHONE': '直接拨打电话，可能产生费用',
    'android.permission.ANSWER_PHONE_CALLS': '接听来电，可能被恶意利用',
    'android.permission.READ_SMS': '读取短信，可能导致隐私泄露',
    'android.permission.SEND_SMS': '发送短信，可能产生费用',
    'android.permission.RECEIVE_SMS': '接收短信，可能拦截验证码',
    'android.permission.RECEIVE_MMS': '接收彩信，可能被恶意利用',
    'android.permission.RECEIVE_WAP_PUSH': '接收 WAP 推送，可能存在安全风险',
    'android.permission.USE_SIP': '使用 SIP 网络电话，可能产生费用',
    'android.permission.ADD_VOICEMAIL': '添加语音邮件，可能被恶意利用',
    'android.permission.BODY_SENSORS': '访问身体传感器(心率等)，可能泄露健康数据',
    'android.permission.BODY_SENSORS_BACKGROUND': '后台访问身体传感器，持续监测健康数据',
    'android.permission.ACTIVITY_RECOGNITION': '识别身体活动(步数等)，可能泄露行为习惯',
    'android.permission.READ_EXTERNAL_STORAGE': '读取外部存储，可能访问敏感文件',
    'android.permission.WRITE_EXTERNAL_STORAGE': '写入外部存储，可能篡改文件',
    'android.permission.MANAGE_EXTERNAL_STORAGE': '管理所有外部存储，可访问全部文件，风险极高',
    'android.permission.READ_MEDIA_IMAGES': '读取媒体图片，可能泄露照片隐私',
    'android.permission.READ_MEDIA_VIDEO': '读取媒体视频，可能泄露视频隐私',
    'android.permission.READ_MEDIA_AUDIO': '读取媒体音频，可能泄露录音隐私',
    'android.permission.POST_NOTIFICATIONS': '发送通知，可能被用于钓鱼或骚扰',
    'android.permission.NEARBY_WIFI_DEVICES': '访问附近 WiFi 设备，可能泄露周边环境信息',
    'android.permission.BLUETOOTH_SCAN': '扫描蓝牙设备，可能泄露周边设备信息',
    'android.permission.BLUETOOTH_CONNECT': '连接蓝牙设备，可能被恶意利用',
    'android.permission.BLUETOOTH_ADVERTISE': '蓝牙广播，可能被用于设备追踪',
  };

  // ============ 普通权限（自动授予，风险较低） ============

  /// 已知普通权限及其中文说明
  static const Map<String, String> _normalPermissions = {
    'android.permission.ACCESS_NETWORK_STATE': '访问网络连接状态',
    'android.permission.ACCESS_WIFI_STATE': '访问 WiFi 连接状态',
    'android.permission.BLUETOOTH': '连接已配对的蓝牙设备',
    'android.permission.BLUETOOTH_ADMIN': '蓝牙管理',
    'android.permission.CHANGE_WIFI_STATE': '修改 WiFi 连接状态',
    'android.permission.CHANGE_NETWORK_STATE': '修改网络连接状态',
    'android.permission.INTERNET': '访问网络',
    'android.permission.VIBRATE': '控制振动器',
    'android.permission.WAKE_LOCK': '保持唤醒锁，阻止设备休眠',
    'android.permission.SET_WALLPAPER': '设置壁纸',
    'android.permission.SET_ALARM': '设置闹钟',
    'android.permission.EXPAND_STATUS_BAR': '展开或收起状态栏',
    'android.permission.RECEIVE_BOOT_COMPLETED': '接收开机完成广播',
    'android.permission.REQUEST_INSTALL_PACKAGES': '请求安装应用包（实际使用中存在风险）',
    'android.permission.FOREGROUND_SERVICE': '运行前台服务',
    'android.permission.FOREGROUND_SERVICE_DATA_SYNC': '运行数据同步前台服务',
    'android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK': '运行媒体播放前台服务',
    'android.permission.FOREGROUND_SERVICE_PHONE_CALL': '运行电话通话前台服务',
    'android.permission.FOREGROUND_SERVICE_LOCATION': '运行定位前台服务',
    'android.permission.FOREGROUND_SERVICE_CAMERA': '运行相机前台服务',
    'android.permission.FOREGROUND_SERVICE_MICROPHONE': '运行麦克风前台服务',
    'android.permission.FOREGROUND_SERVICE_HEALTH': '运行健康相关前台服务',
    'android.permission.FOREGROUND_SERVICE_REMOTE_MESSAGING': '运行远程消息前台服务',
    'android.permission.FOREGROUND_SERVICE_SYSTEM_EXEMPTED': '运行系统豁免前台服务',
    'android.permission.FOREGROUND_SERVICE_FILE_MANAGEMENT': '运行文件管理前台服务',
    'android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION': '运行媒体投影前台服务',
    'android.permission.FOREGROUND_SERVICE_SHORT_SERVICE': '运行短时前台服务',
    'android.permission.FOREGROUND_SERVICE_SPECIAL_USE': '运行特殊用途前台服务',
    'android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE': '运行已连接设备前台服务',
    'android.permission.NFC': '使用 NFC 功能',
    'android.permission.TRANSMIT_IR': '使用红外发射器',
    'android.permission.USE_BIOMETRIC': '使用生物识别',
    'android.permission.USE_FINGERPRINT': '使用指纹',
    'android.permission.HIGH_SAMPLING_RATE_SENSORS': '高采样率传感器访问',
    'android.permission.SCHEDULE_EXACT_ALARM': '调度精确闹钟',
    'android.permission.USE_EXACT_ALARM': '使用精确闹钟',
    'android.permission.QUERY_ALL_PACKAGES': '查询所有已安装应用（实际可能泄露应用列表）',
  };

  // ============ 签名/系统权限（高风险，需签名或系统级授权） ============

  /// 已知签名/系统权限及其中文说明
  static const Map<String, String> _signaturePermissions = {
    'android.permission.BIND_DEVICE_ADMIN': '绑定设备管理服务',
    'android.permission.BIND_ACCESSIBILITY_SERVICE': '绑定无障碍服务，风险极高',
    'android.permission.BIND_APPWIDGET': '绑定应用小部件服务',
    'android.permission.BIND_NFC_SERVICE': '绑定 NFC 服务',
    'android.permission.BIND_INPUT_METHOD': '绑定输入法服务，可能截获输入内容',
    'android.permission.BIND_REMOTEVIEWS': '绑定 RemoteViews 服务',
    'android.permission.BIND_TEXT_SERVICE': '绑定文本服务',
    'android.permission.BIND_VPN_SERVICE': '绑定 VPN 服务，可能拦截网络流量',
    'android.permission.BIND_VOICE_INTERACTION': '绑定语音交互服务',
    'android.permission.BIND_PRINT_SERVICE': '绑定打印服务',
    'android.permission.PACKAGE_USAGE_STATS': '收集应用使用情况统计',
    'android.permission.WRITE_SETTINGS': '修改系统设置',
    'android.permission.WRITE_SECURE_SETTINGS': '修改安全系统设置，风险极高',
    'android.permission.SYSTEM_ALERT_WINDOW': '显示悬浮窗，可能被用于叠加攻击',
    'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS': '请求忽略电池优化',
    'android.permission.BIND_NOTIFICATION_LISTENER_SERVICE': '监听通知，可能截获验证码等敏感信息',
    'android.permission.BIND_SCREENING_SERVICE': '绑定来电筛选服务',
    'android.permission.MOUNT_UNMOUNT_FILESYSTEMS': '挂载或卸载文件系统',
    'android.permission.REBOOT': '重启设备，风险极高',
    'android.permission.DEVICE_POWER': '控制设备电源',
  };

  /// 根据权限保护级别返回简短风险标签
  static String _labelFor(PermissionLevel level) {
    switch (level) {
      case PermissionLevel.normal:
        return '普通';
      case PermissionLevel.dangerous:
        return '危险';
      case PermissionLevel.signature:
        return '签名';
      case PermissionLevel.signatureOrSystem:
        return '系统';
      case PermissionLevel.unknown:
        return '未知';
    }
  }

  /// 分类单个权限，未知权限返回 [PermissionLevel.unknown]
  static PermissionClassification classifyPermission(String permission) {
    final dangerousDesc = _dangerousPermissions[permission];
    if (dangerousDesc != null) {
      return PermissionClassification(
        permission: permission,
        level: PermissionLevel.dangerous,
        description: dangerousDesc,
        riskLabel: _labelFor(PermissionLevel.dangerous),
      );
    }

    final normalDesc = _normalPermissions[permission];
    if (normalDesc != null) {
      return PermissionClassification(
        permission: permission,
        level: PermissionLevel.normal,
        description: normalDesc,
        riskLabel: _labelFor(PermissionLevel.normal),
      );
    }

    final signatureDesc = _signaturePermissions[permission];
    if (signatureDesc != null) {
      return PermissionClassification(
        permission: permission,
        level: PermissionLevel.signature,
        description: signatureDesc,
        riskLabel: _labelFor(PermissionLevel.signature),
      );
    }

    return PermissionClassification(
      permission: permission,
      level: PermissionLevel.unknown,
      description: '未知权限，请自行评估风险',
      riskLabel: _labelFor(PermissionLevel.unknown),
    );
  }

  /// 批量分类权限列表，返回包含全部明细与各级别计数的汇总结果
  static PermissionClassificationResult classify(List<String> permissions) {
    final classifications = <PermissionClassification>[];
    int dangerousCount = 0;
    int normalCount = 0;
    int signatureCount = 0;
    int unknownCount = 0;

    for (final permission in permissions) {
      final classification = classifyPermission(permission);
      classifications.add(classification);
      switch (classification.level) {
        case PermissionLevel.dangerous:
          dangerousCount++;
          break;
        case PermissionLevel.normal:
          normalCount++;
          break;
        case PermissionLevel.signature:
        case PermissionLevel.signatureOrSystem:
          signatureCount++;
          break;
        case PermissionLevel.unknown:
          unknownCount++;
          break;
      }
    }

    return PermissionClassificationResult(
      classifications: classifications,
      dangerousCount: dangerousCount,
      normalCount: normalCount,
      signatureCount: signatureCount,
      unknownCount: unknownCount,
    );
  }
}
