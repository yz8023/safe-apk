import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../models/apk_info.dart';
import '../models/so_symbol.dart';

/// 导出服务
class ExportService {
  /// 导出 APK 分析结果到文本
  static Future<String> exportApkReport(ApkInfo info, {String? obfuscationLevel}) async {
    final buffer = StringBuffer();
    buffer.writeln('=== APK 分析报告 ===');
    buffer.writeln('生成时间: ${DateTime.now()}');
    buffer.writeln('');
    buffer.writeln('包名: ${info.packageName}');
    buffer.writeln('版本: ${info.versionName} (code: ${info.versionCode})');
    buffer.writeln('入口: ${info.mainActivity}');
    buffer.writeln('文件大小: ${info.fileSize} bytes');
    buffer.writeln('DEX 类数: ${info.dexClasses.length}');
    buffer.writeln('权限数: ${info.permissions.length}');
    if (obfuscationLevel != null) {
      buffer.writeln('混淆等级: $obfuscationLevel');
    }
    buffer.writeln('');
    buffer.writeln('=== 权限列表 ===');
    for (final perm in info.permissions) {
      buffer.writeln('  $perm');
    }
    buffer.writeln('');
    buffer.writeln('=== DEX 类列表 (前 100) ===');
    for (final cls in info.dexClasses.take(100)) {
      buffer.writeln('  $cls');
    }

    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'apk_report_${info.packageName}.txt'));
    await file.writeAsString(buffer.toString());
    return file.path;
  }

  /// 导出 SO 分析结果
  static Future<String> exportSoReport(ElfInfo info) async {
    final buffer = StringBuffer();
    buffer.writeln('=== ELF/SO 分析报告 ===');
    buffer.writeln('生成时间: ${DateTime.now()}');
    buffer.writeln('');
    buffer.writeln('架构: ${info.arch}');
    buffer.writeln('类型: ${info.fileType}');
    buffer.writeln('段数量: ${info.sections.length}');
    buffer.writeln('导出符号: ${info.exports.length}');
    buffer.writeln('导入符号: ${info.imports.length}');
    buffer.writeln('');
    buffer.writeln('=== 依赖库 ===');
    for (final dep in info.dependencies) {
      buffer.writeln('  $dep');
    }
    buffer.writeln('');
    buffer.writeln('=== 导出函数 ===');
    for (final sym in info.exports.take(100)) {
      buffer.writeln('  ${sym.name} (${sym.type})');
    }

    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'so_report_${info.arch}.txt'));
    await file.writeAsString(buffer.toString());
    return file.path;
  }
}
