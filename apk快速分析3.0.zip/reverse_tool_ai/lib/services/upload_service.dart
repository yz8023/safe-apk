import 'dart:io';
import 'dart:math' as math;
import 'package:http/http.dart' as http;

/// 流式分片上传服务
///
/// 将一个大文件以固定大小分片，**按序流式读取**并逐片上传，避免一次性把整个文件载入内存。
/// 支持：
/// - 断点续传：从 [startOffset] 或 [queryUploadedOffset] 返回的偏移继续；
/// - 失败重试：单分片上传失败自动重试 [maxRetries] 次；
/// - 进度回调：[onProgress] 回报 0.0 ~ 1.0。
///
/// 设计为目标后端无关：通过 [baseUrl] / [headers] / 分片 URL 拼接规则适配具体 API。
/// 默认分片请求为 `PUT {baseUrl}/part?name=&part=&offset=&end=&total=`，
/// 并携带 `X-Upload-Offset` / `X-Upload-Part` / `X-Upload-Total` 头，便于后端落盘。
class ChunkedUploader {
  final String baseUrl;
  final int chunkSize;
  final Map<String, String> headers;
  final int maxRetries;
  final http.Client _client;

  ChunkedUploader({
    required this.baseUrl,
    this.chunkSize = 5 * 1024 * 1024,
    this.headers = const {},
    this.maxRetries = 3,
    http.Client? client,
  }) : _client = client ?? http.Client();

  /// 上传单个文件。
  /// [onProgress] 回调进度（0.0 ~ 1.0）。[startOffset] 用于断点续传（默认从 0）。
  /// 返回上传结果（文件名、总分片数、总字节数）。
  Future<UploadResult> upload(
    String filePath, {
    void Function(double progress)? onProgress,
    int startOffset = 0,
    String? fileName,
  }) async {
    final file = File(filePath);
    if (!await file.exists()) {
      throw ArgumentError('文件不存在: $filePath');
    }
    final length = await file.length();
    fileName ??= file.uri.pathSegments.last;
    final raf = await file.open(mode: FileMode.read);

    try {
      int offset = math.max(0, startOffset);
      int partNumber = (offset / chunkSize).floor();

      while (offset < length) {
        final end = math.min(offset + chunkSize, length);
        // 流式读取单分片，不一次性载入整文件
        final chunk = await raf.read(end - offset);
        if (chunk.isEmpty) break;

        final url = _buildPartUrl(fileName, partNumber, offset, end, length);
        final ok = await _uploadWithRetry(url, chunk, {
          ...headers,
          'Content-Type': 'application/octet-stream',
          'X-Upload-Offset': '$offset',
          'X-Upload-Part': '$partNumber',
          'X-Upload-Total': '$length',
        });

        if (!ok) {
          throw StateError('分片上传失败，已上传至偏移 $offset / $length');
        }

        offset = end;
        partNumber++;
        onProgress?.call(length == 0 ? 1.0 : offset / length);
      }

      await _complete(fileName, length);

      return UploadResult(
        fileName: fileName,
        totalBytes: length,
        partCount: partNumber,
        uploadedBytes: offset,
      );
    } finally {
      await raf.close();
    }
  }

  /// 查询已上传偏移（用于断点续传）。默认实现请求 `{baseUrl}/status?name=`。
  /// 若后端不支持或请求失败，返回 0（从头开始）。
  Future<int> queryUploadedOffset(String fileName) async {
    try {
      final base = Uri.parse(baseUrl);
      final uri = base.replace(
        pathSegments: [...base.pathSegments, 'status'],
        queryParameters: {'name': fileName},
      );
      final resp = await _client.get(uri, headers: headers);
      if (resp.statusCode == 200) {
        return int.tryParse(resp.body) ?? 0;
      }
    } catch (_) {
      // 忽略，回退到从头上传
    }
    return 0;
  }

  String _buildPartUrl(
    String fileName,
    int part,
    int offset,
    int end,
    int total,
  ) {
    final base = Uri.parse(baseUrl);
    return base
        .replace(
          pathSegments: [...base.pathSegments, 'part'],
          queryParameters: {
            'name': fileName,
            'part': '$part',
            'offset': '$offset',
            'end': '$end',
            'total': '$total',
          },
        )
        .toString();
  }

  Future<bool> _uploadWithRetry(
    String url,
    List<int> chunk,
    Map<String, String> hdrs,
  ) async {
    for (int attempt = 0; attempt < maxRetries; attempt++) {
      try {
        final resp = await _client.put(
          Uri.parse(url),
          headers: hdrs,
          body: chunk,
        );
        if (resp.statusCode >= 200 && resp.statusCode < 300) return true;
      } catch (_) {
        // 网络异常，进入重试
      }
      await Future.delayed(Duration(milliseconds: 200 * (attempt + 1)));
    }
    return false;
  }

  Future<void> _complete(String fileName, int total) async {
    try {
      final base = Uri.parse(baseUrl);
      final uri = base.replace(
        pathSegments: [...base.pathSegments, 'complete'],
        queryParameters: {'name': fileName, 'total': '$total'},
      );
      await _client.post(uri, headers: headers);
    } catch (_) {
      // 完成通知失败不致命，可由后端幂等处理
    }
  }

  /// 释放底层 HTTP 客户端（不再使用时调用）
  void dispose() => _client.close();
}

/// 分片上传结果
class UploadResult {
  final String fileName;
  final int totalBytes;
  final int partCount;
  final int uploadedBytes;

  UploadResult({
    required this.fileName,
    required this.totalBytes,
    required this.partCount,
    required this.uploadedBytes,
  });

  @override
  String toString() =>
      'UploadResult(file=$fileName, parts=$partCount, '
      'bytes=$uploadedBytes/$totalBytes)';
}
