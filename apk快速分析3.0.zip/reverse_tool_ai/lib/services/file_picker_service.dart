import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;

/// 文件选择服务
class FilePickerService {
  /// 选择单个文件
  static Future<String?> pickFile({List<String>? allowedExtensions}) async {
    // Android SAF 对 .so 等非标准扩展名支持不佳，
    // 使用 FileType.any 让用户选择任意文件，再在代码层过滤扩展名。
    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
    );
    if (result == null || result.files.isEmpty) return null;
    final path = result.files.single.path;
    if (path == null) return null;
    // 如果指定了扩展名过滤，检查文件扩展名
    if (allowedExtensions != null && allowedExtensions.isNotEmpty) {
      final ext = p.extension(path).toLowerCase().replaceAll('.', '');
      if (!allowedExtensions.contains(ext)) return null;
    }
    return path;
  }

  /// 选择 APK/SO/DEX 文件
  static Future<String?> pickApkOrSo() async {
    // 不传 allowedExtensions，让用户自由选择
    // 原先使用 FileType.custom + allowedExtensions: ['so']
    // 会导致 Android SAF 无法显示 .so 文件
    return pickFile();
  }

  /// 选择目录
  static Future<String?> pickDirectory() async {
    final result = await FilePicker.platform.getDirectoryPath();
    return result;
  }
}
