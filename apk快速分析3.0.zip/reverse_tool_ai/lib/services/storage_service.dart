import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

/// 存储管理服务
class StorageService {
  /// 获取应用文档目录
  static Future<Directory> getAppDirectory() async {
    final dir = await getApplicationDocumentsDirectory();
    final appDir = Directory(p.join(dir.path, 'reverse_tool_ai'));
    if (!await appDir.exists()) {
      await appDir.create(recursive: true);
    }
    return appDir;
  }

  /// 保存文本到文件
  static Future<String> saveText(String fileName, String content) async {
    final dir = await getAppDirectory();
    final file = File(p.join(dir.path, fileName));
    await file.writeAsString(content);
    return file.path;
  }

  /// 读取文本文件
  static Future<String?> readText(String fileName) async {
    try {
      final dir = await getAppDirectory();
      final file = File(p.join(dir.path, fileName));
      if (await file.exists()) {
        return await file.readAsString();
      }
    } catch (_) {}
    return null;
  }
}
