import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

/// 应用内缓存与临时文件管理（内存回收的一部分）
///
/// 在应用文档目录下维护独立的 `cache` 子目录，用于存放解析中间产物 / 临时文件。
/// 提供缓存大小统计与清理能力，可在切换文件、分析完成或退出时主动释放磁盘与内存占用。
class CacheService {
  static const String _cacheDirName = 'cache';

  /// 获取缓存目录（不存在则创建）
  static Future<Directory> getCacheDirectory() async {
    final appDir = await _appDir();
    final dir = Directory(p.join(appDir.path, _cacheDirName));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<Directory> _appDir() async {
    final dir = await getApplicationDocumentsDirectory();
    final appDir = Directory(p.join(dir.path, 'reverse_tool_ai'));
    if (!await appDir.exists()) await appDir.create(recursive: true);
    return appDir;
  }

  /// 缓存占用字节数（递归统计）
  static Future<int> cacheSize() async {
    try {
      final dir = await getCacheDirectory();
      int total = 0;
      await for (final e in dir.list(recursive: true)) {
        if (e is File) total += await e.length();
      }
      return total;
    } catch (_) {
      return 0;
    }
  }

  /// 清理缓存目录下的所有文件与子目录（保留 cache 目录本身）
  /// 返回被清理的条目数量
  static Future<int> clearCache() async {
    int removed = 0;
    try {
      final dir = await getCacheDirectory();
      if (await dir.exists()) {
        final list = await dir.list().toList();
        for (final e in list) {
          try {
            if (e is File) {
              await e.delete();
              removed++;
            } else if (e is Directory) {
              await e.delete(recursive: true);
              removed++;
            }
          } catch (_) {
            // 单个条目删除失败不影响其余
          }
        }
      }
    } catch (_) {
      // 忽略目录不可访问等异常
    }
    return removed;
  }

  /// 清理临时文件（默认仅删除 cache 目录下 *.tmp，也可指定目录）
  /// 返回被清理的文件数量
  static Future<int> clearTemp({String? dirPath}) async {
    int removed = 0;
    final dir = dirPath != null
        ? Directory(dirPath)
        : await getCacheDirectory();
    try {
      if (await dir.exists()) {
        final list = await dir.list(recursive: true).toList();
        for (final e in list) {
          if (e is File && e.path.endsWith('.tmp')) {
            await e.delete();
            removed++;
          }
        }
      }
    } catch (_) {
      // 忽略
    }
    return removed;
  }
}
