# Ark加固 项目交接文档

## 1. 项目概述

**项目名称：** Ark加固 (Ark APK Reinforce)
**当前版本：** v3.2 (基于 v2.3 核心 + v3.2 新增模块合并)
**项目类型：** Android APK 加固工具 (Android Studio Gradle 项目)
**开发语言：** Java + C++ (NDK/CMake)

Ark加固是一款在 Android 设备上运行的 APK 加固工具，对目标 APK 进行 DEX 加密隐藏、VMP 虚拟机保护、签名校验、反调试等安全增强处理。

---

## 2. 开发进度

### ✅ 已完成功能

**核心加固功能（来自 2.3）：**
- [x] APK 解析与重建 (AndroidManifest 篡改)
- [x] DEX 加密隐藏 —— 将原始 DEX 加密后注入 SO 文件
- [x] VMP 虚拟机保护 —— 抽取 Java 方法为 vmp.bin，通过 Native 解释器执行
- [x] Application 代理 —— 替换入口 Application 为壳 StubApp
- [x] AppComponentFactory 替换 —— 拦截 Activity/Service/Receiver 实例化
- [x] ELF section 注入 —— 将 vmp.bin 注入到 SO 的 .ark section
- [x] 签名工具集成 —— JKS 签名、V1/V2/V3 签名方案
- [x] ZIP 对齐 (ZipAlign)
- [x] SO 名称随机化预设
- [x] 加固器本体 UI (ArkMainActivity)

**v3.2 新增模块：**
- [x] `anti/` —— 反调试检测 (AntiDebug.cpp) + 内存防护 (MemoryProtect.cpp)
- [x] `security/` —— 签名校验 (SignatureChecker.cpp) + SO 签名校验 (SoSignatureChecker.cpp) + Native 签名校验
- [x] `crypt/` —— 动态密钥生成 (DynamicKeyGenerator.cpp) + 白盒解密 (WhiteBoxDecrypt.cpp)
- [x] `dex/` —— 类粒度解密 (ClassDecryptor.cpp) + DEX 完整性校验 (DexIntegrity.cpp)
- [x] `jit/` —— VMP JIT 编译加速 (VmpJIT.cpp)
- [x] `cache/` —— VMP 缓存优化 (VmpCache.cpp)
- [x] `dispatcher/` —— VMP 指令分发 (VmpDispatcher.cpp)
- [x] `compat/` —— 版本兼容适配 (VersionAdapter.cpp) + 降级管理 (DowngradeManager.cpp)
- [x] `grayscale/` —— 灰度发布管理 (GrayscaleManager.cpp)
- [x] `log/` —— 安全日志 (SecureLogger.cpp)
- [x] `monitor/` —— 性能监控 (PerformanceMonitor.cpp)
- [x] Java 安全类: AntiDebugDetector, MemoryProtector, RootDetector, SignatureChecker, SignatureConfig
- [x] Java 加密类: RandomizationUtils, SecureClassLoader
- [x] Provider 实例化支持 (nativeInstantiateProvider)

### ❌ 待开发 / 已知问题

**🔴 紧急：**
- [ ] **编译验证** —— 22 个新增 CPP 源文件尚未通过完整 NDK 编译，可能存在依赖缺失
- [ ] **VMP JIT 稳定性** —— VmpJIT.cpp 将 VMP 指令动态编译为 ARM64 机器码，内存管理和代码生成质量需要验证
- [ ] **白盒解密自洽性** —— WhiteBoxDecrypt.cpp 依赖 whitebox_round0.inc 预计算表，需确认与加密端密钥一致
- [ ] **anti/AntiDebug.cpp** —— 反调试检测可能误杀开发设备（Frida 端口检测），需增加调试模式豁免
- [ ] **security/SignatureChecker.cpp** —— 签名校验失败直接 exit，需改为可配置的降级策略

**🟡 中等：**
- [ ] **Provider 初始化时序** —— ContentProvider 在 Application.onCreate 之前初始化，可能因 DEX 未加载完毕而 ClassNotFoundException
- [ ] **JNI 注册完整性** —— 新增模块可能依赖尚未注册的 Native 方法，需检查 JNI_OnLoad
- [ ] **ArkSelfHash 空壳** —— 当前始终返回 TRUE，需要实现真正的 APK 自校验
- [ ] **MemoryProtector.cpp** —— 依赖 `LibMemProtect` 外部库，需确认可用
- [ ] **NativeSignatureChecker.cpp** —— 依赖 `LibNativeSignatureChecker` 外部类型，需确认可用
- [ ] **SoSignatureChecker.cpp** —— 依赖 `LibSoSignatureChecker` 外部类型，需确认可用
- [ ] **ClassDecryptor.cpp** —— 依赖 `clazz_decryptor` 和 `ArkDexLoader` 的类型定义
- [ ] **DexIntegrity.cpp** —— 依赖外部类型 `dex_digest_struct`

**🟢 低优先级：**
- [ ] 灰度策略配置文件格式定义
- [ ] 性能监控数据上报接口
- [ ] 安全日志 crash 信息加密格式
- [ ] SecureClassLoader Native 方法实现 (decryptClassData / freeClassData)
- [ ] MemoryProtector.java Native 方法实现 (在 ArkTool.so 中)

---

## 3. 项目结构

```
Ark加固2.3/
├── Arkjiagu/                          # 主项目 (Android Studio)
│   ├── build.gradle                   # 根构建脚本
│   ├── settings.gradle
│   ├── gradle.properties
│   ├── gradlew / gradlew.bat
│   ├── local.properties
│   ├── gradle/
│   │   ├── wrapper/
│   │   └── libs.versions.toml
│   └── app/
│       ├── build.gradle               # 模块构建脚本
│       ├── proguard-rules.pro
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── assets/
│           │   ├── Ark.jks            # 签名密钥库
│           │   └── so_name_presets.json
│           ├── res/                   # UI 资源
│           ├── java/com/ark/
│           │   ├── jiagu/             # 加固核心逻辑
│           │   │   ├── ArkMainActivity.java        # UI 入口
│           │   │   ├── ArkJiaguUtils.java          # 核心加固 (1806行)
│           │   │   ├── ArkSettingsManager.java
│           │   │   ├── ApkSignUtil.java
│           │   │   ├── JksSha256Util.java
│           │   │   ├── ZipAlign.java
│           │   │   ├── RandomizationUtils.java     # [v3.2 新增]
│           │   │   └── vm/
│           │   │       ├── VmpJiaguEntry.java       # VMP 加固入口
│           │   │       ├── VmpUtils.java            # VMP 格式定义
│           │   │       └── VmpInvokeCustomHelper.java
│           │   ├── jar/               # XML 转 AXML 库
│           │   ├── secure/
│           │   │   └── SecureClassLoader.java       # [v3.2 新增]
│           │   └── security/          # [v3.2 新增全模块]
│           │       ├── AntiDebugDetector.java
│           │       ├── MemoryProtector.java
│           │       ├── RootDetector.java
│           │       ├── SignatureChecker.java
│           │       └── SignatureConfig.java
│           └── cpp/                   # Native C++ (NDK)
│               ├── CMakeLists.txt     # CMake 构建配置
│               ├── ArkStub.cpp        # 加固壳入口
│               ├── ArkTool.cpp        # 加固器工具 (DEX加密/ELF注入)
│               ├── ArkDexLoader.cpp   # DEX 解密加载
│               ├── ArkEnvGuard.cpp    # 环境检测
│               ├── ArkSelfHash.cpp    # 自校验
│               ├── ArkVMP.cpp         # VMP JNI 桥接
│               ├── VmpRuntime.cpp     # VMP 运行时调度
│               ├── VmpInterpreter.cpp # VMP 解释器循环
│               ├── VmpParser.cpp      # vmp.bin 解析
│               ├── VmContext.cpp      # VMP 上下文管理
│               ├── VmHandlers.cpp     # 250+ Dalvik 指令处理器
│               ├── VmOpcodeHandler.cpp
│               ├── VmpTypes.h         # 核心数据结构
│               ├── VmOpcodeDef.h      # Opcode 定义
│               ├── sha256.cpp
│               ├── android/           # Android 系统头文件
│               ├── zipalign/          # ZIP 对齐 Native
│               ├── anti/              # [v3.2 新增] 反调试
│               ├── cache/             # [v3.2 新增] VMP 缓存
│               ├── compat/            # [v3.2 新增] 兼容适配
│               ├── crypt/             # [v3.2 新增] 加密
│               ├── dex/               # [v3.2 新增] 类解密
│               ├── dispatcher/        # [v3.2 新增] 指令分发
│               ├── grayscale/         # [v3.2 新增] 灰度发布
│               ├── jit/               # [v3.2 新增] JIT 编译
│               ├── log/               # [v3.2 新增] 安全日志
│               ├── monitor/           # [v3.2 新增] 性能监控
│               └── security/          # [v3.2 新增] 签名/内存保护
└── Arkjiagu_v3.2/                     # v3.2 原始源码 (参考)
```

---

## 4. 开发环境

### 必需环境

| 组件 | 版本要求 | 说明 |
|------|---------|------|
| **Android Studio** | Hedgehog (2023.1.1) 或更高 | 推荐使用最新稳定版 |
| **Android SDK** | API 31+ (Android 12) | compileSdk = 31 |
| **Android NDK** | r21+ (推荐 r26) | C++17 特性需要，CMake 3.22+ |
| **JDK** | 17 (含在 Android Studio 中) | Gradle 8.x 要求 |
| **Gradle** | 8.4 (wrapper 自动下载) | 项目自带 gradle-wrapper |
| **CMake** | 3.22.1+ | NDK 自带 |

### 可选环境

| 组件 | 用途 |
|------|------|
| **Android 设备/模拟器** | 运行加固器本体，测试加固效果 |
| **adb** | 安装 APK、查看 logcat 崩溃日志 |
| **IDA Pro / Ghidra** | 逆向分析 Native SO 文件 |

### 快速配置

1. 用 Android Studio 打开 `Arkjiagu/` 目录
2. SDK Manager 安装 API 31 SDK Platform + NDK (Side by Side)
3. 在 `local.properties` 中配置：
```
sdk.dir=/path/to/Android/Sdk
ndk.dir=/path/to/Android/Sdk/ndk/26.1.10909125
```

---

## 5. 构建与输出

### 构建命令

```bash
# 清理并构建 Debug APK
./gradlew clean assembleDebug

# 构建 Release APK
./gradlew assembleRelease

# 仅编译 Native SO（不打包 APK）
./gradlew :app:externalNativeBuildDebug

# 查看构建日志
./gradlew assembleDebug --info
```

### 输出产物

| 产物 | 路径 | 说明 |
|------|------|------|
| **加固器 APK (Debug)** | `app/build/outputs/apk/debug/app-debug.apk` | 带调试签名的加固器 |
| **加固器 APK (Release)** | `app/build/outputs/apk/release/app-release.apk` | 需配置签名 |
| **ArkStub.so** | `app/build/intermediates/cmake/` | 加固壳 Native 库 |
| **ArkTool.so** | `app/build/intermediates/cmake/` | 加固器工具 Native 库 |

### SO 库说明

项目构建两个 SO：
1. **libArkStub.so** —— 加固壳，注入到目标 APK 中，负责运行时 DEX 解密和 VMP 执行
2. **libArkTool.so** —— 加固器本体使用，提供 DEX 加密、ELF 注入、签名校验等工具函数

---

## 6. 关键技术架构

### 加固流程（加固器端）

```
原 APK → 解压
         → 解析 AndroidManifest → 篡改 Application/Factory
         → 提取 DEX → 加密 → 注入到 SO section
         → 抽取 VMP 方法 → 生成 vmp.bin → 注入到 SO section
         → 生成壳 Smali (StubApp/StubFactory)
         → 替换 SO 文件
         → 重新签名
         → ZIP 对齐
         → 输出加固 APK
```

### 运行时流程（加固后应用）

```
系统启动应用
  → StubApp.attachBaseContext
    → native_attachBaseContext
      → ArkEnvGuard_CheckAndLoad_Impl（环境检测 + 签名校验）
      → LoaderDEX（解密 DEX 并注入 ClassLoader）
  → StubApp.onCreate
    → native_onCreate
      → ArkEnvGuard_StartRealApplication_Impl（启动真实 Application）
  → 正常应用生命周期
  → VMP 方法调用时 → VmpRuntime → VmpInterpreter → VmHandlers
```

### VMP 版本协议

- **version=6**: vmOpcode 字段直接保存真实 dex opcode（跳过映射表）
- vmp.bin 格式：`header | insn_table | method_body`
- 写入端: `VmpUtils.java` / `ArkTool.cpp` native_buildVmpBin
- 读取端: `VmpParser.cpp` parseVmpBin

---

## 7. 已知崩溃点与修复建议

### 🔴 P0 - 编译失败风险

**问题：** 22 个新增 .cpp 文件引用了外部依赖（`LibMemProtect`, `LibSignatureChecker`, `clazz_decryptor` 等），这些依赖可能不存在。

**修复方向：**
1. 先执行 `./gradlew assembleDebug` 获取完整编译错误
2. 对缺失的外部依赖，创建 stub/空壳实现
3. 检查 CMakeLists.txt 是否缺少 target_link_libraries
4. 确认所有 .h 头文件对应的 .cpp 实现完整

### 🔴 P0 - 签名校验误杀

**文件：** `security/SignatureChecker.cpp`
**问题：** 签名校验失败调用 `exit(1)` 直接终止进程
**修复：** 增加灰度开关，默认仅在 Release 模式生效

### 🔴 P0 - 反调试误杀开发设备

**文件：** `anti/AntiDebug.cpp`
**问题：** Frida 端口 27042 检测、TracerPid 检测可能在开发设备上误触发
**修复：** 增加 `isDebugBuild()` 判断，Debug 模式跳过检测

### 🟡 P1 - Provider 初始化时序

**文件：** `ArkStub.cpp` nativeInstantiateProvider
**问题：** ContentProvider 在 Application.onCreate 之前初始化，DEX 可能未加载
**修复：** 在 `attachBaseContext` 阶段预加载 Provider 类

---

## 8. 快速上手指南

### 第一次构建

```bash
cd Arkjiagu/
export ANDROID_HOME=/path/to/sdk
./gradlew assembleDebug
```

### 调试崩溃

```bash
# 安装加固器
adb install app/build/outputs/apk/debug/app-debug.apk

# 查看崩溃日志
adb logcat -s "AndroidRuntime:E" "ArkVMP:*" "DEBUG:*"

# 如果加固器本体闪退
adb logcat -b crash | grep -A20 "FATAL"
```

### 测试加固功能

1. 在设备上打开 Ark加固 App
2. 选择目标 APK
3. 配置加固选项（DEX加密 / VMP保护 / 签名校验）
4. 开始加固
5. 获取输出的加固后 APK
6. 安装加固后 APK 验证运行

---

## 9. 关键文件索引

| 想做什么 | 改哪个文件 |
|---------|----------|
| 修改 DEX 加密方式 | `ArkTool.cpp` (b方法), `ArkDexLoader.cpp` |
| 修改 VMP 指令集 | `VmpTypes.h`, `VmOpcodeDef.h`, `VmHandlers.cpp` |
| 修改 vmp.bin 格式 | `VmpUtils.java`, `VmpParser.cpp` |
| 修改反调试策略 | `anti/AntiDebug.cpp`, `ArkEnvGuard.cpp` |
| 修改签名校验 | `security/SignatureChecker.cpp`, `SignatureConfig.java` |
| 修改加固流程 UI | `ArkJiaguUtils.java`, `ArkMainActivity.java` |
| 新增 Native 模块 | 在 `cpp/` 下创建目录，更新 `CMakeLists.txt` |
| 新增 Java 模块 | 在 `java/com/ark/` 下创建包 |

---

## 10. 注意事项

1. **不要随意修改 `VmpTypes.h` 中的结构体** —— 影响 vmp.bin 二进制兼容性
2. **版本升级时确保 `VmpParser.cpp` 和 `VmpUtils.java` 版本号一致**
3. **密钥派生算法 (`deriveDexKeyFromSignKey64`) 加密端和解密端必须完全一致**
4. **`Ark.jks` 是签名密钥库，切勿泄漏**
5. **加固器需要 READ/WRITE_EXTERNAL_STORAGE 权限访问 APK 文件**
6. **Android 11+ Scoped Storage 限制，需使用 SAF 或应用私有目录**

---

*文档生成时间: 2025年7月13日*
*项目状态: 迁移完成，待编译验证*
