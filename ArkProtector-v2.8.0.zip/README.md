# Arkjiagu v3.21 - Android应用加固工具

## 项目概述

Arkjiagu是一款功能强大的Android应用加固工具，提供全方位的安全保护功能，包括VMP虚拟化保护、DEX加密、资源混淆、代码混淆、反调试、Root检测等多项安全特性。

**当前版本：** v3.21  
**项目状态：** 开发中，核心功能已完成，正在进行问题修复和优化

---

## 开发进度

### ✅ 已完成功能

#### 1. 核心加固功能
- ✅ **VMP虚拟化保护** - 方法抽取和虚拟化执行
- ✅ **DEX加密** - DEX文件加密和解密
- ✅ **SO加固** - Native库保护和注入
- ✅ **资源混淆** - 使用AndResGuard混淆资源文件
- ✅ **资源加密** - AES加密assets文件
- ✅ **资源ID重映射** - 重映射资源ID防止静态分析
- ✅ **字符串加密** - 使用StringFog加密字符串常量
- ✅ **函数抽取** - 抽取并加密方法字节码
- ✅ **控制流混淆** - 使用OLLVM混淆控制流
- ✅ **方法隐藏** - 通过反射隐藏方法调用

#### 2. 运行时安全功能（Java层）
- ✅ **签名校验** (SignatureChecker) - 验证应用签名完整性
- ✅ **Root检测** (RootDetector) - 检测设备是否Root
- ✅ **反调试检测** (AntiDebugDetector) - 检测调试器和分析工具
- ✅ **内存保护** (MemoryProtector) - 防止内存读取和修改
- ✅ **配置管理** (SecurityConfigManager) - 统一的功能配置管理

#### 3. 运行时安全功能（C++层）
- ✅ **反调试** (AntiDebug) - C++层反调试检测
- ✅ **内存保护** (MemoryProtect) - 内存区域保护
- ✅ **动态密钥生成** (DynamicKeyGenerator) - 动态生成加密密钥
- ✅ **白盒解密** (WhiteBoxDecrypt) - 白盒密码学解密
- ✅ **类解密** (ClassDecryptor) - DEX类解密
- ✅ **DEX完整性校验** (DexIntegrity) - DEX文件完整性验证
- ✅ **版本降级管理** (DowngradeManager) - 防止版本降级攻击
- ✅ **安全日志** (SecureLogger) - 安全日志记录
- ✅ **性能监控** (PerformanceMonitor) - 性能监控和统计
- ✅ **灰度发布管理** (GrayscaleManager) - 灰度发布和设备筛选

#### 4. 构建工具
- ✅ **资源混淆工具** (res_guard.py) - AndResGuard资源混淆
- ✅ **资源加密工具** (asset_encrypt.py) - AES资源加密
- ✅ **资源ID重映射** (arsc_remap.py) - ARSC资源ID重映射
- ✅ **字符串加密工具** (string_encrypt.py) - StringFog字符串加密
- ✅ **函数抽取工具** (method_extract.py) - 方法抽取和加密
- ✅ **APK混淆工具** (obfuscate_apk.py) - 一键APK混淆
- ✅ **ZIPALIGN工具** - APK对齐优化
- ✅ **签名工具** - APK签名功能

#### 5. 配置系统
- ✅ **功能开关配置** (security_config.json) - 完整的功能配置系统
- ✅ **Java配置管理** (SecurityConfigManager.java)
- ✅ **C++配置管理** (ConfigManager.cpp/h)
- ✅ **Application集成** (ArkApplication.java)

#### 6. 用户界面
- ✅ **主界面** - APK选择和加固操作
- ✅ **设置界面** - 功能配置和参数设置
- ✅ **关于界面** - 项目信息展示
- ✅ **日志显示** - 实时日志输出

#### 7. 问题修复
- ✅ **AntiDebugDetector修复** - 修复7个严重问题（检测间隔、响应策略、模拟器检测、端口超时、资源泄漏）
- ✅ **C++模块修复** - 修复多个问题（随机数种子、内存保护、密钥验证等）
- ✅ **应用启动问题修复** - 修复卡开屏问题（异步清理、异常处理、简化初始化）

---

### 🔧 待开发内容

#### 1. 功能优化
- ⏳ **VMP抽取规则优化** - 改进方法抽取规则，提高覆盖率
- ⏳ **资源混淆深度优化** - 增强AndResGuard混淆效果
- ⏳ **字符串加密优化** - 优化加密算法和性能
- ⏳ **控制流混淆增强** - 增加更多混淆模式
- ⏳ **函数抽取优化** - 改进抽取算法和桩代码注入

#### 2. 性能优化
- ⏳ **加固速度优化** - 优化加固流程，减少处理时间
- ⏳ **内存使用优化** - 降低内存占用
- ⏳ **启动速度优化** - 优化应用启动时间
- ⏳ **DEX解密优化** - 优化DEX解密性能

#### 3. 安全增强
- ⏳ **反模拟器检测增强** - 增加更多模拟器检测方法
- ⏳ **反Hook检测** - 添加Hook检测功能
- ⏳ **反注入检测** - 检测代码注入攻击
- ⏳ **反篡改检测** - 增强文件篡改检测
- ⏳ **网络通信加密** - 加固网络通信

#### 4. 功能扩展
- ⏳ **多DEX支持优化** - 改进多DEX处理
- ⏳ **插件化支持** - 支持插件化应用
- ⏳ **热修复支持** - 支持热修复功能
- ⏳ **加固策略模板** - 提供预设加固策略
- ⏳ **批量加固** - 支持批量APK加固

#### 5. 工具完善
- ⏳ **资源ID重映射完善** - 实现完整的ARSC解析和重映射
- ⏳ **函数抽取工具完善** - 完善DEX解析和桩代码注入
- ⏳ **混淆效果评估** - 添加混淆效果评估工具
- ⏳ **安全测试工具** - 提供安全测试工具

#### 6. 用户界面优化
- ⏳ **界面美化** - 优化UI设计
- ⏳ **操作指引** - 添加使用说明和教程
- ⏳ **进度显示** - 显示详细进度信息
- ⏳ **错误提示** - 优化错误提示信息

---

## 开发环境

### 系统要求
- **操作系统**: Ubuntu 24.04 LTS 或 Windows 10/11
- **内存**: 至少 8GB RAM
- **存储**: 至少 20GB 可用空间

### 开发工具

#### 必需工具
- **JDK**: JDK 8 / JDK 11 / JDK 17 / JDK 21
- **Android SDK**: Android SDK (API Level 21+)
- **Android NDK**: Android NDK r21e 或更高版本
- **Gradle**: Gradle 8.13
- **CMake**: CMake 3.10+

#### 推荐工具
- **Android Studio**: Android Studio Arctic Fox 或更高版本
- **Python**: Python 3.8+ (用于运行构建工具)
- **Git**: Git 2.0+

### Python依赖
```bash
pip install androguard
pip install pycryptodome
pip install pyyaml
```

### 项目结构
```
Arkjiagu/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/
│   │   │   │   └── com/ark/jiagu/
│   │   │   │       ├── ArkMainActivity.java      # 主界面
│   │   │   │       ├── ArkApplication.java       # Application类
│   │   │   │       ├── ArkJiaguUtils.java        # 工具类
│   │   │   │       └── ArkSettingsManager.java   # 设置管理
│   │   │   ├── cpp/
│   │   │   │   ├── ArkStub.cpp                  # Native入口
│   │   │   │   ├── CMakeLists.txt               # CMake配置
│   │   │   │   ├── anti/                        # 反调试模块
│   │   │   │   ├── crypt/                       # 加密解密模块
│   │   │   │   ├── dex/                         # DEX处理模块
│   │   │   │   ├── grayscale/                   # 灰度发布模块
│   │   │   │   ├── log/                         # 日志模块
│   │   │   │   ├── monitor/                     # 监控模块
│   │   │   │   └── compat/                      # 兼容层
│   │   │   ├── assets/
│   │   │   │   └── security_config.json         # 安全配置
│   │   │   └── res/                             # 资源文件
│   │   └── AndroidManifest.xml
│   ├── build.gradle                             # App构建配置
│   └── proguard-rules.pro                       # ProGuard规则
├── tools/                                       # 构建工具
│   ├── res_guard.py                            # 资源混淆
│   ├── asset_encrypt.py                        # 资源加密
│   ├── arsc_remap.py                           # 资源ID重映射
│   ├── string_encrypt.py                       # 字符串加密
│   ├── method_extract.py                       # 函数抽取
│   └── obfuscate_apk.py                        # APK混淆
├── build.gradle                                 # 项目构建配置
├── settings.gradle                              # Gradle设置
└── gradlew                                      # Gradle包装脚本
```

---

## 输出要求

### 构建输出

#### APK文件
- **Debug版本**: `app/build/outputs/apk/debug/app-debug.apk`
- **Release版本**: `app/build/outputs/apk/release/app-release-unsigned.apk`
- **签名版本**: 需要手动签名

#### 架构支持
- arm64-v8a (64位ARM)
- armeabi-v7a (32位ARM)
- x86 (32位Intel)
- x86_64 (64位Intel)

### 构建命令

#### 清理项目
```bash
./gradlew clean
```

#### 构建Debug版本
```bash
./gradlew assembleDebug
```

#### 构建Release版本
```bash
./gradlew assembleRelease
```

#### 安装到设备
```bash
./gradlew installDebug
```

---

## 使用说明

### 1. 环境配置
1. 安装JDK、Android SDK、Android NDK
2. 配置环境变量（JAVA_HOME, ANDROID_HOME, ANDROID_NDK_HOME）
3. 安装Python依赖：`pip install -r requirements.txt`

### 2. 导入项目
1. 使用Android Studio打开项目
2. 等待Gradle同步完成
3. 配置local.properties文件中的SDK路径

### 3. 构建项目
```bash
./gradlew assembleRelease
```

### 4. 运行应用
1. 连接Android设备或启动模拟器
2. 运行应用：`./gradlew installDebug`
3. 或在Android Studio中点击运行按钮

### 5. 使用加固功能
1. 打开应用，授予存储权限
2. 点击"选择APK"按钮选择要加固的APK文件
3. 点击设置按钮配置加固选项
4. 等待加固完成
5. 加固后的APK会保存在设置的输出目录

---

## 配置说明

### 安全配置文件 (security_config.json)

```json
{
  "antiDebug": {
    "enabled": true,
    "detectionInterval": 5000,
    "responseStrategy": "gradual"
  },
  "rootDetection": {
    "enabled": true,
    "responseStrategy": "gradual"
  },
  "memoryProtection": {
    "enabled": true,
    "protectionLevel": "HIGH"
  },
  "vmp": {
    "enabled": true,
    "extractRules": []
  }
}
```

### 功能开关说明
- **antiDebug**: 反调试检测
- **rootDetection**: Root检测
- **memoryProtection**: 内存保护
- **vmp**: VMP虚拟化保护

---

## 已知问题

### 1. 应用启动问题
- **状态**: 已修复
- **问题**: 应用卡在开屏页面
- **解决方案**: 异步清理工作目录，增强异常处理，简化初始化流程

### 2. 资源ID重映射
- **状态**: 功能简化
- **问题**: 当前实现只是复制文件，未实现真正的重映射
- **解决方案**: 需要完整解析ARSC结构并实现重映射

### 3. 函数抽取工具
- **状态**: 功能简化
- **问题**: 当前实现只是创建示例数据，未实现完整的DEX解析和桩代码注入
- **解决方案**: 需要完整解析DEX结构并实现桩代码注入

---

## 技术栈

### Java层
- **语言**: Java
- **最小SDK**: API 21 (Android 5.0)
- **目标SDK**: API 34 (Android 14)
- **构建工具**: Gradle 8.13

### C++层
- **语言**: C++
- **标准**: C++11
- **构建工具**: CMake
- **NDK版本**: r21e+

### Python工具
- **语言**: Python 3.8+
- **主要库**: androguard, pycryptodome, pyyaml

---

## 贡献指南

### 代码规范
- Java代码遵循Google Java Style Guide
- C++代码遵循Google C++ Style Guide
- Python代码遵循PEP 8

### 提交规范
- 使用清晰的commit message
- 每次提交只包含一个功能或修复
- 提交前确保代码通过编译和测试

### 测试要求
- 新功能需要添加测试用例
- 修复bug需要添加回归测试
- 确保所有测试通过后再提交

---

## 许可证

本项目仅供学习和研究使用，请勿用于非法用途。

---

## 联系方式

如有问题或建议，请联系项目维护者。

---

## 更新日志

### v3.21 (2026-07-02)
- ✅ 移植v3.3bug版本的所有安全功能
- ✅ 修复AntiDebugDetector的7个严重问题
- ✅ 修复C++模块的多个问题
- ✅ 添加完整的功能配置系统
- ✅ 修复应用卡开屏问题
- ✅ 添加资源保护和代码保护工具

### v3.1
- 初始版本
- 基础加固功能

---

## 致谢

感谢所有为这个项目做出贡献的开发者。

---

**注意**: 本项目仅供学习和研究使用，使用本工具加固的应用请确保遵守相关法律法规。