#!/usr/bin/env python3
"""
签名密钥管理工具
用于提取和配置APK签名信息
"""

import sys
import os
import subprocess
import json
import hashlib
from pathlib import Path

class SignatureKeyManager:
    def __init__(self):
        self.config_file = "sign_config.json"
        self.config = self.load_config()

    def load_config(self):
        """加载配置文件"""
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def save_config(self):
        """保存配置文件"""
        # 使用绝对路径保存配置文件
        script_dir = os.path.dirname(os.path.abspath(__file__))
        config_path = os.path.join(script_dir, self.config_file)

        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=2, ensure_ascii=False)
        print(f"✓ 配置已保存到 {config_path}")

    def extract_apk_signature(self, apk_path):
        """提取APK签名信息"""
        if not os.path.exists(apk_path):
            print(f"✗ APK文件不存在: {apk_path}")
            return None

        print(f"\n正在提取APK签名: {apk_path}")

        # 使用apksigner或keytool提取签名
        try:
            # 方法1: 使用keytool
            cmd = [
                "keytool",
                "-printcert",
                "-jarfile", apk_path
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

            if result.returncode == 0:
                output = result.stdout
                # 解析SHA256签名
                sha256_hash = self.parse_sha256_from_output(output)
                md5_hash = self.parse_md5_from_output(output)

                if sha256_hash:
                    print(f"✓ SHA256签名: {sha256_hash}")
                    print(f"✓ MD5签名: {md5_hash}")

                    return {
                        "sha256": sha256_hash,
                        "md5": md5_hash,
                        "apk_path": apk_path
                    }
                else:
                    print(f"✗ 无法从输出中解析签名信息")
                    print(f"输出内容: {output[:200]}")
            else:
                print(f"✗ keytool执行失败: {result.stderr}")

        except subprocess.TimeoutExpired:
            print(f"✗ keytool执行超时")
        except Exception as e:
            print(f"✗ 提取签名失败: {e}")

        return None

    def parse_sha256_from_output(self, output):
        """从keytool输出中解析SHA256签名"""
        lines = output.split('\n')
        for line in lines:
            if 'SHA256:' in line:
                # 提取SHA256: 后面的值，格式如：SHA256: DF:92:A3:77...
                parts = line.split('SHA256:')
                if len(parts) > 1:
                    hash_value = parts[1].strip().replace(':', '').replace(' ', '').lower()
                    return hash_value
        return None

    def parse_md5_from_output(self, output):
        """从keytool输出中解析MD5签名"""
        lines = output.split('\n')
        for line in lines:
            if 'MD5' in line:
                # 提取MD5: 后面的值
                parts = line.split(':')
                if len(parts) > 1:
                    hash_value = parts[1].strip().replace(':', '').lower()
                    return hash_value
        return None

    def generate_signature_config(self, apk_path, config_name="default"):
        """生成签名配置"""
        print(f"\n正在生成签名配置: {config_name}")

        signature_info = self.extract_apk_signature(apk_path)
        if signature_info:
            self.config[config_name] = signature_info
            self.save_config()
            return signature_info

        return None

    def generate_java_config(self, output_file="SignatureConfig.java"):
        """生成Java配置文件"""
        print(f"\n正在生成Java配置文件: {output_file}")

        java_code = """package com.ark.security;

/**
 * 签名配置
 * 自动生成，请勿手动修改
 */
public class SignatureConfig {
"""

        for config_name, config_data in self.config.items():
            sha256 = config_data.get("sha256", "")
            md5 = config_data.get("md5", "")

            java_code += f"""
    // {config_name} 配置
    public static final String EXPECTED_SHA256_{config_name.upper()} = "{sha256}";
    public static final String EXPECTED_MD5_{config_name.upper()} = "{md5}";
"""

        java_code += """
    // 当前使用的配置
    public static final String CURRENT_CONFIG = "default";

    public static String getExpectedSha256() {
        switch (CURRENT_CONFIG) {
"""

        for config_name in self.config.keys():
            java_code += f"""
            case "{config_name}":
                return EXPECTED_SHA256_{config_name.upper()};
"""

        java_code += """
            default:
                return EXPECTED_SHA256_DEFAULT;
        }
    }

    public static String getExpectedMd5() {
        switch (CURRENT_CONFIG) {
"""

        for config_name in self.config.keys():
            java_code += f"""
            case "{config_name}":
                return EXPECTED_MD5_{config_name.upper()};
"""

        java_code += """
            default:
                return EXPECTED_MD5_DEFAULT;
        }
    }
}
"""

        # 写入文件到正确的路径
        script_dir = os.path.dirname(os.path.abspath(__file__))
        project_dir = os.path.dirname(script_dir)
        output_path = os.path.join(project_dir, "app/src/main/java/com/ark/security", output_file)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(java_code)

        print(f"✓ Java配置文件已生成: {output_path}")

    def verify_signature(self, apk_path, config_name="default"):
        """验证APK签名"""
        print(f"\n正在验证APK签名: {apk_path}")

        if config_name not in self.config:
            print(f"✗ 配置不存在: {config_name}")
            return False

        current_signature = self.extract_apk_signature(apk_path)
        expected_signature = self.config[config_name]

        if not current_signature:
            print("✗ 无法提取当前签名")
            return False

        # 比较SHA256
        if current_signature["sha256"] == expected_signature["sha256"]:
            print(f"✓ SHA256签名匹配")
            return True
        else:
            print(f"✗ SHA256签名不匹配")
            print(f"  期望: {expected_signature['sha256']}")
            print(f"  实际: {current_signature['sha256']}")
            return False

def main():
    if len(sys.argv) < 2:
        print("""
签名密钥管理工具

用法:
  python key_manager.py extract <apk_path> [config_name]
      - 提取APK签名并生成配置

  python key_manager.py generate_java [output_file]
      - 生成Java配置文件

  python key_manager.py verify <apk_path> [config_name]
      - 验证APK签名

示例:
  python key_manager.py extract app-debug.apk debug
  python key_manager.py generate_java
  python key_manager.py verify app-debug.apk debug
""")
        return

    manager = SignatureKeyManager()
    command = sys.argv[1]

    if command == "extract":
        if len(sys.argv) < 3:
            print("✗ 请指定APK文件路径")
            return

        apk_path = sys.argv[2]
        config_name = sys.argv[3] if len(sys.argv) > 3 else "default"

        manager.generate_signature_config(apk_path, config_name)

    elif command == "generate_java":
        output_file = sys.argv[2] if len(sys.argv) > 2 else "SignatureConfig.java"
        manager.generate_java_config(output_file)

    elif command == "verify":
        if len(sys.argv) < 3:
            print("✗ 请指定APK文件路径")
            return

        apk_path = sys.argv[2]
        config_name = sys.argv[3] if len(sys.argv) > 3 else "default"

        result = manager.verify_signature(apk_path, config_name)
        sys.exit(0 if result else 1)

    else:
        print(f"✗ 未知命令: {command}")

if __name__ == "__main__":
    main()