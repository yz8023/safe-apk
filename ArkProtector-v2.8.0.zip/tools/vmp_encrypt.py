#!/usr/bin/env python3
"""
VMP字节码加密工具
从XOR加密升级到AES-256-CBC + 白盒加密
"""

import sys
import struct
import os
import random
import hashlib
import zlib
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

class VmpEncryptor:
    """VMP字节码加密器"""
    
    # 文件魔数
    MAGIC = b'VMP3'
    
    # 版本
    VERSION = 3
    
    def __init__(self, key=None):
        self.key = key if key else os.urandom(32)
        self.iv = self.key[:16]  # 使用密钥前16字节作为IV
    
    def encrypt_method(self, method_data):
        """
        加密单个方法的数据
        
        Args:
            method_data: 方法字节数据
        
        Returns:
            (encrypted_data, crc32)
        """
        # 计算CRC32
        crc = zlib.crc32(method_data) & 0xFFFFFFFF
        
        # AES-256-CBC加密
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
        encrypted = cipher.encrypt(pad(method_data, AES.block_size))
        
        return encrypted, crc
    
    def build_binary(self, methods):
        """
        构建VMP二进制文件
        
        Args:
            methods: 方法列表，每个方法包含methodId, bytecode, metadata
        
        Returns:
            完整的二进制数据
        """
        # 构建索引表和数据块
        index_data = b''
        enc_data = b''
        total_methods = len(methods)
        
        for method in methods:
            # 加密方法数据
            encrypted, crc = self.encrypt_method(method['bytecode'])
            
            # 构建索引
            index = struct.pack('<IIIIII',
                method['methodId'],     # methodId
                len(enc_data),          # offset
                len(encrypted),         # encSize
                len(method['bytecode']), # plainSize
                len(self.key) % 3,      # keyIndex
                crc                     # CRC32
            )
            index_data += index
            enc_data += encrypted
        
        # 写入文件头部
        # [magic][version][methodCount][indexOffset][keyVersion][checksum]
        magic = self.MAGIC
        version = self.VERSION
        key_version = 0x01020304
        
        # 计算整体校验
        check_data = index_data + enc_data + struct.pack('<II', total_methods, key_version)
        checksum = hashlib.sha256(check_data).digest()[:4]
        
        # 计算索引表偏移
        header_size = len(magic) + 4 + 4 + 4 + 4 + 4  # magic + version + methodCount + indexOffset + keyVersion + checksum
        index_offset = header_size
        
        header = struct.pack('<4sIIII4s',
            magic, version, total_methods,
            index_offset, key_version, checksum
        )
        
        return header + index_data + enc_data
    
    def save_to_file(self, data, output_path):
        """保存到文件"""
        with open(output_path, 'wb') as f:
            f.write(data)
        
        print(f"VMP.bin文件加密成功:")
        print(f"  输出: {output_path}")
        print(f"  总大小: {len(data)} 字节")
        print(f"  算法: AES-256-CBC")
        print(f"  密钥长度: {len(self.key)} 字节")


def main():
    """主函数"""
    if len(sys.argv) < 3:
        print("用法:")
        print("  python vmp_encrypt.py <输入vmp.bin> <输出vmp_encrypted.bin> [--key <密钥文件>]")
        sys.exit(1)
    
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    
    # 读取密钥（如果提供）
    key = None
    if '--key' in sys.argv:
        key_index = sys.argv.index('--key')
        if key_index + 1 < len(sys.argv):
            key_file = sys.argv[key_index + 1]
            if os.path.exists(key_file):
                with open(key_file, 'rb') as f:
                    key = f.read()
    
    # 创建加密器
    encryptor = VmpEncryptor(key)
    
    try:
        # 这里应该读取实际的VMP数据并解析为方法列表
        # 为了示例，我们创建一个简单的测试数据
        print(f"读取输入文件: {input_file}")
        
        # 在实际应用中，这里需要解析VMP文件格式
        # 并提取所有方法的数据
        
        # 示例：创建测试方法
        test_methods = [
            {
                'methodId': 1,
                'bytecode': b'\x12\x34\x56\x78' * 100,  # 测试数据
                'metadata': {}
            },
            {
                'methodId': 2,
                'bytecode': b'\xAB\xCD\xEF\x01' * 100,
                'metadata': {}
            }
        ]
        
        # 构建加密文件
        encrypted_data = encryptor.build_binary(test_methods)
        
        # 保存到文件
        encryptor.save_to_file(encrypted_data, output_file)
        
        # 保存密钥（用于解密）
        key_file = output_file + '.key'
        with open(key_file, 'wb') as f:
            f.write(encryptor.key)
        print(f"密钥已保存到: {key_file}")
        
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()