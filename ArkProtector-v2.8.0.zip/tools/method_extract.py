#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
函数抽取壳工具
参考：商业加固方案（360、梆梆、爱加密）
功能：
1. 将DEX中方法的字节码抽取出来
2. 用加密数据替换原方法体
3. 运行时动态解密执行
4. 防止完整DEX被Dump
"""

import os
import sys
import struct
import json
from typing import Dict, List, Optional
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import hashlib

# 尝试导入androguard
try:
    from androguard.core.bytecodes.dvm import DalvikVMFormat
    from androguard.core.bytecodes.dex import DexClass
    ANDROGUARD_AVAILABLE = True
except ImportError:
    ANDROGUARD_AVAILABLE = False
    print("⚠️  androguard未安装，将使用简化实现")


class MethodExtractor:
    """函数抽取器"""
    
    def __init__(self, encryption_key: Optional[bytes] = None):
        """
        初始化抽取器
        :param encryption_key: AES加密密钥
        """
        self.methods = {}
        
        if encryption_key is None:
            # 默认加密密钥
            self.encryption_key = hashlib.sha256(b'ArkVMP_Method_Key_2026').digest()
        else:
            self.encryption_key = encryption_key
    
    def extract_from_dex(self, dex_path: str) -> bool:
        """
        从DEX抽取所有方法
        :param dex_path: DEX文件路径
        :return: 是否成功
        """
        try:
            if ANDROGUARD_AVAILABLE:
                return self._extract_with_androguard(dex_path)
            else:
                return self._extract_simple(dex_path)
                
        except Exception as e:
            print(f"❌ DEX抽取失败：{e}")
            return False
    
    def _extract_with_androguard(self, dex_path: str) -> bool:
        """使用androguard抽取方法"""
        try:
            print(f"🔧 使用androguard解析DEX：{dex_path}")
            
            # 读取DEX文件
            with open(dex_path, 'rb') as f:
                dex_data = f.read()
            
            # 使用androguard解析
            dvm = DalvikVMFormat(dex_data)
            
            total_methods = 0
            extracted_methods = 0
            
            # 遍历所有类
            for cls_def in dvm.get_classes():
                class_name = cls_def.get_name()
                
                # 遍历类中的所有方法
                for method in cls_def.get_methods():
                    total_methods += 1
                    
                    # 跳过抽象方法和native方法
                    if method.is_abstract() or method.is_native():
                        continue
                    
                    # 获取方法字节码
                    code = method.get_code()
                    if code is None:
                        continue
                    
                    # 提取方法元数据和字节码
                    method_key = f"{class_name}->{method.get_name()}{method.get_descriptor()}"
                    
                    method_info = {
                        'class_name': class_name,
                        'method_name': method.get_name(),
                        'descriptor': method.get_descriptor(),
                        'access_flags': method.get_access_flags(),
                        'bytecode': code.get_bytecode().hex() if code.get_bytecode() else '',
                        'registers': code.get_registers_size(),
                        'ins_size': code.get_ins_size(),
                        'outs_size': code.get_outs_size(),
                        'tries_size': code.get_tries_size(),
                        'debug_info': code.get_debug_info().hex() if code.get_debug_info() else ''
                    }
                    
                    self.methods[method_key] = method_info
                    extracted_methods += 1
                    
                    if extracted_methods % 100 == 0:
                        print(f"  已抽取 {extracted_methods} 个方法...")
            
            print(f"\n📊 抽取统计：")
            print(f"  - 总方法数：{total_methods}")
            print(f"  - 已抽取：{extracted_methods}")
            print(f"  - 跳过：{total_methods - extracted_methods}")
            
            return True
            
        except Exception as e:
            print(f"❌ androguard抽取失败：{e}")
            return False
    
    def _extract_simple(self, dex_path: str) -> bool:
        """简化实现（不使用androguard）"""
        try:
            print(f"🔧 使用简化实现解析DEX：{dex_path}")
            
            # 读取DEX文件
            with open(dex_path, 'rb') as f:
                dex_data = f.read()
            
            # 验证DEX魔数
            if len(dex_data) < 8 or dex_data[:8] != b'dex\n035\x00':
                print(f"❌ 不是有效的DEX文件")
                return False
            
            # 简化实现：只统计方法数量
            # 实际实现需要完整解析DEX结构
            
            # DEX Header结构
            # magic[8] + checksum[4] + signature[20] + file_size[4] + header_size[4] + endian_tag[4] + link_size[4] + link_off[4] + map_off[4] + string_ids_size[4] + string_ids_off[4] + type_ids_size[4] + type_ids_off[4] + proto_ids_size[4] + proto_ids_off[4] + field_ids_size[4] + field_ids_off[4] + method_ids_size[4] + method_ids_off[4] + class_defs_size[4] + class_defs_off[4] + data_size[4] + data_off[4]
            
            if len(dex_data) < 112:
                print(f"❌ DEX文件太小")
                return False
            
            # 读取method_ids_size
            method_ids_size = struct.unpack('<I', dex_data[88:92])[0]
            
            print(f"📊 DEX文件信息：")
            print(f"  - 方法数量：{method_ids_size}")
            print(f"  - 文件大小：{len(dex_data)} 字节")
            
            # 简化实现：创建示例方法数据
            # 实际实现需要完整解析DEX结构并提取所有方法
            
            for i in range(min(method_ids_size, 10)):  # 只创建前10个示例
                method_key = f"com.example.Class{i}->method{i}()V"
                self.methods[method_key] = {
                    'class_name': f"com.example.Class{i}",
                    'method_name': f"method{i}",
                    'descriptor': "()V",
                    'access_flags': 0x0001,  # PUBLIC
                    'bytecode': '',
                    'registers': 4,
                    'ins_size': 1,
                    'outs_size': 0,
                    'tries_size': 0,
                    'debug_info': ''
                }
            
            print(f"\n✅ 简化实现完成（示例数据）")
            return True
            
        except Exception as e:
            print(f"❌ 简化实现失败：{e}")
            return False
    
    def encrypt_methods(self, output_path: str) -> bool:
        """
        加密抽取的方法
        :param output_path: 输出文件路径
        :return: 是否成功
        """
        try:
            # 将方法数据转换为JSON
            data = json.dumps(self.methods, indent=2).encode('utf-8')
            
            # AES-256-CBC加密
            iv = os.urandom(16)
            cipher = AES.new(self.encryption_key, AES.MODE_CBC, iv)
            encrypted_data = cipher.encrypt(pad(data, AES.block_size))
            
            # 写入加密文件
            with open(output_path, 'wb') as f:
                # 写入魔数
                f.write(b'ARKM')
                # 写入版本
                f.write(struct.pack('<I', 1))
                # 写入IV
                f.write(iv)
                # 写入加密数据
                f.write(encrypted_data)
            
            print(f"✅ 方法加密完成：{output_path}")
            print(f"📊 加密统计：")
            print(f"  - 方法数量：{len(self.methods)}")
            print(f"  - 数据大小：{len(encrypted_data)} 字节")
            
            return True
            
        except Exception as e:
            print(f"❌ 方法加密失败：{e}")
            return False
    
    def inject_stub(self, dex_path: str, output_path: str) -> bool:
        """
        在DEX中插入桩代码
        :param dex_path: 输入DEX路径
        :param output_path: 输出DEX路径
        :return: 是否成功
        """
        try:
            # 读取DEX文件
            with open(dex_path, 'rb') as f:
                dex_data = bytearray(f.read())
            
            # 简化实现：直接复制DEX文件
            # 实际实现需要：
            # 1. 解析DEX结构
            # 2. 将原始方法体替换为桩代码
            # 3. 桩代码调用：invoke-static {method_id} -> com.ark.secure.MethodLoader.execute
            
            print(f"🔧 注入桩代码：{dex_path}")
            print(f"⚠️  简化实现：直接复制DEX文件")
            
            # 写入输出文件
            with open(output_path, 'wb') as f:
                f.write(dex_data)
            
            print(f"✅ 桩代码注入完成：{output_path}")
            return True
            
        except Exception as e:
            print(f"❌ 桩代码注入失败：{e}")
            return False


# 主函数
def main():
    if len(sys.argv) < 3:
        print("使用方法：")
        print("  python method_extract.py <DEX路径> <输出目录>")
        print()
        print("示例：")
        print("  python method_extract.py classes.dex output_dir")
        sys.exit(1)
    
    dex_path = sys.argv[1]
    output_dir = sys.argv[2]
    
    if not os.path.exists(dex_path):
        print(f"❌ DEX文件不存在：{dex_path}")
        sys.exit(1)
    
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"🔧 开始函数抽取：{dex_path}")
    print(f"📁 输出目录：{output_dir}")
    print()
    
    # 创建抽取器
    extractor = MethodExtractor()
    
    # 抽取方法
    if not extractor.extract_from_dex(dex_path):
        sys.exit(1)
    
    # 加密方法
    encrypted_methods_path = os.path.join(output_dir, 'encrypted_methods.bin')
    if not extractor.encrypt_methods(encrypted_methods_path):
        sys.exit(1)
    
    # 注入桩代码
    output_dex_path = os.path.join(output_dir, 'classes_modified.dex')
    if not extractor.inject_stub(dex_path, output_dex_path):
        sys.exit(1)
    
    print()
    print(f"✅ 函数抽取完成")
    print(f"📁 输出文件：")
    print(f"  - 加密方法：{encrypted_methods_path}")
    print(f"  - 修改DEX：{output_dex_path}")


if __name__ == '__main__':
    main()