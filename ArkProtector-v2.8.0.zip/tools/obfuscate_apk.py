#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
一键APK混淆脚本
集成所有加固工具，提供一键混淆功能
功能：
1. 资源混淆（AndResGuard）
2. 代码混淆（ProGuard + StringFog）
3. 函数抽取壳
4. 控制流混淆（OLLVM）
5. 签名
"""

import os
import sys
import subprocess
import json
import shutil
import tempfile
from typing import Dict, List, Optional


class ApkObfuscator:
    """APK混淆器"""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化混淆器
        :param config: 配置字典
        """
        if config is None:
            self.config = self.get_default_config()
        else:
            self.config = config
        
        # 工具目录
        self.tools_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 临时目录
        self.temp_dir = tempfile.mkdtemp(prefix='ark_obfuscate_')
        
        # 日志
        self.logs = []
    
    def get_default_config(self) -> Dict:
        """获取默认配置"""
        return {
            'resource_obfuscation': {
                'enabled': True,
                'compress': True
            },
            'code_obfuscation': {
                'enabled': True,
                'string_encryption': True,
                'proguard': True
            },
            'method_extraction': {
                'enabled': True,
                'encryption': True
            },
            'control_flow_obfuscation': {
                'enabled': True
            },
            'signature': {
                'enabled': True,
                'keystore_path': '',
                'keystore_password': '',
                'key_alias': '',
                'key_password': ''
            }
        }
    
    def log(self, message: str):
        """记录日志"""
        self.logs.append(message)
        print(message)
    
    def step1_resource_obfuscation(self, input_apk: str, output_apk: str) -> bool:
        """
        步骤1：资源混淆
        :param input_apk: 输入APK
        :param output_apk: 输出APK
        :return: 是否成功
        """
        if not self.config['resource_obfuscation']['enabled']:
            self.log("⏭️  跳过资源混淆")
            return True
        
        self.log("📦 步骤1：资源混淆")
        
        try:
            # 使用res_guard.py工具
            res_guard_script = os.path.join(self.tools_dir, 'res_guard.py')
            
            if not os.path.exists(res_guard_script):
                self.log("⚠️  res_guard.py不存在，跳过资源混淆")
                return True
            
            compress = self.config['resource_obfuscation']['compress']
            cmd = ['python3', res_guard_script, input_apk, output_apk]
            if compress:
                cmd.append('--compress')
            
            self.log(f"  执行命令：{' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                self.log("  ✅ 资源混淆完成")
                return True
            else:
                self.log(f"  ❌ 资源混淆失败：{result.stderr}")
                return False
                
        except Exception as e:
            self.log(f"  ❌ 资源混淆异常：{e}")
            return False
    
    def step2_code_obfuscation(self, input_apk: str, output_apk: str) -> bool:
        """
        步骤2：代码混淆
        :param input_apk: 输入APK
        :param output_apk: 输出APK
        :return: 是否成功
        """
        if not self.config['code_obfuscation']['enabled']:
            self.log("⏭️  跳过代码混淆")
            return True
        
        self.log("📦 步骤2：代码混淆")
        
        try:
            # 解压APK
            extract_dir = os.path.join(self.temp_dir, 'extracted')
            os.makedirs(extract_dir, exist_ok=True)
            
            self.log("  解压APK...")
            subprocess.run(['unzip', '-q', input_apk, '-d', extract_dir], check=True)
            
            # 字符串加密（仅对smali代码进行后处理加密）
            # 注意：StringFog在编译时已经处理了Java代码
            # 这里只对未处理的smali代码进行加密
            if self.config['code_obfuscation']['string_encryption']:
                self.log("  字符串加密（smali后处理）...")
                string_encrypt_script = os.path.join(self.tools_dir, 'string_encrypt.py')
                java_dir = os.path.join(extract_dir, 'smali')
                
                if os.path.exists(string_encrypt_script) and os.path.exists(java_dir):
                    encrypted_dir = os.path.join(self.temp_dir, 'encrypted')
                    subprocess.run(['python3', string_encrypt_script, java_dir, encrypted_dir], check=True)
                    
                    # 替换原文件
                    shutil.rmtree(java_dir)
                    shutil.copytree(encrypted_dir, java_dir)
                    self.log("    ✅ 字符串加密完成")
                else:
                    self.log("    ℹ️  StringFog已在编译时处理Java代码，跳过smali加密")
            
            # ProGuard混淆（已在编译时处理）
            if self.config['code_obfuscation']['proguard']:
                self.log("  ℹ️  ProGuard混淆已在编译时处理，跳过")
            
            # 重新打包APK
            self.log("  重新打包APK...")
            subprocess.run(['zip', '-q', '-r', output_apk, '.'], cwd=extract_dir, check=True)
            
            self.log("  ✅ 代码混淆完成")
            return True
            
        except Exception as e:
            self.log(f"  ❌ 代码混淆异常：{e}")
            return False
    
    def step3_method_extraction(self, input_apk: str, output_apk: str) -> bool:
        """
        步骤3：函数抽取壳
        :param input_apk: 输入APK
        :param output_apk: 输出APK
        :return: 是否成功
        """
        if not self.config['method_extraction']['enabled']:
            self.log("⏭️  跳过函数抽取壳")
            return True
        
        self.log("📦 步骤3：函数抽取壳")
        self.log("  ⚠️  重要：函数抽取必须在ProGuard混淆之前执行")
        self.log("  ⚠️  否则ProGuard混淆后的方法名无法被正确识别")
        
        try:
            # 解压APK
            extract_dir = os.path.join(self.temp_dir, 'extracted_method')
            os.makedirs(extract_dir, exist_ok=True)
            
            self.log("  解压APK...")
            subprocess.run(['unzip', '-q', input_apk, '-d', extract_dir], check=True)
            
            # 查找DEX文件
            dex_files = []
            for file in os.listdir(extract_dir):
                if file.endswith('.dex'):
                    dex_files.append(os.path.join(extract_dir, file))
            
            if not dex_files:
                self.log("  ⚠️  未找到DEX文件，跳过函数抽取")
                return True
            
            # 使用method_extract.py工具
            method_extract_script = os.path.join(self.tools_dir, 'method_extract.py')
            
            if not os.path.exists(method_extract_script):
                self.log("  ⚠️  method_extract.py不存在，跳过函数抽取")
                return True
            
            # 抽取每个DEX文件
            for dex_file in dex_files:
                self.log(f"  处理DEX文件：{os.path.basename(dex_file)}")
                output_dir = os.path.join(self.temp_dir, 'extracted_methods')
                subprocess.run(['python3', method_extract_script, dex_file, output_dir], check=True)
                
                # 替换原DEX文件
                modified_dex = os.path.join(output_dir, 'classes_modified.dex')
                if os.path.exists(modified_dex):
                    shutil.copy2(modified_dex, dex_file)
                    self.log(f"    ✅ {os.path.basename(dex_file)}抽取完成")
            
            # 重新打包APK
            self.log("  重新打包APK...")
            subprocess.run(['zip', '-q', '-r', output_apk, '.'], cwd=extract_dir, check=True)
            
            self.log("  ✅ 函数抽取壳完成")
            return True
            
        except Exception as e:
            self.log(f"  ❌ 函数抽取壳异常：{e}")
            return False
    
    def step4_control_flow_obfuscation(self, input_apk: str, output_apk: str) -> bool:
        """
        步骤4：控制流混淆（OLLVM）
        :param input_apk: 输入APK
        :param output_apk: 输出APK
        :return: 是否成功
        """
        if not self.config['control_flow_obfuscation']['enabled']:
            self.log("⏭️  跳过控制流混淆")
            return True
        
        self.log("📦 步骤4：控制流混淆（OLLVM）")
        self.log("  ⚠️  OLLVM混淆需要在CMakeLists.txt中配置，编译时自动应用")
        
        # OLLVM混淆是在编译时应用的，不是对APK进行混淆
        # 这里直接复制文件
        shutil.copy2(input_apk, output_apk)
        self.log("  ✅ 控制流混淆（编译时应用）")
        return True
    
    def step5_signature(self, input_apk: str, output_apk: str) -> bool:
        """
        步骤5：签名
        :param input_apk: 输入APK
        :param output_apk: 输出APK
        :return: 是否成功
        """
        if not self.config['signature']['enabled']:
            self.log("⏭️  跳过签名")
            return True
        
        self.log("📦 步骤5：签名")
        
        try:
            # 检查签名配置
            keystore_path = self.config['signature']['keystore_path']
            keystore_password = self.config['signature']['keystore_password']
            key_alias = self.config['signature']['key_alias']
            key_password = self.config['signature']['key_password']
            
            if not keystore_path or not os.path.exists(keystore_path):
                self.log("  ⚠️  未配置签名密钥，使用debug签名")
                # 使用debug签名（需要apksigner）
                self.log("  ⚠️  debug签名需要apksigner工具，跳过")
                shutil.copy2(input_apk, output_apk)
                return True
            
            # 使用apksigner签名
            self.log(f"  使用密钥签名：{keystore_path}")
            cmd = [
                'apksigner',
                'sign',
                '--ks', keystore_path,
                '--ks-pass', f'pass:{keystore_password}',
                '--ks-key-alias', key_alias,
                '--key-pass', f'pass:{key_password}',
                '--out', output_apk,
                input_apk
            ]
            
            self.log(f"  执行命令：{' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0:
                self.log("  ✅ 签名完成")
                return True
            else:
                self.log(f"  ❌ 签名失败：{result.stderr}")
                return False
                
        except Exception as e:
            self.log(f"  ❌ 签名异常：{e}")
            return False
    
    def obfuscate_apk(self, input_apk: str, output_apk: str) -> bool:
        """
        混淆APK
        :param input_apk: 输入APK路径
        :param output_apk: 输出APK路径
        :return: 是否成功
        """
        self.log(f"🚀 开始APK混淆")
        self.log(f"📁 输入APK：{input_apk}")
        self.log(f"📁 输出APK：{output_apk}")
        self.log(f"📁 临时目录：{self.temp_dir}")
        self.log()
        
        if not os.path.exists(input_apk):
            self.log(f"❌ 输入APK不存在：{input_apk}")
            return False
        
        # 创建输出目录
        os.makedirs(os.path.dirname(output_apk), exist_ok=True)
        
        # 步骤1：资源混淆
        temp_apk1 = os.path.join(self.temp_dir, 'step1.apk')
        if not self.step1_resource_obfuscation(input_apk, temp_apk1):
            return False
        
        # 步骤2：代码混淆
        temp_apk2 = os.path.join(self.temp_dir, 'step2.apk')
        if not self.step2_code_obfuscation(temp_apk1, temp_apk2):
            return False
        
        # 步骤3：函数抽取壳
        temp_apk3 = os.path.join(self.temp_dir, 'step3.apk')
        if not self.step3_method_extraction(temp_apk2, temp_apk3):
            return False
        
        # 步骤4：控制流混淆
        temp_apk4 = os.path.join(self.temp_dir, 'step4.apk')
        if not self.step4_control_flow_obfuscation(temp_apk3, temp_apk4):
            return False
        
        # 步骤5：签名
        if not self.step5_signature(temp_apk4, output_apk):
            return False
        
        # 清理临时目录
        try:
            shutil.rmtree(self.temp_dir)
            self.log(f"🧹 清理临时目录：{self.temp_dir}")
        except Exception as e:
            self.log(f"⚠️  清理临时目录失败：{e}")
        
        self.log()
        self.log(f"✅ APK混淆完成：{output_apk}")
        
        # 输出统计信息
        input_size = os.path.getsize(input_apk)
        output_size = os.path.getsize(output_apk)
        size_reduction = (1 - output_size / input_size) * 100
        
        self.log(f"📊 混淆统计：")
        self.log(f"  - 输入大小：{input_size / 1024 / 1024:.2f} MB")
        self.log(f"  - 输出大小：{output_size / 1024 / 1024:.2f} MB")
        self.log(f"  - 大小变化：{size_reduction:+.2f}%")
        
        return True
    
    def save_logs(self, log_file: str) -> bool:
        """
        保存日志
        :param log_file: 日志文件路径
        :return: 是否成功
        """
        try:
            with open(log_file, 'w', encoding='utf-8') as f:
                f.write('\n'.join(self.logs))
            
            self.log(f"✅ 日志已保存：{log_file}")
            return True
            
        except Exception as e:
            self.log(f"❌ 保存日志失败：{e}")
            return False


# 主函数
def main():
    if len(sys.argv) < 3:
        print("使用方法：")
        print("  python obfuscate_apk.py <输入APK> <输出APK> [--config <配置文件>]")
        print()
        print("示例：")
        print("  python obfuscate_apk.py input.apk output.apk")
        print("  python obfuscate_apk.py input.apk output.apk --config config.json")
        sys.exit(1)
    
    input_apk = sys.argv[1]
    output_apk = sys.argv[2]
    config_file = None
    
    # 解析参数
    if '--config' in sys.argv:
        idx = sys.argv.index('--config')
        if idx + 1 < len(sys.argv):
            config_file = sys.argv[idx + 1]
    
    # 加载配置
    config = None
    if config_file and os.path.exists(config_file):
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
    
    # 创建混淆器
    obfuscator = ApkObfuscator(config)
    
    # 混淆APK
    if obfuscator.obfuscate_apk(input_apk, output_apk):
        # 保存日志
        log_file = os.path.splitext(output_apk)[0] + '_log.txt'
        obfuscator.save_logs(log_file)
    else:
        sys.exit(1)


if __name__ == '__main__':
    main()