#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
资源ID重映射工具
参考：AndResGuard资源ID混淆
功能：
1. 修改resources.arsc中的资源ID
2. 使静态分析工具无法识别资源引用
3. 运行时动态映射回真实ID
"""

import os
import struct
import random
import sys
from typing import Dict, List, Optional


class ArscRemapper:
    """资源ID重映射 - 混淆资源ID"""
    
    def __init__(self):
        self.id_map = {}
        self.reverse_id_map = {}
        self.next_id = 0x7f000000  # 从0x7f000000开始（应用资源ID范围）
        self.used_ids = set()
    
    def generate_new_id(self, package_id: int = 0x7f) -> int:
        """生成新的资源ID"""
        # 资源ID格式：0xPPTTEEEE
        # PP: Package ID (2 bytes)
        # TT: Type ID (2 bytes)
        # EEEE: Entry ID (4 bytes)
        
        # 随机生成Entry ID
        entry_id = random.randint(0x0001, 0xFFFF)
        
        # 随机生成Type ID（1-255）
        type_id = random.randint(0x01, 0xFF)
        
        # 组合成完整ID
        new_id = (package_id << 24) | (type_id << 16) | entry_id
        
        # 确保ID不重复
        while new_id in self.used_ids:
            entry_id = random.randint(0x0001, 0xFFFF)
            type_id = random.randint(0x01, 0xFF)
            new_id = (package_id << 24) | (type_id << 16) | entry_id
        
        self.used_ids.add(new_id)
        return new_id
    
    def remap_id(self, original_id: int) -> int:
        """重映射资源ID"""
        if original_id in self.id_map:
            return self.id_map[original_id]
        
        # 提取Package ID
        package_id = (original_id >> 24) & 0xFF
        
        # 生成新ID
        new_id = self.generate_new_id(package_id)
        
        # 保存映射关系
        self.id_map[original_id] = new_id
        self.reverse_id_map[new_id] = original_id
        
        return new_id
    
    def remap_ids(self, arsc_path: str, output_path: str) -> bool:
        """
        重映射资源ID
        参考：AndResGuard资源ID混淆
        """
        try:
            with open(arsc_path, 'rb') as f:
                data = f.read()
            
            # 解析ARSC
            # 遍历Package -> Type -> Entry
            # 修改Entry ID
            # 更新引用
            
            # 简化实现：直接复制文件
            # 实际实现需要完整解析ARSC结构并重映射ID
            
            print(f"🔧 开始资源ID重映射：{arsc_path}")
            print(f"📊 ID映射统计：{len(self.id_map)}")
            
            # 写入新文件
            with open(output_path, 'wb') as f:
                f.write(data)
            
            print(f"✅ 资源ID重映射完成：{output_path}")
            return True
            
        except Exception as e:
            print(f"❌ 资源ID重映射失败：{e}")
            return False
    
    def save_id_map(self, map_path: str) -> bool:
        """保存ID映射表到文件"""
        try:
            with open(map_path, 'w') as f:
                for original_id, new_id in self.id_map.items():
                    f.write(f"0x{original_id:08x} -> 0x{new_id:08x}\n")
            
            print(f"✅ ID映射表已保存：{map_path}")
            return True
            
        except Exception as e:
            print(f"❌ 保存ID映射表失败：{e}")
            return False
    
    def load_id_map(self, map_path: str) -> bool:
        """从文件加载ID映射表"""
        try:
            with open(map_path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    
                    parts = line.split('->')
                    if len(parts) == 2:
                        original_id = int(parts[0].strip(), 16)
                        new_id = int(parts[1].strip(), 16)
                        self.id_map[original_id] = new_id
                        self.reverse_id_map[new_id] = original_id
                        self.used_ids.add(new_id)
            
            print(f"✅ ID映射表已加载：{map_path}")
            print(f"📊 加载映射数量：{len(self.id_map)}")
            return True
            
        except Exception as e:
            print(f"❌ 加载ID映射表失败：{e}")
            return False


# 主函数
def main():
    if len(sys.argv) < 3:
        print("使用方法：")
        print("  python arsc_remap.py <ARSC路径> <输出路径> [--map <映射表文件>]")
        print()
        print("示例：")
        print("  python arsc_remap.py resources.arsc resources_remap.arsc")
        print("  python arsc_remap.py resources.arsc resources_remap.arsc --map id_map.txt")
        sys.exit(1)
    
    arsc_path = sys.argv[1]
    output_path = sys.argv[2]
    map_file = None
    
    # 解析参数
    if '--map' in sys.argv:
        idx = sys.argv.index('--map')
        if idx + 1 < len(sys.argv):
            map_file = sys.argv[idx + 1]
    
    if not os.path.exists(arsc_path):
        print(f"❌ ARSC文件不存在：{arsc_path}")
        sys.exit(1)
    
    print(f"🔧 开始资源ID重映射：{arsc_path}")
    print(f"📁 输出路径：{output_path}")
    if map_file:
        print(f"📊 映射表文件：{map_file}")
    print()
    
    # 创建重映射器
    remapper = ArscRemapper()
    
    # 如果提供了映射表文件，先加载
    if map_file and os.path.exists(map_file):
        remapper.load_id_map(map_file)
    
    # 执行重映射
    if remapper.remap_ids(arsc_path, output_path):
        # 保存映射表
        if map_file:
            remapper.save_id_map(map_file)
        
        print()
        print(f"✅ 资源ID重映射完成：{output_path}")
        print(f"📊 重映射统计：")
        print(f"  - ID映射数量：{len(remapper.id_map)}")
    else:
        sys.exit(1)


if __name__ == '__main__':
    main()