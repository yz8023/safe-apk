#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Ark加固系统 - 自动签名工具
支持自定义签名配置、多渠道签名、签名验证等功能
"""

import os
import sys
import subprocess
import argparse
import json
import shutil
from pathlib import Path
from datetime import datetime

class AutoSigner:
    """自动签名工具类"""
    
    def __init__(self):
        self.project_dir = Path(__file__).parent.parent
        self.keystore_dir = self.project_dir / "keystore"
        self.apk_output_dir = self.project_dir / "app" / "build" / "outputs" / "apk"
        self.config_file = self.project_dir / "sign_config.json"
        
        # 确保keystore目录存在
        self.keystore_dir.mkdir(exist_ok=True)
    
    def generate_keystore(self, keystore_path, alias, password, key_password, dname="CN=Ark,O=ArkSecurity,C=CN"):
        """生成签名密钥库"""
        print(f"正在生成签名密钥库: {keystore_path}")
        
        # 删除已存在的keystore
        if os.path.exists(keystore_path):
            print(f"警告: 密钥库已存在，将被覆盖: {keystore_path}")
            os.remove(keystore_path)
        
        # 使用keytool生成密钥库
        cmd = [
            "keytool",
            "-genkeypair",
            "-keystore", keystore_path,
            "-alias", alias,
            "-keyalg", "RSA",
            "-keysize", "2048",
            "-validity", "10000",
            "-storepass", password,
            "-keypass", key_password,
            "-dname", dname
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            print(f"✓ 成功生成密钥库: {keystore_path}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"✗ 生成密钥库失败: {e.stderr}")
            return False
    
    def sign_apk(self, apk_path, keystore_path, alias, password, signed_apk_path=None):
        """签名APK文件"""
        print(f"正在签名APK: {apk_path}")
        
        if not os.path.exists(apk_path):
            print(f"✗ APK文件不存在: {apk_path}")
            return False
        
        if not os.path.exists(keystore_path):
            print(f"✗ 密钥库文件不存在: {keystore_path}")
            return False
        
        # 如果没有指定输出路径，自动生成
        if signed_apk_path is None:
            apk_name = Path(apk_path).stem
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            signed_apk_path = str(Path(apk_path).parent / f"{apk_name}_signed_{timestamp}.apk")
        
        # 使用jarsigner签名
        cmd = [
            "jarsigner",
            "-verbose",
            "-sigalg", "SHA256withRSA",
            "-digestalg", "SHA256",
            "-keystore", keystore_path,
            "-storepass", password,
            "-keypass", password,
            apk_path,
            alias
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True)
            print(f"✓ 成功签名APK: {apk_path}")
            
            # 重命名为签名后的APK
            if signed_apk_path != apk_path:
                shutil.move(apk_path, signed_apk_path)
                print(f"✓ 签名后的APK已保存到: {signed_apk_path}")
            
            return True
        except subprocess.CalledProcessError as e:
            print(f"✗ 签名APK失败: {e.stderr}")
            return False
    
    def verify_signature(self, apk_path):
        """验证APK签名"""
        print(f"正在验证APK签名: {apk_path}")
        
        if not os.path.exists(apk_path):
            print(f"✗ APK文件不存在: {apk_path}")
            return False
        
        # 使用jarsigner验证签名
        cmd = [
            "jarsigner",
            "-verify",
            "-verbose",
            "-certs",
            apk_path
        ]
        
        try:
            result = subprocess.run(cmd, capture_output=True, text=True)
            if "jar verified" in result.stderr.lower():
                print(f"✓ APK签名验证通过")
                return True
            else:
                print(f"✗ APK签名验证失败")
                print(result.stderr)
                return False
        except Exception as e:
            print(f"✗ 验证签名时出错: {e}")
            return False
    
    def sign_all_apks(self, keystore_path, alias, password):
        """签名所有未签名的APK"""
        print("正在查找未签名的APK文件...")
        
        # 查找所有APK文件
        apk_files = []
        for build_type in ["debug", "release"]:
            build_dir = self.apk_output_dir / build_type
            if build_dir.exists():
                apk_files.extend(build_dir.glob("*.apk"))
        
        if not apk_files:
            print("✗ 未找到APK文件")
            return False
        
        signed_count = 0
        failed_count = 0
        
        for apk_file in apk_files:
            # 跳过已签名的APK
            if "_signed_" in apk_file.name:
                continue
            
            print(f"\n处理APK: {apk_file.name}")
            if self.sign_apk(str(apk_file), keystore_path, alias, password):
                signed_count += 1
            else:
                failed_count += 1
        
        print(f"\n签名完成: 成功 {signed_count} 个, 失败 {failed_count} 个")
        return failed_count == 0
    
    def save_config(self, config):
        """保存签名配置"""
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        print(f"✓ 签名配置已保存到: {self.config_file}")
    
    def load_config(self):
        """加载签名配置"""
        if not self.config_file.exists():
            return None
        
        with open(self.config_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def create_default_config(self):
        """创建默认签名配置"""
        default_config = {
            "debug": {
                "keystore": str(self.keystore_dir / "debug.jks"),
                "alias": "debug",
                "password": "android",
                "enabled": True
            },
            "release": {
                "keystore": str(self.keystore_dir / "release.jks"),
                "alias": "release",
                "password": "123456",
                "enabled": False
            },
            "custom": {
                "keystore": "",
                "alias": "",
                "password": "",
                "enabled": False
            }
        }
        
        self.save_config(default_config)
        return default_config

def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='Ark加固系统 - 自动签名工具')
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 生成密钥库命令
    gen_parser = subparsers.add_parser('gen', help='生成签名密钥库')
    gen_parser.add_argument('--keystore', required=True, help='密钥库路径')
    gen_parser.add_argument('--alias', required=True, help='密钥别名')
    gen_parser.add_argument('--password', default='123456', help='密钥库密码')
    gen_parser.add_argument('--key-password', default='123456', help='密钥密码')
    gen_parser.add_argument('--dname', default='CN=Ark,O=ArkSecurity,C=CN', help='证书信息')
    
    # 签名APK命令
    sign_parser = subparsers.add_parser('sign', help='签名APK文件')
    sign_parser.add_argument('--apk', required=True, help='APK文件路径')
    sign_parser.add_argument('--keystore', required=True, help='密钥库路径')
    sign_parser.add_argument('--alias', required=True, help='密钥别名')
    sign_parser.add_argument('--password', required=True, help='密钥库密码')
    sign_parser.add_argument('--output', help='签名后APK输出路径')
    
    # 验证签名命令
    verify_parser = subparsers.add_parser('verify', help='验证APK签名')
    verify_parser.add_argument('--apk', required=True, help='APK文件路径')
    
    # 批量签名命令
    batch_parser = subparsers.add_parser('batch', help='批量签名所有APK')
    batch_parser.add_argument('--keystore', required=True, help='密钥库路径')
    batch_parser.add_argument('--alias', required=True, help='密钥别名')
    batch_parser.add_argument('--password', required=True, help='密钥库密码')
    
    # 配置管理命令
    config_parser = subparsers.add_parser('config', help='签名配置管理')
    config_parser.add_argument('--init', action='store_true', help='初始化默认配置')
    config_parser.add_argument('--show', action='store_true', help='显示当前配置')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    signer = AutoSigner()
    
    if args.command == 'gen':
        # 生成密钥库
        success = signer.generate_keystore(
            args.keystore, args.alias, args.password, args.key_password, args.dname
        )
        sys.exit(0 if success else 1)
    
    elif args.command == 'sign':
        # 签名APK
        success = signer.sign_apk(
            args.apk, args.keystore, args.alias, args.password, args.output
        )
        sys.exit(0 if success else 1)
    
    elif args.command == 'verify':
        # 验证签名
        success = signer.verify_signature(args.apk)
        sys.exit(0 if success else 1)
    
    elif args.command == 'batch':
        # 批量签名
        success = signer.sign_all_apks(
            args.keystore, args.alias, args.password
        )
        sys.exit(0 if success else 1)
    
    elif args.command == 'config':
        # 配置管理
        if args.init:
            signer.create_default_config()
        elif args.show:
            config = signer.load_config()
            if config:
                print(json.dumps(config, indent=2, ensure_ascii=False))
            else:
                print("未找到配置文件，请先运行 --init 初始化")
        else:
            parser.print_help()

if __name__ == '__main__':
    main()