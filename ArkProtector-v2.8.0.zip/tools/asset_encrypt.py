#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Assets资源文件加密工具
参考：商业加固方案（360、梆梆、爱加密）
功能：
1. 对assets目录下所有文件进行AES加密
2. 运行时动态解密加载
3. 防止资源被直接提取
"""

import os
import sys
import struct
import zlib
from typing import List, Optional
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import hashlib


class AssetEncryptor:
    """Assets资源文件加密器"""
    
    def __init__(self, key: Optional[bytes] = None):
        """
        初始化加密器
        :param key: AES密钥（32字节），如果为None则使用默认密钥
        """
        if key is None:
            # 默认密钥（实际使用时应该从配置读取）
            self.key = hashlib.sha256(b'ArkVMP_Assets_Key_2026').digest()
        else:
            self.key = key
        
        # IV向量（16字节）
        self.iv = os.urandom(16)
    
    def encrypt_file(self, input_path: str, output_path: str) -> bool:
        """
        加密单个文件
        :param input_path: 输入文件路径
        :param output_path: 输出文件路径
        :return: 是否成功
        """
        try:
            # 读取文件内容
            with open(input_path, 'rb') as f:
                data = f.read()
            
            # AES-256-CBC加密
            cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
            encrypted_data = cipher.encrypt(pad(data, AES.block_size))
            
            # 写入加密文件
            with open(output_path, 'wb') as f:
                # 写入魔数（用于识别加密文件）
                f.write(b'ARKE')
                # 写入IV向量
                f.write(self.iv)
                # 写入加密数据
                f.write(encrypted_data)
            
            print(f"✅ 文件加密成功：{input_path} -> {output_path}")
            return True
            
        except Exception as e:
            print(f"❌ 文件加密失败：{e}")
            return False
    
    def encrypt_directory(self, input_dir: str, output_dir: str) -> bool:
        """
        加密整个目录
        :param input_dir: 输入目录
        :param output_dir: 输出目录
        :return: 是否成功
        """
        try:
            # 确保输出目录存在
            os.makedirs(output_dir, exist_ok=True)
            
            success_count = 0
            total_count = 0
            
            # 遍历输入目录
            for root, dirs, files in os.walk(input_dir):
                for file in files:
                    input_path = os.path.join(root, file)
                    
                    # 计算相对路径
                    rel_path = os.path.relpath(input_path, input_dir)
                    output_path = os.path.join(output_dir, rel_path)
                    
                    # 确保输出目录存在
                    os.makedirs(os.path.dirname(output_path), exist_ok=True)
                    
                    # 加密文件
                    if self.encrypt_file(input_path, output_path):
                        success_count += 1
                    total_count += 1
            
            print(f"\n📊 加密统计：")
            print(f"  - 总文件数：{total_count}")
            print(f"  - 成功数：{success_count}")
            print(f"  - 失败数：{total_count - success_count}")
            
            return success_count == total_count
            
        except Exception as e:
            print(f"❌ 目录加密失败：{e}")
            return False
    
    def encrypt_assets_in_apk(self, apk_path: str, output_path: str) -> bool:
        """
        加密APK中的assets目录
        :param apk_path: APK文件路径
        :param output_path: 输出APK路径
        :return: 是否成功
        """
        try:
            import zipfile
            import tempfile
            
            print(f"🔧 开始加密APK中的assets：{apk_path}")
            
            with tempfile.TemporaryDirectory() as temp_dir:
                # 解压APK
                print("📦 解压APK...")
                with zipfile.ZipFile(apk_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
                
                # 查找assets目录
                assets_dir = os.path.join(temp_dir, 'assets')
                
                if not os.path.exists(assets_dir):
                    print(f"⚠️  未找到assets目录")
                    # 直接复制APK
                    import shutil
                    shutil.copy2(apk_path, output_path)
                    return True
                
                # 加密assets目录
                print("🔐 加密assets目录...")
                encrypted_assets_dir = os.path.join(temp_dir, 'assets_encrypted')
                
                if not self.encrypt_directory(assets_dir, encrypted_assets_dir):
                    return False
                
                # 替换原assets目录
                import shutil
                shutil.rmtree(assets_dir)
                shutil.move(encrypted_assets_dir, assets_dir)
                
                # 重新打包APK
                print("📦 重新打包APK...")
                with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    for root, dirs, files in os.walk(temp_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, temp_dir)
                            
                            # 跳过临时文件
                            if 'temp.apk' in arcname or output_path in arcname:
                                continue
                            
                            zipf.write(file_path, arcname)
            
            print(f"\n✅ APK中assets加密完成：{output_path}")
            return True
            
        except Exception as e:
            print(f"❌ APK中assets加密失败：{e}")
            return False
    
    def decrypt_file(self, input_path: str, output_path: str) -> bool:
        """
        解密单个文件
        :param input_path: 输入文件路径
        :param output_path: 输出文件路径
        :return: 是否成功
        """
        try:
            # 读取加密文件
            with open(input_path, 'rb') as f:
                data = f.read()
            
            # 验证魔数
            if len(data) < 4 or data[:4] != b'ARKE':
                print(f"❌ 不是有效的加密文件")
                return False
            
            # 提取IV和加密数据
            iv = data[4:20]
            encrypted_data = data[20:]
            
            # AES-256-CBC解密
            cipher = AES.new(self.key, AES.MODE_CBC, iv)
            decrypted_data = unpad(cipher.decrypt(encrypted_data), AES.block_size)
            
            # 写入解密文件
            with open(output_path, 'wb') as f:
                f.write(decrypted_data)
            
            print(f"✅ 文件解密成功：{input_path} -> {output_path}")
            return True
            
        except Exception as e:
            print(f"❌ 文件解密失败：{e}")
            return False


# 主函数
def main():
    if len(sys.argv) < 3:
        print("使用方法：")
        print("  python asset_encrypt.py <输入路径> <输出路径> [--decrypt]")
        print()
        print("示例：")
        print("  python asset_encrypt.py input.apk output.apk")
        print("  python asset_encrypt.py input.apk output.apk --decrypt")
        print("  python asset_encrypt.py assets_dir encrypted_dir")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    decrypt = '--decrypt' in sys.argv
    
    if not os.path.exists(input_path):
        print(f"❌ 输入路径不存在：{input_path}")
        sys.exit(1)
    
    print(f"🔧 开始{'解' if decrypt else '加'}密：{input_path}")
    print(f"📁 输出路径：{output_path}")
    print()
    
    # 创建加密器
    encryptor = AssetEncryptor()
    
    # 判断是文件还是目录
    if os.path.isfile(input_path):
        # 如果是APK文件
        if input_path.endswith('.apk'):
            if decrypt:
                print(f"❌ APK解密暂不支持")
                sys.exit(1)
            else:
                # 加密APK中的assets
                if encryptor.encrypt_assets_in_apk(input_path, output_path):
                    print(f"\n✅ 操作完成：{output_path}")
                else:
                    sys.exit(1)
        else:
            # 普通文件
            if decrypt:
                if encryptor.decrypt_file(input_path, output_path):
                    print(f"\n✅ 操作完成：{output_path}")
                else:
                    sys.exit(1)
            else:
                if encryptor.encrypt_file(input_path, output_path):
                    print(f"\n✅ 操作完成：{output_path}")
                else:
                    sys.exit(1)
    elif os.path.isdir(input_path):
        # 目录
        if decrypt:
            print(f"❌ 目录解密暂不支持")
            sys.exit(1)
        else:
            if encryptor.encrypt_directory(input_path, output_path):
                print(f"\n✅ 操作完成：{output_path}")
            else:
                sys.exit(1)
    else:
        print(f"❌ 不支持的路径类型：{input_path}")
        sys.exit(1)


if __name__ == '__main__':
    main()