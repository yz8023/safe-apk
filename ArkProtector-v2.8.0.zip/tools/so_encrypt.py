#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SO文件加密工具
参考：商业加固方案（360、梆梆、爱加密）
功能：
1. 对SO文件进行加密
2. 运行时动态解密加载
3. 防止SO文件被直接分析
"""

import os
import sys
import struct
import hashlib
from typing import Optional
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import zlib


class SoEncryptor:
    """SO文件加密器"""
    
    def __init__(self, encryption_key: Optional[bytes] = None):
        """
        初始化加密器
        :param encryption_key: AES加密密钥
        """
        if encryption_key is None:
            # 默认加密密钥
            self.encryption_key = hashlib.sha256(b'ArkVMP_SO_Key_2026').digest()
        else:
            self.encryption_key = encryption_key
        
        # IV向量（16字节）
        self.iv = os.urandom(16)
    
    def encrypt_so_file(self, input_path: str, output_path: str, compress: bool = True) -> bool:
        """
        加密SO文件
        :param input_path: 输入SO文件路径
        :param output_path: 输出SO文件路径
        :param compress: 是否压缩
        :return: 是否成功
        """
        try:
            # 读取SO文件
            with open(input_path, 'rb') as f:
                so_data = f.read()
            
            # 验证ELF魔数
            if len(so_data) < 4 or so_data[:4] not in [b'\x7fELF', b'\x7f\x45\x4c\x46']:
                print(f"❌ 不是有效的ELF文件")
                return False
            
            # 提取ELF头信息
            elf_class = so_data[4]  # 1=32位, 2=64位
            elf_data = so_data[5]  # 数据编码
            elf_version = so_data[6]  # 版本
            
            print(f"📋 ELF文件信息：")
            print(f"  - 类别：{'64位' if elf_class == 2 else '32位'}")
            print(f"  - 数据编码：{elf_data}")
            print(f"  - 版本：{elf_version}")
            print(f"  - 文件大小：{len(so_data)} 字节")
            print()
            
            # 压缩（如果启用）
            if compress:
                print("🗜️  压缩SO文件...")
                compressed_data = zlib.compress(so_data, level=9)
                print(f"  原始大小：{len(so_data)} 字节")
                print(f"  压缩后大小：{len(compressed_data)} 字节")
                print(f"  压缩率：{100 - (len(compressed_data) * 100 / len(so_data)):.2f}%")
                print()
                data_to_encrypt = compressed_data
            else:
                data_to_encrypt = so_data
            
            # AES-256-CBC加密
            print("🔐 加密SO文件...")
            cipher = AES.new(self.encryption_key, AES.MODE_CBC, self.iv)
            encrypted_data = cipher.encrypt(pad(data_to_encrypt, AES.block_size))
            
            # 生成文件哈希（用于完整性校验）
            file_hash = hashlib.sha256(so_data).hexdigest()
            
            # 写入加密文件
            print("📝 写入加密文件...")
            with open(output_path, 'wb') as f:
                # 写入魔数（用于识别加密文件）
                f.write(b'ARKS')
                # 写入版本
                f.write(struct.pack('<I', 1))
                # 写入ELF信息
                f.write(struct.pack('<B', elf_class))
                f.write(struct.pack('<B', elf_data))
                f.write(struct.pack('<B', elf_version))
                f.write(struct.pack('<B', 0))  # 保留字节
                # 写入压缩标志
                f.write(struct.pack('<B', 1 if compress else 0))
                f.write(struct.pack('<B', 0))  # 保留字节
                f.write(struct.pack('<H', 0))  # 保留2字节
                # 写入原始大小
                f.write(struct.pack('<I', len(so_data)))
                # 写入加密后大小
                f.write(struct.pack('<I', len(encrypted_data)))
                # 写入文件哈希
                f.write(file_hash.encode('utf-8'))
                # 写入IV
                f.write(self.iv)
                # 写入加密数据
                f.write(encrypted_data)
            
            print(f"✅ SO文件加密完成：{output_path}")
            print(f"📊 加密统计：")
            print(f"  - 原始大小：{len(so_data)} 字节")
            print(f"  - 加密后大小：{len(encrypted_data)} 字节")
            print(f"  - 文件哈希：{file_hash}")
            
            return True
            
        except Exception as e:
            print(f"❌ SO文件加密失败：{e}")
            return False
    
    def decrypt_so_file(self, input_path: str, output_path: str) -> bool:
        """
        解密SO文件
        :param input_path: 输入加密文件路径
        :param output_path: 输出SO文件路径
        :return: 是否成功
        """
        try:
            # 读取加密文件
            with open(input_path, 'rb') as f:
                data = f.read()
            
            # 验证魔数
            if len(data) < 4 or data[:4] != b'ARKS':
                print(f"❌ 不是有效的加密SO文件")
                return False
            
            offset = 4
            
            # 读取版本
            version = struct.unpack('<I', data[offset:offset+4])[0]
            offset += 4
            
            # 读取ELF信息
            elf_class = data[offset]
            offset += 1
            elf_data = data[offset]
            offset += 1
            elf_version = data[offset]
            offset += 1
            offset += 1  # 跳过保留字节
            
            # 读取压缩标志
            compress_flag = data[offset]
            offset += 1
            offset += 1  # 跳过保留字节
            offset += 2  # 跳过保留2字节
            
            # 读取原始大小
            original_size = struct.unpack('<I', data[offset:offset+4])[0]
            offset += 4
            
            # 读取加密后大小
            encrypted_size = struct.unpack('<I', data[offset:offset+4])[0]
            offset += 4
            
            # 读取文件哈希
            file_hash = data[offset:offset+64].decode('utf-8')
            offset += 64
            
            # 读取IV
            iv = data[offset:offset+16]
            offset += 16
            
            # 读取加密数据
            encrypted_data = data[offset:offset+encrypted_size]
            
            print(f"📋 加密文件信息：")
            print(f"  - 版本：{version}")
            print(f"  - ELF类别：{'64位' if elf_class == 2 else '32位'}")
            print(f"  - 压缩：{'是' if compress_flag else '否'}")
            print(f"  - 原始大小：{original_size} 字节")
            print(f"  - 文件哈希：{file_hash}")
            print()
            
            # AES-256-CBC解密
            print("🔓 解密SO文件...")
            cipher = AES.new(self.encryption_key, AES.MODE_CBC, iv)
            decrypted_data = cipher.decrypt(encrypted_data)
            
            # 去除填充
            decrypted_data = decrypted_data[:-decrypted_data[-1]]
            
            # 解压（如果需要）
            if compress_flag:
                print("📦 解压SO文件...")
                so_data = zlib.decompress(decrypted_data)
            else:
                so_data = decrypted_data
            
            # 验证哈希
            calculated_hash = hashlib.sha256(so_data).hexdigest()
            if calculated_hash != file_hash:
                print(f"❌ 文件哈希不匹配！")
                print(f"  预期：{file_hash}")
                print(f"  实际：{calculated_hash}")
                return False
            
            # 写入解密文件
            print("📝 写入解密文件...")
            with open(output_path, 'wb') as f:
                f.write(so_data)
            
            print(f"✅ SO文件解密完成：{output_path}")
            print(f"📊 解密统计：")
            print(f"  - 文件大小：{len(so_data)} 字节")
            print(f"  - 哈希校验：通过")
            
            return True
            
        except Exception as e:
            print(f"❌ SO文件解密失败：{e}")
            return False
    
    def encrypt_so_directory(self, input_dir: str, output_dir: str, compress: bool = True) -> bool:
        """
        加密目录中的所有SO文件
        :param input_dir: 输入目录
        :param output_dir: 输出目录
        :param compress: 是否压缩
        :return: 是否成功
        """
        try:
            # 确保输出目录存在
            os.makedirs(output_dir, exist_ok=True)
            
            success_count = 0
            total_count = 0
            
            # 遍历输入目录
            for root, dirs, files in os.walk(input_dir):
                for file in files:
                    if file.endswith('.so'):
                        total_count += 1
                        
                        input_path = os.path.join(root, file)
                        
                        # 计算相对路径
                        rel_path = os.path.relpath(input_path, input_dir)
                        output_path = os.path.join(output_dir, rel_path)
                        
                        # 确保输出目录存在
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)
                        
                        # 加密SO文件
                        if self.encrypt_so_file(input_path, output_path, compress):
                            success_count += 1
            
            print(f"\n📊 加密统计：")
            print(f"  - 总文件数：{total_count}")
            print(f"  - 成功数：{success_count}")
            print(f"  - 失败数：{total_count - success_count}")
            
            return success_count == total_count
            
        except Exception as e:
            print(f"❌ 目录加密失败：{e}")
            return False


# 主函数
def main():
    if len(sys.argv) < 3:
        print("使用方法：")
        print("  python so_encrypt.py <输入路径> <输出路径> [--compress] [--decrypt]")
        print()
        print("示例：")
        print("  python so_encrypt.py libArkStub.so libArkStub_encrypted.so")
        print("  python so_encrypt.py lib/ encrypted_lib/ --compress")
        print("  python so_encrypt.py libArkStub_encrypted.so libArkStub.so --decrypt")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    compress = '--compress' in sys.argv
    decrypt = '--decrypt' in sys.argv
    
    if not os.path.exists(input_path):
        print(f"❌ 输入路径不存在：{input_path}")
        sys.exit(1)
    
    print(f"🔧 开始{'解' if decrypt else '加'}密：{input_path}")
    print(f"📁 输出路径：{output_path}")
    if compress:
        print(f"🗜️  压缩：是")
    print()
    
    # 创建加密器
    encryptor = SoEncryptor()
    
    # 判断是文件还是目录
    if os.path.isfile(input_path):
        if input_path.endswith('.so'):
            # SO文件
            if decrypt:
                if encryptor.decrypt_so_file(input_path, output_path):
                    print(f"\n✅ 操作完成：{output_path}")
                else:
                    sys.exit(1)
            else:
                if encryptor.encrypt_so_file(input_path, output_path, compress):
                    print(f"\n✅ 操作完成：{output_path}")
                else:
                    sys.exit(1)
        else:
            print(f"❌ 不是SO文件：{input_path}")
            sys.exit(1)
    elif os.path.isdir(input_path):
        # 目录
        if decrypt:
            print(f"❌ 目录解密暂不支持")
            sys.exit(1)
        else:
            if encryptor.encrypt_so_directory(input_path, output_path, compress):
                print(f"\n✅ 操作完成：{output_path}")
            else:
                sys.exit(1)
    else:
        print(f"❌ 不支持的路径类型：{input_path}")
        sys.exit(1)


if __name__ == '__main__':
    main()