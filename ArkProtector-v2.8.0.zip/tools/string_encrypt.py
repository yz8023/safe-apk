#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
字符串加密工具
参考：StringFog (https://github.com/MegatronKing/StringFog)
功能：
1. 扫描Java代码中所有字符串常量
2. 自动加密存储
3. 运行时解密
4. 防止静态分析提取敏感字符串
"""

import os
import sys
import re
import json
import struct
from typing import List, Dict, Optional
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import hashlib


class StringEncryptor:
    """字符串加密器"""
    
    def __init__(self, encryption_key: Optional[bytes] = None):
        """
        初始化加密器
        :param encryption_key: AES加密密钥
        """
        if encryption_key is None:
            # 默认加密密钥
            self.encryption_key = hashlib.sha256(b'ArkVMP_String_Key_2026').digest()
        else:
            self.encryption_key = encryption_key
        
        # IV向量（16字节）
        self.iv = os.urandom(16)
        
        # 字符串映射表
        self.string_map = {}
    
    def encrypt_string(self, plaintext: str) -> str:
        """
        加密单个字符串
        :param plaintext: 明文字符串
        :return: 加密后的十六进制字符串
        """
        try:
            # 转换为字节
            data = plaintext.encode('utf-8')
            
            # AES-256-CBC加密
            cipher = AES.new(self.encryption_key, AES.MODE_CBC, self.iv)
            encrypted_data = cipher.encrypt(pad(data, AES.block_size))
            
            # 返回十六进制字符串
            return encrypted_data.hex()
            
        except Exception as e:
            print(f"❌ 字符串加密失败：{e}")
            return ""
    
    def scan_java_file(self, java_file: str) -> Dict[str, List[str]]:
        """
        扫描Java文件中的字符串常量
        :param java_file: Java文件路径
        :return: 字符串字典 {类名: [字符串列表]}
        """
        try:
            with open(java_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 提取类名
            class_match = re.search(r'package\s+([\w.]+);', content)
            package = class_match.group(1) if class_match else ""
            
            class_name_match = re.search(r'(?:public|private|protected)?\s*class\s+(\w+)', content)
            class_name = class_name_match.group(1) if class_name_match else ""
            
            full_class_name = f"{package}.{class_name}" if package and class_name else java_file
            
            # 提取字符串常量
            # 匹配双引号字符串
            string_pattern = r'"([^"\\]*(?:\\.[^"\\]*)*)"'
            strings = re.findall(string_pattern, content)
            
            # 过滤短字符串（长度<3）和空字符串
            filtered_strings = [s for s in strings if len(s) >= 3]
            
            return {full_class_name: filtered_strings}
            
        except Exception as e:
            print(f"❌ 扫描Java文件失败：{e}")
            return {}
    
    def scan_directory(self, directory: str) -> Dict[str, List[str]]:
        """
        扫描目录中的所有Java文件
        :param directory: 目录路径
        :return: 字符串字典
        """
        all_strings = {}
        
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.endswith('.java'):
                    java_file = os.path.join(root, file)
                    strings = self.scan_java_file(java_file)
                    all_strings.update(strings)
        
        return all_strings
    
    def encrypt_strings(self, strings: Dict[str, List[str]]) -> Dict[str, Dict[str, str]]:
        """
        加密所有字符串
        :param strings: 字符串字典
        :return: 加密后的字符串字典
        """
        encrypted_strings = {}
        
        for class_name, string_list in strings.items():
            encrypted_strings[class_name] = {}
            for string_val in string_list:
                encrypted = self.encrypt_string(string_val)
                if encrypted:
                    encrypted_strings[class_name][string_val] = encrypted
        
        return encrypted_strings
    
    def generate_encrypted_code(self, java_file: str, encrypted_strings: Dict[str, str]) -> str:
        """
        生成加密后的Java代码
        :param java_file: Java文件路径
        :param encrypted_strings: 加密后的字符串字典
        :return: 加密后的Java代码
        """
        try:
            with open(java_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 替换字符串常量
            for original, encrypted in encrypted_strings.items():
                # 转义特殊字符
                escaped_original = re.escape(original)
                # 替换为解密调用
                content = re.sub(
                    f'"{escaped_original}"',
                    f'StringFog.decrypt("{encrypted}")',
                    content
                )
            
            return content
            
        except Exception as e:
            print(f"❌ 生成加密代码失败：{e}")
            return ""
    
    def save_encrypted_strings(self, encrypted_strings: Dict[str, Dict[str, str]], output_file: str) -> bool:
        """
        保存加密后的字符串到文件
        :param encrypted_strings: 加密后的字符串字典
        :param output_file: 输出文件路径
        :return: 是否成功
        """
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(encrypted_strings, f, indent=2, ensure_ascii=False)
            
            print(f"✅ 加密字符串已保存：{output_file}")
            return True
            
        except Exception as e:
            print(f"❌ 保存加密字符串失败：{e}")
            return False


# 主函数
def main():
    if len(sys.argv) < 3:
        print("使用方法：")
        print("  python string_encrypt.py <输入路径> <输出目录>")
        print()
        print("示例：")
        print("  python string_encrypt.py src/main/java output_dir")
        print("  python string_encrypt.py MyClass.java output_dir")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_dir = sys.argv[2]
    
    if not os.path.exists(input_path):
        print(f"❌ 输入路径不存在：{input_path}")
        sys.exit(1)
    
    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"🔧 开始字符串加密：{input_path}")
    print(f"📁 输出目录：{output_dir}")
    print()
    
    # 创建加密器
    encryptor = StringEncryptor()
    
    # 扫描字符串
    if os.path.isfile(input_path) and input_path.endswith('.java'):
        # 扫描单个Java文件
        strings = encryptor.scan_java_file(input_path)
    elif os.path.isdir(input_path):
        # 扫描目录
        strings = encryptor.scan_directory(input_path)
    else:
        print(f"❌ 不支持的输入类型：{input_path}")
        sys.exit(1)
    
    # 统计字符串数量
    total_strings = sum(len(lst) for lst in strings.values())
    print(f"📊 扫描统计：")
    print(f"  - 类数量：{len(strings)}")
    print(f"  - 字符串数量：{total_strings}")
    print()
    
    if total_strings == 0:
        print(f"⚠️  未发现需要加密的字符串")
        sys.exit(0)
    
    # 加密字符串
    print("🔐 加密字符串...")
    encrypted_strings = encryptor.encrypt_strings(strings)
    
    # 保存加密后的字符串
    encrypted_file = os.path.join(output_dir, 'encrypted_strings.json')
    if not encryptor.save_encrypted_strings(encrypted_strings, encrypted_file):
        sys.exit(1)
    
    # 生成加密后的Java代码
    print("📝 生成加密后的Java代码...")
    for class_name, class_strings in encrypted_strings.items():
        # 查找对应的Java文件
        java_file = None
        if os.path.isfile(input_path):
            java_file = input_path
        elif os.path.isdir(input_path):
            # 在目录中查找对应的Java文件
            package_path = class_name.replace('.', '/')
            java_file = os.path.join(input_path, f"{package_path}.java")
        
        if java_file and os.path.exists(java_file):
            # 生成加密后的代码
            encrypted_code = encryptor.generate_encrypted_code(java_file, class_strings)
            
            # 保存加密后的代码
            output_file = os.path.join(output_dir, os.path.basename(java_file))
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(encrypted_code)
            
            print(f"  ✅ {class_name}")
    
    print()
    print(f"✅ 字符串加密完成")
    print(f"📁 输出文件：")
    print(f"  - 加密字符串：{encrypted_file}")
    print(f"  - 加密代码：{output_dir}/")


if __name__ == '__main__':
    main()