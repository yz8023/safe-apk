#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
白盒加密表生成工具
参考：学术界白盒密码学方案
功能：
1. 生成白盒AES加密表
2. 生成白盒AES解密表
3. 生成白盒密钥派生表
4. 防止密钥被提取
"""

import os
import sys
import struct
import hashlib
import json
from typing import List, Dict, Optional
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import random


class WhiteBoxGenerator:
    """白盒加密表生成器"""
    
    def __init__(self, master_key: Optional[bytes] = None):
        """
        初始化生成器
        :param master_key: 主密钥（32字节）
        """
        if master_key is None:
            # 默认主密钥
            self.master_key = hashlib.sha256(b'ArkVMP_WhiteBox_Master_2026').digest()
        else:
            self.master_key = master_key
        
        # 派生密钥
        self.encryption_key = self._derive_key(b'encryption')
        self.decryption_key = self._derive_key(b'decryption')
    
    def _derive_key(self, purpose: bytes) -> bytes:
        """
        派生子密钥
        :param purpose: 用途标识
        :return: 派生密钥
        """
        # 使用HKDF派生密钥
        hmac = hashlib.sha256(purpose + self.master_key).digest()
        return hmac[:32]
    
    def generate_sbox_table(self, key: Optional[bytes] = None) -> List[int]:
        """
        生成S盒表
        :param key: 可选密钥
        :return: S盒表（256个元素）
        """
        if key is None:
            key = self.encryption_key
        
        # 使用AES作为伪随机数生成器
        cipher = AES.new(key, AES.MODE_ECB)
        
        sbox_table = []
        for i in range(256):
            # 生成S盒值
            plaintext = bytes([i] * 16)
            ciphertext = cipher.encrypt(plaintext)
            sbox_value = ciphertext[0]
            sbox_table.append(sbox_value)
        
        return sbox_table
    
    def generate_inverse_sbox_table(self, key: Optional[bytes] = None) -> List[int]:
        """
        生成逆S盒表
        :param key: 可选密钥
        :return: 逆S盒表（256个元素）
        """
        sbox_table = self.generate_sbox_table(key)
        
        # 计算逆S盒
        inverse_sbox = [0] * 256
        for i in range(256):
            inverse_sbox[sbox_table[i]] = i
        
        return inverse_sbox
    
    def generate_mix_column_table(self, key: Optional[bytes] = None) -> List[List[int]]:
        """
        生成MixColumns表
        :param key: 可选密钥
        :return: MixColumns表（256x256）
        """
        if key is None:
            key = self.encryption_key
        
        # 使用AES作为伪随机数生成器
        cipher = AES.new(key, AES.MODE_ECB)
        
        mix_table = []
        for i in range(256):
            row = []
            for j in range(256):
                # 生成MixColumns值
                plaintext = bytes([i, j] + [0] * 14)
                ciphertext = cipher.encrypt(plaintext)
                mix_value = (ciphertext[0] << 8) | ciphertext[1]
                row.append(mix_value)
            mix_table.append(row)
        
        return mix_table
    
    def generate_round_key_table(self, round_num: int, key: Optional[bytes] = None) -> List[int]:
        """
        生成轮密钥表
        :param round_num: 轮数（0-10）
        :param key: 可选密钥
        :return: 轮密钥表（16个元素）
        """
        if key is None:
            key = self.encryption_key
        
        # 使用AES密钥扩展算法
        cipher = AES.new(key, AES.MODE_ECB)
        
        # 生成轮密钥
        round_key_input = bytes([round_num] * 16)
        round_key = cipher.encrypt(round_key_input)
        
        # 转换为整数列表
        round_key_list = list(round_key)
        
        return round_key_list
    
    def generate_tbox_table(self, key: Optional[bytes] = None) -> List[List[int]]:
        """
        生成T-box表（S盒 + 轮密钥 + MixColumns的组合）
        :param key: 可选密钥
        :return: T-box表（4个256x256的表）
        """
        if key is None:
            key = self.encryption_key
        
        sbox_table = self.generate_sbox_table(key)
        mix_table = self.generate_mix_column_table(key)
        
        # 生成4个T-box
        tbox_tables = []
        for t in range(4):
            tbox = []
            for i in range(256):
                row = []
                for j in range(256):
                    # T-box = Sbox(MixColumns(Sbox(i) XOR round_key[j]))
                    sbox_i = sbox_table[i]
                    mix_value = mix_table[sbox_i][j]
                    tbox_value = sbox_table[mix_value & 0xFF]
                    row.append(tbox_value)
                tbox.append(row)
            tbox_tables.append(tbox)
        
        return tbox_tables
    
    def generate_xor_table(self, key: Optional[bytes] = None) -> List[List[int]]:
        """
        生成XOR表
        :param key: 可选密钥
        :return: XOR表（256x256）
        """
        if key is None:
            key = self.encryption_key
        
        # 使用AES作为伪随机数生成器
        cipher = AES.new(key, AES.MODE_ECB)
        
        xor_table = []
        for i in range(256):
            row = []
            for j in range(256):
                # 生成XOR表值（带随机扰动）
                plaintext = bytes([i, j] + [0] * 14)
                ciphertext = cipher.encrypt(plaintext)
                xor_value = i ^ j
                # 添加扰动
                xor_value ^= ciphertext[0]
                row.append(xor_value)
            xor_table.append(row)
        
        return xor_table
    
    def generate_whitebox_tables(self, rounds: int = 10) -> Dict:
        """
        生成完整的白盒加密表
        :param rounds: 轮数
        :return: 白盒表字典
        """
        print(f"🔧 开始生成白盒加密表（{rounds}轮）...")
        
        tables = {}
        
        # 生成S盒表
        print("  生成S盒表...")
        tables['sbox'] = self.generate_sbox_table()
        tables['inverse_sbox'] = self.generate_inverse_sbox_table()
        
        # 生成MixColumns表
        print("  生成MixColumns表...")
        tables['mix_column'] = self.generate_mix_column_table()
        
        # 生成轮密钥表
        print("  生成轮密钥表...")
        tables['round_keys'] = []
        for r in range(rounds + 1):
            round_key = self.generate_round_key_table(r)
            tables['round_keys'].append(round_key)
        
        # 生成T-box表
        print("  生成T-box表...")
        tables['tbox'] = self.generate_tbox_table()
        
        # 生成XOR表
        print("  生成XOR表...")
        tables['xor'] = self.generate_xor_table()
        
        # 添加元数据
        tables['metadata'] = {
            'version': '1.0',
            'rounds': rounds,
            'key_hash': hashlib.sha256(self.master_key).hexdigest(),
            'table_sizes': {
                'sbox': len(tables['sbox']),
                'inverse_sbox': len(tables['inverse_sbox']),
                'mix_column': len(tables['mix_column']),
                'round_keys': len(tables['round_keys']),
                'tbox': len(tables['tbox']),
                'xor': len(tables['xor'])
            }
        }
        
        print(f"✅ 白盒加密表生成完成")
        
        return tables
    
    def save_tables(self, tables: Dict, output_file: str) -> bool:
        """
        保存白盒表到文件
        :param tables: 白盒表字典
        :param output_file: 输出文件路径
        :return: 是否成功
        """
        try:
            # 保存为JSON格式
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(tables, f, indent=2)
            
            print(f"✅ 白盒表已保存：{output_file}")
            return True
            
        except Exception as e:
            print(f"❌ 保存白盒表失败：{e}")
            return False
    
    def save_tables_binary(self, tables: Dict, output_file: str) -> bool:
        """
        保存白盒表到二进制文件
        :param tables: 白盒表字典
        :param output_file: 输出文件路径
        :return: 是否成功
        """
        try:
            with open(output_file, 'wb') as f:
                # 写入魔数
                f.write(b'ARKW')
                
                # 写入版本
                f.write(struct.pack('<I', 1))
                
                # 写入S盒表
                sbox = tables['sbox']
                f.write(struct.pack('<I', len(sbox)))
                f.write(bytes(sbox))
                
                # 写入逆S盒表
                inverse_sbox = tables['inverse_sbox']
                f.write(struct.pack('<I', len(inverse_sbox)))
                f.write(bytes(inverse_sbox))
                
                # 写入MixColumns表
                mix_column = tables['mix_column']
                f.write(struct.pack('<I', len(mix_column)))
                f.write(struct.pack('<I', len(mix_column[0])))
                for row in mix_column:
                    for value in row:
                        f.write(struct.pack('<H', value))
                
                # 写入轮密钥表
                round_keys = tables['round_keys']
                f.write(struct.pack('<I', len(round_keys)))
                for round_key in round_keys:
                    f.write(struct.pack('<I', len(round_key)))
                    f.write(bytes(round_key))
                
                # 写入T-box表
                tbox = tables['tbox']
                f.write(struct.pack('<I', len(tbox)))
                for tbox_table in tbox:
                    f.write(struct.pack('<I', len(tbox_table)))
                    f.write(struct.pack('<I', len(tbox_table[0])))
                    for row in tbox_table:
                        f.write(bytes(row))
                
                # 写入XOR表
                xor = tables['xor']
                f.write(struct.pack('<I', len(xor)))
                f.write(struct.pack('<I', len(xor[0])))
                for row in xor:
                    for value in row:
                        f.write(struct.pack('<B', value))
                
                # 写入元数据
                metadata = json.dumps(tables['metadata']).encode('utf-8')
                f.write(struct.pack('<I', len(metadata)))
                f.write(metadata)
            
            print(f"✅ 白盒表已保存（二进制）：{output_file}")
            return True
            
        except Exception as e:
            print(f"❌ 保存白盒表失败：{e}")
            return False
    
    def load_tables(self, input_file: str) -> Optional[Dict]:
        """
        从文件加载白盒表
        :param input_file: 输入文件路径
        :return: 白盒表字典
        """
        try:
            with open(input_file, 'r', encoding='utf-8') as f:
                tables = json.load(f)
            
            print(f"✅ 白盒表已加载：{input_file}")
            return tables
            
        except Exception as e:
            print(f"❌ 加载白盒表失败：{e}")
            return None


# 主函数
def main():
    if len(sys.argv) < 2:
        print("使用方法：")
        print("  python whitebox_gen.py <输出文件> [--rounds <轮数>] [--binary]")
        print()
        print("示例：")
        print("  python whitebox_gen.py whitebox_tables.json")
        print("  python whitebox_gen.py whitebox_tables.json --rounds 10")
        print("  python whitebox_gen.py whitebox_tables.bin --binary")
        sys.exit(1)
    
    output_file = sys.argv[1]
    rounds = 10
    binary = False
    
    # 解析参数
    if '--rounds' in sys.argv:
        idx = sys.argv.index('--rounds')
        if idx + 1 < len(sys.argv):
            rounds = int(sys.argv[idx + 1])
    
    binary = '--binary' in sys.argv
    
    print(f"🔧 开始生成白盒加密表")
    print(f"📁 输出文件：{output_file}")
    print(f"🔄 轮数：{rounds}")
    print(f"📦 格式：{'二进制' if binary else 'JSON'}")
    print()
    
    # 创建生成器
    generator = WhiteBoxGenerator()
    
    # 生成白盒表
    tables = generator.generate_whitebox_tables(rounds)
    
    # 保存白盒表
    if binary:
        if not generator.save_tables_binary(tables, output_file):
            sys.exit(1)
    else:
        if not generator.save_tables(tables, output_file):
            sys.exit(1)
    
    print()
    print(f"✅ 白盒加密表生成完成")
    print(f"📊 表统计：")
    metadata = tables['metadata']
    for key, value in metadata['table_sizes'].items():
        print(f"  - {key}: {value}")


if __name__ == '__main__':
    main()