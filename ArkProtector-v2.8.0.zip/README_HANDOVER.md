# Arkjiagu（Ark加固）项目交接文档

## 1. 项目概述

| 项 | 内容 |
|---|---|
| 项目名称 | Arkjiagu / Ark加固 |
| 包名 | `com.ark.jiagu` |
| 当前版本 | `3.71`（`versionCode 371`） |
| 项目类型 | Android APK 加固器（在 Android 设备上直接运行） |
| 开发语言 | Java + C/C++（NDK/CMake） |
| 构建系统 | Gradle 8.13 + Android Gradle Plugin 8.13.2 |
| 核心依赖 | smali-dexlib2 3.0.9、apksigner、BouncyCastle、AndroidX |

Arkjiagu 是一款在 Android 设备端运行的 APK 加固工具。它解析目标 APK，对其 DEX、SO、资源、Manifest 进行加密/混淆/抽取，再重新打包、签名、对齐，输出可直接安装的加固包。

---

## 2. 当前状态

- **项目可编译**：在正确配置 JDK 17 + Android SDK/NDK 后，`./gradlew assembleDebug` 可以成功构建出 APK。
- **加固器本体可运行**：Debug APK 已生成在 `app/build/outputs/apk/debug/app-debug.apk`。
- **仍有运行时崩溃未解决**：
  - 类重命名（Class Rename）加固后的 APK 在运行时会出现 `VerifyError` 闪退。
  - DPT 函数抽取（标准版 / 增强版）加固后的 APK 在运行时闪退。
- 其余功能（DEX 加密、VMP、控制流混淆、垃圾代码、字符串加密等）已可启用，但建议逐功能在测试 APK 上验证后再合入生产流程。

---

## 3. 已完成功能

### 3.1 加固流程

- APK 解压与重新打包
- AndroidManifest 篡改（替换 Application、AppComponentFactory）
- DEX 加密与 Native 层解密加载
- VMP 虚拟机保护（方法抽取 + Native 解释器执行）
- SO 加固与 ELF section 注入
- ZIP 对齐（ZipAlign）
- JKS/V1/V2/V3 APK 签名与自动签名
- SO 名称随机化
- 加固日志实时输出

### 3.2 代码混淆（Java/DEX 层）

| 功能 | 状态 | 说明 |
|---|---|---|
| 控制流混淆 | 可用 | 在 `DexObfuscator.applyControlFlow` |
| 垃圾代码注入 | 可用 | `applyJunkCodeEx` |
| 算术混淆 | 可用 | `applyArithmeticObfuscation` |
| 算术分支 | 可用 | `applyArithmeticBranchEx` |
| 调用间接化 | 可用 | `applyCallIndirection` |
| Goto 插入 | 可用 | `applyGotoInsertion` |
| 常量字符串加密 | 可用 | 字符串加密开关 |
| 方法重载 | 可用 | `applyMethodOverload` |
| Debug 信息移除 | 可用 | 移除行号等调试信息 |
| 类重命名 | **运行时崩溃** | `DexObfuscator` 已处理数组类型、注解、invoke-custom 等，仍闪退 |
| 字段重命名 | 可用 | 与类重命名联动 |

### 3.3 DPT 函数抽取

| 功能 | 状态 | 说明 |
|---|---|---|
| DPT 标准版 | **运行时崩溃** | 已实现小端序解析、Adler32 重算、return stub、native 还原 |
| DPT 增强版 | **运行时崩溃** | 在标准版基础上增加 XOR 加密 |
| 运行时还原 | 已实现 | `DptHook.cpp` 扫描 `/proc/self/maps` 定位 DEX 后 `mprotect` + `memcpy` 还原 |

### 3.4 资源与 SO 保护

- 资源混淆
- 资源压缩
- Assets 加密
- DEX 字符串解密
- SO 名称随机化
- DEX Header 混淆
- 多 DEX 打乱

### 3.5 运行时安全（Native / Java）

- 反模拟器、Root 检测、反调试、反 Xposed、反 VM
- APK 完整性校验
- Frida 管道 / 线程检测
- 内存-磁盘对比检测
- Java/Native Hook 检测
- 位置模拟 / 设备修改检测
- 应用多开检测

### 3.6 配置与 UI

- 设置弹窗：所有功能开关集中配置
- 冲突检测：互斥选项自动关闭（如 DPT 标准/增强、自动签名/签名绕过、控制流/垃圾代码等）
- 自定义 JKS 签名
- SO 名称预设选择

---

## 4. 已知问题与待开发内容

### 4.1 P0 - 阻塞问题（必须先修）

1. **类重命名运行时 VerifyError**
   - 现象：`register vX has type Precise Constant: 1 but expected Reference: android.content.Context` 等 verifier 错误。
   - 已尝试：数组类型递归 remap、注解 remap、invoke-custom/const-method-handle/invoke-polymorphic 支持、寄存器污染修复。
   - 下一步：继续审查 `DexObfuscator` 中所有修改指令后是否破坏寄存器类型流；建议对单个类开启/关闭逐项二分定位。

2. **DPT 两种模式均闪退**
   - 现象：加固后 APK 启动即崩溃。
   - 已尝试：参考 luoyesiqiu/dpt-shell 重写 `DptCodeExtractor`、`DptCodeItemStore`、`DptHook.cpp`；修复小端序、checksum、const/4 编码、宽返回寄存器、base address 定位。
   - 下一步：用 `adb logcat` 抓 Native 崩溃堆栈，确认是还原时机、CodeItem 偏移、还是 DEX 校验失败导致。

### 4.2 P1 - 重要待完善

3. **VMP 抽取覆盖率与稳定性**
   - 部分方法被跳过（显示 0 条），需要检查 `markMethodsAsModified` 与抽取条件。
   - 复杂 try-catch/switch 方法需跳过或特殊处理。

4. **Native 新增模块编译风险**
   - `cpp/anti/`、`cpp/crypt/`、`cpp/dex/`、`cpp/jit/` 等目录下新增模块可能存在未链接的外部类型或缺失实现，需逐个编译验证。

5. **签名校验策略**
   - Native 层签名校验失败直接 `exit`，建议增加调试模式开关与降级策略。

6. **ContentProvider 初始化时序**
   - Provider 在 `Application.onCreate` 之前初始化，可能因 DEX 未加载完毕导致 `ClassNotFoundException`。

### 4.3 P2 - 优化与扩展

7. 资源 ID 重映射（当前仅复制文件，未真正 remap）。
8. 批量加固与策略模板。
9. 加固效果评估工具（反编译对比）。
10. 安全日志与性能监控数据格式定义。
11. UI 操作引导与进度百分比显示。

---

## 5. 开发环境

### 5.1 必需环境

| 组件 | 版本/要求 | 说明 |
|---|---|---|
| 操作系统 | Ubuntu 24.04 LTS / Windows 10/11 | Linux 构建 Native 更稳定 |
| JDK | **17** | Gradle 8.x 与 AGP 8.13 必需 |
| Android SDK | API 36 Platform（compileSdk = 36） | 同时准备 `android-34`、`android-35` |
| Build Tools | 34.x / 35.x | `aapt2`、`dx/d8` 等 |
| Android NDK | **27.0.12077973** 或兼容版本 | CMake 3.22+ |
| CMake | 3.22.1+ | NDK 自带 |
| Gradle | 8.13 | 项目自带 wrapper |

### 5.2 推荐工具

- Android Studio Hedgehog（2023.1.1）或更高
- adb + 真机/模拟器（建议 Android 10 - 14）
- `apktool`、`jadx`、`smali` 用于验证输出

### 5.3 环境变量

```bash
export JAVA_HOME=/path/to/jdk-17
export ANDROID_HOME=/path/to/android-sdk
export ANDROID_NDK_HOME=$ANDROID_HOME/ndk/27.0.12077973
export PATH=$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH
```

### 5.4 配置 local.properties

项目中的 `local.properties` 已排除在源码包外，接手后需在项目根目录新建：

```properties
sdk.dir=/your/android/sdk/path
ndk.dir=/your/android/sdk/ndk/27.0.12077973
```

---

## 6. 构建与输出

### 6.1 构建命令

```bash
cd Arkjiagu/

# 清理并构建 Debug APK
./gradlew clean assembleDebug

# 构建 Release APK（需确认签名配置）
./gradlew assembleRelease

# 仅编译 Native SO
./gradlew :app:externalNativeBuildDebug

# 查看详细日志
./gradlew assembleDebug --info
```

### 6.2 输出产物

| 产物 | 路径 | 说明 |
|---|---|---|
| 加固器 Debug APK | `app/build/outputs/apk/debug/app-debug.apk` | 默认使用 `app/src/main/assets/Ark.jks` 签名 |
| 加固器 Release APK | `app/build/outputs/apk/release/app-release.apk` | 同上用内置 JKS |
| libArkStub.so | `app/build/intermediates/cmake/debug/obj/<abi>/` | 运行时壳 SO |
| libArkTool.so | `app/build/intermediates/cmake/debug/obj/<abi>/` | 加固器工具 SO |
| 加固后 APK | 用户在设置中指定的保存路径 | 默认常为 `/storage/emulated/0/Download/ArkJiagu/` |

### 6.3 签名配置

- 内置签名：`app/src/main/assets/Ark.jks`
  - 密码：`123456`
  - Alias：`123456`
- 可在设置中启用“自定义 JKS”并填写路径/密码/Alias。

---

## 7. 快速上手指南

### 7.1 第一次构建

1. 安装 JDK 17、Android SDK、NDK 27.0.12077973。
2. 解压 `Arkjiagu-source.zip`。
3. 在项目根目录创建 `local.properties`，指向你的 SDK/NDK。
4. 执行 `./gradlew assembleDebug`。
5. 安装到设备：`adb install app/build/outputs/apk/debug/app-debug.apk`。

### 7.2 调试崩溃

```bash
# 查看 Java 层崩溃
adb logcat -s AndroidRuntime:E ArkVMP:D ArkJiagu:D DEBUG:I

# 查看 Native 崩溃（tombstones）
adb logcat -s DEBUG:*

# 过滤加固日志
adb logcat -s ArkJiagu:D
```

### 7.3 测试单个加固功能

1. 准备一个简单的测试 APK（建议先不用 Telegram 等大型应用）。
2. 打开 Ark加固 → 设置 → 只开启一个功能（例如 DEX 加密）。
3. 选择 APK 并开始加固。
4. 安装输出 APK，确认能否正常启动。
5. 逐个开启功能，定位导致崩溃的开关。

### 7.4 推荐修复顺序

1. 先用最小测试 APK 复现类重命名崩溃，修复 `DexObfuscator`。
2. 再用同样方式修复 DPT 崩溃（抓 Native 崩溃日志）。
3. 修复完成后，再用大型 APK（如 Telegram）回归测试。

---

## 8. 关键文件索引

| 想做什么 | 改哪个文件 |
|---|---|
| 修改 DEX 加密/解密 | `ArkJiaguUtils.java`、`ArkDexLoader.cpp` |
| 修改 VMP 抽取与执行 | `DexObfuscator.java`、`ArkVMP.cpp`、`VmpRuntime.cpp`、`VmpInterpreter.cpp`、`VmHandlers.cpp` |
| 修改类/字段重命名 | `DexObfuscator.java`（核心在 `remapType`、`remapInsnInternal`、注解 remap） |
| 修改 DPT 抽取 | `dpt/DptCodeExtractor.java`、`dpt/DptCodeItemStore.java` |
| 修改 DPT 运行时还原 | `cpp/dpt/DptHook.cpp`、`ArkStub.cpp` |
| 修改控制流/垃圾代码/算术混淆 | `DexObfuscator.java` |
| 修改 UI / 设置流程 | `ArkMainActivity.java`、`ArkSettingsManager.java/ExtendedArkSettingsManager.java`、`res/layout/dialog_settings.xml` |
| 修改签名 / ZIP 对齐 | `ApkSignUtil.java`、`ZipAlign.java`、`cpp/zipalign/` |
| 修改反调试 / 反 Root | `cpp/anti/`、`cpp/security/`、`ArkEnvGuard.cpp` |
| 新增 Native 模块 | 在 `app/src/main/cpp/` 下新建目录，更新 `CMakeLists.txt` |
| 新增 Java 模块 | 在 `app/src/main/java/com/ark/jiagu/` 下新建包 |

---

## 9. 注意事项

1. **环境易失**：当前沙箱环境会在会话结束后清除 JDK/SDK，每次重建需重新安装并重新配置。
2. **类重命名与 DPT 仍不稳定**：接手后请优先修复这两项，不要直接用于生产。
3. **内置 JKS 仅用于调试**：正式发布前务必替换为自有的 release 签名。
4. **测试 APK 由简入繁**：先拿 HelloWorld 级别 APK 验证单个开关，再测大型应用。
5. **大型 APK 内存占用高**：加固过程可能 OOM，建议在高端设备或增加 Java heap 参数后测试。
6. **NDK/CMake 版本敏感**：请严格使用 NDK 27.0.12077973 或验证兼容性后再升级。

---

*文档生成时间：2026-07-18*  
*交接包版本：Arkjiagu v3.71 源码 + README_HANDOVER.md*
