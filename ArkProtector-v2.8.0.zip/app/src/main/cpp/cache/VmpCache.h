#ifndef VMP_CACHE_H
#define VMP_CACHE_H

#include <cstdint>
#include <string>
#include <vector>
#include <map>
#include <list>
#include <mutex>
#include <android/log.h>
#include "../VmContext.h"
#include "../VmpTypes.h"

#define LOG_TAG "ArkVMP_Cache"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

// 缓存条目
struct CacheEntry {
    VmpMethod method;
    uint64_t lastAccess;
    size_t size;
    uint64_t hitCount;
    uint64_t loadTime;
};

class VmpCache {
public:
    VmpCache();
    ~VmpCache();
    
    // 获取方法（优先从缓存）
    bool getMethod(int methodId, VmpMethod* out);
    
    // 缓存方法
    bool cacheMethod(int methodId, const VmpMethod& method);
    
    // 预加载方法
    void preload(const std::vector<int>& methodIds);
    
    // 清除缓存
    void clear();
    
    // 设置最大缓存大小
    void setMaxSize(size_t maxSize);
    
    // 获取统计信息
    std::string getStats();
    
    // 获取缓存命中率
    double getHitRate();
    
    // 启用/禁用缓存
    void setEnabled(bool enabled);
    
private:
    static const size_t DEFAULT_MAX_SIZE = 50 * 1024 * 1024; // 50MB
    
    std::map<int, CacheEntry> m_cache;
    std::list<int> m_lruList; // LRU列表，最近访问的在前面
    std::mutex m_mutex;
    
    size_t m_maxSize;
    size_t m_currentSize;
    
    bool m_enabled;
    
    // 统计信息
    uint64_t m_totalHits;
    uint64_t m_totalMisses;
    uint64_t m_totalLoads;
    uint64_t m_totalEvictions;
    
    // 估计方法大小
    size_t estimateSize(const VmpMethod& method);
    
    // LRU淘汰
    void evictLRU();
    
    // 更新LRU列表
    void updateLRU(int methodId);
    
    // 从LRU列表移除
    void removeFromLRU(int methodId);
    
    // 异步预加载
    void asyncPreload(const std::vector<int>& methodIds);
};

} // namespace ArkVMP

#endif // VMP_CACHE_H