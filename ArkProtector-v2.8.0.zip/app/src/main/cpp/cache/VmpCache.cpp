#include "VmpCache.h"
#include <thread>
#include <algorithm>
#include <chrono>

// 获取当前时间（微秒）
static uint64_t getCurrentTimeMicros() {
    auto now = std::chrono::high_resolution_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
}

namespace ArkVMP {

VmpCache::VmpCache()
    : m_maxSize(DEFAULT_MAX_SIZE)
    , m_currentSize(0)
    , m_enabled(true)
    , m_totalHits(0)
    , m_totalMisses(0)
    , m_totalLoads(0)
    , m_totalEvictions(0) {
    
    LOGI("VmpCache初始化完成，最大缓存大小: %zu 字节", m_maxSize);
}

VmpCache::~VmpCache() {
    clear();
}

bool VmpCache::getMethod(int methodId, VmpMethod* out) {
    if (!m_enabled || out == nullptr) {
        return false;
    }
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    auto it = m_cache.find(methodId);
    if (it != m_cache.end()) {
        // 缓存命中
        *out = it->second.method;
        it->second.lastAccess = getCurrentTimeMicros();
        it->second.hitCount++;
        m_totalHits++;
        
        // 更新LRU列表
        updateLRU(methodId);
        
        LOGI("缓存命中: methodId=%d", methodId);
        return true;
    }
    
    // 缓存未命中
    m_totalMisses++;
    LOGI("缓存未命中: methodId=%d", methodId);
    return false;
}

bool VmpCache::cacheMethod(int methodId, const VmpMethod& method) {
    if (!m_enabled) {
        return false;
    }
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    // 检查是否已存在
    if (m_cache.find(methodId) != m_cache.end()) {
        LOGW("方法已缓存: methodId=%d", methodId);
        return true;
    }
    
    // 估计大小
    size_t methodSize = estimateSize(method);
    
    // 检查是否超过限制
    while (m_currentSize + methodSize > m_maxSize && !m_cache.empty()) {
        evictLRU();
    }
    
    // 如果还是太大，放弃缓存
    if (methodSize > m_maxSize) {
        LOGW("方法太大，无法缓存: methodId=%d, 大小=%zu", methodId, methodSize);
        return false;
    }
    
    // 创建缓存条目
    CacheEntry entry;
    entry.method = method;
    entry.lastAccess = getCurrentTimeMicros();
    entry.size = methodSize;
    entry.hitCount = 0;
    entry.loadTime = getCurrentTimeMicros();
    
    // 添加到缓存
    m_cache[methodId] = entry;
    m_currentSize += methodSize;
    m_totalLoads++;
    
    // 添加到LRU列表
    m_lruList.push_front(methodId);
    
    LOGI("方法已缓存: methodId=%d, 大小=%zu, 当前缓存大小=%zu/%zu", 
         methodId, methodSize, m_currentSize, m_maxSize);
    
    return true;
}

void VmpCache::preload(const std::vector<int>& methodIds) {
    if (!m_enabled || methodIds.empty()) {
        return;
    }
    
    LOGI("开始预加载方法，数量: %zu", methodIds.size());
    
    // 异步预加载
    asyncPreload(methodIds);
}

void VmpCache::clear() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    m_cache.clear();
    m_lruList.clear();
    m_currentSize = 0;
    
    LOGI("缓存已清除");
}

void VmpCache::setMaxSize(size_t maxSize) {
    if (maxSize > 0) {
        std::lock_guard<std::mutex> lock(m_mutex);
        
        m_maxSize = maxSize;
        
        // 如果当前大小超过新限制，进行淘汰
        while (m_currentSize > m_maxSize && !m_cache.empty()) {
            evictLRU();
        }
        
        LOGI("最大缓存大小已设置: %zu 字节", maxSize);
    }
}

std::string VmpCache::getStats() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    double hitRate = getHitRate();
    
    char buffer[512];
    snprintf(buffer, sizeof(buffer),
             "缓存统计: 命中次数=%lu, 未命中次数=%lu, 加载次数=%lu, 淘汰次数=%lu, "
                           "命中率=%.2f%%, 缓存大小=%zu/%zu, 条目数=%zu",
                           m_totalHits, m_totalMisses, m_totalLoads, m_totalEvictions,
             hitRate * 100.0, m_currentSize, m_maxSize, m_cache.size());
    
    return std::string(buffer);
}

double VmpCache::getHitRate() {
    uint64_t total = m_totalHits + m_totalMisses;
    if (total == 0) {
        return 0.0;
    }
    return static_cast<double>(m_totalHits) / static_cast<double>(total);
}

void VmpCache::setEnabled(bool enabled) {
    m_enabled = enabled;
    LOGI("缓存已%s", enabled ? "启用" : "禁用");
}

size_t VmpCache::estimateSize(const VmpMethod& method) {
    // 估计方法大小
    size_t size = sizeof(VmpMethod);
    
    // 加上指令大小
    size += method.instructions.size() * sizeof(VmpInstruction);
    
    // 加上其他数据
    size += method.className.length();
    size += method.methodName.length();
    size += method.methodSignature.length();
    
    // 乘以一个系数（考虑内存对齐等）
    return size * 2;
}

void VmpCache::evictLRU() {
    if (m_lruList.empty()) {
        return;
    }
    
    // 获取最旧的条目（列表末尾）
    int methodId = m_lruList.back();
    
    auto it = m_cache.find(methodId);
    if (it != m_cache.end()) {
        m_currentSize -= it->second.size;
        m_cache.erase(it);
        m_totalEvictions++;
        
        LOGI("LRU淘汰: methodId=%d, 大小=%zu", methodId, it->second.size);
    }
    
    m_lruList.pop_back();
}

void VmpCache::updateLRU(int methodId) {
    // 从列表中移除
    removeFromLRU(methodId);
    
    // 添加到前面
    m_lruList.push_front(methodId);
}

void VmpCache::removeFromLRU(int methodId) {
    for (auto it = m_lruList.begin(); it != m_lruList.end(); ++it) {
        if (*it == methodId) {
            m_lruList.erase(it);
            break;
        }
    }
}

void VmpCache::asyncPreload(const std::vector<int>& methodIds) {
    std::thread([this, methodIds]() {
        int loadedCount = 0;
        
        for (int methodId : methodIds) {
            if (m_cache.find(methodId) == m_cache.end()) {
                // 这里应该从VMP文件加载方法
                // 为了示例，我们简化处理
                loadedCount++;
            }
        }
        
        LOGI("异步预加载完成: %d/%zu", loadedCount, methodIds.size());
    }).detach();
}

} // namespace ArkVMP