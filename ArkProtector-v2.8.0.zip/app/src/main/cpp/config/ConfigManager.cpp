#include "ConfigManager.h"
#include <android/log.h>
#include <sstream>

#define LOG_TAG "ConfigManager"
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace arkjiagu {

ConfigManager::ConfigManager()
    : configManagerObj_(nullptr)
    , configManagerClass_(nullptr)
    , jvm_(nullptr)
    , initialized_(false) {
}

ConfigManager::~ConfigManager() {
    cleanup();
}

ConfigManager& ConfigManager::getInstance() {
    static ConfigManager instance;
    return instance;
}

void ConfigManager::initialize(JNIEnv* env, jobject context) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (initialized_) {
        LOGD("ConfigManager已经初始化");
        return;
    }

    // 获取JavaVM
    env->GetJavaVM(&jvm_);

    // 获取SecurityConfigManager类
    jclass localClass = env->FindClass("com/ark/security/SecurityConfigManager");
    if (localClass == nullptr) {
        LOGE("找不到SecurityConfigManager类");
        return;
    }

    // 创建全局引用
    configManagerClass_ = (jclass)env->NewGlobalRef(localClass);
    env->DeleteLocalRef(localClass);

    // 获取getInstance方法
    jmethodID getInstanceMethod = env->GetStaticMethodID(
        configManagerClass_,
        "getInstance",
        "(Landroid/content/Context;)Lcom/ark/security/SecurityConfigManager;"
    );

    if (getInstanceMethod == nullptr) {
        LOGE("找不到getInstance方法");
        return;
    }

    // 调用getInstance获取单例
    jobject localObj = env->CallStaticObjectMethod(configManagerClass_, getInstanceMethod, context);
    if (localObj == nullptr) {
        LOGE("调用getInstance失败");
        return;
    }

    // 创建全局引用
    configManagerObj_ = env->NewGlobalRef(localObj);
    env->DeleteLocalRef(localObj);

    // 缓存配置到本地
    cacheConfig(env);

    initialized_ = true;
    LOGI("ConfigManager初始化成功");
}

void ConfigManager::cacheConfig(JNIEnv* env) {
    if (!configManagerObj_ || !configManagerClass_) {
        return;
    }

    // 缓存常用的布尔配置
    boolCache_["anti_debug.enabled"] = isFeatureEnabled("anti_debug");
    boolCache_["memory_protection.enabled"] = isFeatureEnabled("memory_protection");
    boolCache_["vmp.enabled"] = isFeatureEnabled("vmp");
    boolCache_["grayscale_manager.enabled"] = isFeatureEnabled("grayscale_manager");
    boolCache_["performance_monitor.enabled"] = isFeatureEnabled("performance_monitor");
    boolCache_["downgrade_manager.enabled"] = isFeatureEnabled("downgrade_manager");
    boolCache_["global_settings.log_enabled"] = isLogEnabled();

    // 缓存常用的整型配置
    intCache_["anti_debug.detection_interval_ms"] = getAntiDebugInterval();
    intCache_["grayscale_manager.sample_rate"] = getGrayscaleSampleRate();
    intCache_["performance_monitor.slow_threshold_ms"] = getSlowOperationThreshold();

    // 缓存常用的字符串配置
    stringCache_["anti_debug.response_strategy"] = getAntiDebugResponseStrategy();
    stringCache_["memory_protection.protection_level"] = getMemoryProtectionLevel();
    stringCache_["vmp.extraction_mode"] = getVmpExtractionMode();
    stringCache_["global_settings.log_level"] = getLogLevel();

    LOGD("配置缓存完成");
}

bool ConfigManager::isFeatureEnabled(const std::string& featureName) {
    // 先从缓存读取
    std::string cacheKey = featureName + ".enabled";
    auto it = boolCache_.find(cacheKey);
    if (it != boolCache_.end()) {
        return it->second;
    }

    // 缓存未命中，通过JNI调用
    JNIEnv* env = nullptr;
    if (jvm_->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        LOGE("获取JNIEnv失败");
        return false;
    }

    std::lock_guard<std::mutex> lock(mutex_);

    jmethodID method = env->GetMethodID(
        configManagerClass_,
        "isFeatureEnabled",
        "(Ljava/lang/String;)Z"
    );

    if (method == nullptr) {
        LOGE("找不到isFeatureEnabled方法");
        return false;
    }

    jstring featureStr = env->NewStringUTF(featureName.c_str());
    jboolean result = env->CallBooleanMethod(configManagerObj_, method, featureStr);
    env->DeleteLocalRef(featureStr);

    // 更新缓存
    boolCache_[cacheKey] = result;

    return result;
}

bool ConfigManager::getBoolean(const std::string& featureName, const std::string& key, bool defaultValue) {
    JNIEnv* env = nullptr;
    if (jvm_->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        LOGE("获取JNIEnv失败");
        return defaultValue;
    }

    std::lock_guard<std::mutex> lock(mutex_);

    jmethodID method = env->GetMethodID(
        configManagerClass_,
        "getBoolean",
        "(Ljava/lang/String;Ljava/lang/String;Z)Z"
    );

    if (method == nullptr) {
        LOGE("找不到getBoolean方法");
        return defaultValue;
    }

    jstring featureStr = env->NewStringUTF(featureName.c_str());
    jstring keyStr = env->NewStringUTF(key.c_str());
    jboolean result = env->CallBooleanMethod(configManagerObj_, method, featureStr, keyStr, defaultValue);
    env->DeleteLocalRef(featureStr);
    env->DeleteLocalRef(keyStr);

    return result;
}

int ConfigManager::getInt(const std::string& featureName, const std::string& key, int defaultValue) {
    // 先从缓存读取
    std::string cacheKey = featureName + "." + key;
    auto it = intCache_.find(cacheKey);
    if (it != intCache_.end()) {
        return it->second;
    }

    JNIEnv* env = nullptr;
    if (jvm_->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        LOGE("获取JNIEnv失败");
        return defaultValue;
    }

    std::lock_guard<std::mutex> lock(mutex_);

    jmethodID method = env->GetMethodID(
        configManagerClass_,
        "getInt",
        "(Ljava/lang/String;Ljava/lang/String;I)I"
    );

    if (method == nullptr) {
        LOGE("找不到getInt方法");
        return defaultValue;
    }

    jstring featureStr = env->NewStringUTF(featureName.c_str());
    jstring keyStr = env->NewStringUTF(key.c_str());
    jint result = env->CallIntMethod(configManagerObj_, method, featureStr, keyStr, defaultValue);
    env->DeleteLocalRef(featureStr);
    env->DeleteLocalRef(keyStr);

    // 更新缓存
    intCache_[cacheKey] = result;

    return result;
}

std::string ConfigManager::getString(const std::string& featureName, const std::string& key, const std::string& defaultValue) {
    // 先从缓存读取
    std::string cacheKey = featureName + "." + key;
    auto it = stringCache_.find(cacheKey);
    if (it != stringCache_.end()) {
        return it->second;
    }

    JNIEnv* env = nullptr;
    if (jvm_->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        LOGE("获取JNIEnv失败");
        return defaultValue;
    }

    std::lock_guard<std::mutex> lock(mutex_);

    jmethodID method = env->GetMethodID(
        configManagerClass_,
        "getString",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;"
    );

    if (method == nullptr) {
        LOGE("找不到getString方法");
        return defaultValue;
    }

    jstring featureStr = env->NewStringUTF(featureName.c_str());
    jstring keyStr = env->NewStringUTF(key.c_str());
    jstring defaultStr = env->NewStringUTF(defaultValue.c_str());
    jobject result = env->CallObjectMethod(configManagerObj_, method, featureStr, keyStr, defaultStr);
    env->DeleteLocalRef(featureStr);
    env->DeleteLocalRef(keyStr);
    env->DeleteLocalRef(defaultStr);

    const char* resultStr = env->GetStringUTFChars((jstring)result, nullptr);
    std::string resultString(resultStr);
    env->ReleaseStringUTFChars((jstring)result, resultStr);
    env->DeleteLocalRef(result);

    // 更新缓存
    stringCache_[cacheKey] = resultString;

    return resultString;
}

// 特定功能的快捷访问方法
bool ConfigManager::isAntiDebugEnabled() {
    return isFeatureEnabled("anti_debug");
}

int ConfigManager::getAntiDebugInterval() {
    return getInt("anti_debug", "detection_interval_ms", 5000);
}

std::string ConfigManager::getAntiDebugResponseStrategy() {
    return getString("anti_debug", "response_strategy", "RISK_BASED");
}

bool ConfigManager::isMemoryProtectionEnabled() {
    return isFeatureEnabled("memory_protection");
}

std::string ConfigManager::getMemoryProtectionLevel() {
    return getString("memory_protection", "protection_level", "MEDIUM");
}

bool ConfigManager::isVmpEnabled() {
    return isFeatureEnabled("vmp");
}

std::string ConfigManager::getVmpExtractionMode() {
    return getString("vmp", "extraction_mode", "AUTO");
}

bool ConfigManager::isGrayscaleEnabled() {
    return isFeatureEnabled("grayscale_manager");
}

int ConfigManager::getGrayscaleSampleRate() {
    return getInt("grayscale_manager", "sample_rate", 100);
}

bool ConfigManager::isPerformanceMonitorEnabled() {
    return isFeatureEnabled("performance_monitor");
}

int ConfigManager::getSlowOperationThreshold() {
    return getInt("performance_monitor", "slow_threshold_ms", 1000);
}

bool ConfigManager::isDowngradeManagerEnabled() {
    return isFeatureEnabled("downgrade_manager");
}

std::string ConfigManager::getMinSupportedVersion() {
    return getString("downgrade_manager", "min_supported_version", "1.0");
}

// 日志相关
bool ConfigManager::isLogEnabled() {
    return getBoolean("global_settings", "log_enabled", true);
}

std::string ConfigManager::getLogLevel() {
    return getString("global_settings", "log_level", "INFO");
}

void ConfigManager::cleanup() {
    std::lock_guard<std::mutex> lock(mutex_);

    if (configManagerObj_ && jvm_) {
        JNIEnv* env = nullptr;
        if (jvm_->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) == JNI_OK) {
            env->DeleteGlobalRef(configManagerObj_);
            env->DeleteGlobalRef(configManagerClass_);
        }
    }

    configManagerObj_ = nullptr;
    configManagerClass_ = nullptr;
    jvm_ = nullptr;
    initialized_ = false;

    boolCache_.clear();
    intCache_.clear();
    stringCache_.clear();

    LOGD("ConfigManager清理完成");
}

} // namespace arkjiagu