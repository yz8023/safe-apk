#ifndef ARKJIAGU_CONFIG_MANAGER_H
#define ARKJIAGU_CONFIG_MANAGER_H

#include <jni.h>
#include <string>
#include <map>
#include <mutex>

namespace arkjiagu {

/**
 * C++配置管理器
 * 通过JNI接口从Java层读取配置
 */
class ConfigManager {
public:
    // 获取单例实例
    static ConfigManager& getInstance();

    // 初始化配置（从Java层加载）
    void initialize(JNIEnv* env, jobject context);

    // 检查功能是否启用
    bool isFeatureEnabled(const std::string& featureName);

    // 获取功能的配置值
    bool getBoolean(const std::string& featureName, const std::string& key, bool defaultValue);
    int getInt(const std::string& featureName, const std::string& key, int defaultValue);
    std::string getString(const std::string& featureName, const std::string& key, const std::string& defaultValue);

    // 特定功能的快捷访问方法
    bool isAntiDebugEnabled();
    int getAntiDebugInterval();
    std::string getAntiDebugResponseStrategy();

    bool isMemoryProtectionEnabled();
    std::string getMemoryProtectionLevel();

    bool isVmpEnabled();
    std::string getVmpExtractionMode();

    bool isGrayscaleEnabled();
    int getGrayscaleSampleRate();

    bool isPerformanceMonitorEnabled();
    int getSlowOperationThreshold();

    bool isDowngradeManagerEnabled();
    std::string getMinSupportedVersion();

    // 日志相关
    bool isLogEnabled();
    std::string getLogLevel();

    // 清理资源
    void cleanup();

private:
    ConfigManager();
    ~ConfigManager();
    ConfigManager(const ConfigManager&) = delete;
    ConfigManager& operator=(const ConfigManager&) = delete;

    // JNI方法调用辅助函数
    jboolean callBooleanMethod(JNIEnv* env, const std::string& methodName);
    jint callIntMethod(JNIEnv* env, const std::string& methodName);
    jstring callStringMethod(JNIEnv* env, const std::string& methodName);

    // 缓存配置到本地map中
    void cacheConfig(JNIEnv* env);

    // 配置缓存
    std::map<std::string, bool> boolCache_;
    std::map<std::string, int> intCache_;
    std::map<std::string, std::string> stringCache_;

    // JNI相关
    jobject configManagerObj_;
    jclass configManagerClass_;
    JavaVM* jvm_;

    // 线程安全
    std::mutex mutex_;
    bool initialized_;
};

} // namespace arkjiagu

#endif // ARKJIAGU_CONFIG_MANAGER_H