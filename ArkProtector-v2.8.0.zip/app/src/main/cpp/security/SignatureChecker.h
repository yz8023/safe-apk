#ifndef ARK_SIGNATURE_CHECKER_H
#define ARK_SIGNATURE_CHECKER_H

#include <jni.h>
#include <string>
#include <vector>

namespace ark {
namespace security {

/**
 * APK签名校验类（Native层实现）
 * 用于在Native层验证APK签名，提高安全性
 */
class SignatureChecker {
public:
    /**
     * 初始化签名校验器
     * @param env JNI环境
     * @param context 应用上下文
     */
    static bool initialize(JNIEnv* env, jobject context);
    
    /**
     * 检查APK签名是否有效
     * @return true 如果签名有效，false 如果签名无效
     */
    static bool checkSignature();
    
    /**
     * 获取当前APK的签名哈希
     * @return 签名SHA256哈希值
     */
    static std::string getCurrentSignatureHash();
    
    /**
     * 验证签名是否匹配预期的哈希值
     * @param expectedHash 预期的签名哈希值
     * @return true 如果匹配，false 如果不匹配
     */
    static bool verifySignatureHash(const std::string& expectedHash);
    
    /**
     * 设置预期的签名哈希值
     * @param sha256Hash SHA256哈希值
     * @param md5Hash MD5哈希值（备用）
     */
    static void setExpectedSignatureHash(const std::string& sha256Hash, 
                                        const std::string& md5Hash);
    
    /**
     * 启用/禁用严格签名校验
     * @param enabled 是否启用
     */
    static void setStrictCheck(bool enabled);
    
    /**
     * 启用/禁用签名校验失败时崩溃
     * @param enabled 是否启用
     */
    static void setCrashOnFailure(bool enabled);
    
    /**
     * 获取签名校验错误信息
     * @return 错误信息
     */
    static std::string getLastError();

    /**
     * Native层APK签名校验（JNI调用）
     * @param expectedSha256 期望的SHA256签名
     * @param expectedMd5 期望的MD5签名
     * @return true 如果签名有效，false 如果签名无效
     */
    static bool nativeCheckSignature(const std::string& expectedSha256, const std::string& expectedMd5);

private:
    // JNI相关
    static JNIEnv* s_env;
    static jobject s_context;
    static jobject s_signatureChecker;
    static jmethodID s_checkSignatureMethod;
    static jmethodID s_getCurrentHashMethod;
    static jmethodID s_verifyHashMethod;
    
    // 配置
    static std::string s_expectedSHA256Hash;
    static std::string s_expectedMD5Hash;
    static bool s_strictCheck;
    static bool s_crashOnFailure;
    static std::string s_lastError;
    
    // 工具方法
    static bool initializeJNI();
    static void cleanupJNI();
    static std::string jstringToString(JNIEnv* env, jstring jstr);
    static jstring stringToJString(JNIEnv* env, const std::string& str);
};

} // namespace security
} // namespace ark

#endif // ARK_SIGNATURE_CHECKER_H