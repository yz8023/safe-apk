#include "SignatureChecker.h"
#include <android/log.h>
#include <cstring>

#define LOG_TAG "ArkSignatureChecker"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ark {
namespace security {

// 静态成员初始化
JNIEnv* SignatureChecker::s_env = nullptr;
jobject SignatureChecker::s_context = nullptr;
jobject SignatureChecker::s_signatureChecker = nullptr;
jmethodID SignatureChecker::s_checkSignatureMethod = nullptr;
jmethodID SignatureChecker::s_getCurrentHashMethod = nullptr;
jmethodID SignatureChecker::s_verifyHashMethod = nullptr;

std::string SignatureChecker::s_expectedSHA256Hash = "";
std::string SignatureChecker::s_expectedMD5Hash = "";
bool SignatureChecker::s_strictCheck = true;
bool SignatureChecker::s_crashOnFailure = true;
std::string SignatureChecker::s_lastError = "";

bool SignatureChecker::initialize(JNIEnv* env, jobject context) {
    s_env = env;
    s_context = env->NewGlobalRef(context);
    
    if (!initializeJNI()) {
        s_lastError = "JNI初始化失败";
        LOGE("签名校验器初始化失败: %s", s_lastError.c_str());
        return false;
    }
    
    LOGI("签名校验器初始化成功");
    return true;
}

bool SignatureChecker::initializeJNI() {
    if (s_env == nullptr || s_context == nullptr) {
        return false;
    }
    
    // 查找SignatureChecker类
    jclass checkerClass = s_env->FindClass("com/ark/security/SignatureChecker");
    if (checkerClass == nullptr) {
        s_lastError = "无法找到SignatureChecker类";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    // 创建SignatureChecker实例
    jmethodID constructor = s_env->GetMethodID(checkerClass, "<init>", "()V");
    if (constructor == nullptr) {
        s_lastError = "无法找到SignatureChecker构造函数";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    jobject checker = s_env->NewObject(checkerClass, constructor);
    if (checker == nullptr) {
        s_lastError = "无法创建SignatureChecker实例";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    s_signatureChecker = s_env->NewGlobalRef(checker);
    
    // 获取方法ID
    s_checkSignatureMethod = s_env->GetStaticMethodID(
        checkerClass, "checkSignature", "(Landroid/content/Context;)Z");
    if (s_checkSignatureMethod == nullptr) {
        s_lastError = "无法找到checkSignature方法";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    s_getCurrentHashMethod = s_env->GetStaticMethodID(
        checkerClass, "getCurrentSignatureHash", "(Landroid/content/Context;)Ljava/lang/String;");
    if (s_getCurrentHashMethod == nullptr) {
        s_lastError = "无法找到getCurrentSignatureHash方法";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    s_verifyHashMethod = s_env->GetStaticMethodID(
        checkerClass, "verifySignatureHash", "(Landroid/content/Context;Ljava/lang/String;)Z");
    if (s_verifyHashMethod == nullptr) {
        s_lastError = "无法找到verifySignatureHash方法";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    return true;
}

void SignatureChecker::cleanupJNI() {
    if (s_env != nullptr) {
        if (s_signatureChecker != nullptr) {
            s_env->DeleteGlobalRef(s_signatureChecker);
            s_signatureChecker = nullptr;
        }
        if (s_context != nullptr) {
            s_env->DeleteGlobalRef(s_context);
            s_context = nullptr;
        }
    }
    
    s_env = nullptr;
    s_checkSignatureMethod = nullptr;
    s_getCurrentHashMethod = nullptr;
    s_verifyHashMethod = nullptr;
}

bool SignatureChecker::checkSignature() {
    if (s_env == nullptr || s_context == nullptr || s_checkSignatureMethod == nullptr) {
        s_lastError = "签名校验器未初始化";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    // 调用Java层的checkSignature方法
    jboolean result = s_env->CallStaticBooleanMethod(
        s_env->FindClass("com/ark/security/SignatureChecker"),
        s_checkSignatureMethod,
        s_context
    );
    
    if (s_env->ExceptionCheck()) {
        s_env->ExceptionDescribe();
        s_env->ExceptionClear();
        s_lastError = "签名校验过程中发生异常";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    bool isValid = (result == JNI_TRUE);
    
    if (!isValid) {
        s_lastError = "签名校验失败";
        LOGE("%s", s_lastError.c_str());
    } else {
        LOGI("签名校验通过");
    }
    
    return isValid;
}

std::string SignatureChecker::getCurrentSignatureHash() {
    if (s_env == nullptr || s_context == nullptr || s_getCurrentHashMethod == nullptr) {
        s_lastError = "签名校验器未初始化";
        LOGE("%s", s_lastError.c_str());
        return "";
    }
    
    // 调用Java层的getCurrentSignatureHash方法
    jstring jstr = (jstring)s_env->CallStaticObjectMethod(
        s_env->FindClass("com/ark/security/SignatureChecker"),
        s_getCurrentHashMethod,
        s_context
    );
    
    if (s_env->ExceptionCheck()) {
        s_env->ExceptionDescribe();
        s_env->ExceptionClear();
        s_lastError = "获取签名哈希时发生异常";
        LOGE("%s", s_lastError.c_str());
        return "";
    }
    
    std::string hash = jstringToString(s_env, jstr);
    LOGI("当前签名哈希: %s", hash.c_str());
    
    return hash;
}

bool SignatureChecker::verifySignatureHash(const std::string& expectedHash) {
    if (expectedHash.empty()) {
        LOGW("预期的签名哈希为空，跳过验证");
        return true;
    }
    
    std::string currentHash = getCurrentSignatureHash();
    if (currentHash.empty()) {
        s_lastError = "无法获取当前签名哈希";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    bool isValid = (expectedHash == currentHash);
    
    if (!isValid) {
        s_lastError = "签名哈希不匹配";
        LOGE("签名哈希不匹配");
        LOGE("预期: %s", expectedHash.c_str());
        LOGE("实际: %s", currentHash.c_str());
    } else {
        LOGI("签名哈希验证通过");
    }
    
    return isValid;
}

void SignatureChecker::setExpectedSignatureHash(const std::string& sha256Hash, 
                                               const std::string& md5Hash) {
    s_expectedSHA256Hash = sha256Hash;
    s_expectedMD5Hash = md5Hash;
    LOGI("设置预期签名哈希 - SHA256: %s, MD5: %s", 
         sha256Hash.c_str(), md5Hash.c_str());
}

void SignatureChecker::setStrictCheck(bool enabled) {
    s_strictCheck = enabled;
    LOGI("设置严格签名校验: %s", enabled ? "启用" : "禁用");
}

void SignatureChecker::setCrashOnFailure(bool enabled) {
    s_crashOnFailure = enabled;
    LOGI("设置签名校验失败崩溃: %s", enabled ? "启用" : "禁用");
}

std::string SignatureChecker::getLastError() {
    return s_lastError;
}

bool SignatureChecker::nativeCheckSignature(const std::string& expectedSha256, const std::string& expectedMd5) {
    LOGI("开始Native层APK签名校验");

    // 如果提供了期望的签名哈希，进行验证
    if (!expectedSha256.empty() || !expectedMd5.empty()) {
        std::string currentHash = getCurrentSignatureHash();

        if (currentHash.empty()) {
            s_lastError = "无法获取当前签名哈希";
            LOGE("%s", s_lastError.c_str());
            return false;
        }

        // 验证SHA256
        if (!expectedSha256.empty()) {
            if (expectedSha256 != currentHash) {
                s_lastError = "SHA256签名不匹配";
                LOGE("SHA256签名不匹配");
                LOGE("预期: %s", expectedSha256.c_str());
                LOGE("实际: %s", currentHash.c_str());
                return false;
            }
        }

        // 验证MD5
        if (!expectedMd5.empty()) {
            if (expectedMd5 != currentHash) {
                s_lastError = "MD5签名不匹配";
                LOGE("MD5签名不匹配");
                LOGE("预期: %s", expectedMd5.c_str());
                LOGE("实际: %s", currentHash.c_str());
                return false;
            }
        }

        LOGI("Native层APK签名校验通过");
        return true;
    } else {
        // 如果没有提供期望的签名哈希，只检查签名是否存在
        std::string currentHash = getCurrentSignatureHash();
        bool isValid = !currentHash.empty();

        if (!isValid) {
            s_lastError = "无法获取APK签名";
            LOGE("%s", s_lastError.c_str());
        } else {
            LOGI("Native层APK签名校验通过（未配置预期哈希）");
        }

        return isValid;
    }
}

std::string SignatureChecker::jstringToString(JNIEnv* env, jstring jstr) {
    if (jstr == nullptr) {
        return "";
    }
    
    const char* chars = env->GetStringUTFChars(jstr, nullptr);
    if (chars == nullptr) {
        return "";
    }
    
    std::string result(chars);
    env->ReleaseStringUTFChars(jstr, chars);
    return result;
}

jstring SignatureChecker::stringToJString(JNIEnv* env, const std::string& str) {
    return env->NewStringUTF(str.c_str());
}

} // namespace security
} // namespace ark