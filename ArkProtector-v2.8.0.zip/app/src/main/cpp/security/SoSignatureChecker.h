#ifndef ARK_SO_SIGNATURE_CHECKER_H
#define ARK_SO_SIGNATURE_CHECKER_H

#include <jni.h>
#include <string>
#include <vector>
#include <cstdint>

namespace ark {
namespace security {

/**
 * SO文件签名校验类
 * 用于在Native层验证SO文件的完整性，防止SO文件被替换或篡改
 */
class SoSignatureChecker {
public:
    /**
     * 初始化SO签名校验器
     * @param env JNI环境
     * @param context 应用上下文
     */
    static bool initialize(JNIEnv* env, jobject context);
    
    /**
     * 检查所有SO文件的签名
     * @return true 如果所有SO文件签名有效，false 如果有任何SO文件签名无效
     */
    static bool checkAllSoSignatures();
    
    /**
     * 检查指定SO文件的签名
     * @param soName SO文件名（不含路径）
     * @return true 如果签名有效，false 如果签名无效
     */
    static bool checkSoSignature(const std::string& soName);

    /**
     * 检查指定SO文件的签名（使用完整路径）
     * @param soPath SO文件完整路径
     * @param expectedHash 预期的哈希值（可选）
     * @return true 如果签名有效，false 如果签名无效
     */
    static bool checkSoFile(const std::string& soPath, const std::string& expectedHash);

    /**
     * 获取指定SO文件的当前哈希值
     * @param soName SO文件名（不含路径）
     * @return 当前哈希值
     */
    static std::string getCurrentSoHash(const std::string& soName);
    
    /**
     * 验证SO文件哈希是否匹配预期值
     * @param soName SO文件名（不含路径）
     * @param expectedHash 预期的哈希值
     * @return true 如果匹配，false 如果不匹配
     */
    static bool verifySoHash(const std::string& soName, const std::string& expectedHash);
    
    /**
     * 设置预期的SO文件哈希值
     * @param soName SO文件名（不含路径）
     * @param hash 预期的哈希值
     */
    static void setExpectedSoHash(const std::string& soName, const std::string& hash);
    
    /**
     * 启用/禁用SO签名校验
     * @param enabled 是否启用
     */
    static void setSoCheckEnabled(bool enabled);
    
    /**
     * 启用/禁用SO签名校验失败时崩溃
     * @param enabled 是否启用
     */
    static void setCrashOnFailure(bool enabled);
    
    /**
     * 获取SO签名校验错误信息
     * @return 错误信息
     */
    static std::string getLastError();
    
    /**
     * 获取SO文件路径
     * @param soName SO文件名（不含路径）
     * @return SO文件完整路径
     */
    static std::string getSoFilePath(const std::string& soName);
    
    /**
     * 计算文件的SHA256哈希值
     * @param filePath 文件路径
     * @return SHA256哈希值
     */
    static std::string calculateFileHash(const std::string& filePath);
    
private:
    // JNI相关
    static JNIEnv* s_env;
    static jobject s_context;
    static std::string s_appLibPath;
    
    // 配置
    static bool s_soCheckEnabled;
    static bool s_crashOnFailure;
    static std::string s_lastError;
    
    // 预期的SO文件哈希值
    static std::vector<std::pair<std::string, std::string>> s_expectedSoHashes;
    
    // 工具方法
    static bool initializeAppLibPath();
    static bool checkFileExists(const std::string& filePath);
    static bool checkFileIntegrity(const std::string& filePath, const std::string& expectedHash);
    static void handleSoSignatureFailure(const std::string& soName, const std::string& reason);
    static std::string bytesToHex(const uint8_t* bytes, size_t length);
};

} // namespace security
} // namespace ark

#endif // ARK_SO_SIGNATURE_CHECKER_H