#include "SoSignatureChecker.h"
#include <android/log.h>
#include <cstring>
#include <fstream>
#include <sstream>
#include <iomanip>

#define LOG_TAG "ArkSoSignatureChecker"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ark {
namespace security {

// 静态成员初始化
JNIEnv* SoSignatureChecker::s_env = nullptr;
jobject SoSignatureChecker::s_context = nullptr;
std::string SoSignatureChecker::s_appLibPath = "";

bool SoSignatureChecker::s_soCheckEnabled = true;
bool SoSignatureChecker::s_crashOnFailure = true;
std::string SoSignatureChecker::s_lastError = "";

std::vector<std::pair<std::string, std::string>> SoSignatureChecker::s_expectedSoHashes;

bool SoSignatureChecker::initialize(JNIEnv* env, jobject context) {
    s_env = env;
    s_context = env->NewGlobalRef(context);
    
    if (!initializeAppLibPath()) {
        s_lastError = "无法获取应用库路径";
        LOGE("SO签名校验器初始化失败: %s", s_lastError.c_str());
        return false;
    }
    
    LOGI("SO签名校验器初始化成功");
    LOGI("应用库路径: %s", s_appLibPath.c_str());
    
    return true;
}

bool SoSignatureChecker::initializeAppLibPath() {
    if (s_env == nullptr || s_context == nullptr) {
        return false;
    }
    
    // 获取ApplicationInfo
    jclass activityThreadClass = s_env->FindClass("android/app/ActivityThread");
    if (activityThreadClass == nullptr) {
        return false;
    }
    
    jmethodID currentActivityThreadMethod = s_env->GetStaticMethodID(
        activityThreadClass, "currentActivityThread", "()Landroid/app/ActivityThread;");
    if (currentActivityThreadMethod == nullptr) {
        return false;
    }
    
    jobject activityThread = s_env->CallStaticObjectMethod(
        activityThreadClass, currentActivityThreadMethod);
    if (activityThread == nullptr) {
        return false;
    }
    
    // 获取Application
    jmethodID getApplicationMethod = s_env->GetMethodID(
        activityThreadClass, "getApplication", "()Landroid/app/Application;");
    if (getApplicationMethod == nullptr) {
        return false;
    }
    
    jobject application = s_env->CallObjectMethod(activityThread, getApplicationMethod);
    if (application == nullptr) {
        return false;
    }
    
    // 获取ApplicationInfo
    jclass contextClass = s_env->FindClass("android/content/Context");
    if (contextClass == nullptr) {
        return false;
    }
    
    jmethodID getApplicationInfoMethod = s_env->GetMethodID(
        contextClass, "getApplicationInfo", "(I)Landroid/content/pm/ApplicationInfo;");
    if (getApplicationInfoMethod == nullptr) {
        return false;
    }
    
    jobject applicationInfo = s_env->CallObjectMethod(
        application, getApplicationInfoMethod, 0);
    if (applicationInfo == nullptr) {
        return false;
    }
    
    // 获取nativeLibraryDir
    jclass applicationInfoClass = s_env->FindClass("android/content/pm/ApplicationInfo");
    if (applicationInfoClass == nullptr) {
        return false;
    }
    
    jfieldID nativeLibraryDirField = s_env->GetFieldID(
        applicationInfoClass, "nativeLibraryDir", "Ljava/lang/String;");
    if (nativeLibraryDirField == nullptr) {
        return false;
    }
    
    jstring nativeLibraryDir = (jstring)s_env->GetObjectField(
        applicationInfo, nativeLibraryDirField);
    if (nativeLibraryDir == nullptr) {
        return false;
    }
    
    // 转换为C++字符串
    const char* chars = s_env->GetStringUTFChars(nativeLibraryDir, nullptr);
    if (chars != nullptr) {
        s_appLibPath = std::string(chars);
        s_env->ReleaseStringUTFChars(nativeLibraryDir, chars);
    }
    
    return !s_appLibPath.empty();
}

bool SoSignatureChecker::checkAllSoSignatures() {
    if (!s_soCheckEnabled) {
        LOGI("SO签名校验已禁用");
        return true;
    }
    
    if (s_appLibPath.empty()) {
        s_lastError = "应用库路径未初始化";
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    LOGI("开始检查所有SO文件的签名");
    
    // 检查主要的SO文件
    std::vector<std::string> soFiles = {
        "libArkStub.so",
        "libArkTool.so",
        "libzipalign.so"
    };
    
    int successCount = 0;
    int failureCount = 0;
    
    for (const auto& soName : soFiles) {
        if (checkSoSignature(soName)) {
            successCount++;
        } else {
            failureCount++;
        }
    }
    
    LOGI("SO签名检查完成: 成功 %d, 失败 %d", successCount, failureCount);
    
    return failureCount == 0;
}

bool SoSignatureChecker::checkSoSignature(const std::string& soName) {
    std::string soPath = getSoFilePath(soName);

    LOGI("检查SO文件签名: %s", soPath.c_str());

    if (!checkFileExists(soPath)) {
        s_lastError = "SO文件不存在: " + soPath;
        LOGE("%s", s_lastError.c_str());
        handleSoSignatureFailure(soName, s_lastError);
        return false;
    }

    // 查找预期的哈希值
    std::string expectedHash;
    for (const auto& pair : s_expectedSoHashes) {
        if (pair.first == soName) {
            expectedHash = pair.second;
            break;
        }
    }

    if (!expectedHash.empty()) {
        // 如果配置了预期哈希值，进行严格校验
        if (!checkFileIntegrity(soPath, expectedHash)) {
            s_lastError = "SO文件签名不匹配: " + soName;
            LOGE("%s", s_lastError.c_str());
            handleSoSignatureFailure(soName, s_lastError);
            return false;
        }
    } else {
        LOGW("未配置SO文件预期哈希值，跳过签名校验: %s", soName.c_str());
    }

    LOGI("✓ SO文件签名校验通过: %s", soName.c_str());
    return true;
}

bool SoSignatureChecker::checkSoFile(const std::string& soPath, const std::string& expectedHash) {
    LOGI("检查SO文件签名（完整路径）: %s", soPath.c_str());

    if (!checkFileExists(soPath)) {
        s_lastError = "SO文件不存在: " + soPath;
        LOGE("%s", s_lastError.c_str());
        return false;
    }

    // 如果提供了预期哈希值，进行严格校验
    if (!expectedHash.empty()) {
        if (!checkFileIntegrity(soPath, expectedHash)) {
            s_lastError = "SO文件签名不匹配: " + soPath;
            LOGE("%s", s_lastError.c_str());
            LOGE("预期: %s", expectedHash.c_str());
            LOGE("实际: %s", calculateFileHash(soPath).c_str());
            return false;
        }
    } else {
        // 如果没有提供预期哈希值，只检查文件是否存在
        LOGI("未提供预期哈希值，仅检查文件存在性");
    }

    LOGI("✓ SO文件签名校验通过: %s", soPath.c_str());
    return true;
}

std::string SoSignatureChecker::getCurrentSoHash(const std::string& soName) {
    std::string soPath = getSoFilePath(soName);
    
    if (!checkFileExists(soPath)) {
        s_lastError = "SO文件不存在: " + soPath;
        LOGE("%s", s_lastError.c_str());
        return "";
    }
    
    std::string hash = calculateFileHash(soPath);
    LOGI("SO文件 %s 当前哈希: %s", soName.c_str(), hash.c_str());
    
    return hash;
}

bool SoSignatureChecker::verifySoHash(const std::string& soName, const std::string& expectedHash) {
    if (expectedHash.empty()) {
        LOGW("预期的哈希值为空，跳过验证");
        return true;
    }
    
    std::string currentHash = getCurrentSoHash(soName);
    if (currentHash.empty()) {
        s_lastError = "无法获取SO文件哈希: " + soName;
        LOGE("%s", s_lastError.c_str());
        return false;
    }
    
    bool isValid = (expectedHash == currentHash);
    
    if (!isValid) {
        s_lastError = "SO文件哈希不匹配: " + soName;
        LOGE("%s", s_lastError.c_str());
        LOGE("预期: %s", expectedHash.c_str());
        LOGE("实际: %s", currentHash.c_str());
    } else {
        LOGI("✓ SO文件哈希验证通过: %s", soName.c_str());
    }
    
    return isValid;
}

void SoSignatureChecker::setExpectedSoHash(const std::string& soName, const std::string& hash) {
    // 查找并更新已存在的条目
    for (auto& pair : s_expectedSoHashes) {
        if (pair.first == soName) {
            pair.second = hash;
            LOGI("更新SO文件预期哈希: %s -> %s", soName.c_str(), hash.c_str());
            return;
        }
    }
    
    // 添加新条目
    s_expectedSoHashes.push_back(std::make_pair(soName, hash));
    LOGI("添加SO文件预期哈希: %s -> %s", soName.c_str(), hash.c_str());
}

void SoSignatureChecker::setSoCheckEnabled(bool enabled) {
    s_soCheckEnabled = enabled;
    LOGI("设置SO签名校验: %s", enabled ? "启用" : "禁用");
}

void SoSignatureChecker::setCrashOnFailure(bool enabled) {
    s_crashOnFailure = enabled;
    LOGI("设置SO签名校验失败崩溃: %s", enabled ? "启用" : "禁用");
}

std::string SoSignatureChecker::getLastError() {
    return s_lastError;
}

std::string SoSignatureChecker::getSoFilePath(const std::string& soName) {
    if (s_appLibPath.empty()) {
        return "";
    }
    
    return s_appLibPath + "/" + soName;
}

std::string SoSignatureChecker::calculateFileHash(const std::string& filePath) {
    // 简化的SHA256实现（避免OpenSSL依赖）
    std::ifstream file(filePath, std::ios::binary);
    if (!file) {
        return "";
    }
    
    // 读取文件内容
    std::vector<uint8_t> buffer(8192);
    uint32_t hash[8] = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    };
    
    while (file.read(reinterpret_cast<char*>(buffer.data()), buffer.size())) {
        size_t bytesRead = file.gcount();
        
        // 简化的哈希计算（仅用于示例）
        for (size_t i = 0; i < bytesRead; i++) {
            hash[i % 8] ^= buffer[i];
            hash[i % 8] = (hash[i % 8] << 1) | (hash[i % 8] >> 31);
        }
    }
    
    // 处理剩余数据
    size_t remaining = file.gcount();
    if (remaining > 0) {
        for (size_t i = 0; i < remaining; i++) {
            hash[i % 8] ^= buffer[i];
            hash[i % 8] = (hash[i % 8] << 1) | (hash[i % 8] >> 31);
        }
    }
    
    // 转换为十六进制字符串
    std::stringstream ss;
    for (int i = 0; i < 8; i++) {
        ss << std::hex << std::setw(8) << std::setfill('0') << hash[i];
    }
    
    return ss.str();
}

bool SoSignatureChecker::checkFileExists(const std::string& filePath) {
    std::ifstream file(filePath);
    return file.good();
}

bool SoSignatureChecker::checkFileIntegrity(const std::string& filePath, const std::string& expectedHash) {
    std::string currentHash = calculateFileHash(filePath);
    return expectedHash == currentHash;
}

void SoSignatureChecker::handleSoSignatureFailure(const std::string& soName, const std::string& reason) {
    LOGE("SO签名校验失败: %s - %s", soName.c_str(), reason.c_str());
    
    if (s_crashOnFailure) {
        // 触发应用崩溃
        LOGE("检测到SO文件被篡改，应用将崩溃退出");
        // 这里可以调用系统的崩溃函数或抛出异常
        *((volatile int*)0) = 0; // 触发SIGSEGV
    } else {
        LOGW("SO签名校验失败但未触发崩溃（CRASH_ON_FAILURE=false）");
    }
}

std::string SoSignatureChecker::bytesToHex(const uint8_t* bytes, size_t length) {
    std::stringstream ss;
    for (size_t i = 0; i < length; i++) {
        ss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(bytes[i]);
    }
    return ss.str();
}

} // namespace security
} // namespace ark