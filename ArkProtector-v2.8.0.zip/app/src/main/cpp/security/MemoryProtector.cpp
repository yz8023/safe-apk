#include <jni.h>
#include <sys/mman.h>
#include <string.h>
#include <unistd.h>
#include <android/log.h>
#include <memory>

#define TAG "MemoryProtector-Native"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)

/**
 * 内存保护Native实现
 * 用于保护DEX内存，防止root设备通过内存dump获取原始DEX
 */

extern "C" {

/**
 * 设置内存为只读
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param data 数据字节数组
 * @param size 数据大小
 * @return 成功返回true
 */
JNIEXPORT jboolean JNICALL
Java_com_ark_security_MemoryProtector_nativeSetMemoryReadOnly(
    JNIEnv *env,
    jclass clazz,
    jbyteArray data,
    jint size) {

    if (data == nullptr || size <= 0) {
        LOGE("Invalid parameters for setMemoryReadOnly");
        return JNI_FALSE;
    }

    // 获取数据指针
    jbyte* dataPtr = env->GetByteArrayElements(data, nullptr);
    if (dataPtr == nullptr) {
        LOGE("Failed to get byte array elements");
        return JNI_FALSE;
    }

    // 获取页面对齐的地址
    uintptr_t pageAlignedAddr = (uintptr_t)dataPtr & ~(PAGE_SIZE - 1);

    // 计算需要保护的内存大小（页面对齐）
    size_t pageSize = PAGE_SIZE;
    size_t alignedSize = ((size + PAGE_SIZE - 1) / PAGE_SIZE) * PAGE_SIZE;

    // 设置内存为只读
    int result = mprotect((void*)pageAlignedAddr, alignedSize, PROT_READ);

    if (result == 0) {
        LOGI("Memory set to read-only: addr=%p, size=%zu",
             (void*)pageAlignedAddr, alignedSize);
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return JNI_TRUE;
    } else {
        LOGE("Failed to set memory read-only: %s", strerror(errno));
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return JNI_FALSE;
    }
}

/**
 * 简单的XOR加密
 *
 * @param data 数据
 * @param size 数据大小
 * @param key 密钥
 * @param keySize 密钥大小
 */
static void xorEncryptDecrypt(unsigned char* data, size_t size,
                             const unsigned char* key, size_t keySize) {
    if (key == nullptr || keySize == 0) {
        return;
    }

    for (size_t i = 0; i < size; i++) {
        data[i] ^= key[i % keySize];
    }
}

/**
 * 加密内存
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param data 数据字节数组
 * @param key 加密密钥
 * @return 成功返回true
 */
JNIEXPORT jboolean JNICALL
Java_com_ark_security_MemoryProtector_nativeEncryptMemory(
    JNIEnv *env,
    jclass clazz,
    jbyteArray data,
    jbyteArray key) {

    if (data == nullptr || key == nullptr) {
        LOGE("Invalid parameters for encryptMemory");
        return JNI_FALSE;
    }

    // 获取数据指针和大小
    jbyte* dataPtr = env->GetByteArrayElements(data, nullptr);
    jsize dataSize = env->GetArrayLength(data);

    // 获取密钥指针和大小
    jbyte* keyPtr = env->GetByteArrayElements(key, nullptr);
    jsize keySize = env->GetArrayLength(key);

    if (dataPtr == nullptr || keyPtr == nullptr) {
        LOGE("Failed to get array elements");
        if (dataPtr) env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        if (keyPtr) env->ReleaseByteArrayElements(key, keyPtr, JNI_ABORT);
        return JNI_FALSE;
    }

    // 执行XOR加密
    xorEncryptDecrypt((unsigned char*)dataPtr, dataSize,
                     (unsigned char*)keyPtr, keySize);

    LOGI("Memory encrypted: size=%d", dataSize);

    // 释放资源
    env->ReleaseByteArrayElements(data, dataPtr, 0);
    env->ReleaseByteArrayElements(key, keyPtr, JNI_ABORT);

    return JNI_TRUE;
}

/**
 * 解密内存
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param data 数据字节数组
 * @param key 解密密钥
 * @return 成功返回true
 */
JNIEXPORT jboolean JNICALL
Java_com_ark_security_MemoryProtector_nativeDecryptMemory(
    JNIEnv *env,
    jclass clazz,
    jbyteArray data,
    jbyteArray key) {

    // XOR加密是对称的，解密和加密相同
    return Java_com_ark_security_MemoryProtector_nativeEncryptMemory(
        env, clazz, data, key);
}

/**
 * 读取内存
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param address 内存地址
 * @param size 读取大小
 * @return 读取的数据
 */
JNIEXPORT jbyteArray JNICALL
Java_com_ark_security_MemoryProtector_nativeReadMemory(
    JNIEnv *env,
    jclass clazz,
    jlong address,
    jint size) {

    if (address == 0 || size <= 0) {
        LOGE("Invalid parameters for readMemory");
        return nullptr;
    }

    // 创建字节数组
    jbyteArray result = env->NewByteArray(size);
    if (result == nullptr) {
        LOGE("Failed to create byte array");
        return nullptr;
    }

    // 获取数组指针
    jbyte* arrayPtr = env->GetByteArrayElements(result, nullptr);
    if (arrayPtr == nullptr) {
        LOGE("Failed to get byte array elements");
        env->DeleteLocalRef(result);
        return nullptr;
    }

    // 读取内存
    memcpy(arrayPtr, (void*)address, size);

    LOGI("Memory read: addr=%p, size=%d", (void*)address, size);

    // 释放资源
    env->ReleaseByteArrayElements(result, arrayPtr, 0);

    return result;
}

/**
 * 清空内存
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param address 内存地址
 * @param size 清空大小
 */
JNIEXPORT void JNICALL
Java_com_ark_security_MemoryProtector_nativeClearMemory(
    JNIEnv *env,
    jclass clazz,
    jlong address,
    jint size) {

    if (address == 0 || size <= 0) {
        LOGE("Invalid parameters for clearMemory");
        return;
    }

    // 清空内存
    memset((void*)address, 0, size);

    LOGI("Memory cleared: addr=%p, size=%d", (void*)address, size);
}

/**
 * 获取内存地址
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param data 数据字节数组
 * @return 内存地址
 */
JNIEXPORT jlong JNICALL
Java_com_ark_security_MemoryProtector_nativeGetMemoryAddress(
    JNIEnv *env,
    jclass clazz,
    jbyteArray data) {

    if (data == nullptr) {
        LOGE("Invalid parameters for getMemoryAddress");
        return 0;
    }

    // 获取数据指针
    jbyte* dataPtr = env->GetByteArrayElements(data, nullptr);
    if (dataPtr == nullptr) {
        LOGE("Failed to get byte array elements");
        return 0;
    }

    // 获取地址
    jlong address = (jlong)(uintptr_t)dataPtr;

    // 释放资源（但不修改数据）
    env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);

    LOGI("Memory address: %p", (void*)address);

    return address;
}

/**
 * 计算CRC32校验
 *
 * @param data 数据
 * @param size 数据大小
 * @return CRC32值
 */
static uint32_t calculateCRC32(const unsigned char* data, size_t size) {
    uint32_t crc = 0xFFFFFFFF;

    for (size_t i = 0; i < size; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 1) {
                crc = (crc >> 1) ^ 0xEDB88320;
            } else {
                crc >>= 1;
            }
        }
    }

    return ~crc;
}

/**
 * Native方法：计算CRC32
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param data 数据字节数组
 * @return CRC32值
 */
JNIEXPORT jint JNICALL
Java_com_ark_security_MemoryProtector_nativeCalculateCRC32(
    JNIEnv *env,
    jclass clazz,
    jbyteArray data) {

    if (data == nullptr) {
        LOGE("Invalid parameters for calculateCRC32");
        return 0;
    }

    // 获取数据指针和大小
    jbyte* dataPtr = env->GetByteArrayElements(data, nullptr);
    jsize dataSize = env->GetArrayLength(data);

    if (dataPtr == nullptr) {
        LOGE("Failed to get byte array elements");
        return 0;
    }

    // 计算CRC32
    uint32_t crc = calculateCRC32((unsigned char*)dataPtr, dataSize);

    LOGI("CRC32 calculated: %u", crc);

    // 释放资源
    env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);

    return (jint)crc;
}

/**
 * 设置内存为可读写
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param data 数据字节数组
 * @param size 数据大小
 * @return 成功返回true
 */
JNIEXPORT jboolean JNICALL
Java_com_ark_security_MemoryProtector_nativeSetMemoryReadWrite(
    JNIEnv *env,
    jclass clazz,
    jbyteArray data,
    jint size) {

    if (data == nullptr || size <= 0) {
        LOGE("Invalid parameters for setMemoryReadWrite");
        return JNI_FALSE;
    }

    // 获取数据指针
    jbyte* dataPtr = env->GetByteArrayElements(data, nullptr);
    if (dataPtr == nullptr) {
        LOGE("Failed to get byte array elements");
        return JNI_FALSE;
    }

    // 获取页面对齐的地址
    uintptr_t pageAlignedAddr = (uintptr_t)dataPtr & ~(PAGE_SIZE - 1);

    // 计算需要保护的内存大小（页面对齐）
    size_t pageSize = PAGE_SIZE;
    size_t alignedSize = ((size + PAGE_SIZE - 1) / PAGE_SIZE) * PAGE_SIZE;

    // 设置内存为可读写
    int result = mprotect((void*)pageAlignedAddr, alignedSize, PROT_READ | PROT_WRITE);

    if (result == 0) {
        LOGI("Memory set to read-write: addr=%p, size=%zu",
             (void*)pageAlignedAddr, alignedSize);
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return JNI_TRUE;
    } else {
        LOGE("Failed to set memory read-write: %s", strerror(errno));
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return JNI_FALSE;
    }
}

/**
 * 设置内存为只读且可执行
 *
 * @param env JNI环境
 * @param clazz Java类
 * @param data 数据字节数组
 * @param size 数据大小
 * @return 成功返回true
 */
JNIEXPORT jboolean JNICALL
Java_com_ark_security_MemoryProtector_nativeSetMemoryReadOnlyExecutable(
    JNIEnv *env,
    jclass clazz,
    jbyteArray data,
    jint size) {

    if (data == nullptr || size <= 0) {
        LOGE("Invalid parameters for setMemoryReadOnlyExecutable");
        return JNI_FALSE;
    }

    // 获取数据指针
    jbyte* dataPtr = env->GetByteArrayElements(data, nullptr);
    if (dataPtr == nullptr) {
        LOGE("Failed to get byte array elements");
        return JNI_FALSE;
    }

    // 获取页面对齐的地址
    uintptr_t pageAlignedAddr = (uintptr_t)dataPtr & ~(PAGE_SIZE - 1);

    // 计算需要保护的内存大小（页面对齐）
    size_t pageSize = PAGE_SIZE;
    size_t alignedSize = ((size + PAGE_SIZE - 1) / PAGE_SIZE) * PAGE_SIZE;

    // 设置内存为只读且可执行
    int result = mprotect((void*)pageAlignedAddr, alignedSize, PROT_READ | PROT_EXEC);

    if (result == 0) {
        LOGI("Memory set to read-only-executable: addr=%p, size=%zu",
             (void*)pageAlignedAddr, alignedSize);
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return JNI_TRUE;
    } else {
        LOGE("Failed to set memory read-only-executable: %s", strerror(errno));
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return JNI_FALSE;
    }
}

} // extern "C"