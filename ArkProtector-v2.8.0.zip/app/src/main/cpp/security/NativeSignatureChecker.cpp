#include "security/SoSignatureChecker.h"
#include "security/SignatureChecker.h"
#include <android/log.h>
#include <string>

#define LOG_TAG "ArkNativeSignature"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using namespace ark::security;

extern "C" {

/**
 * Native层APK签名校验
 */
JNIEXPORT jboolean JNICALL
Java_com_ark_security_SignatureChecker_nativeCheckSignature(
    JNIEnv* env,
    jobject thiz,
    jstring expectedSha256,
    jstring expectedMd5) {

    LOGI("开始Native层APK签名校验");

    // 获取期望的签名哈希
    std::string expectedSha256Str;
    std::string expectedMd5Str;

    if (expectedSha256 != nullptr) {
        const char* sha256Chars = env->GetStringUTFChars(expectedSha256, nullptr);
        expectedSha256Str = sha256Chars;
        env->ReleaseStringUTFChars(expectedSha256, sha256Chars);
    }

    if (expectedMd5 != nullptr) {
        const char* md5Chars = env->GetStringUTFChars(expectedMd5, nullptr);
        expectedMd5Str = md5Chars;
        env->ReleaseStringUTFChars(expectedMd5, md5Chars);
    }

    // 调用Native层签名校验
    bool success = SignatureChecker::nativeCheckSignature(expectedSha256Str, expectedMd5Str);

    if (!success) {
        LOGE("Native层APK签名校验失败");
        return JNI_FALSE;
    }

    LOGI("Native层APK签名校验通过");
    return JNI_TRUE;
}

/**
 * Native层SO文件签名校验
 */
JNIEXPORT jboolean JNICALL
Java_com_ark_security_SignatureChecker_nativeCheckSoSignature(
    JNIEnv* env,
    jobject thiz,
    jstring soPath,
    jstring expectedHash) {

    LOGI("开始Native层SO文件签名校验");

    if (soPath == nullptr) {
        LOGE("SO文件路径为空");
        return JNI_FALSE;
    }

    // 获取SO文件路径
    const char* soPathChars = env->GetStringUTFChars(soPath, nullptr);
    std::string soPathStr(soPathChars);
    env->ReleaseStringUTFChars(soPath, soPathChars);

    // 获取期望的哈希值（可选）
    std::string expectedHashStr;
    if (expectedHash != nullptr) {
        const char* hashChars = env->GetStringUTFChars(expectedHash, nullptr);
        expectedHashStr = hashChars;
        env->ReleaseStringUTFChars(expectedHash, hashChars);
    }

    // 调用SO签名校验
    bool success = SoSignatureChecker::checkSoFile(soPathStr, expectedHashStr);

    if (!success) {
        LOGE("Native层SO文件签名校验失败: %s", soPathStr.c_str());
        return JNI_FALSE;
    }

    LOGI("Native层SO文件签名校验通过: %s", soPathStr.c_str());
    return JNI_TRUE;
}

} // extern "C"