#include "VmpDispatcher.h"
#include "../VmOpcodeHandler.h"
#include <android/log.h>
#include <random>
#include <cstring>
#include <sys/mman.h>
#include <unistd.h>
#include <time.h>

#define LOG_TAG "ArkVMP_Dispatcher"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

VmpDispatcher::VmpDispatcher() : m_seed(0x9E3779B9) {
    // 初始化随机种子
    std::random_device rd;
    m_seed = rd();
    
    // 初始化处理器数组
    memset(m_handlers, 0, sizeof(m_handlers));
    memset(m_handlerLoaded, 0, sizeof(m_handlerLoaded));
    
    // 生成动态密钥
    generateKey();
}

VmpDispatcher::~VmpDispatcher() {
    // 清理跳转表
    if (m_tableInitialized) {
        for (void* ptr : m_dispatchTable) {
            if (ptr != nullptr && ptr != (void*)0xDEADBEEF) {
                // 注意：这里不释放内存，因为处理器是共享的
            }
        }
    }
}

void VmpDispatcher::execute(VmContext& ctx) {
    if (!m_tableInitialized) {
        initDispatchTable();
    }
    
    while (ctx.running && ctx.pc >= 0 && ctx.pc < static_cast<int>(ctx.method->instructions.size())) {
        const VmpInstruction& insn = ctx.method->instructions[ctx.pc];
        int realOpcode = insn.realOpcode;
        
        // 动态计算跳转索引
        int idx = getDispatchIndex(realOpcode, ctx.pc);
        
        // 获取或加载Handler
        VmHandler handler = getHandler(realOpcode);
        if (handler == nullptr) {
            handler = loadHandler(realOpcode);
        }
        
        // 执行并通过动态跳转表
        if (handler == nullptr || !handler(ctx, insn)) {
            LOGE("Handler执行失败 realOpcode=0x%x opcode=%s", realOpcode, insn.opcodeName.c_str());
            break;
        }
        
        ctx.pc++;
    }
}

VmHandler VmpDispatcher::getHandler(int opcode) {
    if (opcode >= 0 && opcode < 256 && m_handlerLoaded[opcode]) {
        return m_handlers[opcode];
    }
    return nullptr;
}

void VmpDispatcher::preloadHandlers(const std::vector<int>& opcodes) {
    for (int opcode : opcodes) {
        if (opcode >= 0 && opcode < 256 && !m_handlerLoaded[opcode]) {
            loadHandler(opcode);
        }
    }
}

void VmpDispatcher::initDispatchTable() {
    // 预分配跳转表空间
    m_dispatchTable.resize(DISPATCH_TABLE_SIZE);
    
    // 填充随机跳转地址
    std::mt19937 gen(m_seed);
    std::uniform_int_distribution<uintptr_t> dist(0x1000, 0xFFFFFFFF);
    
    for (int i = 0; i < DISPATCH_TABLE_SIZE; i++) {
        // 实际地址通过运行时动态绑定
        m_dispatchTable[i] = (void*)0xDEADBEEF;
    }
    
    m_tableInitialized = true;
    LOGI("跳转表初始化完成，大小=%d", DISPATCH_TABLE_SIZE);
}

int VmpDispatcher::getDispatchIndex(int opcode, int pc) {
    // 使用双重哈希计算跳转位置
    uint32_t hash1 = hashCombine(opcode * 0x9E3779B9, pc * 0x85EBCA77);
    uint32_t hash2 = hashCombine(opcode * 0x3C6EF372, pc * 0x6DC44B89);
    return static_cast<int>((hash1 + hash2) % DISPATCH_TABLE_SIZE);
}

VmHandler VmpDispatcher::loadHandler(int opcode) {
    if (opcode < 0 || opcode >= 256) {
        return nullptr;
    }
    
    // 从现有的处理器映射中获取
    VmHandler handler = getHandlerByRealOpcode(opcode);
    if (handler != nullptr) {
        m_handlers[opcode] = handler;
        m_handlerLoaded[opcode] = true;
        return handler;
    }
    
    return nullptr;
}

void VmpDispatcher::decryptHandler(const unsigned char* encrypted, size_t size, unsigned char* out) {
    // 简单XOR解密 - 在实际应用中应该使用更强的加密
    for (size_t i = 0; i < size; i++) {
        out[i] = encrypted[i] ^ m_key[i % 32];
    }
}

void VmpDispatcher::generateKey() {
    // 从多个源生成密钥
    uint32_t sources[8];
    sources[0] = m_seed;
    sources[1] = static_cast<uint32_t>(time(nullptr));
    sources[2] = static_cast<uint32_t>(getpid());
    sources[3] = static_cast<uint32_t>(reinterpret_cast<uintptr_t>(this));
    
    // 使用简单的哈希生成密钥
    for (int i = 0; i < 32; i++) {
        uint32_t combined = sources[i % 8] ^ (i * 0x9E3779B9);
        m_key[i] = static_cast<uint8_t>((combined >> (i % 4 * 8)) & 0xFF);
    }
    
    LOGI("动态密钥生成完成");
}

uint32_t VmpDispatcher::hashCombine(uint32_t a, uint32_t b) {
    // Bob Jenkins的哈希组合函数
    a += b;
    a ^= (a << 13);
    a ^= (a >> 17);
    a ^= (a << 5);
    return a;
}

} // namespace ArkVMP