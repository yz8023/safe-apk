#ifndef VMP_DISPATCHER_H
#define VMP_DISPATCHER_H

#include "../VmContext.h"
#include "../VmpTypes.h"
#include <cstdint>
#include <vector>
#include <unordered_map>

namespace ArkVMP {

// 指令处理器类型
typedef bool (*VmHandler)(VmContext& ctx, const VmpInstruction& insn);

class VmpDispatcher {
private:
    // 动态生成的跳转表
    std::vector<void*> m_dispatchTable;
    uint32_t m_seed;
    bool m_tableInitialized = false;
    
    // 指令处理器存储
    VmHandler m_handlers[256];
    bool m_handlerLoaded[256];
    
    // 加密切换
    uint8_t m_key[32];
    
    // 跳转表大小
    static const int DISPATCH_TABLE_SIZE = 1024;
    
public:
    VmpDispatcher();
    ~VmpDispatcher();
    
    // 执行指令
    void execute(VmContext& ctx);
    
    // 获取处理器
    VmHandler getHandler(int opcode);
    
    // 预加载处理器
    void preloadHandlers(const std::vector<int>& opcodes);
    
private:
    // 初始化跳转表
    void initDispatchTable();
    
    // 计算跳转索引
    int getDispatchIndex(int opcode, int pc);
    
    // 加载处理器
    VmHandler loadHandler(int opcode);
    
    // 解密处理器数据
    void decryptHandler(const unsigned char* encrypted, size_t size, unsigned char* out);
    
    // 生成动态密钥
    void generateKey();
    
    // 哈希函数
    uint32_t hashCombine(uint32_t a, uint32_t b);
};

} // namespace ArkVMP

#endif // VMP_DISPATCHER_H