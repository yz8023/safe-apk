#ifndef ARK_GRAYSCALE_GRAYSCALE_MANAGER_H
#define ARK_GRAYSCALE_GRAYSCALE_MANAGER_H

#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <atomic>
#include <functional>

namespace ark {
namespace grayscale {

/**
 * 灰度配置结构
 */
struct GrayscaleConfig {
    std::string version;                    // 配置版本号
    std::vector<std::string> enabledDevices;    // 白名单设备ID列表
    std::vector<std::string> disabledDevices;   // 黑名单设备ID列表
    int sampleRate;                         // 采样率 0-100
    std::map<std::string, bool> features;   // 特性开关映射
    uint64_t lastUpdateTime;                // 最后更新时间
    
    GrayscaleConfig() : sampleRate(0), lastUpdateTime(0) {}
};

/**
 * 灰度发布管理器
 * 
 * 功能：
 * 1. A/B测试框架支持
 * 2. 用户分段和设备分组
 * 3. 特性开关管理
 * 4. 远程配置更新
 * 5. 灰度发布控制
 * 6. 数据上报和监控
 */
class GrayscaleManager {
public:
    static GrayscaleManager& getInstance();
    
    // 初始化
    void initialize();
    
    // 检查设备是否在灰度范围内
    bool isEnabled();
    
    // 检查特定特性是否启用
    bool isFeatureEnabled(const std::string& feature);
    
    // 更新灰度配置
    void updateConfig(const std::string& jsonConfig);
    
    // 更新灰度配置（结构体）
    void updateConfig(const GrayscaleConfig& config);
    
    // 获取当前配置
    GrayscaleConfig getCurrentConfig();
    
    // 设置设备ID
    void setDeviceId(const std::string& deviceId);
    
    // 获取设备ID
    std::string getDeviceId();
    
    // 设置用户ID
    void setUserId(const std::string& userId);
    
    // 获取用户ID
    std::string getUserId();
    
    // 注册配置变更回调
    void registerConfigChangeCallback(std::function<void(const GrayscaleConfig&)> callback);
    
    // 获取设备分组
    int getDeviceGroup();
    
    // 设置设备分组
    void setDeviceGroup(int group);
    
    // 上报设备信息
    void reportDeviceInfo();
    
    // 上报使用统计
    void reportUsageStats(const std::string& feature, bool success);
    
    // 检查是否应该上报数据
    bool shouldReportData();
    
    // 获取采样率
    int getSampleRate();
    
    // 设置采样率
    void setSampleRate(int rate);
    
    // 强制启用（用于测试）
    void forceEnable(bool enable);
    
    // 重置配置
    void resetConfig();

private:
    GrayscaleManager();
    ~GrayscaleManager();
    
    // 禁止拷贝
    GrayscaleManager(const GrayscaleManager&) = delete;
    GrayscaleManager& operator=(const GrayscaleManager&) = delete;
    
    // 解析JSON配置
    GrayscaleConfig parseJsonConfig(const std::string& json);
    
    // 生成JSON配置
    std::string generateJsonConfig(const GrayscaleConfig& config);
    
    // 检查设备是否在白名单
    bool isInWhitelist(const std::string& deviceId);
    
    // 检查设备是否在黑名单
    bool isInBlacklist(const std::string& deviceId);
    
    // 计算设备哈希值
    uint32_t calculateDeviceHash(const std::string& deviceId);
    
    // 从系统获取设备ID
    std::string getSystemDeviceId();
    
    // 从系统获取用户ID
    std::string getSystemUserId();
    
    // 生成默认配置
    GrayscaleConfig generateDefaultConfig();
    
    // 保存配置到本地
    void saveConfigToLocal();
    
    // 从本地加载配置
    void loadConfigFromLocal();
    
    // 通知配置变更
    void notifyConfigChange(const GrayscaleConfig& config);
    
    // 验证配置有效性
    bool validateConfig(const GrayscaleConfig& config);
    
    // 获取当前时间（纳秒）
    static uint64_t getCurrentTimeNs();

private:
    // 当前配置
    GrayscaleConfig m_currentConfig;
    std::mutex m_configMutex;
    
    // 设备信息
    std::string m_deviceId;
    std::string m_userId;
    int m_deviceGroup;
    std::mutex m_deviceInfoMutex;
    
    // 配置变更回调
    std::vector<std::function<void(const GrayscaleConfig&)>> m_callbacks;
    std::mutex m_callbackMutex;
    
    // 标志
    std::atomic<bool> m_initialized;
    std::atomic<bool> m_forceEnabled;
    bool m_forceEnabledValue;
    
    // 配置文件路径
    static constexpr const char* CONFIG_FILE = "/data/local/tmp/ark_grayscale_config.json";
    
    // 特性名称
    static constexpr const char* FEATURE_VMP = "vmp";
    static constexpr const char* FEATURE_JIT = "jit";
    static constexpr const char* FEATURE_ANTI_DEBUG = "anti_debug";
    static constexpr const char* FEATURE_MEMORY_PROTECT = "memory_protect";
    static constexpr const char* FEATURE_CLASS_ENCRYPT = "class_encrypt";
    static constexpr const char* FEATURE_SO_ENCRYPT = "so_encrypt";
};

} // namespace grayscale
} // namespace ark

#endif // ARK_GRAYSCALE_GRAYSCALE_MANAGER_H