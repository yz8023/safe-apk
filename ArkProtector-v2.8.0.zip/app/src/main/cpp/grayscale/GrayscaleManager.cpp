#include "GrayscaleManager.h"
#include "../log/SecureLogger.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <random>
#include <cstring>
#include <sys/system_properties.h>
#include <sys/types.h>
#include <unistd.h>
#include <jni.h>

namespace ark {
namespace grayscale {

// 单例实例
GrayscaleManager& GrayscaleManager::getInstance() {
    static GrayscaleManager instance;
    return instance;
}

GrayscaleManager::GrayscaleManager()
    : m_deviceGroup(0)
    , m_initialized(false)
    , m_forceEnabled(false)
    , m_forceEnabledValue(false)
{
}

GrayscaleManager::~GrayscaleManager() {
}

void GrayscaleManager::initialize() {
    if (m_initialized) {
        return;
    }
    
    // 获取设备ID
    m_deviceId = getSystemDeviceId();
    if (m_deviceId.empty()) {
        // 生成随机设备ID
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, 0xFFFFFFFF);
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "device_%08x", dis(gen));
        m_deviceId = buffer;
    }
    
    // 获取用户ID
    m_userId = getSystemUserId();
    
    // 计算设备分组
    m_deviceGroup = calculateDeviceHash(m_deviceId) % 10;
    
    // 加载本地配置
    loadConfigFromLocal();
    
    // 如果没有本地配置，使用默认配置
    if (m_currentConfig.version.empty()) {
        m_currentConfig = generateDefaultConfig();
    }
    
    // 上报设备信息
    reportDeviceInfo();
    
    m_initialized = true;
    
    LOGI("GrayscaleManager", "灰度管理器：初始化完成，设备ID=%s，用户ID=%s，设备分组=%d，采样率=%d",
         m_deviceId.c_str(), m_userId.c_str(), m_deviceGroup, m_currentConfig.sampleRate);
}

bool GrayscaleManager::isEnabled() {
    // 强制启用
    if (m_forceEnabled) {
        return m_forceEnabledValue;
    }
    
    std::lock_guard<std::mutex> lock(m_configMutex);
    
    // 检查黑名单
    if (isInBlacklist(m_deviceId)) {
        LOGI("GrayscaleManager", "灰度管理器：设备在黑名单中，禁用灰度");
        return false;
    }
    
    // 检查白名单
    if (isInWhitelist(m_deviceId)) {
        LOGI("GrayscaleManager", "灰度管理器：设备在白名单中，启用灰度");
        return true;
    }
    
    // 采样
    int hash = calculateDeviceHash(m_deviceId) % 100;
    bool enabled = hash < m_currentConfig.sampleRate;
    
    LOGI("GrayscaleManager", "灰度管理器：设备哈希=%d，采样率=%d，结果=%s",
         hash, m_currentConfig.sampleRate, enabled ? "启用" : "禁用");
    
    return enabled;
}

bool GrayscaleManager::isFeatureEnabled(const std::string& feature) {
    // 先检查是否在灰度范围内
    if (!isEnabled()) {
        return false;
    }
    
    std::lock_guard<std::mutex> lock(m_configMutex);
    
    // 查找特性配置
    auto it = m_currentConfig.features.find(feature);
    if (it != m_currentConfig.features.end()) {
        return it->second;
    }
    
    // 默认启用
    return true;
}

void GrayscaleManager::updateConfig(const std::string& jsonConfig) {
    GrayscaleConfig newConfig = parseJsonConfig(jsonConfig);
    
    if (validateConfig(newConfig)) {
        updateConfig(newConfig);
    } else {
        LOGW("GrayscaleManager", "灰度管理器：配置验证失败，拒绝更新");
    }
}

void GrayscaleManager::updateConfig(const GrayscaleConfig& config) {
    std::lock_guard<std::mutex> lock(m_configMutex);
    
    GrayscaleConfig oldConfig = m_currentConfig;
    m_currentConfig = config;
    m_currentConfig.lastUpdateTime = getCurrentTimeNs();
    
    // 保存到本地
    saveConfigToLocal();
    
    // 通知配置变更
    notifyConfigChange(config);
    
    LOGI("GrayscaleManager", "灰度管理器：配置已更新，版本=%s，采样率=%d",
         config.version.c_str(), config.sampleRate);
}

GrayscaleConfig GrayscaleManager::getCurrentConfig() {
    std::lock_guard<std::mutex> lock(m_configMutex);
    return m_currentConfig;
}

void GrayscaleManager::setDeviceId(const std::string& deviceId) {
    std::lock_guard<std::mutex> lock(m_deviceInfoMutex);
    m_deviceId = deviceId;
    
    // 重新计算设备分组
    m_deviceGroup = calculateDeviceHash(m_deviceId) % 10;
    
    LOGI("GrayscaleManager", "灰度管理器：设备ID已设置=%s，分组=%d", deviceId.c_str(), m_deviceGroup);
}

std::string GrayscaleManager::getDeviceId() {
    std::lock_guard<std::mutex> lock(m_deviceInfoMutex);
    return m_deviceId;
}

void GrayscaleManager::setUserId(const std::string& userId) {
    std::lock_guard<std::mutex> lock(m_deviceInfoMutex);
    m_userId = userId;
    
    LOGI("GrayscaleManager", "灰度管理器：用户ID已设置=%s", userId.c_str());
}

std::string GrayscaleManager::getUserId() {
    std::lock_guard<std::mutex> lock(m_deviceInfoMutex);
    return m_userId;
}

void GrayscaleManager::registerConfigChangeCallback(
    std::function<void(const GrayscaleConfig&)> callback) {
    std::lock_guard<std::mutex> lock(m_callbackMutex);
    m_callbacks.push_back(callback);
    
    LOGI("GrayscaleManager", "灰度管理器：已注册配置变更回调");
}

int GrayscaleManager::getDeviceGroup() {
    std::lock_guard<std::mutex> lock(m_deviceInfoMutex);
    return m_deviceGroup;
}

void GrayscaleManager::setDeviceGroup(int group) {
    std::lock_guard<std::mutex> lock(m_deviceInfoMutex);
    m_deviceGroup = group;
    
    LOGI("GrayscaleManager", "灰度管理器：设备分组已设置=%d", group);
}

void GrayscaleManager::reportDeviceInfo() {
    // TODO: 上报设备信息到服务器
    LOGI("GrayscaleManager", "灰度管理器：上报设备信息，设备ID=%s，用户ID=%s，分组=%d",
         m_deviceId.c_str(), m_userId.c_str(), m_deviceGroup);
}

void GrayscaleManager::reportUsageStats(const std::string& feature, bool success) {
    // TODO: 上报使用统计到服务器
    LOGI("GrayscaleManager", "灰度管理器：上报使用统计，特性=%s，成功=%s",
         feature.c_str(), success ? "是" : "否");
}

bool GrayscaleManager::shouldReportData() {
    // 只对部分设备上报数据，减少服务器压力
    int hash = calculateDeviceHash(m_deviceId) % 10;
    return hash < 3;  // 30%的设备上报数据
}

int GrayscaleManager::getSampleRate() {
    std::lock_guard<std::mutex> lock(m_configMutex);
    return m_currentConfig.sampleRate;
}

void GrayscaleManager::setSampleRate(int rate) {
    std::lock_guard<std::mutex> lock(m_configMutex);
    // 手动实现 clamp 功能，因为 NDK 21.2 中 std::clamp 不可用
    m_currentConfig.sampleRate = (rate < 0) ? 0 : (rate > 100 ? 100 : rate);
    
    LOGI("GrayscaleManager", "灰度管理器：采样率已设置=%d", rate);
}

void GrayscaleManager::forceEnable(bool enable) {
    m_forceEnabled = true;
    m_forceEnabledValue = enable;
    
    LOGI("GrayscaleManager", "灰度管理器：强制启用=%s", enable ? "是" : "否");
}

void GrayscaleManager::resetConfig() {
    std::lock_guard<std::mutex> lock(m_configMutex);
    
    m_currentConfig = generateDefaultConfig();
    saveConfigToLocal();
    
    LOGI("GrayscaleManager", "灰度管理器：配置已重置");
}

GrayscaleConfig GrayscaleManager::parseJsonConfig(const std::string& json) {
    GrayscaleConfig config;
    
    // 简单JSON解析（实际项目应该使用专业的JSON库）
    // 这里只做简单的键值对解析
    
    // 解析版本
    size_t pos = json.find("\"version\"");
    if (pos != std::string::npos) {
        pos = json.find("\"", pos + 10);
        if (pos != std::string::npos) {
            size_t end = json.find("\"", pos + 1);
            if (end != std::string::npos) {
                config.version = json.substr(pos + 1, end - pos - 1);
            }
        }
    }
    
    // 解析采样率
    pos = json.find("\"sampleRate\"");
    if (pos != std::string::npos) {
        pos = json.find(":", pos + 12);
        if (pos != std::string::npos) {
            size_t end = json.find_first_of(",}", pos + 1);
            if (end != std::string::npos) {
                std::string rateStr = json.substr(pos + 1, end - pos - 1);
                config.sampleRate = std::stoi(rateStr);
            }
        }
    }
    
    // 解析白名单
    pos = json.find("\"enabledDevices\"");
    if (pos != std::string::npos) {
        // 简化处理，实际应该解析数组
        size_t start = json.find("[", pos);
        size_t end = json.find("]", start);
        if (start != std::string::npos && end != std::string::npos) {
            std::string devices = json.substr(start + 1, end - start - 1);
            // TODO: 解析设备列表
        }
    }
    
    // 解析黑名单
    pos = json.find("\"disabledDevices\"");
    if (pos != std::string::npos) {
        // 简化处理，实际应该解析数组
        size_t start = json.find("[", pos);
        size_t end = json.find("]", start);
        if (start != std::string::npos && end != std::string::npos) {
            std::string devices = json.substr(start + 1, end - start - 1);
            // TODO: 解析设备列表
        }
    }
    
    // 解析特性开关
    pos = json.find("\"features\"");
    if (pos != std::string::npos) {
        // 简化处理，实际应该解析对象
        size_t start = json.find("{", pos);
        size_t end = json.find("}", start);
        if (start != std::string::npos && end != std::string::npos) {
            std::string features = json.substr(start + 1, end - start - 1);
            // TODO: 解析特性映射
        }
    }
    
    return config;
}

std::string GrayscaleManager::generateJsonConfig(const GrayscaleConfig& config) {
    std::ostringstream oss;
    
    oss << "{";
    oss << "\"version\":\"" << config.version << "\",";
    oss << "\"sampleRate\":" << config.sampleRate << ",";
    oss << "\"enabledDevices\":[";
    for (size_t i = 0; i < config.enabledDevices.size(); i++) {
        oss << "\"" << config.enabledDevices[i] << "\"";
        if (i < config.enabledDevices.size() - 1) {
            oss << ",";
        }
    }
    oss << "],";
    oss << "\"disabledDevices\":[";
    for (size_t i = 0; i < config.disabledDevices.size(); i++) {
        oss << "\"" << config.disabledDevices[i] << "\"";
        if (i < config.disabledDevices.size() - 1) {
            oss << ",";
        }
    }
    oss << "],";
    oss << "\"features\":{";
    bool first = true;
    for (const auto& pair : config.features) {
        if (!first) {
            oss << ",";
        }
        oss << "\"" << pair.first << "\":" << (pair.second ? "true" : "false");
        first = false;
    }
    oss << "}";
    oss << "}";
    
    return oss.str();
}

bool GrayscaleManager::isInWhitelist(const std::string& deviceId) {
    std::lock_guard<std::mutex> lock(m_configMutex);
    
    for (const auto& device : m_currentConfig.enabledDevices) {
        if (deviceId.find(device) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

bool GrayscaleManager::isInBlacklist(const std::string& deviceId) {
    std::lock_guard<std::mutex> lock(m_configMutex);
    
    for (const auto& device : m_currentConfig.disabledDevices) {
        if (deviceId.find(device) != std::string::npos) {
            return true;
        }
    }
    
    return false;
}

uint32_t GrayscaleManager::calculateDeviceHash(const std::string& deviceId) {
    // 使用FNV-1a哈希算法
    uint32_t hash = 2166136261u;
    
    for (char c : deviceId) {
        hash ^= static_cast<uint32_t>(c);
        hash *= 16777619u;
    }
    
    return hash;
}

std::string GrayscaleManager::getSystemDeviceId() {
    char buffer[PROP_VALUE_MAX];
    
    // 尝试获取Android ID
    // TODO: 通过JNI获取Android ID
    // 这里简化处理，使用设备序列号
    
    // 获取设备序列号
    if (__system_property_get("ro.serialno", buffer) > 0) {
        return std::string(buffer);
    }
    
    // 获取设备名称
    if (__system_property_get("ro.product.name", buffer) > 0) {
        return std::string(buffer);
    }
    
    // 获取设备型号
    if (__system_property_get("ro.product.model", buffer) > 0) {
        return std::string(buffer);
    }
    
    return "";
}

std::string GrayscaleManager::getSystemUserId() {
    char buffer[PROP_VALUE_MAX];
    
    // 获取用户ID（需要通过JNI获取）
    // 这里简化处理
    
    return "default_user";
}

GrayscaleConfig GrayscaleManager::generateDefaultConfig() {
    GrayscaleConfig config;
    
    config.version = "1.0.0";
    config.sampleRate = 10;  // 默认10%灰度
    
    // 默认特性配置
    config.features[FEATURE_VMP] = true;
    config.features[FEATURE_JIT] = true;
    config.features[FEATURE_ANTI_DEBUG] = true;
    config.features[FEATURE_MEMORY_PROTECT] = true;
    config.features[FEATURE_CLASS_ENCRYPT] = true;
    config.features[FEATURE_SO_ENCRYPT] = true;
    
    config.lastUpdateTime = getCurrentTimeNs();
    
    return config;
}

void GrayscaleManager::saveConfigToLocal() {
    std::ofstream file(CONFIG_FILE);
    
    if (file.is_open()) {
        std::string json = generateJsonConfig(m_currentConfig);
        file << json;
        file.close();
        
        LOGI("GrayscaleManager", "灰度管理器：配置已保存到本地=%s", CONFIG_FILE);
    } else {
        LOGW("GrayscaleManager", "灰度管理器：无法保存配置到本地=%s", CONFIG_FILE);
    }
}

void GrayscaleManager::loadConfigFromLocal() {
    std::ifstream file(CONFIG_FILE);
    
    if (file.is_open()) {
        std::stringstream buffer;
        buffer << file.rdbuf();
        file.close();
        
        // 简化实现：不使用异常（编译选项禁用了异常）
        m_currentConfig = parseJsonConfig(buffer.str());
        LOGI("GrayscaleManager", "灰度管理器：已从本地加载配置，版本=%s", m_currentConfig.version.c_str());
    } else {
        LOGI("GrayscaleManager", "灰度管理器：本地配置文件不存在，使用默认配置");
        m_currentConfig = generateDefaultConfig();
    }
}

void GrayscaleManager::notifyConfigChange(const GrayscaleConfig& config) {
    std::lock_guard<std::mutex> lock(m_callbackMutex);
    
    for (auto& callback : m_callbacks) {
        // 简化实现：不使用异常（编译选项禁用了异常）
        callback(config);
    }
}

bool GrayscaleManager::validateConfig(const GrayscaleConfig& config) {
    // 验证采样率
    if (config.sampleRate < 0 || config.sampleRate > 100) {
        LOGW("GrayscaleManager", "灰度管理器：采样率无效=%d", config.sampleRate);
        return false;
    }
    
    // 验证版本号
    if (config.version.empty()) {
        LOGW("GrayscaleManager", "灰度管理器：版本号为空");
        return false;
    }
    
    // 验证特性开关
    for (const auto& pair : config.features) {
        if (pair.first.empty()) {
            LOGW("GrayscaleManager", "灰度管理器：特性名称为空");
            return false;
        }
    }
    
    return true;
}

uint64_t GrayscaleManager::getCurrentTimeNs() {
    auto now = std::chrono::steady_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::nanoseconds>(duration).count();
}

} // namespace grayscale
} // namespace ark