#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <pthread.h>
#include "ArkEnvGuard.h"
#include "ArkVMP.h"
#include "ArkDexLoader.h"
#include "security/SignatureChecker.h"
#include "config/ConfigManager.h"

#define LOG_TAG "ArkVMP"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static jobject g_ark_context = nullptr;
static bool g_ark_dex_loaded = false;
static jobject g_real_factory = nullptr;
static pthread_mutex_t g_ark_load_mutex = PTHREAD_MUTEX_INITIALIZER;

// ===== 安全检测配置（由Java层通过setSecurityConfig传递到native层）=====
struct SecurityConfig {
    bool antiEmulator;
    bool antiRoot;
    bool antiDebugger;
    bool antiXposed;
    bool antiVm;
    bool checkApkIntegrity;
    bool checkMemDisk;
    bool checkFridaPipe;
    bool checkFridaThread;
    bool checkAppMultiOpen;
    bool checkJavaHook;
    bool checkNativeHook;
    bool checkLocation;
    bool checkDevice;
};

static SecurityConfig g_security_config;
static pthread_mutex_t g_security_config_mutex = PTHREAD_MUTEX_INITIALIZER;

// 函数声明
static std::string getSoNameFromMetaData(JNIEnv *env, jobject context);
static std::string getFeatureKeyFromMetaData(JNIEnv *env, jobject context);

static void saveArkContext(JNIEnv *env, jobject context) {
    if (env == nullptr || context == nullptr) {
        return;
    }

    if (g_ark_context != nullptr) {
        return;
    }

    g_ark_context = env->NewGlobalRef(context);
}

static jobject getCurrentApplication(JNIEnv *env) {
    jclass activityThreadClass = env->FindClass("android/app/ActivityThread");
    if (activityThreadClass == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jmethodID midCurrentApplication = env->GetStaticMethodID(
            activityThreadClass,
            "currentApplication",
            "()Landroid/app/Application;"
    );

    if (midCurrentApplication == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jobject app = env->CallStaticObjectMethod(activityThreadClass, midCurrentApplication);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return nullptr;
    }

    return app;
}

static jobject getRealAppComponentFactory(JNIEnv *env, jobject classLoader) {
    if (g_real_factory != nullptr) {
        return g_real_factory;
    }

    const char *factoryName = ArkDexLoader_GetRealAppComponentFactoryName();
    if (factoryName == nullptr || strlen(factoryName) <= 0) {
        return nullptr;
    }

    jclass clsClassLoader = env->FindClass("java/lang/ClassLoader");
    jclass clsClass = env->FindClass("java/lang/Class");

    if (clsClassLoader == nullptr || clsClass == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jmethodID midLoadClass = env->GetMethodID(
            clsClassLoader,
            "loadClass",
            "(Ljava/lang/String;)Ljava/lang/Class;"
    );

    jmethodID midNewInstance = env->GetMethodID(
            clsClass,
            "newInstance",
            "()Ljava/lang/Object;"
    );

    if (midLoadClass == nullptr || midNewInstance == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jstring factoryNameJ = env->NewStringUTF(factoryName);

    jobject factoryClass = env->CallObjectMethod(
            classLoader,
            midLoadClass,
            factoryNameJ
    );

    if (env->ExceptionCheck() || factoryClass == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jobject factoryObj = env->CallObjectMethod(
            factoryClass,
            midNewInstance
    );

    if (env->ExceptionCheck() || factoryObj == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    g_real_factory = env->NewGlobalRef(factoryObj);

    //LOGI("已创建原 AppComponentFactory：%s", factoryName);

    return g_real_factory;
}
static jobject defaultNewInstance(JNIEnv *env, jobject classLoader, jstring className) {
    jclass clsClassLoader = env->FindClass("java/lang/ClassLoader");
    jclass clsClass = env->FindClass("java/lang/Class");

    if (clsClassLoader == nullptr || clsClass == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jmethodID midLoadClass = env->GetMethodID(
            clsClassLoader,
            "loadClass",
            "(Ljava/lang/String;)Ljava/lang/Class;"
    );

    jmethodID midNewInstance = env->GetMethodID(
            clsClass,
            "newInstance",
            "()Ljava/lang/Object;"
    );

    if (midLoadClass == nullptr || midNewInstance == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jobject targetClass = env->CallObjectMethod(
            classLoader,
            midLoadClass,
            className
    );

    if (env->ExceptionCheck() || targetClass == nullptr) {
        return nullptr;
    }

    jobject obj = env->CallObjectMethod(
            targetClass,
            midNewInstance
    );

    return obj;
}
static bool ensureDexLoadedFromFactory(JNIEnv *env, jobject classLoader) {
    if (classLoader == nullptr) {
        return false;
    }

    pthread_mutex_lock(&g_ark_load_mutex);

    if (g_ark_dex_loaded) {
        pthread_mutex_unlock(&g_ark_load_mutex);
        return true;
    }

    ArkDexLoaderFactoryFunc factoryFunc = ArkDexLoader_GetFactoryEntry();
    if (factoryFunc == nullptr) {
        pthread_mutex_unlock(&g_ark_load_mutex);
        return false;
    }

    bool ok = factoryFunc(env, classLoader);
    if (ok) {
        g_ark_dex_loaded = true;
        //LOGI("加载 dex 成功，来源=AppComponentFactory代理");
    }

    pthread_mutex_unlock(&g_ark_load_mutex);
    return ok;
}
static bool ensureArkDexLoaded(JNIEnv *env, jobject context, const char *from) {
    if (env == nullptr || context == nullptr) {
        //LOGE("加载 dex 失败：env 或 context 为空，来源=%s", from);
        return false;
    }

    pthread_mutex_lock(&g_ark_load_mutex);

    if (g_ark_dex_loaded) {
        //LOGI("dex 已加载，跳过重复加载，来源=%s", from);
        pthread_mutex_unlock(&g_ark_load_mutex);
        return true;
    }

    //LOGI("开始加载 dex，来源=%s", from);

    saveArkContext(env, context);

    ArkVMP_SetContext(env, context);

    // 【新增】读取随机化的SO名称和特征键
    std::string randomSoName = getSoNameFromMetaData(env, context);
    std::string randomFeatureKey = getFeatureKeyFromMetaData(env, context);

    if (!randomSoName.empty()) {
        //LOGI("读取到随机化的SO名称：%s", randomSoName.c_str());
        // 将SO名称传递给ArkDexLoader模块（这里需要根据实际的接口进行修改）
        // 例如：ArkDexLoader_SetSoName(randomSoName.c_str());
    }

    if (!randomFeatureKey.empty()) {
        //LOGI("读取到随机化的特征键：%s", randomFeatureKey.c_str());
        // 将特征键传递给ArkDexLoader模块（这里需要根据实际的接口进行修改）
        // 例如：ArkDexLoader_SetFeatureKey(randomFeatureKey.c_str());
    }

    ArkEnvGuardFunc guardFunc = ArkEnvGuard_GetEntry();
    if (guardFunc == nullptr) {
        //LOGE("加载 dex 失败：ArkEnvGuard_GetEntry 返回空，来源=%s", from);
        pthread_mutex_unlock(&g_ark_load_mutex);
        return false;
    }

    bool ok = guardFunc(env, context);
    if (ok) {
        g_ark_dex_loaded = true;
        //LOGI("加载 dex 成功，来源=%s", from);
    } else {
        //LOGE("加载 dex 失败：guardFunc 返回 false，来源=%s", from);
    }

    pthread_mutex_unlock(&g_ark_load_mutex);
    return ok;
}

/**
 * 从AndroidManifest.xml的meta-data中读取随机化的SO名称
 */
static std::string getSoNameFromMetaData(JNIEnv *env, jobject context) {
    if (env == nullptr || context == nullptr) {
        return "";
    }

    // 获取PackageManager
    jclass clsContext = env->FindClass("android/content/Context");
    if (clsContext == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jmethodID midGetPackageManager = env->GetMethodID(
        clsContext,
        "getPackageManager",
        "()Landroid/content/pm/PackageManager;"
    );

    if (midGetPackageManager == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jobject packageManager = env->CallObjectMethod(context, midGetPackageManager);
    if (env->ExceptionCheck() || packageManager == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 获取ApplicationInfo
    jclass clsPackageManager = env->FindClass("android/content/pm/PackageManager");
    if (clsPackageManager == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jmethodID midGetPackageInfo = env->GetMethodID(
        clsPackageManager,
        "getPackageInfo",
        "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;"
    );

    if (midGetPackageInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 获取包名
    jmethodID midGetPackageName = env->GetMethodID(
        clsContext,
        "getPackageName",
        "()Ljava/lang/String;"
    );

    if (midGetPackageName == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jstring packageName = (jstring) env->CallObjectMethod(context, midGetPackageName);
    if (env->ExceptionCheck() || packageName == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jobject packageInfo = env->CallObjectMethod(
        packageManager,
        midGetPackageInfo,
        packageName,
        0x00000080  // GET_META_DATA
    );

    if (env->ExceptionCheck() || packageInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 获取ApplicationInfo
    jclass clsPackageInfo = env->FindClass("android/content/pm/PackageInfo");
    if (clsPackageInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jfieldID fidApplicationInfo = env->GetFieldID(
        clsPackageInfo,
        "applicationInfo",
        "Landroid/content/pm/ApplicationInfo;"
    );

    if (fidApplicationInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jobject applicationInfo = env->GetObjectField(packageInfo, fidApplicationInfo);
    if (env->ExceptionCheck() || applicationInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 获取meta-data
    jclass clsApplicationInfo = env->FindClass("android/content/pm/ApplicationInfo");
    if (clsApplicationInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jfieldID fidMetaData = env->GetFieldID(
        clsApplicationInfo,
        "metaData",
        "Landroid/os/Bundle;"
    );

    if (fidMetaData == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jobject metaData = env->GetObjectField(applicationInfo, fidMetaData);
    if (env->ExceptionCheck() || metaData == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 从meta-data中读取SO名称
    jclass clsBundle = env->FindClass("android/os/Bundle");
    if (clsBundle == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jmethodID midGetString = env->GetMethodID(
        clsBundle,
        "getString",
        "(Ljava/lang/String;)Ljava/lang/String;"
    );

    if (midGetString == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jstring soNameKey = env->NewStringUTF("ark.so.name");
    jstring soNameValue = (jstring) env->CallObjectMethod(metaData, midGetString, soNameKey);

    if (env->ExceptionCheck() || soNameValue == nullptr) {
        env->ExceptionClear();
        return "";
    }

    const char *soNameCStr = env->GetStringUTFChars(soNameValue, nullptr);
    std::string result(soNameCStr);
    env->ReleaseStringUTFChars(soNameValue, soNameCStr);

    return result;
}

/**
 * 从AndroidManifest.xml的meta-data中读取随机化的特征键
 */
static std::string getFeatureKeyFromMetaData(JNIEnv *env, jobject context) {
    if (env == nullptr || context == nullptr) {
        return "";
    }

    // 获取PackageManager
    jclass clsContext = env->FindClass("android/content/Context");
    if (clsContext == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jmethodID midGetPackageManager = env->GetMethodID(
        clsContext,
        "getPackageManager",
        "()Landroid/content/pm/PackageManager;"
    );

    if (midGetPackageManager == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jobject packageManager = env->CallObjectMethod(context, midGetPackageManager);
    if (env->ExceptionCheck() || packageManager == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 获取ApplicationInfo
    jclass clsPackageManager = env->FindClass("android/content/pm/PackageManager");
    if (clsPackageManager == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jmethodID midGetPackageInfo = env->GetMethodID(
        clsPackageManager,
        "getPackageInfo",
        "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;"
    );

    if (midGetPackageInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 获取包名
    jmethodID midGetPackageName = env->GetMethodID(
        clsContext,
        "getPackageName",
        "()Ljava/lang/String;"
    );

    if (midGetPackageName == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jstring packageName = (jstring) env->CallObjectMethod(context, midGetPackageName);
    if (env->ExceptionCheck() || packageName == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jobject packageInfo = env->CallObjectMethod(
        packageManager,
        midGetPackageInfo,
        packageName,
        0x00000080  // GET_META_DATA
    );

    if (env->ExceptionCheck() || packageInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 获取ApplicationInfo
    jclass clsPackageInfo = env->FindClass("android/content/pm/PackageInfo");
    if (clsPackageInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jfieldID fidApplicationInfo = env->GetFieldID(
        clsPackageInfo,
        "applicationInfo",
        "Landroid/content/pm/ApplicationInfo;"
    );

    if (fidApplicationInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jobject applicationInfo = env->GetObjectField(packageInfo, fidApplicationInfo);
    if (env->ExceptionCheck() || applicationInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 获取meta-data
    jclass clsApplicationInfo = env->FindClass("android/content/pm/ApplicationInfo");
    if (clsApplicationInfo == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jfieldID fidMetaData = env->GetFieldID(
        clsApplicationInfo,
        "metaData",
        "Landroid/os/Bundle;"
    );

    if (fidMetaData == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jobject metaData = env->GetObjectField(applicationInfo, fidMetaData);
    if (env->ExceptionCheck() || metaData == nullptr) {
        env->ExceptionClear();
        return "";
    }

    // 从meta-data中读取特征键
    jclass clsBundle = env->FindClass("android/os/Bundle");
    if (clsBundle == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jmethodID midGetString = env->GetMethodID(
        clsBundle,
        "getString",
        "(Ljava/lang/String;)Ljava/lang/String;"
    );

    if (midGetString == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jstring featureKeyKey = env->NewStringUTF("ark.feature.key");
    jstring featureKeyValue = (jstring) env->CallObjectMethod(metaData, midGetString, featureKeyKey);

    if (env->ExceptionCheck() || featureKeyValue == nullptr) {
        env->ExceptionClear();
        return "";
    }

    const char *featureKeyCStr = env->GetStringUTFChars(featureKeyValue, nullptr);
    std::string result(featureKeyCStr);
    env->ReleaseStringUTFChars(featureKeyValue, featureKeyCStr);

    return result;
}

static jobject native_instantiateApplication(JNIEnv *env, jclass clazz, jobject classLoader, jstring className) {
    ensureDexLoadedFromFactory(env, classLoader);

    jobject realFactory = getRealAppComponentFactory(env, classLoader);
    if (realFactory != nullptr) {
        jclass clsFactory = env->FindClass("android/app/AppComponentFactory");
        jmethodID mid = env->GetMethodID(
                clsFactory,
                "instantiateApplication",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroid/app/Application;"
        );

        jobject obj = env->CallObjectMethod(realFactory, mid, classLoader, className);
        if (!env->ExceptionCheck() && obj != nullptr) {
            return obj;
        }

        env->ExceptionClear();
    }

    return defaultNewInstance(env, classLoader, className);
}
static jobject native_instantiateProvider(JNIEnv *env, jclass clazz, jobject classLoader, jstring className) {
    ensureDexLoadedFromFactory(env, classLoader);

    jobject realFactory = getRealAppComponentFactory(env, classLoader);
    if (realFactory != nullptr) {
        jclass clsFactory = env->FindClass("android/app/AppComponentFactory");
        jmethodID mid = env->GetMethodID(
                clsFactory,
                "instantiateProvider",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroid/content/ContentProvider;"
        );

        jobject obj = env->CallObjectMethod(realFactory, mid, classLoader, className);
        if (!env->ExceptionCheck() && obj != nullptr) {
            return obj;
        }

        env->ExceptionClear();
    }

    return defaultNewInstance(env, classLoader, className);
}
static jobject native_instantiateActivity(JNIEnv *env, jclass clazz, jobject classLoader, jstring className, jobject intent) {
    ensureDexLoadedFromFactory(env, classLoader);

    jobject realFactory = getRealAppComponentFactory(env, classLoader);
    if (realFactory != nullptr) {
        jclass clsFactory = env->FindClass("android/app/AppComponentFactory");
        jmethodID mid = env->GetMethodID(
                clsFactory,
                "instantiateActivity",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Activity;"
        );

        jobject obj = env->CallObjectMethod(realFactory, mid, classLoader, className, intent);
        if (!env->ExceptionCheck() && obj != nullptr) {
            return obj;
        }

        env->ExceptionClear();
    }

    return defaultNewInstance(env, classLoader, className);
}
static jobject native_instantiateService(JNIEnv *env, jclass clazz, jobject classLoader, jstring className, jobject intent) {
    ensureDexLoadedFromFactory(env, classLoader);

    jobject realFactory = getRealAppComponentFactory(env, classLoader);
    if (realFactory != nullptr) {
        jclass clsFactory = env->FindClass("android/app/AppComponentFactory");
        jmethodID mid = env->GetMethodID(
                clsFactory,
                "instantiateService",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Service;"
        );

        jobject obj = env->CallObjectMethod(realFactory, mid, classLoader, className, intent);
        if (!env->ExceptionCheck() && obj != nullptr) {
            return obj;
        }

        env->ExceptionClear();
    }

    return defaultNewInstance(env, classLoader, className);
}
static jobject native_instantiateReceiver(JNIEnv *env, jclass clazz, jobject classLoader, jstring className, jobject intent) {
    ensureDexLoadedFromFactory(env, classLoader);

    jobject realFactory = getRealAppComponentFactory(env, classLoader);
    if (realFactory != nullptr) {
        jclass clsFactory = env->FindClass("android/app/AppComponentFactory");
        jmethodID mid = env->GetMethodID(
                clsFactory,
                "instantiateReceiver",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/content/BroadcastReceiver;"
        );

        jobject obj = env->CallObjectMethod(realFactory, mid, classLoader, className, intent);
        if (!env->ExceptionCheck() && obj != nullptr) {
            return obj;
        }

        env->ExceptionClear();
    }

    return defaultNewInstance(env, classLoader, className);
}

/**
 * 给 AppComponentFactory 调用
 * 对应壳类方法：
 * public static native void loadDexFromFactory(ClassLoader cl);
 */
static void native_loadDexFromFactory(JNIEnv *env, jclass clazz, jobject classLoader) {
    //LOGI("进入 AppComponentFactory 加载入口");

    if (classLoader == nullptr) {
        //LOGE("Factory 入口传入的 ClassLoader 为空");
        return;
    }

    pthread_mutex_lock(&g_ark_load_mutex);

    if (g_ark_dex_loaded) {
        //LOGI("dex 已加载，跳过重复加载，来源=AppComponentFactory");
        pthread_mutex_unlock(&g_ark_load_mutex);
        return;
    }

    ArkDexLoaderFactoryFunc factoryFunc = ArkDexLoader_GetFactoryEntry();
    if (factoryFunc == nullptr) {
        //LOGE("Factory 加载 dex 失败：ArkDexLoader_GetFactoryEntry 返回空");
        pthread_mutex_unlock(&g_ark_load_mutex);
        return;
    }

    bool ok = factoryFunc(env, classLoader);
    if (ok) {
        g_ark_dex_loaded = true;
        //LOGI("加载 dex 成功，来源=AppComponentFactory");
    } else {
        //LOGE("加载 dex 失败，来源=AppComponentFactory");
    }

    pthread_mutex_unlock(&g_ark_load_mutex);
}

// ===== DPT 函数抽取运行时还原 =====
// 从 assets 读取 dpt_codeitems.bin，调用 DptHook 还原被抽取的方法
static void tryDptRestore(JNIEnv* env, jobject context) {
    if (context == nullptr) return;

    // 获取 AssetManager
    jclass ctxClass = env->GetObjectClass(context);
    jmethodID getAssets = env->GetMethodID(ctxClass, "getAssets", "()Landroid/content/res/AssetManager;");
    if (getAssets == nullptr) { env->ExceptionClear(); return; }
    jobject assetManager = env->CallObjectMethod(context, getAssets);
    if (assetManager == nullptr) return;

    // 打开 dpt_codeitems.bin
    jclass amClass = env->GetObjectClass(assetManager);
    jmethodID openMethod = env->GetMethodID(amClass, "open", "(Ljava/lang/String;)Ljava/io/InputStream;");
    if (openMethod == nullptr) { env->ExceptionClear(); return; }

    jstring fileName = env->NewStringUTF("dpt_codeitems.bin");
    jobject inputStream = env->CallObjectMethod(assetManager, openMethod, fileName);
    env->DeleteLocalRef(fileName);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return; // DPT 未启用，没有这个文件
    }
    if (inputStream == nullptr) return;

    // 读取全部字节
    // 先用 available() 获取大小，不够则循环读取
    jclass isClass = env->GetObjectClass(inputStream);
    jmethodID availableMethod = env->GetMethodID(isClass, "available", "()I");
    jmethodID readMethod = env->GetMethodID(isClass, "read", "([B)I");
    jmethodID closeMethod = env->GetMethodID(isClass, "close", "()V");

    int initialSize = 0;
    if (availableMethod != nullptr) {
        initialSize = env->CallIntMethod(inputStream, availableMethod);
        if (initialSize < 1024) initialSize = 1024;
    } else {
        initialSize = 65536;
    }

    // 动态扩容读取
    std::vector<unsigned char> data;
    data.reserve(initialSize);
    jbyteArray buf = env->NewByteArray(8192);
    while (true) {
        int n = env->CallIntMethod(inputStream, readMethod, buf);
        if (n <= 0) break;
        jbyte* p = env->GetByteArrayElements(buf, nullptr);
        data.insert(data.end(), p, p + n);
        env->ReleaseByteArrayElements(buf, p, JNI_ABORT);
    }
    env->CallVoidMethod(inputStream, closeMethod);
    env->DeleteLocalRef(buf);
    env->DeleteLocalRef(inputStream);
    env->DeleteLocalRef(assetManager);
    env->DeleteLocalRef(amClass);
    env->DeleteLocalRef(isClass);
    env->DeleteLocalRef(ctxClass);

    if (data.empty()) return;

    // 读取 dpt_config.json 判断是否增强版
    bool enhanced = false;
    // 简单检查 version 字段
    // version=2 表示增强版
    int version = data[0] | (data[1] << 8);
    if (version == 2) enhanced = true;

    // 调用 DptNativeBridge.nativeLoadCodeItems
    jclass bridgeClass = env->FindClass("com/ark/jiagu/dpt/DptNativeBridge");
    if (bridgeClass == nullptr) {
        env->ExceptionClear();
        // 直接调用 DptHook.cpp 的 C 函数
        // 构造 jbyteArray
        jbyteArray jdata = env->NewByteArray(data.size());
        env->SetByteArrayRegion(jdata, 0, data.size(), (jbyte*)data.data());

        // 调用 native 方法
        jmethodID loadMethod = env->GetStaticMethodID(
            env->FindClass("com/ark/jiagu/dpt/DptNativeBridge"),
            "nativeLoadCodeItems", "([BZ)I");
        if (loadMethod != nullptr) {
            env->CallStaticIntMethod(env->FindClass("com/ark/jiagu/dpt/DptNativeBridge"),
                loadMethod, jdata, enhanced ? JNI_TRUE : JNI_FALSE);
        }
        env->DeleteLocalRef(jdata);
    } else {
        jmethodID loadMethod = env->GetStaticMethodID(bridgeClass,
            "nativeLoadCodeItems", "([BZ)I");
        if (loadMethod != nullptr) {
            jbyteArray jdata = env->NewByteArray(data.size());
            env->SetByteArrayRegion(jdata, 0, data.size(), (jbyte*)data.data());
            env->CallStaticIntMethod(bridgeClass, loadMethod, jdata,
                enhanced ? JNI_TRUE : JNI_FALSE);
            env->DeleteLocalRef(jdata);
        }
        env->DeleteLocalRef(bridgeClass);
    }
}


static void native_attachBaseContext(JNIEnv *env, jobject thiz, jobject context) {
    if (context == nullptr) {
        return;
    }

    jclass contextWrapperClass = env->FindClass("android/content/ContextWrapper");
    if (contextWrapperClass == nullptr) {
        env->ExceptionClear();
        return;
    }

    jmethodID midAttachBaseContext = env->GetMethodID(
            contextWrapperClass,
            "attachBaseContext",
            "(Landroid/content/Context;)V"
    );

    if (midAttachBaseContext == nullptr) {
        env->ExceptionClear();
        return;
    }

    env->CallNonvirtualVoidMethod(
            thiz,
            contextWrapperClass,
            midAttachBaseContext,
            context
    );

    if (env->ExceptionCheck()) {
        return;
    }

    saveArkContext(env, context);
    ensureArkDexLoaded(env, context, "attachBaseContext");

    // DPT 函数抽取还原：DEX 已加载到内存，扫描并还原被抽取的方法
    tryDptRestore(env, context);
}

static void native_onCreate(JNIEnv *env, jobject thiz) {
    jclass applicationClass = env->FindClass("android/app/Application");
    if (applicationClass == nullptr) {
        env->ExceptionClear();
        return;
    }

    jmethodID midOnCreate = env->GetMethodID(
            applicationClass,
            "onCreate",
            "()V"
    );

    if (midOnCreate == nullptr) {
        env->ExceptionClear();
        return;
    }

    env->CallNonvirtualVoidMethod(
            thiz,
            applicationClass,
            midOnCreate
    );

    if (env->ExceptionCheck()) {
        return;
    }

    saveArkContext(env, thiz);
    ArkVMP_SetContext(env, thiz);

    ArkEnvGuardFunc starterFunc = ArkEnvGuard_GetStartRealApplicationEntry();
    if (starterFunc != nullptr) {
        starterFunc(env, thiz);
    }
}

static std::string jstringToString(JNIEnv *env, jstring str) {
    if (str == nullptr) {
        return "";
    }

    const char *chars = env->GetStringUTFChars(str, nullptr);
    if (chars == nullptr) {
        return "";
    }

    std::string result(chars);
    env->ReleaseStringUTFChars(str, chars);
    return result;
}

static void dotToSlash(std::string &name) {
    for (size_t i = 0; i < name.length(); i++) {
        if (name[i] == '.') {
            name[i] = '/';
        }
    }
}

static std::string getStubClassNameFromProperty(JNIEnv *env) {
    jclass clsSystem = env->FindClass("java/lang/System");
    if (clsSystem == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jmethodID midGetProperty = env->GetStaticMethodID(
            clsSystem,
            "getProperty",
            "(Ljava/lang/String;)Ljava/lang/String;"
    );

    if (midGetProperty == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jstring key = env->NewStringUTF("_cls_ref");

    jstring value = (jstring) env->CallStaticObjectMethod(
            clsSystem,
            midGetProperty,
            key
    );

    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return "";
    }

    std::string className = jstringToString(env, value);
    dotToSlash(className);

    return className;
}

static JNINativeMethod gStubMethods[] = {
        {
                "attachBaseContext",
                "(Landroid/content/Context;)V",
                (void *) native_attachBaseContext
        },
        {
                "onCreate",
                "()V",
                (void *) native_onCreate
        },
        {
                "loadDexFromFactory",
                "(Ljava/lang/ClassLoader;)V",
                (void *) native_loadDexFromFactory
        },
        {
                "nativeInstantiateApplication",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroid/app/Application;",
                (void *) native_instantiateApplication
        },
        {
                "nativeInstantiateProvider",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;)Landroid/content/ContentProvider;",
                (void *) native_instantiateProvider
        },
        {
                "nativeInstantiateActivity",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Activity;",
                (void *) native_instantiateActivity
        },
        {
                "nativeInstantiateService",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/app/Service;",
                (void *) native_instantiateService
        },
        {
                "nativeInstantiateReceiver",
                "(Ljava/lang/ClassLoader;Ljava/lang/String;Landroid/content/Intent;)Landroid/content/BroadcastReceiver;",
                (void *) native_instantiateReceiver
        }
};

// ===== 新增：传递安全检测配置到native层 =====
// 将Java层的安全检测配置保存到全局变量，供运行时安全检测使用。
// 在JNI_OnLoad或StubApp.onCreate后由Java层调用。
extern "C" JNIEXPORT void JNICALL
Java_com_ark_jiagu_ArkApplication_setSecurityConfig(JNIEnv *env, jobject thiz,
    jboolean antiEmulator, jboolean antiRoot, jboolean antiDebugger,
    jboolean antiXposed, jboolean antiVm, jboolean checkApkIntegrity,
    jboolean checkMemDisk, jboolean checkFridaPipe, jboolean checkFridaThread,
    jboolean checkAppMultiOpen, jboolean checkJavaHook, jboolean checkNativeHook,
    jboolean checkLocation, jboolean checkDevice) {
    pthread_mutex_lock(&g_security_config_mutex);
    g_security_config.antiEmulator = antiEmulator;
    g_security_config.antiRoot = antiRoot;
    g_security_config.antiDebugger = antiDebugger;
    g_security_config.antiXposed = antiXposed;
    g_security_config.antiVm = antiVm;
    g_security_config.checkApkIntegrity = checkApkIntegrity;
    g_security_config.checkMemDisk = checkMemDisk;
    g_security_config.checkFridaPipe = checkFridaPipe;
    g_security_config.checkFridaThread = checkFridaThread;
    g_security_config.checkAppMultiOpen = checkAppMultiOpen;
    g_security_config.checkJavaHook = checkJavaHook;
    g_security_config.checkNativeHook = checkNativeHook;
    g_security_config.checkLocation = checkLocation;
    g_security_config.checkDevice = checkDevice;
    pthread_mutex_unlock(&g_security_config_mutex);

    LOGI("安全检测配置已更新: antiEmulator=%d antiRoot=%d antiDebugger=%d antiXposed=%d antiVm=%d",
         antiEmulator, antiRoot, antiDebugger, antiXposed, antiVm);
}

/**
 * 通过JNI调用Java层RuntimeSecurityChecker执行运行时安全检测。
 * RuntimeSecurityChecker为可选的Java侧检测组件，若不存在则静默跳过，不影响主流程。
 */
static void triggerRuntimeSecurityChecker(JNIEnv *env, jobject application) {
    if (env == nullptr || application == nullptr) {
        return;
    }

    jclass checkerClass = env->FindClass("com/ark/security/RuntimeSecurityChecker");
    if (checkerClass == nullptr) {
        env->ExceptionClear();
        return;
    }

    jmethodID midStart = env->GetStaticMethodID(
            checkerClass, "startChecks", "(Landroid/content/Context;)V");
    if (midStart == nullptr) {
        env->ExceptionClear();
        env->DeleteLocalRef(checkerClass);
        return;
    }

    env->CallStaticVoidMethod(checkerClass, midStart, application);
    if (env->ExceptionCheck()) {
        env->ExceptionClear();
    }

    env->DeleteLocalRef(checkerClass);
}

// ArkApplication类的native方法注册数组。
// 注意：gStubMethods注册的是动态壳类(由_cls_ref属性指定)，而setSecurityConfig
// 属于com.ark.jiagu.ArkApplication，目标类不同，因此使用独立的注册数组。
// 注册失败不致命：标准JNI命名(Java_com_ark_jiagu_ArkApplication_setSecurityConfig)
// 会在方法被调用时自动兜底绑定。
static JNINativeMethod gArkAppNativeMethods[] = {
        {
                "setSecurityConfig",
                "(ZZZZZZZZZZZZZZ)V",
                (void *) Java_com_ark_jiagu_ArkApplication_setSecurityConfig
        }
};

static int registerArkApplicationNatives(JNIEnv *env) {
    jclass clazz = env->FindClass("com/ark/jiagu/ArkApplication");
    if (clazz == nullptr) {
        // JNI_OnLoad阶段应用类可能尚未加载，清除异常并依赖标准JNI命名自动绑定
        env->ExceptionClear();
        return JNI_FALSE;
    }

    int ret = env->RegisterNatives(
            clazz,
            gArkAppNativeMethods,
            sizeof(gArkAppNativeMethods) / sizeof(gArkAppNativeMethods[0]));

    if (ret != JNI_OK) {
        env->ExceptionClear();
        env->DeleteLocalRef(clazz);
        return JNI_FALSE;
    }

    env->DeleteLocalRef(clazz);
    return JNI_TRUE;
}

// Application配置初始化
extern "C" JNIEXPORT void JNICALL
Java_com_ark_jiagu_ArkApplication_initializeNativeConfig(JNIEnv *env, jobject thiz) {
    // 获取Application context
    jobject application = getCurrentApplication(env);
    if (application == nullptr) {
        LOGE("无法获取Application context");
        return;
    }

    // 初始化ConfigManager
    arkjiagu::ConfigManager& config = arkjiagu::ConfigManager::getInstance();
    config.initialize(env, application);

    LOGI("Native层配置初始化完成");

    // 打印配置信息
    if (config.isLogEnabled()) {
        LOGI("日志级别: %s", config.getLogLevel().c_str());
        LOGI("反调试检测: %s", config.isAntiDebugEnabled() ? "启用" : "禁用");
        LOGI("内存保护: %s", config.isMemoryProtectionEnabled() ? "启用" : "禁用");
        LOGI("VMP: %s", config.isVmpEnabled() ? "启用" : "禁用");
        LOGI("灰度发布: %s", config.isGrayscaleEnabled() ? "启用" : "禁用");
        LOGI("性能监控: %s", config.isPerformanceMonitorEnabled() ? "启用" : "禁用");
    }

    // 通过JNI调用Java层RuntimeSecurityChecker执行运行时安全检测
    triggerRuntimeSecurityChecker(env, application);
}

static int registerNativeMethods(JNIEnv *env) {
    std::string className = getStubClassNameFromProperty(env);

    if (className.empty()) {
        // 不再硬编码回退类名，强制依赖setProperty
        className = "_cls_ref";
    }

    jclass clazz = env->FindClass(className.c_str());
    if (clazz == nullptr) {
        env->ExceptionClear();
        return JNI_FALSE;
    }

    if (env->RegisterNatives(
            clazz,
            gStubMethods,
            sizeof(gStubMethods) / sizeof(gStubMethods[0])
    ) != JNI_OK) {
        env->ExceptionClear();
        return JNI_FALSE;
    }

    return JNI_TRUE;
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env = nullptr;

    if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return JNI_ERR;
    }

    if (!registerNativeMethods(env)) {
        //LOGE("注册方法失败");
        return JNI_ERR;
    }

    // 注册ArkApplication的安全配置方法（失败不致命，标准JNI命名会兜底绑定）
    registerArkApplicationNatives(env);

    if (ArkVMP_OnLoad(vm) == JNI_ERR) {
        return JNI_ERR;
    }

    return JNI_VERSION_1_6;
}