#ifndef VERSION_ADAPTER_H
#define VERSION_ADAPTER_H

#include <cstdint>
#include <string>
#include <vector>
#include <map>
#include <android/log.h>
#include <android/api-level.h>

#define LOG_TAG "ArkVMP_VersionAdapter"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

// API特性
struct ApiFeatures {
    bool supportInMemoryDexLoader;  // 支持内存DEX加载
    bool supportNativeBridge;        // 支持Native桥接
    bool supportJNI_1_6;            // 支持JNI 1.6
    bool supportFridaDetection;     // 支持Frida检测
    bool supportMemoryProtect;      // 支持内存保护
    bool supportOreoFeatures;       // 支持Android 8.0特性
    bool supportPieFeatures;        // 支持Android 9.0特性
    bool supportQFeatures;          // 支持Android 10.0特性
    bool supportRFeatures;          // 支持Android 11.0特性
    bool supportSFeatures;          // 支持Android 12.0特性
};

class VersionAdapter {
public:
    VersionAdapter();
    ~VersionAdapter();
    
    // 获取API特性
    ApiFeatures getFeatures();
    
    // 获取Android API级别
    static int getAndroidApiLevel();
    
    // 检测是否为ART运行时
    static bool isArtRuntime();
    
    // 检测是否为64位架构
    static bool is64Bit();
    
    // 获取架构名称
    static std::string getArchName();
    
    // 获取设备信息
    static std::string getDeviceInfo();
    
    // 检查是否支持特定功能
    bool supportsFeature(const std::string& feature);
    
    // 获取推荐的配置
    std::string getRecommendedConfig();
    
    // 检查兼容性
    bool checkCompatibility();
    
    // 获取兼容性警告
    std::vector<std::string> getCompatibilityWarnings();
    
private:
    ApiFeatures m_features;
    int m_apiLevel;
    std::string m_archName;
    std::vector<std::string> m_warnings;
    
    // 初始化特性
    void initializeFeatures();
    
    // 获取系统属性
    static std::string getSystemProperty(const std::string& key);
    
    // 检查文件是否存在
    static bool fileExists(const std::string& path);
    
    // 添加警告
    void addWarning(const std::string& warning);
};

} // namespace ArkVMP

#endif // VERSION_ADAPTER_H