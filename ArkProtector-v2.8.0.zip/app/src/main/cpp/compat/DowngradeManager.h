#ifndef ARK_COMPAT_DOWNGRADE_MANAGER_H
#define ARK_COMPAT_DOWNGRADE_MANAGER_H

#include <atomic>
#include <chrono>
#include <string>
#include <thread>
#include <mutex>
#include <vector>

namespace ark {
namespace compat {

/**
 * 保护等级定义
 */
enum class ProtectionLevel {
    LEVEL_FULL = 0,       // 完整保护：所有功能开启
    LEVEL_HIGH = 1,       // 高级保护：关闭部分耗时功能
    LEVEL_MEDIUM = 2,     // 中等保护：关闭VMP JIT
    LEVEL_LOW = 3,        // 基础保护：关闭反调试
    LEVEL_MINIMAL = 4,    // 最小保护：仅保留基础加密
    LEVEL_NONE = 5        // 无保护：应急模式
};

/**
 * 降级原因
 */
enum class DowngradeReason {
    REASON_NONE,
    REASON_CRASH,         // 连续崩溃
    REASON_HANG,          // 连续卡顿
    REASON_PERFORMANCE,   // 性能低下
    REASON_INCOMPATIBLE,  // 不兼容
    REASON_USER_REQUEST,  // 用户请求
    REASON_EMERGENCY      // 应急模式
};

/**
 * 性能指标
 */
struct PerformanceMetrics {
    uint64_t startTime;           // 启动开始时间
    uint64_t endTime;             // 启动结束时间
    uint64_t vmpExecTime;         // VMP执行时间
    uint64_t methodCount;         // 方法调用次数
    uint64_t avgMethodTime;       // 平均方法执行时间
    uint32_t memoryUsage;         // 内存使用量（MB）
    uint32_t cpuUsage;            // CPU使用率（%）
    bool isPerformanceLow;        // 是否性能低下
};

/**
 * 降级管理器
 * 
 * 功能：
 * 1. 监控应用运行状态（崩溃、卡顿、性能）
 * 2. 根据运行情况自动降级保护等级
 * 3. 支持手动降级和应急模式
 * 4. 提供降级原因记录和查询
 */
class DowngradeManager {
public:
    static DowngradeManager& getInstance();
    
    // 初始化
    void initialize();
    
    // 获取当前保护等级
    ProtectionLevel getCurrentLevel();
    
    // 记录崩溃
    void recordCrash(const std::string& reason = "");
    
    // 记录卡顿
    void recordHang(uint64_t hangDurationMs);
    
    // 记录性能指标
    void recordPerformance(const PerformanceMetrics& metrics);
    
    // 检查是否需要降级
    bool shouldDowngrade();
    
    // 执行降级
    void performDowngrade(DowngradeReason reason);
    
    // 手动设置保护等级
    void setLevel(ProtectionLevel level, DowngradeReason reason);
    
    // 检查应急模式
    bool isEmergencyMode();
    
    // 获取降级历史
    std::string getDowngradeHistory();
    
    // 重置降级状态
    void reset();
    
    // 启动监控
    void startMonitoring();
    
    // 停止监控
    void stopMonitoring();

private:
    DowngradeManager();
    ~DowngradeManager();
    
    // 禁止拷贝
    DowngradeManager(const DowngradeManager&) = delete;
    DowngradeManager& operator=(const DowngradeManager&) = delete;
    
    // 降级到下一级
    void downgradeToNextLevel(DowngradeReason reason);
    
    // 应用保护等级
    void applyProtectionLevel(ProtectionLevel level);
    
    // 检查性能是否低下
    bool isPerformanceLow();
    
    // 检查是否需要降级
    bool checkDowngradeNeeded();
    
    // 记录降级事件
    void logDowngradeEvent(ProtectionLevel from, ProtectionLevel to, 
                          DowngradeReason reason);
    
    // 检查应急模式触发条件
    bool checkEmergencyMode();
    
    // 清理崩溃计数
    void clearCrashCount();
    
    // 清理卡顿计数
    void clearHangCount();
    
    // 监控线程
    void monitoringThread();
    
    // 获取当前时间（纳秒）
    uint64_t getCurrentTimeNs();
    
    // 获取当前时间（毫秒）
    uint64_t getCurrentTimeMs();

private:
    // 当前保护等级
    std::atomic<ProtectionLevel> m_currentLevel;
    
    // 崩溃计数（原子操作）
    std::atomic<int> m_crashCount;
    std::atomic<int> m_crashCountInWindow;
    
    // 卡顿计数
    std::atomic<int> m_hangCount;
    std::atomic<int> m_hangCountInWindow;
    
    // 性能指标
    PerformanceMetrics m_lastMetrics;
    std::mutex m_metricsMutex;
    
    // 监控线程
    std::thread m_monitorThread;
    std::atomic<bool> m_monitoringRunning;
    
    // 降级历史
    struct DowngradeEvent {
        ProtectionLevel from;
        ProtectionLevel to;
        DowngradeReason reason;
        uint64_t timestamp;
        std::string detail;
    };
    std::vector<DowngradeEvent> m_downgradeHistory;
    std::mutex m_historyMutex;
    
    // 时间窗口（秒）
    static constexpr int CRASH_WINDOW = 300;  // 5分钟内的崩溃
    static constexpr int HANG_WINDOW = 60;    // 1分钟内的卡顿
    
    // 降级阈值
    static constexpr int CRASH_THRESHOLD = 3;   // 连续3次崩溃触发降级
    static constexpr int HANG_THRESHOLD = 2;    // 连续2次卡顿触发降级
    static constexpr uint64_t MAX_STARTUP_TIME = 10 * 1000;  // 最大启动时间10秒
    static constexpr uint64_t MAX_VMP_TIME_RATIO = 20;       // VMP时间占比最大5%
    
    // 标志
    bool m_initialized;
    bool m_emergencyMode;
};

} // namespace compat
} // namespace ark

#endif // ARK_COMPAT_DOWNGRADE_MANAGER_H