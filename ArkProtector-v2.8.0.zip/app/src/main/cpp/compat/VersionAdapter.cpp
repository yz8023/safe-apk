#include "VersionAdapter.h"
#include <cstring>
#include <vector>
#include <unistd.h>
#include <sys/system_properties.h>

namespace ArkVMP {

VersionAdapter::VersionAdapter() {
    m_apiLevel = getAndroidApiLevel();
    m_archName = getArchName();
    
    initializeFeatures();
    
    LOGI("VersionAdapter初始化完成，API级别=%d, 架构=%s", m_apiLevel, m_archName.c_str());
}

VersionAdapter::~VersionAdapter() {
}

ApiFeatures VersionAdapter::getFeatures() {
    return m_features;
}

int VersionAdapter::getAndroidApiLevel() {
    return android_get_device_api_level();
}

bool VersionAdapter::isArtRuntime() {
    // 检测ART还是Dalvik
    char runtime[PROP_VALUE_MAX];
    
    if (__system_property_get("persist.sys.dalvik.vm.lib", runtime) > 0) {
        return strstr(runtime, "art") != nullptr;
    }
    
    // 默认返回true（现代Android都是ART）
    return true;
}

bool VersionAdapter::is64Bit() {
#if defined(__aarch64__) || defined(__x86_64__)
    return true;
#else
    return false;
#endif
}

std::string VersionAdapter::getArchName() {
#if defined(__aarch64__)
    return "arm64";
#elif defined(__arm__)
    return "arm";
#elif defined(__x86_64__)
    return "x86_64";
#elif defined(__i386__)
    return "x86";
#else
    return "unknown";
#endif
}

std::string VersionAdapter::getDeviceInfo() {
    char buffer[256];
    std::string info;
    
    // 获取设备品牌
    if (__system_property_get("ro.product.brand", buffer) > 0) {
        info += "品牌: " + std::string(buffer) + ", ";
    }
    
    // 获取设备型号
    if (__system_property_get("ro.product.model", buffer) > 0) {
        info += "型号: " + std::string(buffer) + ", ";
    }
    
    // 获取Android版本
    if (__system_property_get("ro.build.version.release", buffer) > 0) {
        info += "Android: " + std::string(buffer);
    }
    
    return info;
}

bool VersionAdapter::supportsFeature(const std::string& feature) {
    if (feature == "InMemoryDexLoader") {
        return m_features.supportInMemoryDexLoader;
    } else if (feature == "NativeBridge") {
        return m_features.supportNativeBridge;
    } else if (feature == "JNI_1_6") {
        return m_features.supportJNI_1_6;
    } else if (feature == "FridaDetection") {
        return m_features.supportFridaDetection;
    } else if (feature == "MemoryProtect") {
        return m_features.supportMemoryProtect;
    } else if (feature == "OreoFeatures") {
        return m_features.supportOreoFeatures;
    } else if (feature == "PieFeatures") {
        return m_features.supportPieFeatures;
    } else if (feature == "QFeatures") {
        return m_features.supportQFeatures;
    } else if (feature == "RFeatures") {
        return m_features.supportRFeatures;
    } else if (feature == "SFeatures") {
        return m_features.supportSFeatures;
    }
    
    return false;
}

std::string VersionAdapter::getRecommendedConfig() {
    std::string config;
    
    config += "API级别: " + std::to_string(m_apiLevel) + "\n";
    config += "架构: " + m_archName + "\n";
    config += "运行时: " + std::string(isArtRuntime() ? "ART" : "Dalvik") + "\n";
    config += "位数: " + std::string(is64Bit() ? "64位" : "32位") + "\n\n";
    
    config += "推荐配置:\n";
    
    if (m_apiLevel >= 26) {
        config += "- 启用内存DEX加载\n";
    } else {
        config += "- 使用传统DEX加载\n";
    }
    
    if (m_apiLevel >= 23) {
        config += "- 启用完整反调试\n";
    } else {
        config += "- 使用基础反调试\n";
    }
    
    if (m_features.supportMemoryProtect) {
        config += "- 启用内存保护\n";
    }
    
    if (is64Bit()) {
        config += "- 启用64位优化\n";
    }
    
    return config;
}

bool VersionAdapter::checkCompatibility() {
    bool compatible = true;
    
    // 检查最低API级别
    if (m_apiLevel < 21) {
        addWarning("API级别过低 (< 21)，部分功能可能不可用");
        compatible = false;
    }
    
    // 检查架构支持
    if (m_archName == "unknown") {
        addWarning("未知架构，可能存在兼容性问题");
        compatible = false;
    }
    
    // 检查运行时
    if (!isArtRuntime()) {
        addWarning("检测到Dalvik运行时，性能可能受影响");
    }
    
    // 检查特定版本的已知问题
    if (m_apiLevel == 23) {
        addWarning("Android 6.0存在已知兼容性问题，建议升级");
    }
    
    if (m_apiLevel >= 30) {
        addWarning("Android 11+需要额外的权限配置");
    }
    
    return compatible;
}

std::vector<std::string> VersionAdapter::getCompatibilityWarnings() {
    return m_warnings;
}

void VersionAdapter::initializeFeatures() {
    // 根据API级别初始化特性
    m_features.supportInMemoryDexLoader = (m_apiLevel >= 26);
    m_features.supportNativeBridge = (m_apiLevel >= 24);
    m_features.supportJNI_1_6 = (m_apiLevel >= 21);
    m_features.supportFridaDetection = (m_apiLevel >= 23);
    m_features.supportMemoryProtect = (m_apiLevel >= 21);
    m_features.supportOreoFeatures = (m_apiLevel >= 26);
    m_features.supportPieFeatures = (m_apiLevel >= 28);
    m_features.supportQFeatures = (m_apiLevel >= 29);
    m_features.supportRFeatures = (m_apiLevel >= 30);
    m_features.supportSFeatures = (m_apiLevel >= 31);
    
    LOGI("API特性初始化完成");
}

std::string VersionAdapter::getSystemProperty(const std::string& key) {
    char value[PROP_VALUE_MAX];
    
    if (__system_property_get(key.c_str(), value) > 0) {
        return std::string(value);
    }
    
    return "";
}

bool VersionAdapter::fileExists(const std::string& path) {
    return access(path.c_str(), F_OK) == 0;
}

void VersionAdapter::addWarning(const std::string& warning) {
    m_warnings.push_back(warning);
    LOGW("兼容性警告: %s", warning.c_str());
}

} // namespace ArkVMP