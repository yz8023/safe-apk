#include "DowngradeManager.h"
#include "../log/SecureLogger.h"
#include "../monitor/PerformanceMonitor.h"
#include <algorithm>
#include <sstream>
#include <cstring>
#include <vector>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>

namespace ark {
namespace compat {

// 单例实例
DowngradeManager& DowngradeManager::getInstance() {
    static DowngradeManager instance;
    return instance;
}

DowngradeManager::DowngradeManager()
    : m_currentLevel(ProtectionLevel::LEVEL_FULL)
    , m_crashCount(0)
    , m_crashCountInWindow(0)
    , m_hangCount(0)
    , m_hangCountInWindow(0)
    , m_monitoringRunning(false)
    , m_initialized(false)
    , m_emergencyMode(false)
{
    memset(&m_lastMetrics, 0, sizeof(m_lastMetrics));
}

DowngradeManager::~DowngradeManager() {
    stopMonitoring();
}

void DowngradeManager::initialize() {
    if (m_initialized) {
        return;
    }
    
    // 检查应急模式
    if (checkEmergencyMode()) {
        m_emergencyMode = true;
        m_currentLevel = ProtectionLevel::LEVEL_NONE;
        LOGW("DowngradeManager", "降级管理器：检测到应急模式，所有保护已关闭");
    }
    
    // 启动监控
    startMonitoring();
    
    m_initialized = true;
    LOGI("DowngradeManager", "降级管理器：初始化完成，当前保护等级=%d", static_cast<int>(m_currentLevel.load()));
}

ProtectionLevel DowngradeManager::getCurrentLevel() {
    return m_currentLevel.load();
}

void DowngradeManager::recordCrash(const std::string& reason) {
    int crashCount = ++m_crashCount;
    int crashCountInWindow = ++m_crashCountInWindow;
    
    LOGW("DowngradeManager", "降级管理器：记录崩溃，总数=%d，窗口内=%d，原因=%s",
         crashCount, crashCountInWindow, reason.c_str());
    
    // 检查是否需要降级
    if (shouldDowngrade()) {
        performDowngrade(DowngradeReason::REASON_CRASH);
    }
}

void DowngradeManager::recordHang(uint64_t hangDurationMs) {
    int hangCount = ++m_hangCount;
    int hangCountInWindow = ++m_hangCountInWindow;
    
    LOGW("DowngradeManager", "降级管理器：记录卡顿，持续时间=%llums，总数=%d，窗口内=%d",
         hangDurationMs, hangCount, hangCountInWindow);
    
    // 检查是否需要降级
    if (shouldDowngrade()) {
        performDowngrade(DowngradeReason::REASON_HANG);
    }
}

void DowngradeManager::recordPerformance(const PerformanceMetrics& metrics) {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    m_lastMetrics = metrics;
    
    // 检查性能是否低下
    if (metrics.isPerformanceLow) {
        LOGW("DowngradeManager", "降级管理器：检测到性能低下，启动时间=%llums，VMP时间=%llums，内存=%uMB",
                 (metrics.endTime - metrics.startTime) / 1000000,
             metrics.vmpExecTime / 1000000,
             metrics.memoryUsage);
        
        if (shouldDowngrade()) {
            performDowngrade(DowngradeReason::REASON_PERFORMANCE);
        }
    }
}

bool DowngradeManager::shouldDowngrade() {
    if (m_emergencyMode) {
        return false;  // 应急模式下不再降级
    }
    
    return checkDowngradeNeeded();
}

void DowngradeManager::performDowngrade(DowngradeReason reason) {
    ProtectionLevel currentLevel = m_currentLevel.load();
    
    // 如果已经是最低级，不再降级
    if (currentLevel == ProtectionLevel::LEVEL_NONE) {
        LOGW("DowngradeManager", "降级管理器：已处于最低保护等级，不再降级");
        return;
    }
    
    // 降级到下一级
    downgradeToNextLevel(reason);
}

void DowngradeManager::setLevel(ProtectionLevel level, DowngradeReason reason) {
    ProtectionLevel currentLevel = m_currentLevel.load();
    
    if (currentLevel == level) {
        return;
    }
    
    LOGI("DowngradeManager", "降级管理器：手动设置保护等级，从%d到%d，原因=%d",
         static_cast<int>(currentLevel), static_cast<int>(level), static_cast<int>(reason));
    
    logDowngradeEvent(currentLevel, level, reason);
    applyProtectionLevel(level);
    m_currentLevel = level;
    
    // 清理计数
    clearCrashCount();
    clearHangCount();
}

bool DowngradeManager::isEmergencyMode() {
    return m_emergencyMode;
}

std::string DowngradeManager::getDowngradeHistory() {
    std::lock_guard<std::mutex> lock(m_historyMutex);
    
    std::ostringstream oss;
    oss << "降级历史记录：\n";
    oss << "====================\n";
    
    for (const auto& event : m_downgradeHistory) {
        oss << "时间: " << event.timestamp << "\n";
        oss << "从: " << static_cast<int>(event.from) << " -> ";
        oss << "到: " << static_cast<int>(event.to) << "\n";
        oss << "原因: " << static_cast<int>(event.reason) << "\n";
        oss << "详情: " << event.detail << "\n";
        oss << "--------------------\n";
    }
    
    return oss.str();
}

void DowngradeManager::reset() {
    LOGI("DowngradeManager", "降级管理器：重置降级状态");
    
    m_crashCount = 0;
    m_crashCountInWindow = 0;
    m_hangCount = 0;
    m_hangCountInWindow = 0;
    m_currentLevel = ProtectionLevel::LEVEL_FULL;
    
    {
        std::lock_guard<std::mutex> lock(m_historyMutex);
        m_downgradeHistory.clear();
    }
    
    applyProtectionLevel(ProtectionLevel::LEVEL_FULL);
}

void DowngradeManager::startMonitoring() {
    if (m_monitoringRunning) {
        return;
    }
    
    m_monitoringRunning = true;
    m_monitorThread = std::thread(&DowngradeManager::monitoringThread, this);
    
    LOGI("DowngradeManager", "降级管理器：启动监控线程");
}

void DowngradeManager::stopMonitoring() {
    if (!m_monitoringRunning) {
        return;
    }
    
    m_monitoringRunning = false;
    
    if (m_monitorThread.joinable()) {
        m_monitorThread.join();
    }
    
    LOGI("DowngradeManager", "降级管理器：停止监控线程");
}

void DowngradeManager::downgradeToNextLevel(DowngradeReason reason) {
    ProtectionLevel currentLevel = m_currentLevel.load();
    ProtectionLevel newLevel;
    
    // 根据当前等级决定降级目标
    switch (currentLevel) {
        case ProtectionLevel::LEVEL_FULL:
            newLevel = ProtectionLevel::LEVEL_HIGH;
            break;
        case ProtectionLevel::LEVEL_HIGH:
            newLevel = ProtectionLevel::LEVEL_MEDIUM;
            break;
        case ProtectionLevel::LEVEL_MEDIUM:
            newLevel = ProtectionLevel::LEVEL_LOW;
            break;
        case ProtectionLevel::LEVEL_LOW:
            newLevel = ProtectionLevel::LEVEL_MINIMAL;
            break;
        case ProtectionLevel::LEVEL_MINIMAL:
            newLevel = ProtectionLevel::LEVEL_NONE;
            break;
        case ProtectionLevel::LEVEL_NONE:
            return;  // 已经是最低级
    }
    
    LOGW("DowngradeManager", "降级管理器：自动降级，从%d到%d，原因=%d",
         static_cast<int>(currentLevel), static_cast<int>(newLevel), static_cast<int>(reason));
    
    logDowngradeEvent(currentLevel, newLevel, reason);
    applyProtectionLevel(newLevel);
    m_currentLevel = newLevel;
    
    // 清理计数
    clearCrashCount();
    clearHangCount();
}

void DowngradeManager::applyProtectionLevel(ProtectionLevel level) {
    // 根据保护等级应用不同的保护策略
    // 这里通过设置全局变量或调用其他模块的接口来实现
    
    LOGI("DowngradeManager", "降级管理器：应用保护等级=%d", static_cast<int>(level));
    
    switch (level) {
        case ProtectionLevel::LEVEL_FULL:
            // 完整保护：所有功能开启
            // TODO: 启用所有保护功能
            break;
            
        case ProtectionLevel::LEVEL_HIGH:
            // 高级保护：关闭部分耗时功能
            // TODO: 关闭JIT编译等耗时功能
            break;
            
        case ProtectionLevel::LEVEL_MEDIUM:
            // 中等保护：关闭VMP JIT
            // TODO: 关闭VMP JIT编译
            break;
            
        case ProtectionLevel::LEVEL_LOW:
            // 基础保护：关闭反调试
            // TODO: 关闭反调试功能
            break;
            
        case ProtectionLevel::LEVEL_MINIMAL:
            // 最小保护：仅保留基础加密
            // TODO: 仅保留基础加密功能
            break;
            
        case ProtectionLevel::LEVEL_NONE:
            // 无保护：应急模式
            // TODO: 关闭所有保护功能
            LOGW("DowngradeManager", "降级管理器：进入应急模式，所有保护已关闭");
            break;
    }
}

bool DowngradeManager::isPerformanceLow() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    
    // 检查启动时间
    if (m_lastMetrics.startTime > 0 && m_lastMetrics.endTime > 0) {
        uint64_t startupTime = (m_lastMetrics.endTime - m_lastMetrics.startTime) / 1000000;
        if (startupTime > MAX_STARTUP_TIME) {
            LOGW("DowngradeManager", "降级管理器：启动时间过长=%llums，超过阈值=%llums", 
                 startupTime, MAX_STARTUP_TIME);
            return true;
        }
    }
    
    // 检查VMP执行时间占比
    if (m_lastMetrics.startTime > 0 && m_lastMetrics.endTime > 0) {
        uint64_t totalTime = m_lastMetrics.endTime - m_lastMetrics.startTime;
        if (totalTime > 0 && m_lastMetrics.vmpExecTime > 0) {
            uint64_t ratio = (m_lastMetrics.vmpExecTime * 100) / totalTime;
            if (ratio > (100 / MAX_VMP_TIME_RATIO)) {
                LOGW("DowngradeManager", "降级管理器：VMP执行时间占比过高=%llu%%，超过阈值=%llu%%",
                     ratio, 100 / MAX_VMP_TIME_RATIO);
                return true;
            }
        }
    }
    
    // 检查内存使用
    if (m_lastMetrics.memoryUsage > 100) {  // 超过100MB
        LOGW("DowngradeManager", "降级管理器：内存使用过高=%uMB", m_lastMetrics.memoryUsage);
        return true;
    }
    
    return false;
}

bool DowngradeManager::checkDowngradeNeeded() {
    // 检查崩溃计数
    if (m_crashCountInWindow >= CRASH_THRESHOLD) {
        LOGW("DowngradeManager", "降级管理器：窗口内崩溃次数=%d，超过阈值=%d",
             m_crashCountInWindow.load(), CRASH_THRESHOLD);
        return true;
    }
    
    // 检查卡顿计数
    if (m_hangCountInWindow >= HANG_THRESHOLD) {
        LOGW("DowngradeManager", "降级管理器：窗口内卡顿次数=%d，超过阈值=%d",
             m_hangCountInWindow.load(), HANG_THRESHOLD);
        return true;
    }
    
    // 检查性能
    if (isPerformanceLow()) {
        return true;
    }
    
    return false;
}

void DowngradeManager::logDowngradeEvent(ProtectionLevel from, ProtectionLevel to, 
                                         DowngradeReason reason) {
    std::lock_guard<std::mutex> lock(m_historyMutex);
    
    DowngradeEvent event;
    event.from = from;
    event.to = to;
    event.reason = reason;
    event.timestamp = getCurrentTimeNs();
    
    // 生成详情
    std::ostringstream oss;
    oss << "崩溃次数: " << m_crashCount.load() << ", ";
    oss << "卡顿次数: " << m_hangCount.load();
    event.detail = oss.str();
    
    m_downgradeHistory.push_back(event);
    
    // 限制历史记录数量
    if (m_downgradeHistory.size() > 100) {
        m_downgradeHistory.erase(m_downgradeHistory.begin());
    }
}

bool DowngradeManager::checkEmergencyMode() {
    // 检查应急文件
    const char* emergencyFiles[] = {
        "/sdcard/.ark_emergency",
        "/data/local/tmp/.ark_emergency",
        "/storage/emulated/0/.ark_emergency"
    };
    
    for (const char* filePath : emergencyFiles) {
        if (access(filePath, F_OK) == 0) {
            LOGW("DowngradeManager", "降级管理器：检测到应急文件=%s", filePath);
            return true;
        }
    }
    
    // 检查系统属性（需要通过JNI调用）
    // TODO: 通过JNI获取系统属性 "ark.emergency"
    
    return false;
}

void DowngradeManager::clearCrashCount() {
    m_crashCountInWindow = 0;
    LOGI("DowngradeManager", "降级管理器：清理崩溃计数");
}

void DowngradeManager::clearHangCount() {
    m_hangCountInWindow = 0;
    LOGI("DowngradeManager", "降级管理器：清理卡顿计数");
}

void DowngradeManager::monitoringThread() {
    uint64_t lastWindowReset = getCurrentTimeNs();
    
    while (m_monitoringRunning) {
        // 检查是否需要降级
        if (shouldDowngrade()) {
            performDowngrade(DowngradeReason::REASON_PERFORMANCE);
        }
        
        // 定期清理窗口计数
        uint64_t currentTime = getCurrentTimeNs();
        uint64_t windowDuration = (currentTime - lastWindowReset) / 1000000000;  // 转换为秒
        
        if (windowDuration >= CRASH_WINDOW) {
            // 清理崩溃窗口计数
            if (m_crashCountInWindow > 0) {
                LOGI("DowngradeManager", "降级管理器：清理崩溃窗口计数，当前=%d", m_crashCountInWindow.load());
                clearCrashCount();
            }
            lastWindowReset = currentTime;
        }
        
        // 睡眠一段时间
        std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    }
}

uint64_t DowngradeManager::getCurrentTimeNs() {
    auto now = std::chrono::steady_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::nanoseconds>(duration).count();
}

uint64_t DowngradeManager::getCurrentTimeMs() {
    return getCurrentTimeNs() / 1000000;
}

} // namespace compat
} // namespace ark