#ifndef WHITEBOX_DECRYPT_H
#define WHITEBOX_DECRYPT_H

#include <cstdint>
#include <cstring>
#include <android/log.h>

#define LOG_TAG "ArkVMP_WhiteBox"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

class WhiteBoxDecrypt {
public:
    // 白盒查表大小
    static const int TABLE_SIZE = 256;
    static const int ROUND_COUNT = 10;
    
    // 通过白盒查表获取密钥
    static void getKeyFromWhiteBox(unsigned char* outKey, int keyIndex);
    
    // AES-256-CBC解密
    static bool decryptVmpData(
        const unsigned char* ciphertext,
        size_t cipherLen,
        const unsigned char* key,
        unsigned char* plaintext
    );
    
    // 初始化白盒表
    static void initialize();
    
private:
    // 白盒查表 - 将AES密钥隐藏在256x256的表中
    static const unsigned char whitebox_table[ROUND_COUNT][TABLE_SIZE][TABLE_SIZE];
    
    // 混合函数
    static unsigned char mixBytes(unsigned char a, unsigned char b, unsigned char c);
    
    // S盒替换（简化版）
    static unsigned char sBox(unsigned char input);
};

} // namespace ArkVMP

#endif // WHITEBOX_DECRYPT_H