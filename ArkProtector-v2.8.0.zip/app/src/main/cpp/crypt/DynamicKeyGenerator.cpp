#include "DynamicKeyGenerator.h"
#include "WhiteBoxDecrypt.h"

namespace ArkVMP {

void DynamicKeyGenerator::generateKey(VmContext* ctx, unsigned char* outKey) {
    if (ctx == nullptr || outKey == nullptr) {
        LOGE("参数为空");
        return;
    }
    
    // 组合多个运行时信息
    uint64_t values[16];
    int index = 0;
    
    // 上下文信息
    values[index++] = reinterpret_cast<uint64_t>(ctx);
    values[index++] = reinterpret_cast<uint64_t>(ctx->env);
    values[index++] = reinterpret_cast<uint64_t>(ctx->method);
    values[index++] = reinterpret_cast<uint64_t>(ctx->thiz);
    
    // 方法信息
    if (ctx->method != nullptr) {
        values[index++] = static_cast<uint64_t>(ctx->method->methodId);
        values[index++] = static_cast<uint64_t>(ctx->method->registerCount);
        values[index++] = static_cast<uint64_t>(ctx->method->instructions.size());
    }
    
    // 执行状态
        values[index++] = static_cast<uint64_t>(ctx->pc);
        values[index++] = static_cast<uint64_t>(ctx->running);
    
        // 寄存器信息
        if (!ctx->regs.empty()) {
            values[index++] = static_cast<uint64_t>(ctx->regs.size());
            values[index++] = reinterpret_cast<uint64_t>(ctx->regs.data());
        }
    
        // 时间和线程信息
        values[index++] = getCurrentTime();
        values[index++] = getThreadId();
        values[index++] = getProcessId();
    
    // 生成基础密钥
    mixValues(values, index, outKey);
    
    // 与白盒密钥混合
    int keyIndex = ctx->method ? ctx->method->methodId % 10 : 0;
    mixWithWhiteBox(outKey, keyIndex);
    
    LOGI("动态密钥生成完成，methodId=%d", ctx->method ? ctx->method->methodId : -1);
}

void DynamicKeyGenerator::generateMethodKey(int methodId, unsigned char* outKey) {
    if (outKey == nullptr) {
        return;
    }
    
    // 基于方法ID生成密钥
    uint64_t values[8];
    
    values[0] = static_cast<uint64_t>(methodId);
    values[1] = getCurrentTime();
    values[2] = getThreadId();
    values[3] = getProcessId();
    values[4] = reinterpret_cast<uint64_t>(outKey);
    values[5] = static_cast<uint64_t>(pthread_self());
    values[6] = methodId * 0x9E3779B9;
    values[7] = methodId * 0x85EBCA77;
    
    // 生成基础密钥
    mixValues(values, 8, outKey);
    
    // 与白盒密钥混合
    int keyIndex = methodId % 10;
    mixWithWhiteBox(outKey, keyIndex);
}

void DynamicKeyGenerator::generateContextKey(VmContext* ctx, unsigned char* outKey) {
    if (ctx == nullptr || outKey == nullptr) {
        return;
    }
    
    // 基于上下文生成密钥
    uint64_t values[12];
    int index = 0;
    
    // 上下文基本信息
    values[index++] = reinterpret_cast<uint64_t>(ctx);
    values[index++] = reinterpret_cast<uint64_t>(ctx->env);
    values[index++] = getCurrentTime();
    values[index++] = getThreadId();
    
    // 执行状态
        values[index++] = static_cast<uint64_t>(ctx->pc);
        values[index++] = static_cast<uint64_t>(ctx->running);
    
    // 寄存器状态
    if (!ctx->regs.empty()) {
        values[index++] = static_cast<uint64_t>(ctx->regs.size());
        // 混合部分寄存器值
        for (size_t i = 0; i < std::min(size_t(4), ctx->regs.size()); i++) {
            values[index++] = static_cast<uint64_t>(ctx->regs[i].intValue);
        }
    }
    
    // 生成基础密钥
    mixValues(values, index, outKey);
    
    // 与白盒密钥混合
    int keyIndex = (ctx->pc ^ static_cast<int>(getThreadId())) % 10;
    mixWithWhiteBox(outKey, keyIndex);
}

uint64_t DynamicKeyGenerator::getCurrentTime() {
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    return static_cast<uint64_t>(tv.tv_sec) * 1000000ULL + tv.tv_usec;
}

uint64_t DynamicKeyGenerator::getThreadId() {
    return static_cast<uint64_t>(pthread_self());
}

uint32_t DynamicKeyGenerator::getProcessId() {
    return static_cast<uint32_t>(getpid());
}

void DynamicKeyGenerator::sha256Hash(const unsigned char* data, size_t len, unsigned char* hash) {
    // 简化的SHA256实现（避免OpenSSL依赖）
    memset(hash, 0, 32);
    
    for (size_t i = 0; i < len && i < 32; i++) {
        hash[i % 32] ^= data[i];
    }
    
    // 简单的混淆
    for (int i = 0; i < 32; i++) {
        hash[i] = (hash[i] ^ (i * 7)) & 0xFF;
    }
}

void DynamicKeyGenerator::mixValues(const uint64_t* values, size_t count, unsigned char* out) {
    if (values == nullptr || count == 0 || out == nullptr) {
        return;
    }

    // 修复：限制count大小，避免栈溢出
    if (count > 16) {
        count = 16;
    }

    // 将所有值转换为字节数组
    unsigned char buffer[sizeof(uint64_t) * 16]; // 固定最大缓冲区
    for (size_t i = 0; i < count; i++) {
        uint64_t value = values[i];
        buffer[i * 8] = value & 0xFF;
        buffer[i * 8 + 1] = (value >> 8) & 0xFF;
        buffer[i * 8 + 2] = (value >> 16) & 0xFF;
        buffer[i * 8 + 3] = (value >> 24) & 0xFF;
        buffer[i * 8 + 4] = (value >> 32) & 0xFF;
        buffer[i * 8 + 5] = (value >> 40) & 0xFF;
        buffer[i * 8 + 6] = (value >> 48) & 0xFF;
        buffer[i * 8 + 7] = (value >> 56) & 0xFF;
    }

    // 使用SHA-256生成32字节密钥
    sha256Hash(buffer, sizeof(uint64_t) * count, out);

    // 额外的混淆轮次
    for (int round = 0; round < 3; round++) {
        unsigned char temp[32];
        memcpy(temp, out, 32);

        for (int i = 0; i < 32; i++) {
            out[i] ^= temp[(i + 13) & 0x1F];
            out[i] = (out[i] << 3) | (out[i] >> 5);
        }
    }
}

void DynamicKeyGenerator::mixWithWhiteBox(unsigned char* key, int keyIndex) {
    // 修复：限制keyIndex在有效范围内
    if (keyIndex < 0 || keyIndex > 9) {
        keyIndex = 0;
    }

    // 从白盒获取密钥
    unsigned char whiteboxKey[32];
    WhiteBoxDecrypt::getKeyFromWhiteBox(whiteboxKey, keyIndex);

    // 混合两个密钥
    for (int i = 0; i < 32; i++) {
        key[i] ^= whiteboxKey[i];
        key[i] = (key[i] + whiteboxKey[i]) & 0xFF;
    }

    // 应用额外的混淆
    for (int round = 0; round < 2; round++) {
        unsigned char temp[32];
        memcpy(temp, key, 32);

        for (int i = 0; i < 32; i++) {
            key[i] ^= temp[(i + 7) & 0x1F];
            key[i] = (key[i] >> 2) | (key[i] << 6);
        }
    }
}

} // namespace ArkVMP