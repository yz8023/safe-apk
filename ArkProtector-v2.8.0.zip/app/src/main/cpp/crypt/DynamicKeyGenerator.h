#ifndef DYNAMIC_KEY_GENERATOR_H
#define DYNAMIC_KEY_GENERATOR_H

#include <cstdint>
#include <cstring>
#include "../VmContext.h"
#include "WhiteBoxDecrypt.h"
#include <android/log.h>
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>

#define LOG_TAG "ArkVMP_DynamicKey"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

class DynamicKeyGenerator {
public:
    // 生成动态密钥
    static void generateKey(VmContext* ctx, unsigned char* outKey);
    
    // 生成基于方法的密钥
    static void generateMethodKey(int methodId, unsigned char* outKey);
    
    // 生成基于上下文的密钥
    static void generateContextKey(VmContext* ctx, unsigned char* outKey);
    
private:
    // 获取当前时间戳
    static uint64_t getCurrentTime();
    
    // 获取线程ID
    static uint64_t getThreadId();
    
    // 获取进程ID
    static uint32_t getProcessId();
    
    // SHA-256哈希
    static void sha256Hash(const unsigned char* data, size_t len, unsigned char* hash);
    
    // 混合多个值
    static void mixValues(const uint64_t* values, size_t count, unsigned char* out);
    
    // 添加白盒密钥混合
    static void mixWithWhiteBox(unsigned char* key, int keyIndex);
};

} // namespace ArkVMP

#endif // DYNAMIC_KEY_GENERATOR_H