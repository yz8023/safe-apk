#include "ArkVMP.h"
#include "VmpRuntime.h"

#include <string>
#include <android/log.h>

#define LOG_TAG "ArkVMP_ArkVMP"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C"
__attribute__((used))
__attribute__((visibility("default")))
__attribute__((section(".ArkProtector_MaintainedBy_Forinxy_OpenSourceLearning")))
const char g_ark_vmp_section[] = "ArkProtector";

extern "C"
__attribute__((used))
__attribute__((visibility("default")))
const void *ArkVmpKeepCustomSection() {
    return g_ark_vmp_section;
}


static JavaVM *g_vm = nullptr;

extern "C" void ArkVMP_SetContext(JNIEnv *env, jobject context) {
    VmpRuntime_SetContext(env, context);
}

static std::string jstringToString(JNIEnv *env, jstring str) {
    if (str == nullptr) {
        return "";
    }

    const char *chars = env->GetStringUTFChars(str, nullptr);
    if (chars == nullptr) {
        return "";
    }

    std::string result(chars);
    env->ReleaseStringUTFChars(str, chars);

    return result;
}

static void dotToSlash(std::string &name) {
    for (size_t i = 0; i < name.length(); i++) {
        if (name[i] == '.') {
            name[i] = '/';
        }
    }
}

static std::string getStubClassNameFromProperty(JNIEnv *env) {
    jclass clsSystem = env->FindClass("java/lang/System");
    if (clsSystem == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jmethodID midGetProperty = env->GetStaticMethodID(
            clsSystem,
            "getProperty",
            "(Ljava/lang/String;)Ljava/lang/String;"
    );

    if (midGetProperty == nullptr) {
        env->ExceptionClear();
        return "";
    }

    jstring key = env->NewStringUTF("_cls_ref");

    jstring value = (jstring) env->CallStaticObjectMethod(
            clsSystem,
            midGetProperty,
            key
    );

    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return "";
    }

    std::string className = jstringToString(env, value);
    dotToSlash(className);

    return className;
}

static void native_callVoid(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callVoid methodId=%d", methodId);
    VmpRuntime_Execute(env, methodId, thiz, args);
}

static jboolean native_callBoolean(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callBoolean methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).booleanValue;
}

static jbyte native_callByte(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callByte methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).byteValue;
}

static jshort native_callShort(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callShort methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).shortValue;
}

static jchar native_callChar(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callChar methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).charValue;
}

static jint native_callInt(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callInt methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).intValue;
}

static jlong native_callLong(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callLong methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).longValue;
}

static jfloat native_callFloat(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callFloat methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).floatValue;
}

static jdouble native_callDouble(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callDouble methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).doubleValue;
}

static jobject native_callObject(JNIEnv *env, jclass clazz, jint methodId, jobject thiz, jobjectArray args) {
    //LOGI("callObject methodId=%d", methodId);
    return VmpRuntime_Execute(env, methodId, thiz, args).objectValue;
}

static JNINativeMethod g_methods[] = {
        {"callVoid", "(ILjava/lang/Object;[Ljava/lang/Object;)V", (void *) native_callVoid},
        {"callBoolean", "(ILjava/lang/Object;[Ljava/lang/Object;)Z", (void *) native_callBoolean},
        {"callByte", "(ILjava/lang/Object;[Ljava/lang/Object;)B", (void *) native_callByte},
        {"callShort", "(ILjava/lang/Object;[Ljava/lang/Object;)S", (void *) native_callShort},
        {"callChar", "(ILjava/lang/Object;[Ljava/lang/Object;)C", (void *) native_callChar},
        {"callInt", "(ILjava/lang/Object;[Ljava/lang/Object;)I", (void *) native_callInt},
        {"callLong", "(ILjava/lang/Object;[Ljava/lang/Object;)J", (void *) native_callLong},
        {"callFloat", "(ILjava/lang/Object;[Ljava/lang/Object;)F", (void *) native_callFloat},
        {"callDouble", "(ILjava/lang/Object;[Ljava/lang/Object;)D", (void *) native_callDouble},
        {"callObject", "(ILjava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;", (void *) native_callObject}
};

extern "C" jint ArkVMP_OnLoad(JavaVM *vm) {
    g_vm = vm;
    (void) ArkVmpKeepCustomSection();//引用自定义字符串信息防止被编译器优化
    JNIEnv *env = nullptr;
    if (vm->GetEnv((void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        //LOGE("ArkVMP 获取 JNIEnv 失败");
        return JNI_ERR;
    }

    std::string className = getStubClassNameFromProperty(env);
    if (className.empty()) {
        className = "_cls_ref";
    }

    jclass stubClass = env->FindClass(className.c_str());
    if (stubClass == nullptr) {
        env->ExceptionClear();
        //LOGE("找不到VM调用入口类：%s", className.c_str());
        return JNI_ERR;
    }

    //LOGI("ArkVMP 开始注册call方法到目标类：%s", className.c_str());

    int methodCount = sizeof(g_methods) / sizeof(g_methods[0]);

    if (env->RegisterNatives(stubClass, g_methods, methodCount) != JNI_OK) {
        env->ExceptionClear();
        //LOGE("ArkVMP RegisterNatives失败，目标类：%s", className.c_str());
        return JNI_ERR;
    }

    //LOGI("ArkVMP注册成功，目标类：%s", className.c_str());

    return JNI_VERSION_1_6;
}