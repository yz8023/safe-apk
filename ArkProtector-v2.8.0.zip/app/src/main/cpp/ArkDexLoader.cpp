#include "ArkDexLoader.h"

#include <jni.h>
#include <android/log.h>
#include <vector>
#include <string>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/stat.h>
#include "ArkSelfHash.h"

#define LOG_TAG "ArkVMP"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
static const int ARK_BLOCK_TYPE_DEX = 1;
static const int ARK_BLOCK_TYPE_APP = 2;
static const int ARK_BLOCK_TYPE_INDEX = 3;
static const int ARK_BLOCK_TYPE_FACTORY = 4;

static const int ARK_BLOCK_FLAG_RANDOM_KEY = 1;
static const int ARK_BLOCK_FLAG_SIGN_KEY = 2;
struct ArkPayloadFooter {
    size_t payloadOff;
    size_t payloadLen;
    size_t indexOff;
    size_t indexLen;
};
static const unsigned char ARK_BLOCK_USE_SIGN_KEY_FLAG[4] = {
        0x41, 0x52, 0x4B, 0x53 // "ARKS"
};
static uint32_t readLe32(const unsigned char *p) {
    return ((uint32_t) p[0])
           | ((uint32_t) p[1] << 8)
           | ((uint32_t) p[2] << 16)
           | ((uint32_t) p[3] << 24);
}

// 【新增】只记录加密 dex 块信息，不保存明文 dex
struct ArkDexBlockInfo {
    size_t dataOffset;
    size_t plainLen;
    size_t cipherLen;
    unsigned char key[64];
};

static std::vector<unsigned char> xorData(
        const unsigned char *data,
        size_t len,
        const unsigned char *key,
        size_t keyLen) {

    std::vector<unsigned char> out;
    out.resize(len);

    for (size_t i = 0; i < len; i++) {
        out[i] = data[i] ^ key[i % keyLen];
    }

    return out;
}
//索引表结构体
struct ArkPayloadIndexEntry {
    int type;
    int index;
    size_t offset;
    size_t size;
    int flags;
};
//读取 vector 中的 LE32
static bool readLe32FromVector(
        const std::vector<unsigned char> &data,
        size_t &pos,
        uint32_t &out
) {
    if (pos + 4 > data.size()) {
        return false;
    }

    out = readLe32(data.data() + pos);
    pos += 4;
    return true;
}

static void deriveDexKeyFromSignKey64(
        const unsigned char inKey[64],
        unsigned char outKey[64]
) {
    static const unsigned char salt[64] = {
            0x41, 0x72, 0x6B, 0x56, 0x4D, 0x50, 0x23, 0x19,
            0x8A, 0xC3, 0x55, 0x21, 0x7D, 0xE1, 0x39, 0xB6,
            0x10, 0x92, 0xFA, 0x66, 0x2C, 0xD8, 0x73, 0x4F,
            0xA7, 0x05, 0x31, 0xCB, 0x98, 0x44, 0xE9, 0x12,
            0x6D, 0x81, 0x3A, 0xFE, 0x57, 0x20, 0xBC, 0x09,
            0xD1, 0x64, 0x2E, 0xA9, 0x7B, 0xC0, 0x16, 0x5F,
            0xE3, 0x38, 0x91, 0x0C, 0xB2, 0x75, 0x4A, 0xDD,
            0x27, 0xF8, 0x60, 0x9E, 0x13, 0xAC, 0x52, 0x87
    };

    for (int i = 0; i < 64; i++) {
        unsigned char v = inKey[i];

        v ^= salt[i];
        v = static_cast<unsigned char>((v << 3) | (v >> 5));
        v ^= static_cast<unsigned char>(i * 17 + 0x5A);
        v = static_cast<unsigned char>((v >> 2) | (v << 6));
        v ^= salt[(i * 7) & 63];

        outKey[i] = v;
    }

    for (int round = 0; round < 3; round++) {
        for (int i = 0; i < 64; i++) {
            unsigned char a = outKey[i];
            unsigned char b = outKey[(i + 13) & 63];
            unsigned char c = outKey[(i + 37) & 63];

            outKey[i] = static_cast<unsigned char>(
                    ((a ^ b) + c + salt[(i + round * 11) & 63]) & 0xff
            );
        }
    }
}

static bool parsePayloadFooterFromTail(
        const std::vector<unsigned char> &allData,
        ArkPayloadFooter &outFooter
) {
    memset(&outFooter, 0, sizeof(outFooter));

    const size_t footerSize = 36;

    //LOGI("开始解析 AKPF footer，文件大小=%zu，footer大小=%zu", allData.size(), footerSize);

    if (allData.size() < footerSize) {
        //LOGE("解析 AKPF footer 失败：文件大小不足");
        return false;
    }

    size_t pos = allData.size() - footerSize;
    const unsigned char *p = allData.data() + pos;

    //LOGI("AKPF footer 偏移=%zu", pos);

    if (!(p[0] == 0x5C
          && p[1] == 0xE1
          && p[2] == 0x38
          && p[3] == 0x90)) {
        //LOGE("解析 AKPF footer 失败：magic 不匹配，实际=%02X %02X %02X %02X",p[0], p[1], p[2], p[3]);
        return false;
    }

    pos += 4;

    uint32_t version = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t flags = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t payloadOff = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t payloadLen = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t indexOff = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t indexLen = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t reserved1 = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t reserved2 = readLe32(allData.data() + pos);
    pos += 4;

    //LOGI("AKPF footer 信息：version=%u flags=%u payloadOff=%u payloadLen=%u indexOff=%u indexLen=%u reserved1=%u reserved2=%u",version,flags,payloadOff,payloadLen,indexOff,indexLen,reserved1,reserved2);

    if (version != 1) {
        //LOGE("解析 AKPF footer 失败：version 不支持=%u", version);
        return false;
    }

    if (payloadLen == 0 || indexLen == 0) {
        //LOGE("解析 AKPF footer 失败：payloadLen 或 indexLen 为 0，payloadLen=%u indexLen=%u",payloadLen,indexLen);
        return false;
    }

    if ((size_t) payloadOff + (size_t) payloadLen > allData.size() - footerSize) {
        //LOGE("解析 AKPF footer 失败：payload 越界，payloadOff=%u payloadLen=%u 文件有效末尾=%zu",payloadOff,payloadLen,allData.size() - footerSize);
        return false;
    }

    if ((size_t) indexOff + (size_t) indexLen > (size_t) payloadLen) {
        //LOGE("解析 AKPF footer 失败：index 越界，indexOff=%u indexLen=%u payloadLen=%u",indexOff,indexLen,payloadLen);
        return false;
    }

    outFooter.payloadOff = static_cast<size_t>(payloadOff);
    outFooter.payloadLen = static_cast<size_t>(payloadLen);
    outFooter.indexOff = static_cast<size_t>(indexOff);
    outFooter.indexLen = static_cast<size_t>(indexLen);

    //LOGI("解析 AKPF footer 成功：payloadAbs=[%zu, %zu)，indexAbs=[%zu, %zu)",outFooter.payloadOff,outFooter.payloadOff + outFooter.payloadLen,outFooter.payloadOff + outFooter.indexOff,outFooter.payloadOff + outFooter.indexOff + outFooter.indexLen);

    return true;
}


//解析索引表明文
static bool parsePayloadIndexPlainBytes(
        const std::vector<unsigned char> &plain,
        std::vector<ArkPayloadIndexEntry> &outEntries
) {
    outEntries.clear();

    //LOGI("开始解析 AKIT 索引表，明文大小=%zu", plain.size());

    if (plain.size() < 12) {
        //LOGE("解析 AKIT 索引表失败：大小不足");
        return false;
    }

    if (!(plain[0] == 0x71
          && plain[1] == 0x32
          && plain[2] == 0xA6
          && plain[3] == 0x4D)) {
        //LOGE("解析 AKIT 索引表失败：magic 不匹配，实际=%02X %02X %02X %02X",plain[0], plain[1], plain[2], plain[3]);
        return false;
    }

    size_t pos = 4;

    uint32_t version = 0;
    uint32_t entryCount = 0;

    if (!readLe32FromVector(plain, pos, version)) {
        //LOGE("解析 AKIT 索引表失败：读取 version 失败");
        return false;
    }

    if (version != 1) {
        //LOGE("解析 AKIT 索引表失败：version 不支持=%u", version);
        return false;
    }

    if (!readLe32FromVector(plain, pos, entryCount)) {
        //LOGE("解析 AKIT 索引表失败：读取 entryCount 失败");
        return false;
    }

    //LOGI("AKIT 索引表信息：version=%u entryCount=%u", version, entryCount);

    if (entryCount == 0 || entryCount > 256) {
        //LOGE("解析 AKIT 索引表失败：entryCount 异常=%u", entryCount);
        return false;
    }

    if (pos + entryCount * 20 > plain.size()) {
        //LOGE("解析 AKIT 索引表失败：索引项越界，pos=%zu entryCount=%u plainSize=%zu",pos,entryCount,plain.size());
        return false;
    }

    for (uint32_t i = 0; i < entryCount; i++) {
        uint32_t type = 0;
        uint32_t index = 0;
        uint32_t offset = 0;
        uint32_t size = 0;
        uint32_t flags = 0;

        if (!readLe32FromVector(plain, pos, type)) {
            //LOGE("解析 AKIT 索引表失败：读取第 %u 项 type 失败", i);
            return false;
        }

        if (!readLe32FromVector(plain, pos, index)) {
            //LOGE("解析 AKIT 索引表失败：读取第 %u 项 index 失败", i);
            return false;
        }

        if (!readLe32FromVector(plain, pos, offset)) {
            //LOGE("解析 AKIT 索引表失败：读取第 %u 项 offset 失败", i);
            return false;
        }

        if (!readLe32FromVector(plain, pos, size)) {
            //LOGE("解析 AKIT 索引表失败：读取第 %u 项 size 失败", i);
            return false;
        }

        if (!readLe32FromVector(plain, pos, flags)) {
            //LOGE("解析 AKIT 索引表失败：读取第 %u 项 flags 失败", i);
            return false;
        }

        if (size == 0) {
            //LOGE("解析 AKIT 索引表失败：第 %u 项 size 为 0", i);
            return false;
        }

        ArkPayloadIndexEntry entry;
        entry.type = static_cast<int>(type);
        entry.index = static_cast<int>(index);
        entry.offset = static_cast<size_t>(offset);
        entry.size = static_cast<size_t>(size);
        entry.flags = static_cast<int>(flags);

        outEntries.push_back(entry);

        //LOGI("AKIT 索引项[%u]：type=%d index=%d offset=%zu size=%zu flags=%d",i,entry.type,entry.index,entry.offset,entry.size,entry.flags);
    }

    //LOGI("解析 AKIT 索引表成功，索引数量=%zu", outEntries.size());
    return true;
}
//按索引解析加密 block 信息
static bool parseEncryptedBlockInfoByIndex(
        const std::vector<unsigned char> &allData,
        size_t blockOffset,
        size_t blockSize,
        ArkDexBlockInfo &outInfo,
        const unsigned char *signKey64
) {
    memset(&outInfo, 0, sizeof(outInfo));

    //LOGI("开始解析 AKBL 数据块：blockOffset=%zu blockSize=%zu", blockOffset, blockSize);

    if (blockSize < 28) {
        //LOGE("解析 AKBL 数据块失败：blockSize 小于头部大小，blockSize=%zu", blockSize);
        return false;
    }

    if (blockOffset + blockSize > allData.size()) {
        //LOGE("解析 AKBL 数据块失败：block 越界，blockOffset=%zu blockSize=%zu allSize=%zu",blockOffset,blockSize,allData.size());
        return false;
    }

    const unsigned char *block = allData.data() + blockOffset;

    if (!(block[0] == 0x63
          && block[1] == 0x19
          && block[2] == 0xB7
          && block[3] == 0x52)) {
        //LOGE("解析 AKBL 数据块失败：magic 不匹配，实际=%02X %02X %02X %02X",block[0], block[1], block[2], block[3]);
        return false;
    }

    size_t pos = blockOffset + 4;

    uint32_t type = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t index = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t flags = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t plainLen = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t cipherLen = readLe32(allData.data() + pos);
    pos += 4;

    uint32_t keyLen = readLe32(allData.data() + pos);
    pos += 4;

    //LOGI("AKBL 头信息：type=%u index=%u flags=%u plainLen=%u cipherLen=%u keyLen=%u dataOffset=%zu",type,index,flags,plainLen,cipherLen,keyLen,pos);

    if (plainLen == 0 || cipherLen == 0) {
        //LOGE("解析 AKBL 数据块失败：plainLen 或 cipherLen 为 0，plainLen=%u cipherLen=%u",plainLen,cipherLen);
        return false;
    }

    if (plainLen != cipherLen) {
        //LOGE("解析 AKBL 数据块失败：plainLen 和 cipherLen 不一致，plainLen=%u cipherLen=%u",plainLen,cipherLen);
        return false;
    }

    if (flags == ARK_BLOCK_FLAG_RANDOM_KEY) {
        if (keyLen != 64) {
            //LOGE("解析 AKBL 数据块失败：随机 key 模式 keyLen 非 64，keyLen=%u", keyLen);
            return false;
        }

        if (28 + cipherLen + keyLen != blockSize) {
            //LOGE("解析 AKBL 数据块失败：随机 key 模式块大小不匹配，期望=%u 实际=%zu",28 + cipherLen + keyLen,blockSize);
            return false;
        }

        outInfo.dataOffset = pos;
        outInfo.plainLen = plainLen;
        outInfo.cipherLen = cipherLen;

        memcpy(
                outInfo.key,
                allData.data() + pos + cipherLen,
                64
        );

        //LOGI("解析 AKBL 数据块成功：随机 key 模式，type=%u index=%u dataOffset=%zu plainLen=%zu keyOffset=%zu",type,index,outInfo.dataOffset,outInfo.plainLen,pos + cipherLen);

        return true;
    }

    if (flags == ARK_BLOCK_FLAG_SIGN_KEY) {
        if (keyLen != 0) {
            //LOGE("解析 AKBL 数据块失败：签名 key 模式 keyLen 必须为 0，keyLen=%u", keyLen);
            return false;
        }

        if (signKey64 == nullptr) {
            //LOGE("解析 AKBL 数据块失败：签名 key 模式但 signKey64 为空");
            return false;
        }

        if (28 + cipherLen != blockSize) {
            //LOGE("解析 AKBL 数据块失败：签名 key 模式块大小不匹配，期望=%u 实际=%zu",28 + cipherLen,blockSize);
            return false;
        }

        outInfo.dataOffset = pos;
        outInfo.plainLen = plainLen;
        outInfo.cipherLen = cipherLen;

        //memcpy(outInfo.key, signKey64, 64);
        deriveDexKeyFromSignKey64(signKey64, outInfo.key);

        //LOGI("解析 AKBL 数据块成功：签名 key 模式，type=%u index=%u dataOffset=%zu plainLen=%zu",type,index,outInfo.dataOffset,outInfo.plainLen);

        return true;
    }

    //LOGE("解析 AKBL 数据块失败：未知 flags=%u", flags);
    return false;
}
static bool decryptStringBlockByEntry(
        const std::vector<unsigned char> &shellDex,
        const ArkPayloadFooter &footer,
        const ArkPayloadIndexEntry &entry,
        std::string &outText
) {
    outText.clear();

    size_t absOffset = footer.payloadOff + entry.offset;

    if (absOffset + entry.size > shellDex.size()) {
        return false;
    }

    ArkDexBlockInfo info;
    memset(&info, 0, sizeof(info));

    if (!parseEncryptedBlockInfoByIndex(
            shellDex,
            absOffset,
            entry.size,
            info,
            nullptr
    )) {
        return false;
    }

    std::vector<unsigned char> data = xorData(
            shellDex.data() + info.dataOffset,
            info.plainLen,
            info.key,
            64
    );

    data.push_back('\0');
    outText = reinterpret_cast<const char *>(data.data());

    std::vector<unsigned char>().swap(data);

    return !outText.empty();
}







static std::string gRealApplicationName;
static std::string gRealAppComponentFactoryName;
static std::vector<void *> gDexMemoryList;

static bool gArkDexLoaded = false;


static bool checkException(JNIEnv *env, const char *msg) {
    if (env->ExceptionCheck()) {
        //LOGE("%s 出现异常", msg);
        env->ExceptionDescribe();
        env->ExceptionClear();
        return true;
    }
    return false;
}

static jstring newString(JNIEnv *env, const char *text) {
    return env->NewStringUTF(text);
}

static int getSdkInt(JNIEnv *env) {
    jclass clsBuildVersion = env->FindClass("android/os/Build$VERSION");
    jfieldID fidSdkInt = env->GetStaticFieldID(clsBuildVersion, "SDK_INT", "I");
    return env->GetStaticIntField(clsBuildVersion, fidSdkInt);
    //return 25;
}




static bool getSelfSignKey64(JNIEnv *env, unsigned char outKey[64]) {
    if (env == nullptr || outKey == nullptr) {
        return false;
    }

    jbyteArray sha32Array = env->NewByteArray(32);
    if (sha32Array == nullptr) {
        return false;
    }

    if (!ark_get_self_cert_sha256(env, sha32Array)) {
        env->DeleteLocalRef(sha32Array);
        return false;
    }

    unsigned char sha32[32];
    memset(sha32, 0, sizeof(sha32));

    env->GetByteArrayRegion(
            sha32Array,
            0,
            32,
            reinterpret_cast<jbyte *>(sha32)
    );

    env->DeleteLocalRef(sha32Array);

    if (env->ExceptionCheck()) {
        env->ExceptionClear();
        return false;
    }

    static const char hexTable[] = "0123456789abcdef";

    for (int i = 0; i < 32; i++) {
        outKey[i * 2] = hexTable[(sha32[i] >> 4) & 0x0F];
        outKey[i * 2 + 1] = hexTable[sha32[i] & 0x0F];
    }

    return true;
}

static bool isValidDexData(const std::vector<unsigned char> &data) {
    return data.size() >= 0x70
           && data[0] == 'd'
           && data[1] == 'e'
           && data[2] == 'x'
           && data[3] == '\n';
}
// 【新增】校验裸 dex 内存，避免为了校验再创建 vector
static bool isValidDexRaw(const unsigned char *data, size_t len) {
    return data != nullptr
           && len >= 0x70
           && data[0] == 'd'
           && data[1] == 'e'
           && data[2] == 'x'
           && data[3] == '\n';
}
static std::vector<unsigned char> readAllBytesFromInputStream(JNIEnv *env, jobject inputStream) {
    std::vector<unsigned char> result;

    jclass clsInputStream = env->FindClass("java/io/InputStream");
    jmethodID midRead = env->GetMethodID(clsInputStream, "read", "([B)I");
    jmethodID midClose = env->GetMethodID(clsInputStream, "close", "()V");

    const int bufferSize = 8192;
    jbyteArray buffer = env->NewByteArray(bufferSize);

    while (true) {
        jint readSize = env->CallIntMethod(inputStream, midRead, buffer);
        if (checkException(env, "读取 InputStream")) {
            result.clear();
            return result;
        }

        if (readSize <= 0) {
            break;
        }

        size_t oldSize = result.size();
        result.resize(oldSize + readSize);

        env->GetByteArrayRegion(
                buffer,
                0,
                readSize,
                reinterpret_cast<jbyte *>(result.data() + oldSize)
        );

        if (checkException(env, "复制 InputStream 数据")) {
            result.clear();
            return result;
        }
    }

    env->CallVoidMethod(inputStream, midClose);
    checkException(env, "关闭 InputStream");

    return result;
}

static std::vector<unsigned char> readSelfClassesDex(JNIEnv *env, jobject context) {
    std::vector<unsigned char> result;

    jclass clsContext = env->GetObjectClass(context);
    jmethodID midGetApplicationInfo = env->GetMethodID(
            clsContext,
            "getApplicationInfo",
            "()Landroid/content/pm/ApplicationInfo;"
    );

    jobject appInfo = env->CallObjectMethod(context, midGetApplicationInfo);
    if (checkException(env, "获取 ApplicationInfo") || appInfo == nullptr) {
        return result;
    }

    jclass clsApplicationInfo = env->FindClass("android/content/pm/ApplicationInfo");
    jfieldID fidSourceDir = env->GetFieldID(
            clsApplicationInfo,
            "sourceDir",
            "Ljava/lang/String;"
    );

    jstring sourceDirJ = (jstring) env->GetObjectField(appInfo, fidSourceDir);
    if (sourceDirJ == nullptr) {
        //LOGE("sourceDir 为空");
        return result;
    }

    const char *sourceDir = env->GetStringUTFChars(sourceDirJ, nullptr);
    //LOGI("当前 APK 路径：%s", sourceDir);

    jclass clsZipFile = env->FindClass("java/util/zip/ZipFile");
    jmethodID midZipInit = env->GetMethodID(
            clsZipFile,
            "<init>",
            "(Ljava/lang/String;)V"
    );

    jobject zipFile = env->NewObject(clsZipFile, midZipInit, sourceDirJ);
    env->ReleaseStringUTFChars(sourceDirJ, sourceDir);

    if (checkException(env, "创建 ZipFile") || zipFile == nullptr) {
        return result;
    }

    jmethodID midGetEntry = env->GetMethodID(
            clsZipFile,
            "getEntry",
            "(Ljava/lang/String;)Ljava/util/zip/ZipEntry;"
    );
    jstring entryName = env->NewStringUTF("classes.dex");
    jobject zipEntry = env->CallObjectMethod(zipFile, midGetEntry, entryName);
    if (checkException(env, "获取 classes.dex ZipEntry") || zipEntry == nullptr) {
        //LOGE("APK 中找不到 classes.dex");
        return result;
    }
    jmethodID midGetInputStream = env->GetMethodID(
            clsZipFile,
            "getInputStream",
            "(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;"
    );
    jobject inputStream = env->CallObjectMethod(zipFile, midGetInputStream, zipEntry);
    if (checkException(env, "获取 classes.dex InputStream") || inputStream == nullptr) {
        return result;
    }
    result = readAllBytesFromInputStream(env, inputStream);
    jmethodID midClose = env->GetMethodID(clsZipFile, "close", "()V");
    env->CallVoidMethod(zipFile, midClose);
    checkException(env, "关闭 ZipFile");
    //LOGI("读取自身 classes.dex 完成，大小=%zu", result.size());
    return result;
}


static std::vector<unsigned char> readSelfClassesDexFromSourceDir(JNIEnv *env, jstring sourceDirJ) {
    std::vector<unsigned char> result;

    if (sourceDirJ == nullptr) {
        return result;
    }

    jclass clsZipFile = env->FindClass("java/util/zip/ZipFile");
    if (clsZipFile == nullptr) {
        env->ExceptionClear();
        return result;
    }

    jmethodID midZipInit = env->GetMethodID(
            clsZipFile,
            "<init>",
            "(Ljava/lang/String;)V"
    );

    if (midZipInit == nullptr) {
        env->ExceptionClear();
        return result;
    }

    jobject zipFile = env->NewObject(clsZipFile, midZipInit, sourceDirJ);
    if (checkException(env, "Factory 创建 ZipFile") || zipFile == nullptr) {
        return result;
    }

    jmethodID midGetEntry = env->GetMethodID(
            clsZipFile,
            "getEntry",
            "(Ljava/lang/String;)Ljava/util/zip/ZipEntry;"
    );

    jstring entryName = env->NewStringUTF("classes.dex");
    jobject zipEntry = env->CallObjectMethod(zipFile, midGetEntry, entryName);

    if (checkException(env, "Factory 获取 classes.dex ZipEntry") || zipEntry == nullptr) {
        return result;
    }

    jmethodID midGetInputStream = env->GetMethodID(
            clsZipFile,
            "getInputStream",
            "(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;"
    );

    jobject inputStream = env->CallObjectMethod(zipFile, midGetInputStream, zipEntry);
    if (checkException(env, "Factory 获取 classes.dex InputStream") || inputStream == nullptr) {
        return result;
    }

    result = readAllBytesFromInputStream(env, inputStream);

    jmethodID midClose = env->GetMethodID(clsZipFile, "close", "()V");
    env->CallVoidMethod(zipFile, midClose);
    checkException(env, "Factory 关闭 ZipFile");

    return result;
}
static jobject getCurrentActivityThread(JNIEnv *env) {
    jclass clsActivityThread = env->FindClass("android/app/ActivityThread");
    if (clsActivityThread == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jmethodID midCurrentActivityThread = env->GetStaticMethodID(
            clsActivityThread,
            "currentActivityThread",
            "()Landroid/app/ActivityThread;"
    );

    if (midCurrentActivityThread == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jobject currentActivityThread = env->CallStaticObjectMethod(
            clsActivityThread,
            midCurrentActivityThread
    );

    if (checkException(env, "Factory 获取 currentActivityThread")) {
        return nullptr;
    }

    return currentActivityThread;
}
static jobject getBoundLoadedApk(JNIEnv *env) {
    jobject currentActivityThread = getCurrentActivityThread(env);
    if (currentActivityThread == nullptr) {
        return nullptr;
    }

    jclass clsActivityThread = env->FindClass("android/app/ActivityThread");
    jclass clsAppBindData = env->FindClass("android/app/ActivityThread$AppBindData");

    if (clsActivityThread == nullptr || clsAppBindData == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jfieldID fidBoundApplication = env->GetFieldID(
            clsActivityThread,
            "mBoundApplication",
            "Landroid/app/ActivityThread$AppBindData;"
    );

    if (fidBoundApplication == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jobject boundApplication = env->GetObjectField(
            currentActivityThread,
            fidBoundApplication
    );

    if (boundApplication == nullptr) {
        return nullptr;
    }

    jfieldID fidInfo = env->GetFieldID(
            clsAppBindData,
            "info",
            "Landroid/app/LoadedApk;"
    );

    if (fidInfo == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jobject loadedApk = env->GetObjectField(boundApplication, fidInfo);
    if (loadedApk == nullptr) {
        return nullptr;
    }

    return loadedApk;
}
static jobject getLoadedApkApplicationInfo(JNIEnv *env, jobject loadedApk) {
    if (loadedApk == nullptr) {
        return nullptr;
    }

    jclass clsLoadedApk = env->FindClass("android/app/LoadedApk");
    if (clsLoadedApk == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jfieldID fidApplicationInfo = env->GetFieldID(
            clsLoadedApk,
            "mApplicationInfo",
            "Landroid/content/pm/ApplicationInfo;"
    );

    if (fidApplicationInfo == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jobject appInfo = env->GetObjectField(loadedApk, fidApplicationInfo);
    return appInfo;
}
static jstring getApplicationInfoStringField(
        JNIEnv *env,
        jobject appInfo,
        const char *fieldName
) {
    if (appInfo == nullptr || fieldName == nullptr) {
        return nullptr;
    }

    jclass clsApplicationInfo = env->FindClass("android/content/pm/ApplicationInfo");
    if (clsApplicationInfo == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    jfieldID fid = env->GetFieldID(
            clsApplicationInfo,
            fieldName,
            "Ljava/lang/String;"
    );

    if (fid == nullptr) {
        env->ExceptionClear();
        return nullptr;
    }

    return (jstring) env->GetObjectField(appInfo, fid);
}
static jobjectArray loadDexBuffersFromSelfClassesDexBySourceDir(JNIEnv *env, jstring sourceDirJ) {
    std::vector<unsigned char> shellDex = readSelfClassesDexFromSourceDir(env, sourceDirJ);
    if (shellDex.size() < 36) {
        //LOGE("Factory 读取自身 classes.dex 失败");
        return nullptr;
    }

    ArkPayloadFooter footer;
    memset(&footer, 0, sizeof(footer));

    if (!parsePayloadFooterFromTail(shellDex, footer)) {
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 解析 payload footer 失败");
        return nullptr;
    }

    size_t indexAbsOffset = footer.payloadOff + footer.indexOff;

    if (indexAbsOffset + footer.indexLen > shellDex.size()) {
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 索引表越界");
        return nullptr;
    }

    ArkDexBlockInfo indexInfo;
    memset(&indexInfo, 0, sizeof(indexInfo));

    if (!parseEncryptedBlockInfoByIndex(
            shellDex,
            indexAbsOffset,
            footer.indexLen,
            indexInfo,
            nullptr
    )) {
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 解析索引块失败");
        return nullptr;
    }

    std::vector<unsigned char> indexPlain = xorData(
            shellDex.data() + indexInfo.dataOffset,
            indexInfo.plainLen,
            indexInfo.key,
            64
    );

    std::vector<ArkPayloadIndexEntry> indexEntries;
    if (!parsePayloadIndexPlainBytes(indexPlain, indexEntries)) {
        std::vector<unsigned char>().swap(indexPlain);
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 解析索引表明文失败");
        return nullptr;
    }

    std::vector<unsigned char>().swap(indexPlain);

    ArkPayloadIndexEntry appEntry;
    memset(&appEntry, 0, sizeof(appEntry));

    ArkPayloadIndexEntry factoryEntry;
    memset(&factoryEntry, 0, sizeof(factoryEntry));

    bool hasAppEntry = false;
    bool hasFactoryEntry = false;
    uint32_t dexCount = 0;

    for (size_t i = 0; i < indexEntries.size(); i++) {
        if (indexEntries[i].type == ARK_BLOCK_TYPE_APP) {
            appEntry = indexEntries[i];
            hasAppEntry = true;
        } else if (indexEntries[i].type == ARK_BLOCK_TYPE_FACTORY) {
            factoryEntry = indexEntries[i];
            hasFactoryEntry = true;
        } else if (indexEntries[i].type == ARK_BLOCK_TYPE_DEX) {
            dexCount++;
        }
    }

    if (!hasAppEntry || dexCount <= 0 || dexCount > 128) {
        std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 索引中没有有效 app/dex 项");
        return nullptr;
    }

    if (!decryptStringBlockByEntry(
            shellDex,
            footer,
            appEntry,
            gRealApplicationName
    )) {
        std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("解析真实 Application 名称失败");
        return nullptr;
    }

    if (hasFactoryEntry) {
        if (decryptStringBlockByEntry(
                shellDex,
                footer,
                factoryEntry,
                gRealAppComponentFactoryName
        )) {
            //LOGI("已解析原 AppComponentFactory：%s", gRealAppComponentFactoryName.c_str());
        } else {
            gRealAppComponentFactoryName.clear();
            //LOGE("解析原 AppComponentFactory 失败，按无原 Factory 处理");
        }
    } else {
        gRealAppComponentFactoryName.clear();
        //LOGI("原 AppComponentFactory：无");
    }

    if (gRealApplicationName.empty()) {
        std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 真实 Application 名称为空");
        return nullptr;
    }

    unsigned char signKey64[64];
    memset(signKey64, 0, sizeof(signKey64));

    if (!getSelfSignKey64(env, signKey64)) {
        std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 获取签名 key 失败");
        return nullptr;
    }

    std::vector<ArkDexBlockInfo> dexBlockList;
    dexBlockList.resize(dexCount);

    for (size_t i = 0; i < indexEntries.size(); i++) {
        ArkPayloadIndexEntry &entry = indexEntries[i];

        if (entry.type != ARK_BLOCK_TYPE_DEX) {
            continue;
        }

        if (entry.index <= 0 || static_cast<uint32_t>(entry.index) > dexCount) {
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
            std::vector<unsigned char>().swap(shellDex);
            //LOGE("Factory dex index 异常");
            return nullptr;
        }

        size_t absOffset = footer.payloadOff + entry.offset;

        ArkDexBlockInfo info;
        memset(&info, 0, sizeof(info));

        if (absOffset + entry.size > shellDex.size()
            || !parseEncryptedBlockInfoByIndex(
                shellDex,
                absOffset,
                entry.size,
                info,
                signKey64
        )) {
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
            std::vector<unsigned char>().swap(shellDex);
            //LOGE("Factory 解析 dex 块失败");
            return nullptr;
        }

        dexBlockList[entry.index - 1] = info;
    }

    std::vector<ArkPayloadIndexEntry>().swap(indexEntries);

    jclass clsByteBuffer = env->FindClass("java/nio/ByteBuffer");
    if (clsByteBuffer == nullptr) {
        std::vector<ArkDexBlockInfo>().swap(dexBlockList);
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 找不到 ByteBuffer");
        return nullptr;
    }

    jobjectArray bufferArray = env->NewObjectArray(dexCount, clsByteBuffer, nullptr);
    if (bufferArray == nullptr) {
        std::vector<ArkDexBlockInfo>().swap(dexBlockList);
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("Factory 创建 ByteBuffer 数组失败");
        return nullptr;
    }

    for (uint32_t i = 0; i < dexCount; i++) {
        ArkDexBlockInfo &info = dexBlockList[i];

        if (info.plainLen <= 0 || info.cipherLen <= 0) {
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<unsigned char>().swap(shellDex);
            //LOGE("Factory dex 长度异常");
            return nullptr;
        }

        void *dexMemory = malloc(info.plainLen);
        if (dexMemory == nullptr) {
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<unsigned char>().swap(shellDex);
            //LOGE("Factory 申请 dex 内存失败");
            return nullptr;
        }

        unsigned char *out = reinterpret_cast<unsigned char *>(dexMemory);
        const unsigned char *enc = shellDex.data() + info.dataOffset;

        for (size_t k = 0; k < info.plainLen; k++) {
            out[k] = enc[k] ^ info.key[k % 64];
        }

        if (!isValidDexRaw(out, info.plainLen)) {
            free(dexMemory);
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<unsigned char>().swap(shellDex);
            //LOGE("Factory 解密后的 dex 无效");
            return nullptr;
        }

        gDexMemoryList.push_back(dexMemory);

        jobject byteBuffer = env->NewDirectByteBuffer(
                dexMemory,
                static_cast<jlong>(info.plainLen)
        );

        if (byteBuffer == nullptr) {
            free(dexMemory);
            gDexMemoryList.pop_back();
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<unsigned char>().swap(shellDex);
            //LOGE("Factory 创建 DirectByteBuffer 失败");
            return nullptr;
        }

        env->SetObjectArrayElement(bufferArray, i, byteBuffer);

        if (checkException(env, "Factory 设置 ByteBuffer 数组元素")) {
            env->DeleteLocalRef(byteBuffer);
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<unsigned char>().swap(shellDex);
            return nullptr;
        }

        env->DeleteLocalRef(byteBuffer);
    }

    std::vector<ArkDexBlockInfo>().swap(dexBlockList);
    std::vector<unsigned char>().swap(shellDex);

    return bufferArray;
}
static jobject createDexClassLoaderFromFactory(
        JNIEnv *env,
        jobjectArray dexBuffers,
        jstring nativeLibDir,
        jobject parentClassLoader
) {
    if (dexBuffers == nullptr || parentClassLoader == nullptr) {
        //LOGE("Factory 创建 ClassLoader 失败：参数为空");
        return nullptr;
    }

    jclass clsLoader = env->FindClass("dalvik/system/InMemoryDexClassLoader");
    if (clsLoader == nullptr) {
        env->ExceptionClear();
        //LOGE("Factory 找不到 InMemoryDexClassLoader");
        return nullptr;
    }

    jmethodID initMethod = env->GetMethodID(
            clsLoader,
            "<init>",
            "([Ljava/nio/ByteBuffer;Ljava/lang/String;Ljava/lang/ClassLoader;)V"
    );

    if (initMethod != nullptr && nativeLibDir != nullptr) {
        jobject loader = env->NewObject(
                clsLoader,
                initMethod,
                dexBuffers,
                nativeLibDir,
                parentClassLoader
        );

        if (!checkException(env, "Factory 创建三参数 InMemoryDexClassLoader") && loader != nullptr) {
            return loader;
        }
    }

    env->ExceptionClear();

    initMethod = env->GetMethodID(
            clsLoader,
            "<init>",
            "([Ljava/nio/ByteBuffer;Ljava/lang/ClassLoader;)V"
    );

    if (initMethod == nullptr) {
        env->ExceptionClear();
        //LOGE("Factory 找不到可用的 InMemoryDexClassLoader 构造方法");
        return nullptr;
    }

    jobject loader = env->NewObject(
            clsLoader,
            initMethod,
            dexBuffers,
            parentClassLoader
    );

    if (checkException(env, "Factory 创建双参数 InMemoryDexClassLoader")) {
        return nullptr;
    }

    return loader;
}
static bool replaceBoundLoadedApkClassLoader(JNIEnv *env, jobject loadedApk, jobject newClassLoader) {
    if (loadedApk == nullptr || newClassLoader == nullptr) {
        return false;
    }

    jclass clsLoadedApk = env->FindClass("android/app/LoadedApk");
    if (clsLoadedApk == nullptr) {
        env->ExceptionClear();
        return false;
    }

    jfieldID fidClassLoader = env->GetFieldID(
            clsLoadedApk,
            "mClassLoader",
            "Ljava/lang/ClassLoader;"
    );

    if (fidClassLoader == nullptr) {
        env->ExceptionClear();
        return false;
    }

    env->SetObjectField(loadedApk, fidClassLoader, newClassLoader);

    if (checkException(env, "Factory 替换 LoadedApk.mClassLoader")) {
        return false;
    }

    return true;
}
bool LoaderDEXFromFactory(JNIEnv *env, jobject parentClassLoader) {
    if (gArkDexLoaded) {
        //LOGI("Factory DEX 已加载，跳过重复加载");
        return true;
    }

    if (env == nullptr || parentClassLoader == nullptr) {
        //LOGE("Factory 加载 dex 失败：env 或 parentClassLoader 为空");
        return false;
    }

    int sdk = getSdkInt(env);
    if (sdk < 26) {
        //LOGE("Factory 无 Context 加载仅支持 Android 8.0+");
        return false;
    }

    jobject loadedApk = getBoundLoadedApk(env);
    if (loadedApk == nullptr) {
        //LOGE("Factory 获取 LoadedApk 失败");
        return false;
    }

    jobject appInfo = getLoadedApkApplicationInfo(env, loadedApk);
    if (appInfo == nullptr) {
        //LOGE("Factory 获取 ApplicationInfo 失败");
        return false;
    }

    jstring sourceDir = getApplicationInfoStringField(env, appInfo, "sourceDir");
    if (sourceDir == nullptr) {
        //LOGE("Factory 获取 sourceDir 失败");
        return false;
    }

    jstring nativeLibDir = getApplicationInfoStringField(env, appInfo, "nativeLibraryDir");

    jobjectArray dexBuffers = loadDexBuffersFromSelfClassesDexBySourceDir(env, sourceDir);
    if (dexBuffers == nullptr) {
        //LOGE("Factory 解密 dexBuffers 失败");
        return false;
    }

    jobject newClassLoader = createDexClassLoaderFromFactory(
            env,
            dexBuffers,
            nativeLibDir,
            parentClassLoader
    );

    if (newClassLoader == nullptr) {
        //LOGE("Factory 创建 ClassLoader 失败");
        return false;
    }

    if (!replaceBoundLoadedApkClassLoader(env, loadedApk, newClassLoader)) {
        //LOGE("Factory 替换 LoadedApk.mClassLoader 失败");
        return false;
    }

    gArkDexLoaded = true;

    //LOGI("Factory 加载 dex 成功");
    return true;
}









static jobjectArray loadDexBuffersFromSelfClassesDex(JNIEnv *env, jobject context) {
    std::vector<unsigned char> shellDex = readSelfClassesDex(env, context);
    if (shellDex.size() < 36) {
        return nullptr;
    }

    ArkPayloadFooter footer;
    memset(&footer, 0, sizeof(footer));

    if (!parsePayloadFooterFromTail(shellDex, footer)) {
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    size_t indexAbsOffset = footer.payloadOff + footer.indexOff;

    if (indexAbsOffset + footer.indexLen > shellDex.size()) {
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    ArkDexBlockInfo indexInfo;
    memset(&indexInfo, 0, sizeof(indexInfo));

    if (!parseEncryptedBlockInfoByIndex(
            shellDex,
            indexAbsOffset,
            footer.indexLen,
            indexInfo,
            nullptr
    )) {
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    std::vector<unsigned char> indexPlain = xorData(
            shellDex.data() + indexInfo.dataOffset,
            indexInfo.plainLen,
            indexInfo.key,
            64
    );

    std::vector<ArkPayloadIndexEntry> indexEntries;
    if (!parsePayloadIndexPlainBytes(indexPlain, indexEntries)) {
        std::vector<unsigned char>().swap(indexPlain);
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    std::vector<unsigned char>().swap(indexPlain);

    ArkPayloadIndexEntry appEntry;
    memset(&appEntry, 0, sizeof(appEntry));

    ArkPayloadIndexEntry factoryEntry;
    memset(&factoryEntry, 0, sizeof(factoryEntry));

    bool hasAppEntry = false;
    bool hasFactoryEntry = false;
    uint32_t dexCount = 0;

    for (size_t i = 0; i < indexEntries.size(); i++) {
        if (indexEntries[i].type == ARK_BLOCK_TYPE_APP) {
            appEntry = indexEntries[i];
            hasAppEntry = true;
        } else if (indexEntries[i].type == ARK_BLOCK_TYPE_FACTORY) {
            factoryEntry = indexEntries[i];
            hasFactoryEntry = true;
        } else if (indexEntries[i].type == ARK_BLOCK_TYPE_DEX) {
            dexCount++;
        }
    }

    if (!hasAppEntry || dexCount <= 0 || dexCount > 128) {
        std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    if (!decryptStringBlockByEntry(
            shellDex,
            footer,
            appEntry,
            gRealApplicationName
    )) {
        std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
        std::vector<unsigned char>().swap(shellDex);
        //LOGE("解析真实 Application 名称失败");
        return nullptr;
    }

    if (hasFactoryEntry) {
        if (decryptStringBlockByEntry(
                shellDex,
                footer,
                factoryEntry,
                gRealAppComponentFactoryName
        )) {
            //LOGI("已解析原 AppComponentFactory：%s", gRealAppComponentFactoryName.c_str());
        } else {
            gRealAppComponentFactoryName.clear();
            //LOGE("解析原 AppComponentFactory 失败，按无原 Factory 处理");
        }
    } else {
        gRealAppComponentFactoryName.clear();
        //LOGI("原 AppComponentFactory：无");
    }

    if (gRealApplicationName.empty()) {
        std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    unsigned char signKey64[64];
    memset(signKey64, 0, sizeof(signKey64));

    if (!getSelfSignKey64(env, signKey64)) {
        std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    std::vector<ArkDexBlockInfo> dexBlockList;
    dexBlockList.resize(dexCount);

    for (size_t i = 0; i < indexEntries.size(); i++) {
        ArkPayloadIndexEntry &entry = indexEntries[i];

        if (entry.type != ARK_BLOCK_TYPE_DEX) {
            continue;
        }

        if (entry.index <= 0 || static_cast<uint32_t>(entry.index) > dexCount) {
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
            std::vector<unsigned char>().swap(shellDex);
            return nullptr;
        }

        size_t absOffset = footer.payloadOff + entry.offset;

        if (absOffset + entry.size > shellDex.size()) {
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
            std::vector<unsigned char>().swap(shellDex);
            return nullptr;
        }

        ArkDexBlockInfo info;
        memset(&info, 0, sizeof(info));

        if (!parseEncryptedBlockInfoByIndex(
                shellDex,
                absOffset,
                entry.size,
                info,
                signKey64
        )) {
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<ArkPayloadIndexEntry>().swap(indexEntries);
            std::vector<unsigned char>().swap(shellDex);
            return nullptr;
        }

        dexBlockList[entry.index - 1] = info;
    }

    std::vector<ArkPayloadIndexEntry>().swap(indexEntries);

    jclass clsByteBuffer = env->FindClass("java/nio/ByteBuffer");
    if (clsByteBuffer == nullptr) {
        std::vector<ArkDexBlockInfo>().swap(dexBlockList);
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    jmethodID midWrap = env->GetStaticMethodID(
            clsByteBuffer,
            "wrap",
            "([B)Ljava/nio/ByteBuffer;"
    );

    jobjectArray bufferArray = env->NewObjectArray(dexCount, clsByteBuffer, nullptr);
    if (bufferArray == nullptr) {
        std::vector<ArkDexBlockInfo>().swap(dexBlockList);
        std::vector<unsigned char>().swap(shellDex);
        return nullptr;
    }

    int sdk = getSdkInt(env);

    for (uint32_t i = 0; i < dexCount; i++) {
        ArkDexBlockInfo &info = dexBlockList[i];

        if (info.plainLen <= 0 || info.cipherLen <= 0) {
            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<unsigned char>().swap(shellDex);
            return nullptr;
        }

        jobject byteBuffer = nullptr;

        if (sdk >= 26) {
            void *dexMemory = malloc(info.plainLen);
            if (dexMemory == nullptr) {
                std::vector<ArkDexBlockInfo>().swap(dexBlockList);
                std::vector<unsigned char>().swap(shellDex);
                return nullptr;
            }

            unsigned char *out = reinterpret_cast<unsigned char *>(dexMemory);
            const unsigned char *enc = shellDex.data() + info.dataOffset;

            for (size_t k = 0; k < info.plainLen; k++) {
                out[k] = enc[k] ^ info.key[k % 64];
            }

            if (!isValidDexRaw(out, info.plainLen)) {
                free(dexMemory);
                std::vector<ArkDexBlockInfo>().swap(dexBlockList);
                std::vector<unsigned char>().swap(shellDex);
                return nullptr;
            }

            gDexMemoryList.push_back(dexMemory);

            byteBuffer = env->NewDirectByteBuffer(
                    dexMemory,
                    static_cast<jlong>(info.plainLen)
            );

            if (byteBuffer == nullptr) {
                free(dexMemory);
                gDexMemoryList.pop_back();
                std::vector<ArkDexBlockInfo>().swap(dexBlockList);
                std::vector<unsigned char>().swap(shellDex);
                return nullptr;
            }
        } else {
            std::vector<unsigned char> dexData = xorData(
                    shellDex.data() + info.dataOffset,
                    info.plainLen,
                    info.key,
                    64
            );

            if (!isValidDexData(dexData)) {
                std::vector<unsigned char>().swap(dexData);
                std::vector<ArkDexBlockInfo>().swap(dexBlockList);
                std::vector<unsigned char>().swap(shellDex);
                return nullptr;
            }

            jbyteArray dexArray = env->NewByteArray(static_cast<jsize>(dexData.size()));
            if (dexArray == nullptr) {
                std::vector<unsigned char>().swap(dexData);
                std::vector<ArkDexBlockInfo>().swap(dexBlockList);
                std::vector<unsigned char>().swap(shellDex);
                return nullptr;
            }

            env->SetByteArrayRegion(
                    dexArray,
                    0,
                    static_cast<jsize>(dexData.size()),
                    reinterpret_cast<const jbyte *>(dexData.data())
            );

            if (checkException(env, "写入 dex byte[]")) {
                env->DeleteLocalRef(dexArray);
                std::vector<unsigned char>().swap(dexData);
                std::vector<ArkDexBlockInfo>().swap(dexBlockList);
                std::vector<unsigned char>().swap(shellDex);
                return nullptr;
            }

            byteBuffer = env->CallStaticObjectMethod(
                    clsByteBuffer,
                    midWrap,
                    dexArray
            );

            if (checkException(env, "ByteBuffer.wrap") || byteBuffer == nullptr) {
                env->DeleteLocalRef(dexArray);
                std::vector<unsigned char>().swap(dexData);
                std::vector<ArkDexBlockInfo>().swap(dexBlockList);
                std::vector<unsigned char>().swap(shellDex);
                return nullptr;
            }

            env->DeleteLocalRef(dexArray);
            std::vector<unsigned char>().swap(dexData);
        }

        env->SetObjectArrayElement(bufferArray, i, byteBuffer);
        if (checkException(env, "设置 ByteBuffer 数组元素")) {
            if (byteBuffer != nullptr) {
                env->DeleteLocalRef(byteBuffer);
            }

            std::vector<ArkDexBlockInfo>().swap(dexBlockList);
            std::vector<unsigned char>().swap(shellDex);
            return nullptr;
        }

        if (byteBuffer != nullptr) {
            env->DeleteLocalRef(byteBuffer);
        }
    }

    std::vector<ArkDexBlockInfo>().swap(dexBlockList);
    std::vector<unsigned char>().swap(shellDex);

    return bufferArray;
}

/**
 * 获取当前包名
 */
static jstring getPackageName(JNIEnv *env, jobject context) {
    jclass clsContext = env->GetObjectClass(context);
    jmethodID midGetPackageName = env->GetMethodID(
            clsContext,
            "getPackageName",
            "()Ljava/lang/String;"
    );

    return (jstring) env->CallObjectMethod(context, midGetPackageName);
}


static bool writeFileBytes(const char *path, const unsigned char *data, int len) {
    FILE *fp = fopen(path, "wb");
    if (fp == nullptr) {
        //LOGE("打开 dex 输出文件失败：%s", path);
        return false;
    }

    int written = fwrite(data, 1, len, fp);
    fclose(fp);

    if (written != len) {
        //LOGE("写入 dex 文件不完整：%s，期望=%d，实际=%d", path, len, written);
        return false;
    }

    chmod(path, 0600);
    //LOGI("写入 dex 文件成功：%s，大小=%d", path, len);
    return true;
}

static jstring getAbsolutePath(JNIEnv *env, jobject fileObj) {
    jclass clsFile = env->FindClass("java/io/File");
    jmethodID midGetAbsolutePath = env->GetMethodID(
            clsFile,
            "getAbsolutePath",
            "()Ljava/lang/String;"
    );
    return (jstring) env->CallObjectMethod(fileObj, midGetAbsolutePath);
}

static jobject getCodeCacheDir(JNIEnv *env, jobject context) {
    jclass clsContext = env->GetObjectClass(context);
    jmethodID midGetCodeCacheDir = env->GetMethodID(
            clsContext,
            "getCodeCacheDir",
            "()Ljava/io/File;"
    );

    if (midGetCodeCacheDir != nullptr) {
        jobject dir = env->CallObjectMethod(context, midGetCodeCacheDir);
        if (!checkException(env, "调用 getCodeCacheDir") && dir != nullptr) {
            return dir;
        }
    }

    jmethodID midGetDir = env->GetMethodID(
            clsContext,
            "getDir",
            "(Ljava/lang/String;I)Ljava/io/File;"
    );

    jstring name = env->NewStringUTF("ark_code_cache");
    return env->CallObjectMethod(context, midGetDir, name, 0);
}

static bool ensureDir(JNIEnv *env, jobject fileObj) {
    jclass clsFile = env->FindClass("java/io/File");

    jmethodID midExists = env->GetMethodID(clsFile, "exists", "()Z");
    jmethodID midMkdirs = env->GetMethodID(clsFile, "mkdirs", "()Z");

    jboolean exists = env->CallBooleanMethod(fileObj, midExists);
    if (exists) {
        return true;
    }

    jboolean ok = env->CallBooleanMethod(fileObj, midMkdirs);
    return ok == JNI_TRUE;
}

static jobject newFile(JNIEnv *env, jobject parent, const char *child) {
    jclass clsFile = env->FindClass("java/io/File");
    jmethodID midInit = env->GetMethodID(
            clsFile,
            "<init>",
            "(Ljava/io/File;Ljava/lang/String;)V"
    );

    jstring childName = env->NewStringUTF(child);
    return env->NewObject(clsFile, midInit, parent, childName);
}

static jstring buildDexPathFromBuffers(JNIEnv *env, jobject context, jobjectArray dexBuffers) {
    jobject codeCacheDir = getCodeCacheDir(env, context);
    if (codeCacheDir == nullptr) {
        //LOGE("获取 code_cache 目录失败");
        return nullptr;
    }

    jobject dexDir = newFile(env, codeCacheDir, "ark_dex");
    jobject optDir = newFile(env, codeCacheDir, "ark_opt");

    if (!ensureDir(env, dexDir) || !ensureDir(env, optDir)) {
        //LOGE("创建 dex/opt 私有目录失败");
        return nullptr;
    }

    int dexCount = env->GetArrayLength(dexBuffers);
    std::string dexPath;

    jclass clsByteBuffer = env->FindClass("java/nio/ByteBuffer");
    jmethodID midRemaining = env->GetMethodID(clsByteBuffer, "remaining", "()I");
    jmethodID midGet = env->GetMethodID(clsByteBuffer, "get", "([B)Ljava/nio/ByteBuffer;");
    jmethodID midPosition = env->GetMethodID(clsByteBuffer, "position", "()I");
    jmethodID midPositionSet = env->GetMethodID(clsByteBuffer, "position", "(I)Ljava/nio/Buffer;");

    for (int i = 0; i < dexCount; i++) {
        jobject buffer = env->GetObjectArrayElement(dexBuffers, i);
        if (buffer == nullptr) {
            //LOGE("dexBuffers[%d] 为空", i);
            return nullptr;
        }

        jint oldPos = env->CallIntMethod(buffer, midPosition);
        jint len = env->CallIntMethod(buffer, midRemaining);

        if (len <= 0) {
            //LOGE("dexBuffers[%d] 数据长度异常：%d", i, len);
            return nullptr;
        }

        jbyteArray byteArray = env->NewByteArray(len);
        if (byteArray == nullptr) {
            //LOGE("创建 dex byte[] 失败：%d", i);
            return nullptr;
        }

        env->CallObjectMethod(buffer, midGet, byteArray);
        if (checkException(env, "读取 ByteBuffer 数据")) {
            return nullptr;
        }

        env->CallObjectMethod(buffer, midPositionSet, oldPos);

        std::vector<unsigned char> dexData(len);
        env->GetByteArrayRegion(
                byteArray,
                0,
                len,
                reinterpret_cast<jbyte *>(dexData.data())
        );

        if (checkException(env, "复制 dex byte[]")) {
            return nullptr;
        }

        char dexName[64];
        snprintf(dexName, sizeof(dexName), "ark_payload_%d.dex", i);

        jobject dexFile = newFile(env, dexDir, dexName);
        jstring dexFilePathJ = getAbsolutePath(env, dexFile);
        const char *dexFilePath = env->GetStringUTFChars(dexFilePathJ, nullptr);

        bool writeOk = writeFileBytes(dexFilePath, dexData.data(), len);

        if (dexPath.empty()) {
            dexPath = dexFilePath;
        } else {
            dexPath += ":";
            dexPath += dexFilePath;
        }

        env->ReleaseStringUTFChars(dexFilePathJ, dexFilePath);

        if (!writeOk) {
            return nullptr;
        }

        //LOGI("添加 dexPath：%s", dexPath.c_str());
    }

    return env->NewStringUTF(dexPath.c_str());
}

static jobject createFileDexClassLoader(JNIEnv *env, jobject context, jobjectArray dexBuffers, jobject parentClassLoader) {
    jstring dexPath = buildDexPathFromBuffers(env, context, dexBuffers);
    if (dexPath == nullptr) {
        return nullptr;
    }

    jobject codeCacheDir = getCodeCacheDir(env, context);
    jobject optDir = newFile(env, codeCacheDir, "ark_opt");

    if (!ensureDir(env, optDir)) {
        return nullptr;
    }

    jstring optPath = getAbsolutePath(env, optDir);

    jclass clsContext = env->GetObjectClass(context);

    jmethodID midGetApplicationInfo = env->GetMethodID(
            clsContext,
            "getApplicationInfo",
            "()Landroid/content/pm/ApplicationInfo;"
    );

    jobject appInfo = env->CallObjectMethod(context, midGetApplicationInfo);
    if (checkException(env, "获取 ApplicationInfo") || appInfo == nullptr) {
        return nullptr;
    }

    jclass clsApplicationInfo = env->FindClass("android/content/pm/ApplicationInfo");
    jfieldID fidNativeLibraryDir = env->GetFieldID(
            clsApplicationInfo,
            "nativeLibraryDir",
            "Ljava/lang/String;"
    );

    jstring nativeLibDir = (jstring) env->GetObjectField(appInfo, fidNativeLibraryDir);
    if (nativeLibDir == nullptr) {
        return nullptr;
    }

    jclass clsDexClassLoader = env->FindClass("dalvik/system/DexClassLoader");
    if (clsDexClassLoader == nullptr) {
        return nullptr;
    }

    jmethodID midInit = env->GetMethodID(
            clsDexClassLoader,
            "<init>",
            "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V"
    );

    if (midInit == nullptr) {
        return nullptr;
    }

    jobject loader = env->NewObject(
            clsDexClassLoader,
            midInit,
            dexPath,
            optPath,
            nativeLibDir,
            parentClassLoader
    );

    if (checkException(env, "创建 DexClassLoader")) {
        return nullptr;
    }

    const char *dexPathChars = env->GetStringUTFChars(dexPath, nullptr);
    if (dexPathChars != nullptr) {
        std::string allPath = dexPathChars;
        env->ReleaseStringUTFChars(dexPath, dexPathChars);

        size_t start = 0;
        while (start < allPath.length()) {
            size_t pos = allPath.find(':', start);
            std::string onePath = allPath.substr(
                    start,
                    pos == std::string::npos ? std::string::npos : pos - start
            );

            if (!onePath.empty()) {
                unlink(onePath.c_str());
            }

            if (pos == std::string::npos) {
                break;
            }

            start = pos + 1;
        }
    }

    return loader;
}



static jobject createDexClassLoader(JNIEnv *env, jobject context, jobjectArray dexBuffers) {
    jclass clsContext = env->GetObjectClass(context);

    jmethodID midGetClassLoader = env->GetMethodID(
            clsContext,
            "getClassLoader",
            "()Ljava/lang/ClassLoader;"
    );

    jobject parentClassLoader = env->CallObjectMethod(context, midGetClassLoader);
    if (checkException(env, "获取父 ClassLoader")) {
        return nullptr;
    }

    jmethodID midGetApplicationInfo = env->GetMethodID(
            clsContext,
            "getApplicationInfo",
            "()Landroid/content/pm/ApplicationInfo;"
    );

    jobject appInfo = env->CallObjectMethod(context, midGetApplicationInfo);
    if (checkException(env, "获取 ApplicationInfo") || appInfo == nullptr) {
        return nullptr;
    }

    jclass clsApplicationInfo = env->FindClass("android/content/pm/ApplicationInfo");
    jfieldID fidNativeLibraryDir = env->GetFieldID(
            clsApplicationInfo,
            "nativeLibraryDir",
            "Ljava/lang/String;"
    );

    jstring nativeLibDir = (jstring) env->GetObjectField(appInfo, fidNativeLibraryDir);
    if (nativeLibDir == nullptr) {
        return nullptr;
    }

    int sdk = getSdkInt(env);

    if (sdk >= 26) {
        jclass clsLoader = env->FindClass("dalvik/system/InMemoryDexClassLoader");
        if (clsLoader == nullptr) {
            return nullptr;
        }

        jmethodID initMethod = env->GetMethodID(
                clsLoader,
                "<init>",
                "([Ljava/nio/ByteBuffer;Ljava/lang/String;Ljava/lang/ClassLoader;)V"
        );

        if (initMethod == nullptr) {
            return nullptr;
        }

        jobject loader = env->NewObject(
                clsLoader,
                initMethod,
                dexBuffers,
                nativeLibDir,
                parentClassLoader
        );

        if (checkException(env, "创建系统 InMemoryDexClassLoader")) {
            return nullptr;
        }

        return loader;
    }

    return createFileDexClassLoader(env, context, dexBuffers, parentClassLoader);
}

/**
 * 替换 LoadedApk.mClassLoader
 */
static bool replaceLoadedApkClassLoader(JNIEnv *env, jobject context, jobject newClassLoader) {
    jclass clsActivityThread = env->FindClass("android/app/ActivityThread");
    jclass clsMap = env->FindClass("java/util/Map");
    jclass clsReference = env->FindClass("java/lang/ref/Reference");
    jclass clsLoadedApk = env->FindClass("android/app/LoadedApk");

    if (!clsActivityThread || !clsMap || !clsReference || !clsLoadedApk) {
        //LOGE("查找系统类失败");
        return false;
    }

    jmethodID midCurrentActivityThread = env->GetStaticMethodID(
            clsActivityThread,
            "currentActivityThread",
            "()Landroid/app/ActivityThread;"
    );

    jobject currentActivityThread = env->CallStaticObjectMethod(clsActivityThread, midCurrentActivityThread);
    if (checkException(env, "获取 currentActivityThread")) {
        return false;
    }

    if (currentActivityThread == nullptr) {
        //LOGE("currentActivityThread 为空");
        return false;
    }

    jfieldID fidPackages = env->GetFieldID(
            clsActivityThread,
            "mPackages",
            "Landroid/util/ArrayMap;"
    );

    jobject mPackages = env->GetObjectField(currentActivityThread, fidPackages);
    if (mPackages == nullptr) {
        //LOGE("mPackages 为空");
        return false;
    }

    jstring packageName = getPackageName(env, context);

    jmethodID midMapGet = env->GetMethodID(
            clsMap,
            "get",
            "(Ljava/lang/Object;)Ljava/lang/Object;"
    );

    jobject weakRefLoadedApk = env->CallObjectMethod(mPackages, midMapGet, packageName);
    if (checkException(env, "从 mPackages 获取 LoadedApk 引用")) {
        return false;
    }

    if (weakRefLoadedApk == nullptr) {
        //LOGE("LoadedApk 弱引用为空");
        return false;
    }

    jmethodID midReferenceGet = env->GetMethodID(
            clsReference,
            "get",
            "()Ljava/lang/Object;"
    );

    jobject loadedApk = env->CallObjectMethod(weakRefLoadedApk, midReferenceGet);
    if (loadedApk == nullptr) {
        //LOGE("LoadedApk 为空");
        return false;
    }

    jfieldID fidClassLoader = env->GetFieldID(
            clsLoadedApk,
            "mClassLoader",
            "Ljava/lang/ClassLoader;"
    );

    env->SetObjectField(loadedApk, fidClassLoader, newClassLoader);

    //LOGI("替换 LoadedApk.mClassLoader 成功");
    return true;
}

static jobject getPackageLoadedApk(JNIEnv *env, jobject context) {
    jclass clsActivityThread = env->FindClass("android/app/ActivityThread");
    jclass clsMap = env->FindClass("java/util/Map");
    jclass clsReference = env->FindClass("java/lang/ref/Reference");

    if (!clsActivityThread || !clsMap || !clsReference) {
        env->ExceptionClear();
        return nullptr;
    }

    jmethodID midCurrentActivityThread = env->GetStaticMethodID(
            clsActivityThread,
            "currentActivityThread",
            "()Landroid/app/ActivityThread;"
    );

    jobject currentActivityThread = env->CallStaticObjectMethod(
            clsActivityThread,
            midCurrentActivityThread
    );

    if (checkException(env, "获取 currentActivityThread") || currentActivityThread == nullptr) {
        return nullptr;
    }

    jfieldID fidPackages = env->GetFieldID(
            clsActivityThread,
            "mPackages",
            "Landroid/util/ArrayMap;"
    );

    jobject mPackages = env->GetObjectField(currentActivityThread, fidPackages);
    if (mPackages == nullptr) {
        return nullptr;
    }

    jstring packageName = getPackageName(env, context);
    if (packageName == nullptr) {
        return nullptr;
    }

    jmethodID midMapGet = env->GetMethodID(
            clsMap,
            "get",
            "(Ljava/lang/Object;)Ljava/lang/Object;"
    );

    jobject weakRefLoadedApk = env->CallObjectMethod(mPackages, midMapGet, packageName);
    if (checkException(env, "获取 mPackages LoadedApk 弱引用") || weakRefLoadedApk == nullptr) {
        return nullptr;
    }

    jmethodID midReferenceGet = env->GetMethodID(
            clsReference,
            "get",
            "()Ljava/lang/Object;"
    );

    jobject loadedApk = env->CallObjectMethod(weakRefLoadedApk, midReferenceGet);
    if (checkException(env, "获取 mPackages LoadedApk") || loadedApk == nullptr) {
        return nullptr;
    }

    return loadedApk;
}

// 【新增修复】同步替换 ActivityThread.mPackages 中的 LoadedApk.mApplication
// 目的：避免部分 Context / Activity 仍然从 mPackages 对应的 LoadedApk 拿到 StubApp
static bool replacePackageLoadedApkApplication(JNIEnv *env, jobject context, jobject realApplication) {
    jclass clsActivityThread = env->FindClass("android/app/ActivityThread");
    jclass clsMap = env->FindClass("java/util/Map");
    jclass clsReference = env->FindClass("java/lang/ref/Reference");
    jclass clsLoadedApk = env->FindClass("android/app/LoadedApk");

    if (!clsActivityThread || !clsMap || !clsReference || !clsLoadedApk) {
        //LOGE("替换 mPackages Application 时查找系统类失败");
        return false;
    }

    jmethodID midCurrentActivityThread = env->GetStaticMethodID(
            clsActivityThread,
            "currentActivityThread",
            "()Landroid/app/ActivityThread;"
    );

    jobject currentActivityThread = env->CallStaticObjectMethod(
            clsActivityThread,
            midCurrentActivityThread
    );

    if (checkException(env, "获取 currentActivityThread") || currentActivityThread == nullptr) {
        return false;
    }

    jfieldID fidPackages = env->GetFieldID(
            clsActivityThread,
            "mPackages",
            "Landroid/util/ArrayMap;"
    );

    jobject mPackages = env->GetObjectField(currentActivityThread, fidPackages);
    if (mPackages == nullptr) {
        //LOGE("mPackages 为空，无法同步替换 Application");
        return false;
    }

    jstring packageName = getPackageName(env, context);
    if (packageName == nullptr) {
        //LOGE("获取包名失败，无法同步替换 Application");
        return false;
    }

    jmethodID midMapGet = env->GetMethodID(
            clsMap,
            "get",
            "(Ljava/lang/Object;)Ljava/lang/Object;"
    );

    jobject weakRefLoadedApk = env->CallObjectMethod(mPackages, midMapGet, packageName);
    if (checkException(env, "从 mPackages 获取 LoadedApk 弱引用") || weakRefLoadedApk == nullptr) {
        //LOGE("mPackages 中 LoadedApk 弱引用为空");
        return false;
    }

    jmethodID midReferenceGet = env->GetMethodID(
            clsReference,
            "get",
            "()Ljava/lang/Object;"
    );

    jobject packageLoadedApk = env->CallObjectMethod(weakRefLoadedApk, midReferenceGet);
    if (checkException(env, "从弱引用获取 LoadedApk") || packageLoadedApk == nullptr) {
        //LOGE("mPackages 中 LoadedApk 为空");
        return false;
    }

    jfieldID fidLoadedApkApplication = env->GetFieldID(
            clsLoadedApk,
            "mApplication",
            "Landroid/app/Application;"
    );

    if (fidLoadedApkApplication == nullptr || env->ExceptionCheck()) {
        env->ExceptionClear();
        //LOGE("获取 LoadedApk.mApplication 字段失败");
        return false;
    }

    env->SetObjectField(packageLoadedApk, fidLoadedApkApplication, realApplication);

    if (checkException(env, "替换 mPackages LoadedApk.mApplication")) {
        return false;
    }

    //LOGI("同步替换 mPackages LoadedApk.mApplication 成功");
    return true;
}

static void replaceAllActivityApplication(JNIEnv *env, jobject realApplication) {
    jclass clsActivityThread = env->FindClass("android/app/ActivityThread");
    jclass clsMap = env->FindClass("java/util/Map");
    jclass clsCollection = env->FindClass("java/util/Collection");
    jclass clsIterator = env->FindClass("java/util/Iterator");
    jclass clsActivity = env->FindClass("android/app/Activity");

    jmethodID midCurrentActivityThread = env->GetStaticMethodID(
            clsActivityThread,
            "currentActivityThread",
            "()Landroid/app/ActivityThread;"
    );

    jobject currentActivityThread = env->CallStaticObjectMethod(
            clsActivityThread,
            midCurrentActivityThread
    );

    jfieldID fidActivities = env->GetFieldID(
            clsActivityThread,
            "mActivities",
            "Landroid/util/ArrayMap;"
    );

    jobject mActivities = env->GetObjectField(currentActivityThread, fidActivities);
    if (mActivities == nullptr) {
        return;
    }

    jmethodID midValues = env->GetMethodID(
            clsMap,
            "values",
            "()Ljava/util/Collection;"
    );

    jobject values = env->CallObjectMethod(mActivities, midValues);

    jmethodID midIterator = env->GetMethodID(
            clsCollection,
            "iterator",
            "()Ljava/util/Iterator;"
    );

    jobject iterator = env->CallObjectMethod(values, midIterator);

    jmethodID midHasNext = env->GetMethodID(
            clsIterator,
            "hasNext",
            "()Z"
    );

    jmethodID midNext = env->GetMethodID(
            clsIterator,
            "next",
            "()Ljava/lang/Object;"
    );

    while (env->CallBooleanMethod(iterator, midHasNext)) {
        jobject activityClientRecord = env->CallObjectMethod(iterator, midNext);
        if (activityClientRecord == nullptr) {
            continue;
        }

        jclass clsRecord = env->GetObjectClass(activityClientRecord);

        jfieldID fidActivity = env->GetFieldID(
                clsRecord,
                "activity",
                "Landroid/app/Activity;"
        );

        if (env->ExceptionCheck() || fidActivity == nullptr) {
            env->ExceptionClear();
            continue;
        }

        jobject activity = env->GetObjectField(activityClientRecord, fidActivity);
        if (activity == nullptr) {
            continue;
        }

        jfieldID fidApplication = env->GetFieldID(
                clsActivity,
                "mApplication",
                "Landroid/app/Application;"
        );

        if (env->ExceptionCheck() || fidApplication == nullptr) {
            env->ExceptionClear();
            continue;
        }

        env->SetObjectField(activity, fidApplication, realApplication);
        env->ExceptionClear();
    }
}
/**
 * 启动真实 Application
 *
 * 【修复点】
 * 1. 参数增加 context，用于同步修复 mPackages 中的 LoadedApk.mApplication
 * 2. makeApplication 后同时替换：
 *    - boundApplication.info.mApplication
 *    - ActivityThread.mInitialApplication
 *    - ActivityThread.mPackages[packageName].get().mApplication
 *    - 已存在 Activity.mApplication
 * 3. 避免 Activity.getApplication() / getApplicationContext() 仍然拿到 StubApp
 */
static bool startRealApplication(JNIEnv *env, jobject context) {
    if (env == nullptr || context == nullptr) {
        return false;
    }

    jclass clsActivityThread = env->FindClass("android/app/ActivityThread");
    jclass clsAppBindData = env->FindClass("android/app/ActivityThread$AppBindData");
    jclass clsApplicationInfo = env->FindClass("android/content/pm/ApplicationInfo");
    jclass clsLoadedApk = env->FindClass("android/app/LoadedApk");
    jclass clsApplication = env->FindClass("android/app/Application");
    jclass clsList = env->FindClass("java/util/List");
    jclass clsClassLoader = env->FindClass("java/lang/ClassLoader");
    jclass clsClass = env->FindClass("java/lang/Class");

    if (!clsActivityThread || !clsAppBindData || !clsApplicationInfo
        || !clsLoadedApk || !clsApplication || !clsList
        || !clsClassLoader || !clsClass) {
        env->ExceptionClear();
        return false;
    }

    jmethodID midCurrentActivityThread = env->GetStaticMethodID(
            clsActivityThread,
            "currentActivityThread",
            "()Landroid/app/ActivityThread;"
    );

    jobject currentActivityThread = env->CallStaticObjectMethod(
            clsActivityThread,
            midCurrentActivityThread
    );

    if (checkException(env, "获取 currentActivityThread") || currentActivityThread == nullptr) {
        return false;
    }

    jfieldID fidBoundApplication = env->GetFieldID(
            clsActivityThread,
            "mBoundApplication",
            "Landroid/app/ActivityThread$AppBindData;"
    );

    jobject boundApplication = env->GetObjectField(currentActivityThread, fidBoundApplication);
    if (boundApplication == nullptr) {
        return false;
    }

    jfieldID fidInfo = env->GetFieldID(
            clsAppBindData,
            "info",
            "Landroid/app/LoadedApk;"
    );

    jobject loadedApk = env->GetObjectField(boundApplication, fidInfo);
    if (loadedApk == nullptr) {
        return false;
    }

    jobject packageLoadedApk = getPackageLoadedApk(env, context);

    jfieldID fidLoadedApkApplication = env->GetFieldID(
            clsLoadedApk,
            "mApplication",
            "Landroid/app/Application;"
    );

    jfieldID fidLoadedApkApplicationInfo = env->GetFieldID(
            clsLoadedApk,
            "mApplicationInfo",
            "Landroid/content/pm/ApplicationInfo;"
    );

    jfieldID fidClassLoader = env->GetFieldID(
            clsLoadedApk,
            "mClassLoader",
            "Ljava/lang/ClassLoader;"
    );

    jfieldID fidInitialApplication = env->GetFieldID(
            clsActivityThread,
            "mInitialApplication",
            "Landroid/app/Application;"
    );

    jfieldID fidAllApplications = env->GetFieldID(
            clsActivityThread,
            "mAllApplications",
            "Ljava/util/ArrayList;"
    );

    jfieldID fidAppInfo = env->GetFieldID(
            clsAppBindData,
            "appInfo",
            "Landroid/content/pm/ApplicationInfo;"
    );

    jfieldID fidClassName = env->GetFieldID(
            clsApplicationInfo,
            "className",
            "Ljava/lang/String;"
    );

    if (env->ExceptionCheck()
        || fidLoadedApkApplication == nullptr
        || fidLoadedApkApplicationInfo == nullptr
        || fidClassLoader == nullptr
        || fidInitialApplication == nullptr
        || fidAllApplications == nullptr
        || fidAppInfo == nullptr
        || fidClassName == nullptr) {
        env->ExceptionClear();
        return false;
    }

    if (gRealApplicationName.empty()) {
        return false;
    }

    std::string realAppNameStr = gRealApplicationName;
    for (size_t i = 0; i < realAppNameStr.length(); i++) {
        if (realAppNameStr[i] == '/') {
            realAppNameStr[i] = '.';
        }
    }

    jstring realAppName = env->NewStringUTF(realAppNameStr.c_str());
    if (realAppName == nullptr) {
        return false;
    }

    jobject oldApplication = env->GetObjectField(currentActivityThread, fidInitialApplication);
    jobject allApplications = env->GetObjectField(currentActivityThread, fidAllApplications);

    if (oldApplication != nullptr && allApplications != nullptr) {
        jmethodID midRemoveObject = env->GetMethodID(
                clsList,
                "remove",
                "(Ljava/lang/Object;)Z"
        );

        if (midRemoveObject != nullptr) {
            env->CallBooleanMethod(allApplications, midRemoveObject, oldApplication);
            checkException(env, "移除旧 Application");
        }
    }

    env->SetObjectField(loadedApk, fidLoadedApkApplication, nullptr);
    checkException(env, "清空 boundApplication LoadedApk.mApplication");

    if (packageLoadedApk != nullptr) {
        env->SetObjectField(packageLoadedApk, fidLoadedApkApplication, nullptr);
        checkException(env, "清空 package LoadedApk.mApplication");
    }

    jobject loadedApkApplicationInfo = env->GetObjectField(
            loadedApk,
            fidLoadedApkApplicationInfo
    );

    if (loadedApkApplicationInfo != nullptr) {
        env->SetObjectField(loadedApkApplicationInfo, fidClassName, realAppName);
    }

    if (packageLoadedApk != nullptr) {
        jobject packageLoadedApkApplicationInfo = env->GetObjectField(
                packageLoadedApk,
                fidLoadedApkApplicationInfo
        );

        if (packageLoadedApkApplicationInfo != nullptr) {
            env->SetObjectField(packageLoadedApkApplicationInfo, fidClassName, realAppName);
        }
    }

    jobject appInfo = env->GetObjectField(boundApplication, fidAppInfo);
    if (appInfo != nullptr) {
        env->SetObjectField(appInfo, fidClassName, realAppName);
    }

    if (checkException(env, "设置真实 Application className")) {
        return false;
    }

    jobject classLoader = env->GetObjectField(loadedApk, fidClassLoader);
    if (classLoader == nullptr && packageLoadedApk != nullptr) {
        classLoader = env->GetObjectField(packageLoadedApk, fidClassLoader);
    }

    if (classLoader == nullptr) {
        return false;
    }

    jmethodID midLoadClass = env->GetMethodID(
            clsClassLoader,
            "loadClass",
            "(Ljava/lang/String;)Ljava/lang/Class;"
    );

    if (midLoadClass == nullptr || env->ExceptionCheck()) {
        env->ExceptionClear();
        return false;
    }

    jobject realAppClass = env->CallObjectMethod(
            classLoader,
            midLoadClass,
            realAppName
    );

    if (checkException(env, "加载真实 Application 类") || realAppClass == nullptr) {
        return false;
    }

    jmethodID midNewInstance = env->GetMethodID(
            clsClass,
            "newInstance",
            "()Ljava/lang/Object;"
    );

    if (midNewInstance == nullptr || env->ExceptionCheck()) {
        env->ExceptionClear();
        return false;
    }

    jobject realApplication = env->CallObjectMethod(
            realAppClass,
            midNewInstance
    );

    if (checkException(env, "创建真实 Application 实例") || realApplication == nullptr) {
        return false;
    }

    env->SetObjectField(loadedApk, fidLoadedApkApplication, realApplication);

    if (packageLoadedApk != nullptr) {
        env->SetObjectField(packageLoadedApk, fidLoadedApkApplication, realApplication);
    }

    env->SetObjectField(currentActivityThread, fidInitialApplication, realApplication);

    if (checkException(env, "替换 Application 引用")) {
        return false;
    }

    jmethodID midAttach = env->GetMethodID(
            clsApplication,
            "attach",
            "(Landroid/content/Context;)V"
    );

    if (midAttach == nullptr || env->ExceptionCheck()) {
        env->ExceptionClear();
        return false;
    }

    env->CallVoidMethod(
            realApplication,
            midAttach,
            context
    );

    if (checkException(env, "调用真实 Application.attach")) {
        return false;
    }

    replacePackageLoadedApkApplication(env, context, realApplication);
    replaceAllActivityApplication(env, realApplication);

    jmethodID midOnCreate = env->GetMethodID(
            clsApplication,
            "onCreate",
            "()V"
    );

    if (midOnCreate == nullptr || env->ExceptionCheck()) {
        env->ExceptionClear();
        return false;
    }

    env->CallVoidMethod(realApplication, midOnCreate);
    if (checkException(env, "调用真实 Application.onCreate")) {
        return false;
    }

    return true;
}




/**
 * Native 层 Dex 加载入口
 *
 * 【修复点】
 * 这里只负责：
 * 1. 解密 dex
 * 2. 创建 ClassLoader
 * 3. 替换 LoadedApk.mClassLoader
 *
 * 不要在这里启动真实 Application。
 */
bool LoaderDEX(JNIEnv *env, jobject context) {
    if (gArkDexLoaded) {
        //LOGI("attach 阶段发现 DEX 已加载，跳过重复加载");
        return true;
    }

    if (env == nullptr || context == nullptr) {
        //LOGE("attach 加载 dex 失败：env 或 context 为空");
        return false;
    }

    jobjectArray dexBuffers = loadDexBuffersFromSelfClassesDex(env, context);
    if (dexBuffers == nullptr) {
        //LOGE("attach 从自身 classes.dex 解密加载 dex 失败");
        return false;
    }

    jobject newClassLoader = createDexClassLoader(env, context, dexBuffers);
    if (newClassLoader == nullptr) {
        //LOGE("attach 创建新的 ClassLoader 失败");
        return false;
    }

    if (!replaceLoadedApkClassLoader(env, context, newClassLoader)) {
        //LOGE("attach 替换 ClassLoader 失败");
        return false;
    }

    gArkDexLoaded = true;

    //LOGI("attach 加载 dex 成功");
    return true;
}
/**
 * Native 层启动真实 Application 入口
 *
 * 【新增修复】
 * 这个方法给 StubApp.onCreate 调用。
 */
bool StartRealApplicationFromNative(JNIEnv *env, jobject context) {
    static bool sRealApplicationStarted = false;

    //LOGI("开始执行 StartRealApplicationFromNative");

    if (sRealApplicationStarted) {
        //LOGI("真实 Application 已启动，跳过重复启动");
        return true;
    }

    if (!startRealApplication(env, context)) {
        //LOGE("启动真实 Application 失败");
        return false;
    }

    sRealApplicationStarted = true;

    //LOGI("StartRealApplicationFromNative 执行完成");
    return true;
}
ArkDexLoaderFunc ArkDexLoader_GetEntry() {
    volatile ArkDexLoaderFunc fn = LoaderDEX;
    return fn;
}

ArkDexLoaderFactoryFunc ArkDexLoader_GetFactoryEntry() {
    volatile ArkDexLoaderFactoryFunc fn = LoaderDEXFromFactory;
    return fn;
}

ArkRealApplicationStarterFunc ArkDexLoader_GetStartRealApplicationEntry() {
    volatile ArkRealApplicationStarterFunc fn = StartRealApplicationFromNative;
    return fn;
}

const char *ArkDexLoader_GetRealAppComponentFactoryName() {
    if (gRealAppComponentFactoryName.empty()) {
        return nullptr;
    }
    return gRealAppComponentFactoryName.c_str();
}