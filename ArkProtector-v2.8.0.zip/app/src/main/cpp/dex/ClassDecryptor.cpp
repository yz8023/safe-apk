#include "ClassDecryptor.h"
#include "../crypt/WhiteBoxDecrypt.h"
#include "../crypt/DynamicKeyGenerator.h"
#include <cstring>
#include <algorithm>

namespace ArkVMP {

ClassDecryptor::ClassDecryptor() : m_keySet(false) {
    memset(m_key, 0, sizeof(m_key));
    LOGI("ClassDecryptor初始化完成");
}

ClassDecryptor::~ClassDecryptor() {
    clearCache();
}

bool ClassDecryptor::initializeClassIndex(const unsigned char* dexData, size_t dexSize) {
    // 这里应该解析DEX文件，提取类的索引信息
    // 为了示例，我们使用简化的实现
    
    LOGI("初始化类索引，DEX大小: %zu 字节", dexSize);
    
    // 在实际应用中，这里需要：
    // 1. 解析DEX文件头部
    // 2. 读取类定义列表
    // 3. 为每个类创建ClassIndex条目
    // 4. 加载加密的类数据偏移和大小
    
    // 示例：创建一个测试类索引
    ClassIndex testIndex;
    testIndex.className = "Lcom/example/Test;";
    testIndex.offset = 0x1000;
    testIndex.encryptedSize = 512;
    testIndex.plainSize = 480;
    testIndex.crc32 = 0x12345678;
    testIndex.keyIndex = 0;
    
    m_classIndex[testIndex.className] = testIndex;
    
    LOGI("类索引初始化完成，类数量: %zu", m_classIndex.size());
    return true;
}

jbyteArray ClassDecryptor::decryptClass(JNIEnv* env, const std::string& className) {
    if (env == nullptr || className.empty()) {
        LOGE("参数无效");
        return nullptr;
    }
    
    // 检查缓存
    auto cacheIt = m_cache.find(className);
    if (cacheIt != m_cache.end()) {
        LOGI("从缓存加载类: %s", className.c_str());
        const std::vector<uint8_t>& cachedData = cacheIt->second;
        jbyteArray result = env->NewByteArray(cachedData.size());
        env->SetByteArrayRegion(result, 0, cachedData.size(), 
                                reinterpret_cast<const jbyte*>(cachedData.data()));
        return result;
    }
    
    // 查找类索引
    auto it = m_classIndex.find(className);
    if (it == m_classIndex.end()) {
        LOGE("类索引不存在: %s", className.c_str());
        return nullptr;
    }
    
    const ClassIndex& index = it->second;
    
    // 读取加密数据
    std::vector<uint8_t> encryptedData(index.encryptedSize);
    if (!readEncryptedData(index.offset, index.encryptedSize, encryptedData.data())) {
        LOGE("读取加密数据失败: %s", className.c_str());
        return nullptr;
    }
    
    // 生成解密密钥
    unsigned char decryptKey[32];
    if (m_keySet) {
        memcpy(decryptKey, m_key, 32);
    } else {
        // 使用白盒密钥
        WhiteBoxDecrypt::getKeyFromWhiteBox(decryptKey, index.keyIndex);
    }
    
    // 解密数据
    std::vector<uint8_t> plainData(index.plainSize);
    if (!aesDecrypt(encryptedData.data(), index.encryptedSize, decryptKey, plainData.data())) {
        LOGE("解密失败: %s", className.c_str());
        return nullptr;
    }
    
    // 校验CRC
    uint32_t calculatedCRC = calculateCRC32(plainData.data(), plainData.size());
    if (calculatedCRC != index.crc32) {
        LOGE("CRC校验失败: %s (期望: 0x%08X, 实际: 0x%08X)", 
             className.c_str(), index.crc32, calculatedCRC);
        return nullptr;
    }
    
    // 缓存解密数据
    if (m_cache.size() >= MAX_CACHE_SIZE) {
        // 移除最旧的条目
        auto oldestIt = m_cache.begin();
        m_cache.erase(oldestIt);
    }
    m_cache[className] = plainData;
    
    // 转换为Java字节数组
    jbyteArray result = env->NewByteArray(plainData.size());
    env->SetByteArrayRegion(result, 0, plainData.size(), 
                            reinterpret_cast<const jbyte*>(plainData.data()));
    
    LOGI("成功解密类: %s, 大小: %u 字节", className.c_str(), plainData.size());
    return result;
}

void ClassDecryptor::setDecryptionKey(const unsigned char* key, size_t keySize) {
    if (key != nullptr && keySize >= 32) {
        memcpy(m_key, key, 32);
        m_keySet = true;
        LOGI("解密密钥已设置");
    }
}

void ClassDecryptor::clearCache() {
    m_cache.clear();
    LOGI("缓存已清除");
}

uint32_t ClassDecryptor::calculateCRC32(const unsigned char* data, size_t size) {
    // 简化的CRC32实现
    // 实际应用中应该使用标准的CRC32算法
    uint32_t crc = 0xFFFFFFFF;
    
    for (size_t i = 0; i < size; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 1) {
                crc = (crc >> 1) ^ 0xEDB88320;
            } else {
                crc >>= 1;
            }
        }
    }
    
    return ~crc;
}

bool ClassDecryptor::readEncryptedData(uint64_t offset, size_t size, unsigned char* out) {
    // 这里应该从实际的DEX文件或内存中读取加密数据
    // 为了示例，我们使用模拟数据
    
    // 在实际应用中，这里需要：
    // 1. 打开DEX文件
    // 2. 定位到指定偏移
    // 3. 读取加密数据
    
    // 示例：填充模拟数据
    memset(out, 0xAA, size);
    
    return true;
}

bool ClassDecryptor::aesDecrypt(const unsigned char* ciphertext, size_t cipherSize,
                                const unsigned char* key, unsigned char* plaintext) {
    if (ciphertext == nullptr || key == nullptr || plaintext == nullptr) {
        return false;
    }
    
    if (cipherSize % 16 != 0) {
        LOGE("密文长度不是16的倍数");
        return false;
    }
    
    // 使用简化的AES解密（避免OpenSSL依赖）
    // CBC模式，IV取密钥前16字节
    unsigned char iv[16];
    memcpy(iv, key, 16);
    
    // 简化实现：逐块解密
    for (size_t i = 0; i < cipherSize; i += 16) {
        // XOR解密（简化实现）
        for (int j = 0; j < 16; j++) {
            plaintext[i + j] = ciphertext[i + j] ^ key[j % 16];
        }
        
        // CBC模式：与前一个密文块进行XOR
        if (i > 0) {
            for (int j = 0; j < 16; j++) {
                plaintext[i + j] ^= ciphertext[i - 16 + j];
            }
        } else {
            // 第一个块与IV进行XOR
            for (int j = 0; j < 16; j++) {
                plaintext[i + j] ^= iv[j];
            }
        }
    }
    
    return true;
}

} // namespace ArkVMP

// JNI接口
extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_ark_secure_SecureClassLoader_decryptClassData(
    JNIEnv* env,
    jclass clazz,
    jstring className) {
    
    if (className == nullptr) {
        return nullptr;
    }
    
    const char* classNameStr = env->GetStringUTFChars(className, nullptr);
    if (classNameStr == nullptr) {
        return nullptr;
    }
    
    std::string classNameCpp(classNameStr);
    env->ReleaseStringUTFChars(className, classNameStr);
    
    static ArkVMP::ClassDecryptor decryptor;
    return decryptor.decryptClass(env, classNameCpp);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_ark_secure_SecureClassLoader_freeClassData(
    JNIEnv* env,
    jclass clazz,
    jbyteArray data) {
    // Java层的字节数组会自动被垃圾回收
    // 这里不需要做任何操作
}