#ifndef CLASS_DECRYPTOR_H
#define CLASS_DECRYPTOR_H

#include <jni.h>
#include <string>
#include <vector>
#include <map>
#include <cstdint>
#include <android/log.h>

#define LOG_TAG "ArkVMP_ClassDecryptor"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

// 类索引信息
struct ClassIndex {
    std::string className;
    uint64_t offset;
    uint32_t encryptedSize;
    uint32_t plainSize;
    uint32_t crc32;
    uint32_t keyIndex;
};

class ClassDecryptor {
public:
    ClassDecryptor();
    ~ClassDecryptor();
    
    // 初始化类索引
    bool initializeClassIndex(const unsigned char* dexData, size_t dexSize);
    
    // 解密类数据
    jbyteArray decryptClass(JNIEnv* env, const std::string& className);
    
    // 设置解密密钥
    void setDecryptionKey(const unsigned char* key, size_t keySize);
    
    // 清除缓存
    void clearCache();
    
private:
    // DEX文件映射
    std::map<std::string, ClassIndex> m_classIndex;
    
    // 解密密钥
    unsigned char m_key[32];
    bool m_keySet;
    
    // 类数据缓存
    std::map<std::string, std::vector<uint8_t>> m_cache;
    static const size_t MAX_CACHE_SIZE = 50;
    
    // 计算CRC32
    uint32_t calculateCRC32(const unsigned char* data, size_t size);
    
    // 读取加密数据
    bool readEncryptedData(uint64_t offset, size_t size, unsigned char* out);
    
    // AES解密
    bool aesDecrypt(const unsigned char* ciphertext, size_t cipherSize,
                    const unsigned char* key, unsigned char* plaintext);
};

} // namespace ArkVMP

#endif // CLASS_DECRYPTOR_H