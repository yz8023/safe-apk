#include "DexIntegrity.h"
#include <cstring>

// 简化的SHA1实现（避免OpenSSL依赖）
namespace {
    // 简化的SHA1实现（仅用于演示）
    void sha1(const unsigned char* data, size_t len, unsigned char* hash) {
        // 简化实现：使用简单的哈希算法
        // 实际应用中应该使用完整的SHA1算法
        memset(hash, 0, 20);
        
        for (size_t i = 0; i < len && i < 20; i++) {
            hash[i % 20] ^= data[i];
        }
        
        // 简单的混淆
        for (int i = 0; i < 20; i++) {
            hash[i] = (hash[i] ^ (i * 7)) & 0xFF;
        }
    }
}

namespace ArkVMP {

// DEX文件魔数
static const uint8_t DEX_MAGIC[] = { 0x64, 0x65, 0x78, 0x0A, 0x30, 0x33, 0x35, 0x00 };

DexIntegrity::DexIntegrity() {
    LOGI("DexIntegrity初始化完成");
}

DexIntegrity::~DexIntegrity() {
}

IntegrityCheckResult DexIntegrity::verifyDexHeader(const unsigned char* dexData, size_t size) {
    if (dexData == nullptr || size < 0x70) {
        LOGE("DEX数据为空或大小不足");
        return INTEGRITY_UNKNOWN_ERROR;
    }
    
    // 验证魔数
    if (memcmp(dexData, DEX_MAGIC, sizeof(DEX_MAGIC)) != 0) {
        LOGE("DEX魔数不匹配");
        return INTEGRITY_BAD_MAGIC;
    }
    
    // 验证校验和
    if (!verifyChecksum(dexData, size)) {
        LOGE("DEX校验和验证失败");
        return INTEGRITY_CHECKSUM_FAILED;
    }
    
    // 验证签名
    if (!verifySignature(dexData, size)) {
        LOGE("DEX签名验证失败");
        return INTEGRITY_SIGNATURE_FAILED;
    }
    
    LOGI("DEX头部验证通过");
    return INTEGRITY_OK;
}

bool DexIntegrity::verifyChecksum(const unsigned char* dexData, size_t size) {
    if (dexData == nullptr || size < 12) {
        return false;
    }
    
    // 读取存储的校验和
    uint32_t storedChecksum = 0;
    storedChecksum |= dexData[8];
    storedChecksum |= (dexData[9] << 8);
    storedChecksum |= (dexData[10] << 16);
    storedChecksum |= (dexData[11] << 24);
    
    // 计算校验和（从字节偏移12开始）
    uint32_t calculatedChecksum = adler32(dexData + 12, size - 12);
    
    if (storedChecksum != calculatedChecksum) {
        LOGW("DEX校验和不匹配: 存储=0x%08X, 计算=0x%08X", storedChecksum, calculatedChecksum);
        return false;
    }
    
    return true;
}

bool DexIntegrity::verifySignature(const unsigned char* dexData, size_t size) {
    if (dexData == nullptr || size < 32) {
        return false;
    }
    
    // 读取存储的签名
    uint8_t storedSignature[20];
    memcpy(storedSignature, dexData + 12, 20);
    
    // 计算签名（从字节偏移32开始）
    uint8_t calculatedSignature[20];
    sha1(dexData + 32, size - 32, calculatedSignature);
    
    if (memcmp(storedSignature, calculatedSignature, 20) != 0) {
        LOGW("DEX签名不匹配");
        return false;
    }
    
    return true;
}

bool DexIntegrity::verifyClassAtRuntime(const unsigned char* classData, size_t classSize, uint32_t expectedCRC) {
    if (classData == nullptr || classSize == 0) {
        LOGE("类数据为空");
        return false;
    }
    
    // 计算当前CRC
    uint32_t calculatedCRC = calculateCRC32(classData, classSize);
    
    if (calculatedCRC != expectedCRC) {
        LOGW("类CRC不匹配: 期望=0x%08X, 实际=0x%08X", expectedCRC, calculatedCRC);
        return false;
    }
    
    return true;
}

uint32_t DexIntegrity::calculateChecksum(const unsigned char* data, size_t size) {
    return adler32(data, size);
}

void DexIntegrity::calculateSHA1(const unsigned char* data, size_t size, unsigned char* hash) {
    sha1(data, size, hash);
}

uint32_t DexIntegrity::calculateCRC32(const unsigned char* data, size_t size) {
    uint32_t crc = 0xFFFFFFFF;
    
    for (size_t i = 0; i < size; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 1) {
                crc = (crc >> 1) ^ 0xEDB88320;
            } else {
                crc >>= 1;
            }
        }
    }
    
    return ~crc;
}

bool DexIntegrity::isDexTampered(const unsigned char* dexData, size_t size) {
    IntegrityCheckResult result = verifyDexHeader(dexData, size);
    return result != INTEGRITY_OK;
}

uint32_t DexIntegrity::adler32(const unsigned char* data, size_t len) {
    const uint32_t MOD_ADLER = 65521;
    uint32_t a = 1, b = 0;
    
    for (size_t i = 0; i < len; i++) {
        a = (a + data[i]) % MOD_ADLER;
        b = (b + a) % MOD_ADLER;
    }
    
    return (b << 16) | a;
}

void DexIntegrity::sha1(const unsigned char* data, size_t len, unsigned char* hash) {
    // 使用命名空间中的简化SHA1实现
    ::sha1(data, len, hash);
}

} // namespace ArkVMP