#ifndef DEX_INTEGRITY_H
#define DEX_INTEGRITY_H

#include <cstdint>
#include <string>
#include <vector>
#include <android/log.h>

#define LOG_TAG "ArkVMP_DexIntegrity"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

// DEX完整性检查结果
enum IntegrityCheckResult {
    INTEGRITY_OK = 0,
    INTEGRITY_BAD_MAGIC = 1,
    INTEGRITY_CHECKSUM_FAILED = 2,
    INTEGRITY_SIGNATURE_FAILED = 3,
    INTEGRITY_TAMPERED = 4,
    INTEGRITY_UNKNOWN_ERROR = 5
};

class DexIntegrity {
public:
    DexIntegrity();
    ~DexIntegrity();
    
    // 验证DEX头部
    static IntegrityCheckResult verifyDexHeader(const unsigned char* dexData, size_t size);
    
    // 验证DEX校验和
    static bool verifyChecksum(const unsigned char* dexData, size_t size);
    
    // 验证DEX签名
    static bool verifySignature(const unsigned char* dexData, size_t size);
    
    // 运行时校验类
    static bool verifyClassAtRuntime(const unsigned char* classData, size_t classSize, uint32_t expectedCRC);
    
    // 计算数据校验和
    static uint32_t calculateChecksum(const unsigned char* data, size_t size);
    
    // 计算数据SHA1
    static void calculateSHA1(const unsigned char* data, size_t size, unsigned char* hash);
    
    // 计算数据CRC32
    static uint32_t calculateCRC32(const unsigned char* data, size_t size);
    
    // 检查DEX是否被篡改
    static bool isDexTampered(const unsigned char* dexData, size_t size);
    
private:
    // Adler32校验和算法
    static uint32_t adler32(const unsigned char* data, size_t len);
    
    // SHA1哈希算法
    static void sha1(const unsigned char* data, size_t len, unsigned char* hash);
};

} // namespace ArkVMP

#endif // DEX_INTEGRITY_H