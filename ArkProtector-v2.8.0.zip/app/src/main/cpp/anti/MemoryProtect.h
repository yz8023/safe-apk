#ifndef MEMORY_PROTECT_H
#define MEMORY_PROTECT_H

#include <cstdint>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <android/log.h>
#include <sys/mman.h>

#define LOG_TAG "ArkVMP_MemoryProtect"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

// 受保护的内存区域
struct ProtectedRegion {
    void* addr;
    size_t size;
    uint32_t crc;
    std::string tag;
    uint32_t protectionFlags;
};

class MemoryProtect {
public:
    MemoryProtect();
    ~MemoryProtect();
    
    // 保护内存区域
    bool protect(void* addr, size_t size, const std::string& tag, uint32_t flags = PROT_READ);
    
    // 取消保护
    bool unprotect(void* addr);
    
    // 校验所有受保护区域
    bool verifyAll();
    
    // 校验单个区域
    bool verify(const ProtectedRegion& region);
    
    // 检测内存断点
    static bool detectBreakpoints();
    
    // 检测函数是否被Hook
    static bool isFunctionHooked(void* func);
    
    // 保护关键函数
    bool protectKeyFunctions();
    
    // 清除所有保护
    void clearAll();
    
    // 获取保护统计信息
    std::string getStats();
    
private:
    std::vector<ProtectedRegion> m_regions;
    std::mutex m_mutex;
    
    // 计算CRC32
    static uint32_t calculateCRC32(const unsigned char* data, size_t size);
    
    // 检查函数是否被修改
    static bool isFunctionModified(void* func);
    
    // 获取关键函数列表
    static std::vector<void*> getKeyFunctions();
    
    // 保护单个函数
    bool protectFunction(void* func, const std::string& name);
    
    // 随机化保护标志
    uint32_t randomizeProtectionFlags();
};

} // namespace ArkVMP

#endif // MEMORY_PROTECT_H