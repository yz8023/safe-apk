#ifndef ANTI_DEBUG_H
#define ANTI_DEBUG_H

#include <cstdint>
#include <string>
#include <vector>
#include <thread>
#include <atomic>
#include <android/log.h>
#include <sys/ptrace.h>
#include <unistd.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define LOG_TAG "ArkVMP_AntiDebug"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

class AntiDebug {
public:
    // 威胁类型
    enum ThreatType {
        THREAT_DEBUGGER = 1,
        THREAT_FRIDA = 2,
        THREAT_XPOSED = 3,
        THREAT_BREAKPOINT = 4,
        THREAT_TRACE = 5,
        THREAT_EMULATOR = 6,
        THREAT_ROOTED = 7
    };
    
    // 威胁处理策略
    enum ThreatAction {
        ACTION_NONE = 0,           // 不处理
        ACTION_LOG = 1,            // 仅记录日志
        ACTION_CRASH = 2,          // 立即崩溃
        ACTION_DELAYED_CRASH = 3,  // 延迟崩溃
        ACTION_MISBEHAVIOR = 4     // 异常行为
    };
    
    AntiDebug();
    ~AntiDebug();
    
    // 启动反调试监控
    void startMonitoring();
    
    // 停止反调试监控
    void stopMonitoring();
    
    // 设置威胁处理策略
    void setThreatAction(ThreatType type, ThreatAction action);
    
    // 手动检测所有威胁
    bool detectAllThreats();
    
    // 检查是否在调试器中运行
    static bool isDebuggerAttached();
    
    // 检查Frida注入
    static bool isFridaInjected();
    
    // 检查Xposed注入
    static bool isXposedInjected();
    
    // 检查内存断点
    static bool hasMemoryBreakpoint();
    
    // 检查Trace
    static bool isTraced();
    
    // 检查模拟器
    static bool isEmulator();
    
    // 检查Root设备
    static bool isRooted();
    
private:
    std::atomic<bool> m_running;
    std::thread m_monitorThread;
    ThreatAction m_threatActions[8];
    
    // 监控线程函数
    void monitorThread();
    
    // 处理检测到的威胁
    void handleDetected(ThreatType type);
    
    // 获取TracerPid
    static int getTracerPid();
    
    // 检查端口
    static bool checkPort(int port);
    
    // 检查进程
    static bool findProcess(const std::string& name);
    
    // 扫描内存模式
    static bool scanMemoryForPattern(const std::string& pattern);
    
    // 检查Frida的D-Bus
    static bool checkFridaDBus();
    
    // 检查Android Studio调试标志
    static bool isAndroidStudioAttached();
    
    // 检查类是否存在
    static bool findClass(const std::string& className);
    
    // 检查文件是否存在
    static bool fileExists(const std::string& path);
    
    // 检查Xposed模块
    static bool findXposedModules();
    
    // 检查函数是否被Hook
    static bool isFunctionHooked(void* func);
    
    // 检查关键函数
    static bool checkKeyFunctions();
    
    // 立即崩溃
    static void crashImmediately();
    
    // 延迟崩溃
    static void delayedCrash(int seconds);
    
    // 触发异常行为
    static void triggerMisbehavior();
    
    // 随机损坏数据
    static void corruptSomeData();
    
    // 生成随机延迟
    static int getRandomDelay(int minMs, int maxMs);
};

} // namespace ArkVMP

#endif // ANTI_DEBUG_H