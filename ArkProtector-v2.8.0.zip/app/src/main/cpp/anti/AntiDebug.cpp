#include "AntiDebug.h"
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <sys/syscall.h>
#include <sys/prctl.h>
#include <dlfcn.h>
#include <jni.h>

namespace ArkVMP {

AntiDebug::AntiDebug() : m_running(false) {
    // 初始化随机数种子 - 修复：避免rand()返回固定值
    srand(time(nullptr));

    // 初始化威胁处理策略
    for (int i = 0; i < 8; i++) {
        m_threatActions[i] = ACTION_LOG;
    }

    // 设置默认策略
    m_threatActions[THREAT_DEBUGGER] = ACTION_DELAYED_CRASH;
    m_threatActions[THREAT_FRIDA] = ACTION_DELAYED_CRASH;
    m_threatActions[THREAT_XPOSED] = ACTION_MISBEHAVIOR;
    m_threatActions[THREAT_BREAKPOINT] = ACTION_CRASH;
    m_threatActions[THREAT_TRACE] = ACTION_DELAYED_CRASH;
    m_threatActions[THREAT_EMULATOR] = ACTION_LOG;
    m_threatActions[THREAT_ROOTED] = ACTION_LOG;

    LOGI("AntiDebug初始化完成");
}

AntiDebug::~AntiDebug() {
    stopMonitoring();
}

void AntiDebug::startMonitoring() {
    if (m_running.load()) {
        LOGW("反调试监控已在运行");
        return;
    }
    
    m_running.store(true);
    m_monitorThread = std::thread(&AntiDebug::monitorThread, this);
    
    LOGI("反调试监控已启动");
}

void AntiDebug::stopMonitoring() {
    if (!m_running.load()) {
        return;
    }
    
    m_running.store(false);
    
    if (m_monitorThread.joinable()) {
        m_monitorThread.join();
    }
    
    LOGI("反调试监控已停止");
}

void AntiDebug::setThreatAction(ThreatType type, ThreatAction action) {
    if (type >= 0 && type < 8) {
        m_threatActions[type] = action;
        LOGI("威胁处理策略已设置: type=%d, action=%d", type, action);
    }
}

bool AntiDebug::detectAllThreats() {
    bool threatDetected = false;
    
    if (isDebuggerAttached()) {
        LOGW("检测到调试器");
        handleDetected(THREAT_DEBUGGER);
        threatDetected = true;
    }
    
    if (isFridaInjected()) {
        LOGW("检测到Frida");
        handleDetected(THREAT_FRIDA);
        threatDetected = true;
    }
    
    if (isXposedInjected()) {
        LOGW("检测到Xposed");
        handleDetected(THREAT_XPOSED);
        threatDetected = true;
    }
    
    if (hasMemoryBreakpoint()) {
        LOGW("检测到内存断点");
        handleDetected(THREAT_BREAKPOINT);
        threatDetected = true;
    }
    
    if (isTraced()) {
        LOGW("检测到Trace");
        handleDetected(THREAT_TRACE);
        threatDetected = true;
    }
    
    if (isEmulator()) {
        LOGW("检测到模拟器");
        handleDetected(THREAT_EMULATOR);
        threatDetected = true;
    }
    
    if (isRooted()) {
        LOGW("检测到Root设备");
        handleDetected(THREAT_ROOTED);
        threatDetected = true;
    }
    
    return threatDetected;
}

void AntiDebug::monitorThread() {
    LOGI("反调试监控线程启动");

    while (m_running.load()) {
        // 检测所有威胁
        detectAllThreats();

        // 修复：增加检测间隔，避免性能问题
        // 从500-1000ms改为5000-10000ms（5-10秒）
        int delay = getRandomDelay(5000, 10000);
        std::this_thread::sleep_for(std::chrono::milliseconds(delay));
    }

    LOGI("反调试监控线程退出");
}

void AntiDebug::handleDetected(ThreatType type) {
    ThreatAction action = m_threatActions[type];
    
    switch (action) {
        case ACTION_NONE:
            break;
        case ACTION_LOG:
            // 仅记录日志，已在检测时完成
            break;
        case ACTION_CRASH:
            LOGW("触发立即崩溃");
            crashImmediately();
            break;
        case ACTION_DELAYED_CRASH:
            LOGW("触发延迟崩溃");
            delayedCrash(rand() % 10 + 5);
            break;
        case ACTION_MISBEHAVIOR:
            LOGW("触发异常行为");
            triggerMisbehavior();
            break;
    }
}

bool AntiDebug::isDebuggerAttached() {
    // 方法1：检查TracerPid
    int tracerPid = getTracerPid();
    if (tracerPid != 0) {
        return true;
    }
    
    // 方法2：检查调试端口
    if (checkPort(5037) || checkPort(5039)) {
        return true;
    }
    
    // 方法3：检查Android Studio调试标志
    if (isAndroidStudioAttached()) {
        return true;
    }
    
    return false;
}

bool AntiDebug::isFridaInjected() {
    // 方法1：检查Frida相关端口
    if (checkPort(27042) || checkPort(27043)) {
        return true;
    }
    
    // 方法2：检查Frida相关进程
    if (findProcess("frida") || findProcess("gum-js-loop")) {
        return true;
    }
    
    // 方法3：检查Frida内存特征
    if (scanMemoryForPattern("frida")) {
        return true;
    }
    
    // 方法4：检查Frida的D-Bus
    if (checkFridaDBus()) {
        return true;
    }
    
    return false;
}

bool AntiDebug::isXposedInjected() {
    // 方法1：检查Xposed相关类
    if (findClass("de/robv/android/xposed/XposedBridge")) {
        return true;
    }
    if (findClass("de/robv/android/xposed/XposedHelpers")) {
        return true;
    }
    
    // 方法2：检查Xposed相关文件
    if (fileExists("/data/data/de.robv.android.xposed.installer")) {
        return true;
    }
    if (fileExists("/data/local/tmp/xposed.prop")) {
        return true;
    }
    
    // 方法3：检查Xposed模块
    if (findXposedModules()) {
        return true;
    }
    
    return false;
}

bool AntiDebug::hasMemoryBreakpoint() {
    // 检查关键函数是否被修改
    return checkKeyFunctions();
}

bool AntiDebug::isTraced() {
    // 修复：移除ptrace调用，避免误报
    // ptrace(PTRACE_TRACEME)在非调试环境下也可能失败
    // 仅依赖TracerPid检测

    // 检查/proc/self/status
    int tracePid = getTracerPid();
    if (tracePid != 0) {
        return true;
    }

    return false;
}

bool AntiDebug::isEmulator() {
    // 修复：移除过于宽泛的检测条件，避免误报
    // 检查明确的模拟器特征

    // 检查QEMU内核特征
    const char* qemu = getenv("qemu");
    if (qemu && strcmp(qemu, "1") == 0) {
        return true;
    }

    // 检查Goldfish硬件（Android模拟器的标准硬件）
    const char* hardware = getenv("HARDWARE");
    if (hardware && strstr(hardware, "goldfish")) {
        return true;
    }

    // 检查Ranchu硬件（新版本Android模拟器）
    if (hardware && strstr(hardware, "ranchu")) {
        return true;
    }

    // 移除对"generic"、"sdk"的检测，这些在真机开发版也可能出现

    return false;
}

bool AntiDebug::isRooted() {
    // 检查su文件
    const char* suPaths[] = {
        "/system/bin/su",
        "/system/xbin/su",
        "/system/sbin/su",
        "/sbin/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/data/local/su"
    };
    
    for (const char* path : suPaths) {
        if (fileExists(path)) {
            return true;
        }
    }
    
    // 检查Build.TAGS
    const char* tags = getenv("BUILD_TAGS");
    if (tags && strstr(tags, "test-keys")) {
        return true;
    }
    
    return false;
}

int AntiDebug::getTracerPid() {
    int tracerPid = 0;
    FILE* fp = fopen("/proc/self/status", "r");
    if (fp) {
        char line[256];
        while (fgets(line, sizeof(line), fp)) {
            if (strncmp(line, "TracerPid:", 10) == 0) {
                sscanf(line + 10, "%d", &tracerPid);
                break;
            }
        }
        fclose(fp); // 确保文件句柄被关闭
    }
    return tracerPid;
}

bool AntiDebug::checkPort(int port) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        return false;
    }
    
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    
    bool result = (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) == 0);
    close(sock);
    
    return result;
}

bool AntiDebug::findProcess(const std::string& name) {
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "pgrep -f %s", name.c_str());
    
    FILE* fp = popen(cmd, "r");
    if (fp) {
        char line[256];
        while (fgets(line, sizeof(line), fp)) {
            if (strlen(line) > 1) {
                pclose(fp);
                return true;
            }
        }
        pclose(fp);
    }
    
    return false;
}

bool AntiDebug::scanMemoryForPattern(const std::string& pattern) {
    // 简化实现：扫描当前进程的内存
    // 实际应用中应该更精确地扫描特定内存区域
    
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) {
        return false;
    }
    
    char line[256];
    while (fgets(line, sizeof(line), fp)) {
        unsigned long start, end;
        if (sscanf(line, "%lx-%lx", &start, &end) == 2) {
            // 这里可以添加实际的内存扫描逻辑
            // 为了示例，我们简化处理
        }
    }
    
    fclose(fp);
    return false;
}

bool AntiDebug::checkFridaDBus() {
    // 检查Frida的D-Bus连接
    return fileExists("/var/run/dbus/system_bus_socket");
}

bool AntiDebug::isAndroidStudioAttached() {
    // 检查Android Studio调试标志
    const char* debuggable = getenv("android.debuggable");
    if (debuggable && strcmp(debuggable, "1") == 0) {
        return true;
    }
    
    return false;
}

bool AntiDebug::findClass(const std::string& className) {
    // 使用JNI检查类是否存在
    // 这里简化实现
    return false;
}

bool AntiDebug::fileExists(const std::string& path) {
    return access(path.c_str(), F_OK) == 0;
}

bool AntiDebug::findXposedModules() {
    // 检查Xposed模块
    return fileExists("/data/data/de.robv.android.xposed.installer/conf/modules.list");
}

bool AntiDebug::isFunctionHooked(void* func) {
    if (func == nullptr) {
        return false;
    }
    
    // 检查前4个字节是否正常
    uint32_t* bytes = (uint32_t*)func;
    
    // 如果前4个字节是0xE51FF004 (ARM的bx指令) 或类似
    // 通常表示被HOOK
    if (*bytes == 0xE51FF004 || *bytes == 0xE59FF000) {
        return true;
    }
    
    // 检查是否是跳转指令
    if ((*bytes & 0xFF000000) == 0xEA000000) {
        return true;
    }
    
    return false;
}

bool AntiDebug::checkKeyFunctions() {
    // 检查关键函数的开头是否被修改
    void* funcs[] = {
        (void*)dlopen,
        (void*)dlsym,
        (void*)malloc,
        (void*)free
    };
    
    for (void* func : funcs) {
        if (isFunctionHooked(func)) {
            return true;
        }
    }
    
    return false;
}

void AntiDebug::crashImmediately() {
    // 制造难以分析的崩溃
    volatile int* p = (volatile int*)0xDEADBEEF;
    *p = 0x12345678; // SIGSEGV
}

void AntiDebug::delayedCrash(int seconds) {
    std::thread([seconds]() {
        std::this_thread::sleep_for(std::chrono::seconds(seconds));
        crashImmediately();
    }).detach();
}

void AntiDebug::triggerMisbehavior() {
    // 随机触发异常行为
    int action = rand() % 100;
    
    if (action < 30) {
        // 30%概率：随机损坏一些数据
        corruptSomeData();
    } else if (action < 40) {
        // 10%概率：随机触发崩溃
        crashImmediately();
    }
    // 其他情况：静默处理
}

void AntiDebug::corruptSomeData() {
    // 随机损坏一些内存数据
    // 这里简化实现
    static char buffer[1024];
    memset(buffer, rand() & 0xFF, sizeof(buffer));
}

int AntiDebug::getRandomDelay(int minMs, int maxMs) {
    return minMs + (rand() % (maxMs - minMs));
}

} // namespace ArkVMP