#include "MemoryProtect.h"
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <dlfcn.h>

namespace ArkVMP {

MemoryProtect::MemoryProtect() {
    LOGI("MemoryProtect初始化完成");
    srand(time(nullptr));
}

MemoryProtect::~MemoryProtect() {
    clearAll();
}

bool MemoryProtect::protect(void* addr, size_t size, const std::string& tag, uint32_t flags) {
    if (addr == nullptr || size == 0) {
        LOGE("无效的内存区域");
        return false;
    }
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    // 计算原始CRC
    uint32_t crc = calculateCRC32(static_cast<const unsigned char*>(addr), size);
    
    // 设置内存保护
    if (mprotect(addr, size, flags) != 0) {
        LOGE("设置内存保护失败: %s", tag.c_str());
        return false;
    }
    
    // 记录保护区域
    ProtectedRegion region;
    region.addr = addr;
    region.size = size;
    region.crc = crc;
    region.tag = tag;
    region.protectionFlags = flags;
    
    m_regions.push_back(region);
    
    LOGI("内存区域已保护: %s, 地址=%p, 大小=%zu, 标志=0x%x", 
         tag.c_str(), addr, size, flags);
    
    return true;
}

bool MemoryProtect::unprotect(void* addr) {
    if (addr == nullptr) {
        return false;
    }
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    for (auto it = m_regions.begin(); it != m_regions.end(); ++it) {
        if (it->addr == addr) {
            // 恢复读写权限
            mprotect(it->addr, it->size, PROT_READ | PROT_WRITE);
            m_regions.erase(it);
            LOGI("内存区域已取消保护: %s", it->tag.c_str());
            return true;
        }
    }
    
    return false;
}

bool MemoryProtect::verifyAll() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    bool allValid = true;
    for (const auto& region : m_regions) {
        if (!verify(region)) {
            allValid = false;
            LOGW("内存区域校验失败: %s", region.tag.c_str());
        }
    }
    
    return allValid;
}

bool MemoryProtect::verify(const ProtectedRegion& region) {
    // 临时设置可读权限
    mprotect(region.addr, region.size, PROT_READ);
    
    // 计算当前CRC
    uint32_t currentCRC = calculateCRC32(
        static_cast<const unsigned char*>(region.addr), 
        region.size
    );
    
    // 恢复保护
    mprotect(region.addr, region.size, region.protectionFlags);
    
    if (currentCRC != region.crc) {
        LOGW("内存区域被篡改: %s (期望: 0x%08X, 实际: 0x%08X)", 
             region.tag.c_str(), region.crc, currentCRC);
        return false;
    }
    
    return true;
}

bool MemoryProtect::detectBreakpoints() {
    // 检查关键函数是否被修改
    std::vector<void*> keyFuncs = getKeyFunctions();
    for (void* func : keyFuncs) {
        if (isFunctionHooked(func)) {
            LOGW("检测到内存断点/Hook: 函数=%p", func);
            return true;
        }
    }
    
    return false;
}

bool MemoryProtect::isFunctionHooked(void* func) {
    if (func == nullptr) {
        return false;
    }
    
    return isFunctionModified(func);
}

bool MemoryProtect::protectKeyFunctions() {
    std::vector<void*> keyFuncs = getKeyFunctions();
    int protectedCount = 0;
    
    for (void* func : keyFuncs) {
        if (protectFunction(func, "key_function")) {
            protectedCount++;
        }
    }
    
    LOGI("关键函数保护完成: %d/%zu", protectedCount, keyFuncs.size());
    return protectedCount > 0;
}

void MemoryProtect::clearAll() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    for (const auto& region : m_regions) {
        // 恢复读写权限
        mprotect(region.addr, region.size, PROT_READ | PROT_WRITE);
    }
    
    m_regions.clear();
    LOGI("所有内存保护已清除");
}

std::string MemoryProtect::getStats() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    char buffer[256];
    snprintf(buffer, sizeof(buffer), "保护区域数量: %zu", m_regions.size());
    return std::string(buffer);
}

uint32_t MemoryProtect::calculateCRC32(const unsigned char* data, size_t size) {
    uint32_t crc = 0xFFFFFFFF;
    
    for (size_t i = 0; i < size; i++) {
        crc ^= data[i];
        for (int j = 0; j < 8; j++) {
            if (crc & 1) {
                crc = (crc >> 1) ^ 0xEDB88320;
            } else {
                crc >>= 1;
            }
        }
    }
    
    return ~crc;
}

bool MemoryProtect::isFunctionModified(void* func) {
    if (func == nullptr) {
        return false;
    }
    
    // 检查前4个字节是否正常
    uint32_t* bytes = (uint32_t*)func;
    
    // 如果前4个字节是0xE51FF004 (ARM的bx指令) 或类似
    // 通常表示被HOOK
    if (*bytes == 0xE51FF004 || *bytes == 0xE59FF000) {
        return true;
    }
    
    // 检查是否是跳转指令
    if ((*bytes & 0xFF000000) == 0xEA000000) {
        return true;
    }
    
    return false;
}

std::vector<void*> MemoryProtect::getKeyFunctions() {
    std::vector<void*> funcs;
    
    // 获取关键函数地址
    void* dlopen_ptr = dlsym(RTLD_DEFAULT, "dlopen");
    void* dlsym_ptr = dlsym(RTLD_DEFAULT, "dlsym");
    void* malloc_ptr = dlsym(RTLD_DEFAULT, "malloc");
    void* free_ptr = dlsym(RTLD_DEFAULT, "free");
    
    if (dlopen_ptr) funcs.push_back(dlopen_ptr);
    if (dlsym_ptr) funcs.push_back(dlsym_ptr);
    if (malloc_ptr) funcs.push_back(malloc_ptr);
    if (free_ptr) funcs.push_back(free_ptr);
    
    return funcs;
}

bool MemoryProtect::protectFunction(void* func, const std::string& name) {
    if (func == nullptr) {
        return false;
    }
    
    // 获取函数大小（简化处理，实际应该从符号表获取）
    size_t funcSize = 64; // 假设函数大小为64字节
    
    // 随机化保护标志
    uint32_t flags = randomizeProtectionFlags();
    
    return protect(func, funcSize, name, flags);
}

uint32_t MemoryProtect::randomizeProtectionFlags() {
    // 修复：移除PROT_NONE选项，避免代码无法执行
    // 随机选择保护标志，增加不可预测性
    int choice = rand() % 2;

    switch (choice) {
        case 0:
            return PROT_READ;
        case 1:
            return PROT_READ | PROT_EXEC;
        default:
            return PROT_READ;
    }
}

} // namespace ArkVMP