#ifndef ARK_MONITOR_PERFORMANCE_MONITOR_H
#define ARK_MONITOR_PERFORMANCE_MONITOR_H

#include <atomic>
#include <chrono>
#include <map>
#include <string>
#include <mutex>
#include <vector>

namespace ark {
namespace monitor {

/**
 * 性能指标
 */
struct PerformanceMetrics {
    uint64_t totalExecTime;         // 总执行时间（纳秒）
    uint64_t methodCount;           // 方法调用次数
    uint64_t vmpStartTime;          // VMP启动时间（纳秒）
    uint64_t vmpEndTime;            // VMP结束时间（纳秒）
    std::map<int, uint64_t> methodTime;  // 各方法执行时间
    uint32_t memoryUsage;           // 内存使用量（MB）
    uint32_t cpuUsage;              // CPU使用率（%）
    bool isPerformanceLow;          // 是否性能低下
    
    PerformanceMetrics() 
        : totalExecTime(0)
        , methodCount(0)
        , vmpStartTime(0)
        , vmpEndTime(0)
        , memoryUsage(0)
        , cpuUsage(0)
        , isPerformanceLow(false)
    {}
};

/**
 * 性能监控器
 * 
 * 功能：
 * 1. 监控VMP执行时间
 * 2. 记录方法调用统计
 * 3. 检测热点方法
 * 4. 性能预算管理
 * 5. 自动降级触发
 */
class PerformanceMonitor {
public:
    static PerformanceMonitor& getInstance();
    
    // 初始化
    void initialize();
    
    // 开始VMP监控
    void startVMP();
    
    // 结束VMP监控
    void endVMP();
    
    // 记录方法执行
    void recordMethodExecution(int methodId, uint64_t duration);
    
    // 获取总执行时间
    uint64_t getTotalExecTime();
    
    // 获取方法调用次数
    uint64_t getMethodCount();
    
    // 获取方法平均执行时间
    uint64_t getAvgMethodTime();
    
    // 获取热点方法列表
    std::vector<std::pair<int, uint64_t>> getHotMethods(int topN = 10);
    
    // 获取当前性能指标
    PerformanceMetrics getCurrentMetrics();
    
    // 检查是否超出性能预算
    bool isOverBudget();
    
    // 设置性能预算
    void setPerformanceBudget(uint64_t maxExecTimeRatio);
    
    // 获取性能预算
    uint64_t getPerformanceBudget();
    
    // 重置统计
    void reset();
    
    // 启用/禁用监控
    void setEnabled(bool enabled);
    
    // 检查是否启用
    bool isEnabled();

private:
    PerformanceMonitor();
    ~PerformanceMonitor();
    
    // 禁止拷贝
    PerformanceMonitor(const PerformanceMonitor&) = delete;
    PerformanceMonitor& operator=(const PerformanceMonitor&) = delete;
    
    // 检测热点方法
    void detectHotMethods();
    
    // 计算平均方法执行时间
    void calculateAvgMethodTime();
    
    // 检查性能是否低下
    void checkPerformanceLow();
    
    // 获取当前时间（纳秒）
    uint64_t getCurrentTimeNs();

private:
    // 性能指标
    PerformanceMetrics m_metrics;
    std::mutex m_metricsMutex;
    
    // 性能预算（VMP时间占比最大值，单位：百分比）
    std::atomic<uint64_t> m_performanceBudget;
    
    // 热点方法阈值（调用次数）
    static constexpr int HOT_METHOD_THRESHOLD = 50;
    
    // 标志
    std::atomic<bool> m_enabled;
    bool m_initialized;
};

} // namespace monitor
} // namespace ark

#endif // ARK_MONITOR_PERFORMANCE_MONITOR_H