#include "PerformanceMonitor.h"
#include "../log/SecureLogger.h"
#include <algorithm>
#include <sstream>
#include <cstring>
#include <sys/resource.h>
#include <unistd.h>
#include <fstream>

namespace ark {
namespace monitor {

// 单例实例
PerformanceMonitor& PerformanceMonitor::getInstance() {
    static PerformanceMonitor instance;
    return instance;
}

PerformanceMonitor::PerformanceMonitor()
    : m_performanceBudget(5)  // 默认VMP时间占比不超过5%
    , m_enabled(true)
    , m_initialized(false)
{
}

PerformanceMonitor::~PerformanceMonitor() {
}

void PerformanceMonitor::initialize() {
    if (m_initialized) {
        return;
    }
    
    m_initialized = true;
    
    LOGI("PerformanceMonitor", "性能监控器初始化完成，性能预算=%llu%%", m_performanceBudget.load());
}

void PerformanceMonitor::startVMP() {
    if (!m_enabled || !m_initialized) {
        return;
    }
    
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    m_metrics.vmpStartTime = getCurrentTimeNs();
    
    LOGI("PerformanceMonitor", "开始VMP监控");
}

void PerformanceMonitor::endVMP() {
    if (!m_enabled || !m_initialized) {
        return;
    }
    
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    m_metrics.vmpEndTime = getCurrentTimeNs();
    
    // 检查性能是否低下
    checkPerformanceLow();
    
    // 检测热点方法
    detectHotMethods();
    
    // 计算平均方法执行时间
    calculateAvgMethodTime();
    
    LOGI("PerformanceMonitor", "结束VMP监控，总执行时间=%llums，方法调用次数=%llu",
         m_metrics.totalExecTime / 1000000, m_metrics.methodCount);
}

void PerformanceMonitor::recordMethodExecution(int methodId, uint64_t duration) {
    if (!m_enabled || !m_initialized) {
        return;
    }
    
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    
    m_metrics.totalExecTime += duration;
    m_metrics.methodCount++;
    m_metrics.methodTime[methodId] += duration;
    
    // 每100次调用检查一次性能
    if (m_metrics.methodCount % 100 == 0) {
        checkPerformanceLow();
    }
}

uint64_t PerformanceMonitor::getTotalExecTime() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    return m_metrics.totalExecTime;
}

uint64_t PerformanceMonitor::getMethodCount() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    return m_metrics.methodCount;
}

uint64_t PerformanceMonitor::getAvgMethodTime() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    if (m_metrics.methodCount == 0) {
        return 0;
    }
    return m_metrics.totalExecTime / m_metrics.methodCount;
}

std::vector<std::pair<int, uint64_t>> PerformanceMonitor::getHotMethods(int topN) {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    
    std::vector<std::pair<int, uint64_t>> hotMethods;
    
    for (const auto& pair : m_metrics.methodTime) {
        hotMethods.push_back(pair);
    }
    
    // 按执行时间排序
    std::sort(hotMethods.begin(), hotMethods.end(),
              [](const std::pair<int, uint64_t>& a, const std::pair<int, uint64_t>& b) {
                  return a.second > b.second;
              });
    
    // 返回前N个
    if (hotMethods.size() > static_cast<size_t>(topN)) {
        hotMethods.resize(topN);
    }
    
    return hotMethods;
}

PerformanceMetrics PerformanceMonitor::getCurrentMetrics() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    return m_metrics;
}

bool PerformanceMonitor::isOverBudget() {
    if (!m_enabled || !m_initialized) {
        return false;
    }
    
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    
    // 检查VMP执行时间占比
    if (m_metrics.vmpStartTime > 0 && m_metrics.vmpEndTime > 0) {
        uint64_t totalTime = m_metrics.vmpEndTime - m_metrics.vmpStartTime;
        if (totalTime > 0 && m_metrics.totalExecTime > 0) {
            uint64_t ratio = (m_metrics.totalExecTime * 100) / totalTime;
            
            if (ratio > m_performanceBudget) {
                LOGW("PerformanceMonitor", "VMP执行时间占比超预算：%llu%% > %llu%%",
                     ratio, m_performanceBudget.load());
                return true;
            }
        }
    }
    
    return false;
}

void PerformanceMonitor::setPerformanceBudget(uint64_t maxExecTimeRatio) {
    m_performanceBudget = maxExecTimeRatio;
    
    LOGI("PerformanceMonitor", "性能预算已设置=%llu%%", maxExecTimeRatio);
}

uint64_t PerformanceMonitor::getPerformanceBudget() {
    return m_performanceBudget.load();
}

void PerformanceMonitor::reset() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    
    m_metrics = PerformanceMetrics();
    
    LOGI("PerformanceMonitor", "性能统计已重置");
}

void PerformanceMonitor::setEnabled(bool enabled) {
    m_enabled = enabled;
    
    LOGI("PerformanceMonitor", "性能监控已%s", enabled ? "启用" : "禁用");
}

bool PerformanceMonitor::isEnabled() {
    return m_enabled;
}

void PerformanceMonitor::detectHotMethods() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    
    int hotMethodCount = 0;
    
    for (const auto& pair : m_metrics.methodTime) {
        // 检查方法调用次数是否超过阈值
        // 这里简化处理，实际应该统计调用次数
        if (pair.second > 1000000) {  // 执行时间超过1ms
            hotMethodCount++;
            
            if (hotMethodCount <= 5) {  // 只报告前5个热点方法
                LOGI("PerformanceMonitor", "热点方法: ID=%d, 执行时间=%llums",
                     pair.first, pair.second / 1000000);
            }
        }
    }
    
    if (hotMethodCount > 0) {
        LOGI("PerformanceMonitor", "检测到%d个热点方法", hotMethodCount);
    }
}

void PerformanceMonitor::calculateAvgMethodTime() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    // 平均方法时间现在通过getAvgMethodTime()动态计算，不需要存储
}

void PerformanceMonitor::checkPerformanceLow() {
    std::lock_guard<std::mutex> lock(m_metricsMutex);
    
    bool isLow = false;
    
    // 检查启动时间
    if (m_metrics.vmpStartTime > 0 && m_metrics.vmpEndTime > 0) {
        uint64_t startupTime = (m_metrics.vmpEndTime - m_metrics.vmpStartTime) / 1000000;
        if (startupTime > 10000) {  // 启动时间超过10秒
            LOGW("PerformanceMonitor", "启动时间过长=%llums", startupTime);
            isLow = true;
        }
    }
    
    // 检查VMP执行时间占比
    if (m_metrics.vmpStartTime > 0 && m_metrics.vmpEndTime > 0) {
        uint64_t totalTime = m_metrics.vmpEndTime - m_metrics.vmpStartTime;
        if (totalTime > 0 && m_metrics.totalExecTime > 0) {
            uint64_t ratio = (m_metrics.totalExecTime * 100) / totalTime;
            if (ratio > m_performanceBudget) {
                LOGW("PerformanceMonitor", "VMP执行时间占比过高=%llu%%", ratio);
                isLow = true;
            }
        }
    }
    
    // 检查内存使用
    struct rusage usage;
    if (getrusage(RUSAGE_SELF, &usage) == 0) {
        uint32_t memoryUsage = usage.ru_maxrss / 1024;  // 转换为MB
        m_metrics.memoryUsage = memoryUsage;
        
        if (memoryUsage > 100) {  // 超过100MB
            LOGW("PerformanceMonitor", "内存使用过高=%uMB", memoryUsage);
            isLow = true;
        }
    }
    
    m_metrics.isPerformanceLow = isLow;
}

uint64_t PerformanceMonitor::getCurrentTimeNs() {
    auto now = std::chrono::steady_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::nanoseconds>(duration).count();
}

} // namespace monitor
} // namespace ark