#ifndef ARK_LOG_SECURE_LOGGER_H
#define ARK_LOG_SECURE_LOGGER_H

#include <string>
#include <cstdarg>
#include <atomic>

namespace ark {
namespace log {

/**
 * 安全日志级别
 */
enum class LogLevel {
    LOG_VERBOSE = 2,
    LOG_DEBUG = 3,
    LOG_INFO = 4,
    LOG_WARN = 5,
    LOG_ERROR = 6,
    LOG_FATAL = 7
};

/**
 * 安全日志记录器
 * 
 * 功能：
 * 1. 加密日志内容，防止敏感信息泄露
 * 2. 支持多种日志级别
 * 3. 支持文件和控制台输出
 * 4. 线程安全
 * 5. 可动态启用/禁用
 */
class SecureLogger {
public:
    static SecureLogger& getInstance();
    
    // 初始化
    void initialize();
    
    // 设置日志级别
    void setLogLevel(LogLevel level);
    
    // 设置启用状态
    void setEnabled(bool enabled);
    
    // 设置日志文件路径
    void setLogFilePath(const std::string& path);
    
    // 记录日志
    void log(LogLevel level, const char* tag, const char* format, ...);
    
    // 便捷方法
    void v(const char* tag, const char* format, ...);
    void d(const char* tag, const char* format, ...);
    void i(const char* tag, const char* format, ...);
    void w(const char* tag, const char* format, ...);
    void e(const char* tag, const char* format, ...);
    
    // 刷新日志
    void flush();
    
    // 关闭日志
    void close();

private:
    SecureLogger();
    ~SecureLogger();
    
    // 禁止拷贝
    SecureLogger(const SecureLogger&) = delete;
    SecureLogger& operator=(const SecureLogger&) = delete;
    
    // 加密日志内容
    void encryptLog(const char* input, char* output, size_t size);
    
    // 写入日志
    void writeLog(LogLevel level, const char* tag, const char* message);
    
    // 获取日志级别字符串
    const char* getLevelString(LogLevel level);
    
    // 写入到文件
    void writeToFile(const char* message);
    
    // 写入到控制台
    void writeToConsole(LogLevel level, const char* tag, const char* message);

private:
    std::atomic<LogLevel> m_logLevel;
    std::atomic<bool> m_enabled;
    std::string m_logFilePath;
    
    // 加密密钥
    unsigned char m_key[32];
    
    // 标志
    bool m_initialized;
};

} // namespace log
} // namespace ark

// 宏定义
#define LOGV(tag, ...) ark::log::SecureLogger::getInstance().v(tag, ##__VA_ARGS__)
#define LOGD(tag, ...) ark::log::SecureLogger::getInstance().d(tag, ##__VA_ARGS__)
#define LOGI(tag, ...) ark::log::SecureLogger::getInstance().i(tag, ##__VA_ARGS__)
#define LOGW(tag, ...) ark::log::SecureLogger::getInstance().w(tag, ##__VA_ARGS__)
#define LOGE(tag, ...) ark::log::SecureLogger::getInstance().e(tag, ##__VA_ARGS__)

#endif // ARK_LOG_SECURE_LOGGER_H