#include "SecureLogger.h"
#include <chrono>
#include <ctime>
#include <cstring>
#include <cstdarg>
#include <fstream>
#include <sys/stat.h>
#include <unistd.h>
#include <android/log.h>

namespace ark {
namespace log {

// 单例实例
SecureLogger& SecureLogger::getInstance() {
    static SecureLogger instance;
    return instance;
}

SecureLogger::SecureLogger()
    : m_logLevel(LogLevel::LOG_INFO)
    , m_enabled(true)
    , m_initialized(false)
{
    // 生成默认密钥
    for (int i = 0; i < 32; i++) {
        m_key[i] = static_cast<unsigned char>(i * 7 + 0x5A);
    }
}

SecureLogger::~SecureLogger() {
    close();
}

void SecureLogger::initialize() {
    if (m_initialized) {
        return;
    }
    
    // 设置默认日志文件路径
    m_logFilePath = "/data/local/tmp/ark_secure.log";
    
    m_initialized = true;
    
    i("SecureLogger", "安全日志记录器初始化完成");
}

void SecureLogger::setLogLevel(LogLevel level) {
    m_logLevel = level;
}

void SecureLogger::setEnabled(bool enabled) {
    m_enabled = enabled;
}

void SecureLogger::setLogFilePath(const std::string& path) {
    m_logFilePath = path;
}

void SecureLogger::log(LogLevel level, const char* tag, const char* format, ...) {
    if (!m_enabled || !m_initialized) {
        return;
    }
    
    // 检查日志级别
    if (level < m_logLevel) {
        return;
    }
    
    // 格式化消息
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    // 写入日志
    writeLog(level, tag, buffer);
}

void SecureLogger::v(const char* tag, const char* format, ...) {
    if (!m_enabled || !m_initialized || LogLevel::LOG_VERBOSE < m_logLevel) {
        return;
    }
    
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    writeLog(LogLevel::LOG_VERBOSE, tag, buffer);
}

void SecureLogger::d(const char* tag, const char* format, ...) {
    if (!m_enabled || !m_initialized || LogLevel::LOG_DEBUG < m_logLevel) {
        return;
    }
    
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    writeLog(LogLevel::LOG_DEBUG, tag, buffer);
}

void SecureLogger::i(const char* tag, const char* format, ...) {
    if (!m_enabled || !m_initialized || LogLevel::LOG_INFO < m_logLevel) {
        return;
    }
    
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    writeLog(LogLevel::LOG_INFO, tag, buffer);
}

void SecureLogger::w(const char* tag, const char* format, ...) {
    if (!m_enabled || !m_initialized || LogLevel::LOG_WARN < m_logLevel) {
        return;
    }
    
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    writeLog(LogLevel::LOG_WARN, tag, buffer);
}

void SecureLogger::e(const char* tag, const char* format, ...) {
    if (!m_enabled || !m_initialized || LogLevel::LOG_ERROR < m_logLevel) {
        return;
    }
    
    char buffer[1024];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    
    writeLog(LogLevel::LOG_ERROR, tag, buffer);
}

void SecureLogger::flush() {
    // TODO: 刷新日志缓冲区
}

void SecureLogger::close() {
    if (m_initialized) {
        i("SecureLogger", "安全日志记录器关闭");
        m_initialized = false;
    }
}

void SecureLogger::encryptLog(const char* input, char* output, size_t size) {
    // 简单的XOR加密（实际项目应该使用更安全的加密算法）
    for (size_t i = 0; i < size && input[i] != '\0'; i++) {
        output[i] = input[i] ^ m_key[i % 32];
    }
}

void SecureLogger::writeLog(LogLevel level, const char* tag, const char* message) {
    // 写入到控制台
    writeToConsole(level, tag, message);
    
    // 写入到文件
    writeToFile(message);
}

const char* SecureLogger::getLevelString(LogLevel level) {
    switch (level) {
        case LogLevel::LOG_VERBOSE: return "V";
        case LogLevel::LOG_DEBUG: return "D";
        case LogLevel::LOG_INFO: return "I";
        case LogLevel::LOG_WARN: return "W";
        case LogLevel::LOG_ERROR: return "E";
        case LogLevel::LOG_FATAL: return "F";
        default: return "?";
    }
}

void SecureLogger::writeToFile(const char* message) {
    if (m_logFilePath.empty()) {
        return;
    }
    
    // 打开日志文件
    std::ofstream file(m_logFilePath, std::ios::app);
    
    if (file.is_open()) {
        // 加密日志内容
        char encrypted[1024];
        encryptLog(message, encrypted, strlen(message));
        
        // 写入加密内容
        file << encrypted << std::endl;
        file.close();
    }
}

void SecureLogger::writeToConsole(LogLevel level, const char* tag, const char* message) {
    // 获取当前时间
    auto now = std::chrono::system_clock::now();
    auto time = std::chrono::system_clock::to_time_t(now);
    struct tm* tm_info = localtime(&time);
    
    char timeBuffer[64];
    strftime(timeBuffer, sizeof(timeBuffer), "%Y-%m-%d %H:%M:%S", tm_info);
    
    // 格式化日志消息
    char logBuffer[2048];
    snprintf(logBuffer, sizeof(logBuffer), "[%s] [%s] %s: %s",
             timeBuffer, getLevelString(level), tag, message);
    
    // 输出到Android Logcat
    android_LogPriority priority;
    switch (level) {
        case LogLevel::LOG_VERBOSE: priority = ANDROID_LOG_VERBOSE; break;
        case LogLevel::LOG_DEBUG: priority = ANDROID_LOG_DEBUG; break;
        case LogLevel::LOG_INFO: priority = ANDROID_LOG_INFO; break;
        case LogLevel::LOG_WARN: priority = ANDROID_LOG_WARN; break;
        case LogLevel::LOG_ERROR: priority = ANDROID_LOG_ERROR; break;
        case LogLevel::LOG_FATAL: priority = ANDROID_LOG_FATAL; break;
        default: priority = ANDROID_LOG_INFO; break;
    }
    
    __android_log_print(priority, "ArkSecure", "%s", logBuffer);
}

} // namespace log
} // namespace ark