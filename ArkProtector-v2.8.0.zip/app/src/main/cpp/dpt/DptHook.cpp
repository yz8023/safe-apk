// dpt_hook.cpp - dpt-shell函数抽取壳的native运行时实现
//
// 运行时还原流程：
// 1. 从 assets 读取 dpt_codeitems.bin
// 2. 扫描 /proc/self/maps 找到 DEX 内存区域
// 3. 对每个被抽取的方法，用 codeOffset 定位 CodeItem
// 4. mprotect 设为可写，memcpy 还原原始字节码

#include <jni.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <dlfcn.h>
#include <sys/mman.h>
#include <unistd.h>
#include <errno.h>
#include <android/log.h>

#define TAG "DptHook"
#define LOGD(fmt, ...) __android_log_print(ANDROID_LOG_DEBUG, TAG, fmt, ##__VA_ARGS__)
#define LOGE(fmt, ...) __android_log_print(ANDROID_LOG_ERROR, TAG, fmt, ##__VA_ARGS__)

// ===== CodeItem数据结构 =====
struct CodeItem {
    int methodIndex;
    int codeOffset;
    int insnsSize;
    int xorKey;
    int noiseSeed;
    unsigned char* insnsData;
};

struct DexCodeItems {
    int dexIndex;
    CodeItem* items;
    int itemCount;
};

static DexCodeItems* g_dexItems = nullptr;
static int g_dexCount = 0;
static bool g_enhanced = false;
static int g_patchedCount = 0;

// ===== XOR解密 =====
static void xorDecrypt(unsigned char* data, int size, int key) {
    for (int i = 0; i < size; i++) {
        int shift = (i & 3) << 3;
        data[i] ^= (unsigned char)((key >> shift) & 0xFF);
    }
}

// ===== 扫描 /proc/self/maps 找 DEX 内存区域 =====
struct DexMemRegion {
    void* base;
    size_t size;
    int prot;
    char path[256];
};
static DexMemRegion g_dexRegions[128];
static int g_dexRegionCount = 0;

static bool isDexMagic(const unsigned char* ptr) {
    return ptr[0] == 'd' && ptr[1] == 'e' && ptr[2] == 'x' && ptr[3] == '\n';
}

static void scanDexMemory() {
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) {
        LOGE("无法打开 /proc/self/maps");
        return;
    }

    char line[512];
    while (fgets(line, sizeof(line), fp)) {
        unsigned long start, end;
        char perms[8];
        char path[256] = {0};
        // 格式：start-end perms offset dev inode path
        int n = sscanf(line, "%lx-%lx %s %*s %*s %*s %255[^\n]",
                       &start, &end, perms, path);
        if (n < 3) continue;

        size_t size = end - start;
        if (size < 112) continue; // DEX header 最小 112 字节

        int prot = 0;
        if (strchr(perms, 'r')) prot |= PROT_READ;
        if (strchr(perms, 'w')) prot |= PROT_WRITE;
        if (strchr(perms, 'x')) prot |= PROT_EXEC;

        // 在映射区内搜索 DEX magic
        unsigned char* begin = (unsigned char*)start;
        unsigned char* p = begin;
        unsigned char* limit = begin + size - 8;
        while (p < limit) {
            if (isDexMagic(p)) {
                // 找到 DEX 实际起始位置 p，从 p 到映射区结束作为该 DEX 区域
                if (g_dexRegionCount < 128) {
                    g_dexRegions[g_dexRegionCount].base = p;
                    g_dexRegions[g_dexRegionCount].size = end - (unsigned long)p;
                    g_dexRegions[g_dexRegionCount].prot = prot;
                    strncpy(g_dexRegions[g_dexRegionCount].path, path, 255);
                    g_dexRegions[g_dexRegionCount].path[255] = '\0';
                    g_dexRegionCount++;
                    LOGD("找到DEX内存: base=%p, size=%zu, prot=%s, magic=%c%c%c, path=%s",
                         p, g_dexRegions[g_dexRegionCount - 1].size, perms, p[0], p[1], p[2], path);
                }
                break; // 一个映射区只记录一次
            }
            p++;
        }
    }
    fclose(fp);
    LOGD("DEX内存扫描完成: 找到 %d 个DEX区域", g_dexRegionCount);
}

// ===== 根据 dexIndex 匹配 DEX 区域 =====
// 约定：classes.dex -> index 0, classes2.dex -> index 1, ...
static DexMemRegion* findDexRegion(int dexIndex) {
    for (int i = 0; i < g_dexRegionCount; i++) {
        const char* path = g_dexRegions[i].path;
        // 匹配 classes.dex 或 classesN.dex
        const char* p = strrchr(path, '/');
        if (p == nullptr) p = path;
        else p++;

        if (dexIndex == 0) {
            if (strstr(p, "classes.dex") != nullptr && strstr(p, "classes2.dex") == nullptr
                && strstr(p, "classes3.dex") == nullptr && strstr(p, "classes4.dex") == nullptr
                && strstr(p, "classes5.dex") == nullptr) {
                return &g_dexRegions[i];
            }
        } else {
            char name[32];
            snprintf(name, sizeof(name), "classes%d.dex", dexIndex + 1);
            if (strstr(p, name) != nullptr) {
                return &g_dexRegions[i];
            }
        }
    }
    return nullptr;
}

// ===== 确保内存可写，保留原执行权限 =====
static bool ensureWritable(void* addr, size_t size, int originalProt) {
    long pagesize = sysconf(_SC_PAGE_SIZE);
    void* page = (void*)((unsigned long)addr & ~(pagesize - 1));
    size_t pageEnd = (size_t)addr + size;
    size_t pageStart = (size_t)page;
    size_t alignedSize = pageEnd - pageStart;

    int newProt = PROT_READ | PROT_WRITE;
    if (originalProt & PROT_EXEC) newProt |= PROT_EXEC;

    if (mprotect(page, alignedSize, newProt) != 0) {
        LOGE("mprotect失败: %p, size=%zu, errno=%d(%s)", addr, size, errno, strerror(errno));
        return false;
    }
    return true;
}

// ===== 还原所有方法 =====
static void patchAllMethods() {
    for (int d = 0; d < g_dexCount; d++) {
        DexCodeItems& dex = g_dexItems[d];
        DexMemRegion* region = findDexRegion(d);
        if (region == nullptr) {
            LOGE("未找到 dexIndex=%d 对应的DEX内存区域", d);
            continue;
        }

        unsigned char* dexBase = (unsigned char*)region->base;
        size_t dexSize = region->size;

        for (int i = 0; i < dex.itemCount; i++) {
            CodeItem& item = dex.items[i];
            if (item.codeOffset == 0 || item.insnsSize == 0) continue;

            // codeOffset 必须在 DEX 范围内（至少留出 header 16 字节 + insns）
            if ((size_t)item.codeOffset + 16 + item.insnsSize > dexSize) {
                LOGE("codeOffset越界: dex=%d, method=%d, codeOffset=%d, insnsSize=%d, dexSize=%zu",
                     d, item.methodIndex, item.codeOffset, item.insnsSize, dexSize);
                continue;
            }

            // insns 在 CodeItem 中的偏移 = codeOffset + 16（CodeItem header）
            unsigned char* insnsPtr = dexBase + item.codeOffset + 16;

            // 可选校验：目标位置当前应为 return stub（前2字节是 return-void 或 const/4）
            // 这里不做强校验，允许覆盖

            if (!ensureWritable(insnsPtr, item.insnsSize, region->prot)) {
                LOGE("跳过 method=%d (mprotect失败)", item.methodIndex);
                continue;
            }

            if (item.xorKey != 0) {
                unsigned char* data = (unsigned char*)malloc(item.insnsSize);
                if (data == nullptr) continue;
                memcpy(data, item.insnsData, item.insnsSize);
                xorDecrypt(data, item.insnsSize, item.xorKey);
                memcpy(insnsPtr, data, item.insnsSize);
                free(data);
            } else {
                memcpy(insnsPtr, item.insnsData, item.insnsSize);
            }
            g_patchedCount++;
        }
    }
    LOGD("DPT还原完成: 已还原 %d 个方法", g_patchedCount);
}

// ===== JNI方法实现 =====

extern "C" {

// nativeInitDpt: 初始化 DPT，加载 bin 数据
JNIEXPORT jint JNICALL Java_com_ark_jiagu_dpt_DptNativeBridge_nativeInitDpt(
        JNIEnv* env, jclass clazz, jstring apkPath) {
    const char* path = env->GetStringUTFChars(apkPath, nullptr);
    LOGD("dpt初始化: %s", path);
    env->ReleaseStringUTFChars(apkPath, path);
    return 0;
}

// nativeLoadCodeItems: 加载 CodeItem 数据
JNIEXPORT jint JNICALL Java_com_ark_jiagu_dpt_DptNativeBridge_nativeLoadCodeItems(
        JNIEnv* env, jclass clazz, jbyteArray data, jboolean enhanced) {
    g_enhanced = enhanced;

    jsize dataLen = env->GetArrayLength(data);
    if (dataLen < 4) {
        LOGE("bin数据太短: %d", dataLen);
        return -1;
    }

    jbyte* dataPtr = env->GetByteArrayElements(data, nullptr);
    if (dataPtr == nullptr) {
        LOGE("GetByteArrayElements失败");
        return -1;
    }
    unsigned char* buf = (unsigned char*)dataPtr;

    // 边界检查宏
    #define CHECK_POS(need) do { if (pos + (need) > dataLen) { \
        LOGE("bin解析越界: pos=%d, need=%d, len=%d", pos, need, dataLen); \
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT); \
        return -1; \
    } } while(0)

    int pos = 0;
    CHECK_POS(2);
    int version = buf[pos] | (buf[pos+1] << 8); pos += 2;
    CHECK_POS(2);
    int dexCount = buf[pos] | (buf[pos+1] << 8); pos += 2;

    if (dexCount <= 0 || dexCount > 64) {
        LOGE("dexCount非法: %d", dexCount);
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return -1;
    }

    g_dexCount = dexCount;
    g_dexItems = (DexCodeItems*)calloc(sizeof(DexCodeItems), dexCount);
    if (g_dexItems == nullptr) {
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return -1;
    }

    int* offsets = (int*)malloc(sizeof(int) * dexCount);
    if (offsets == nullptr) {
        free(g_dexItems); g_dexItems = nullptr;
        env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
        return -1;
    }

    for (int i = 0; i < dexCount; i++) {
        CHECK_POS(4);
        offsets[i] = buf[pos] | (buf[pos+1]<<8) | (buf[pos+2]<<16) | (buf[pos+3]<<24);
        pos += 4;
    }

    for (int d = 0; d < dexCount; d++) {
        pos = offsets[d];
        CHECK_POS(2);
        int methodCount = buf[pos] | (buf[pos+1] << 8); pos += 2;

        if (methodCount < 0 || methodCount > 65536) {
            LOGE("methodCount非法: dex=%d, count=%d", d, methodCount);
            free(offsets);
            env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
            return -1;
        }

        g_dexItems[d].dexIndex = d;
        g_dexItems[d].itemCount = methodCount;
        g_dexItems[d].items = (CodeItem*)calloc(sizeof(CodeItem), methodCount);
        if (g_dexItems[d].items == nullptr && methodCount > 0) {
            free(offsets);
            env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);
            return -1;
        }

        for (int m = 0; m < methodCount; m++) {
            CodeItem& item = g_dexItems[d].items[m];
            CHECK_POS(4+4+4+4+4);
            item.methodIndex = buf[pos] | (buf[pos+1]<<8) | (buf[pos+2]<<16) | (buf[pos+3]<<24); pos += 4;
            item.codeOffset  = buf[pos] | (buf[pos+1]<<8) | (buf[pos+2]<<16) | (buf[pos+3]<<24); pos += 4;
            item.insnsSize   = buf[pos] | (buf[pos+1]<<8) | (buf[pos+2]<<16) | (buf[pos+3]<<24); pos += 4;
            item.xorKey      = buf[pos] | (buf[pos+1]<<8) | (buf[pos+2]<<16) | (buf[pos+3]<<24); pos += 4;
            item.noiseSeed   = buf[pos] | (buf[pos+1]<<8) | (buf[pos+2]<<16) | (buf[pos+3]<<24); pos += 4;

            if (item.insnsSize < 0 || item.insnsSize > 16 * 1024 * 1024) {
                LOGE("insnsSize非法: dex=%d, method=%d, size=%d", d, item.methodIndex, item.insnsSize);
                item.insnsSize = 0;
                continue;
            }

            CHECK_POS(item.insnsSize);
            item.insnsData = (unsigned char*)malloc(item.insnsSize);
            if (item.insnsData == nullptr) {
                item.insnsSize = 0;
                continue;
            }
            memcpy(item.insnsData, buf + pos, item.insnsSize);
            pos += item.insnsSize;
        }
    }

    #undef CHECK_POS

    free(offsets);
    env->ReleaseByteArrayElements(data, dataPtr, JNI_ABORT);

    LOGD("CodeItem加载完成: %d个DEX, 增强模式=%d, 总数据=%d字节", dexCount, enhanced, dataLen);

    // 扫描 DEX 内存并还原所有方法
    scanDexMemory();
    patchAllMethods();

    return 0;
}

// nativePatchMethod
JNIEXPORT jint JNICALL Java_com_ark_jiagu_dpt_DptNativeBridge_nativePatchMethod(
        JNIEnv* env, jclass clazz, jint dexIndex, jint methodIndex,
        jbyteArray codeBytes, jint codeOffset, jint insnsSize) {
    return 0;
}

// nativeGetPatchedCount
JNIEXPORT jint JNICALL Java_com_ark_jiagu_dpt_DptNativeBridge_nativeGetPatchedCount(
        JNIEnv* env, jclass clazz) {
    return g_patchedCount;
}

// nativeVerifyDex
JNIEXPORT jint JNICALL Java_com_ark_jiagu_dpt_DptNativeBridge_nativeVerifyDex(
        JNIEnv* env, jclass clazz, jbyteArray dexData) {
    return 0;
}

} // extern "C"
