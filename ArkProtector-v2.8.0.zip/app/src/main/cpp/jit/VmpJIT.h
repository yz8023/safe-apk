#ifndef VMP_JIT_H
#define VMP_JIT_H

#include <cstdint>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <android/log.h>
#include <sys/mman.h>
#include <cstring>
#include "../VmContext.h"
#include "../VmpTypes.h"

#define LOG_TAG "ArkVMP_JIT"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace ArkVMP {

// JIT缓存条目
struct JITCacheEntry {
    int methodId;
    void* nativeCode;
    size_t codeSize;
    uint64_t lastUsed;
    uint64_t hitCount;
    uint64_t compileTime;
};

class VmpJIT {
public:
    VmpJIT();
    ~VmpJIT();
    
    // 编译热点方法
    void* compileIfHot(int methodId, VmpMethod* method);
    
    // 编译方法
    void* compile(int methodId, VmpMethod* method);
    
    // 获取编译后的代码
    void* getCompiledCode(int methodId);
    
    // 清除缓存
    void clearCache();
    
    // 设置热点阈值
    void setHotThreshold(int threshold);
    
    // 获取统计信息
    std::string getStats();
    
    // 启用/禁用JIT
    void setEnabled(bool enabled);
    
private:
    static const int MAX_CACHE_SIZE = 100;
    static const int DEFAULT_HOT_THRESHOLD = 50;
    
    std::map<int, JITCacheEntry> m_cache;
    std::mutex m_mutex;
    
    // 热点方法阈值
    int m_hotThreshold;
    
    // 方法调用计数
    std::map<int, uint64_t> m_callCount;
    
    // JIT是否启用
    bool m_enabled;
    
    // 统计信息
    uint64_t m_totalCompilations;
    uint64_t m_totalHits;
    uint64_t m_totalMisses;
    
    // 生成ARM64代码
    bool generateARM64Code(VmpMethod* method, unsigned char* out, size_t& outSize);
    
    // 生成ARM代码
    bool generateARMCode(VmpMethod* method, unsigned char* out, size_t& outSize);
    
    // 估计代码大小
    size_t estimateCodeSize(VmpMethod* method);
    
    // 淘汰最旧的条目
    void evictOldest();
    
    // 分配可执行内存
    void* allocateExecutableMemory(size_t size);
    
    // 释放可执行内存
    void freeExecutableMemory(void* addr, size_t size);
    
    // 检查是否支持JIT
    static bool isJITSupported();
    
    // 获取当前架构
    static std::string getCurrentArch();
};

} // namespace ArkVMP

#endif // VMP_JIT_H