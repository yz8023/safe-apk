#include "VmpJIT.h"
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <sys/syscall.h>
#include <chrono>

// 获取当前时间（微秒）
static uint64_t getCurrentTimeMicros() {
    auto now = std::chrono::high_resolution_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
}

namespace ArkVMP {

VmpJIT::VmpJIT() 
    : m_hotThreshold(DEFAULT_HOT_THRESHOLD)
    , m_enabled(true)
    , m_totalCompilations(0)
    , m_totalHits(0)
    , m_totalMisses(0) {
    
    // 检查是否支持JIT
    if (!isJITSupported()) {
        LOGW("JIT不支持，已禁用");
        m_enabled = false;
    } else {
        LOGI("VmpJIT初始化完成，架构: %s", getCurrentArch().c_str());
    }
}

VmpJIT::~VmpJIT() {
    clearCache();
}

void* VmpJIT::compileIfHot(int methodId, VmpMethod* method) {
    if (!m_enabled || method == nullptr) {
        return nullptr;
    }
    
    // 增加调用计数
    m_callCount[methodId]++;
    
    // 检查是否达到热点阈值
        if (m_callCount[methodId] >= m_hotThreshold) {
            LOGI("方法达到热点阈值: methodId=%d, 调用次数=%lu",
                 methodId, m_callCount[methodId]);
        return compile(methodId, method);
    }
    
    return nullptr;
}

void* VmpJIT::compile(int methodId, VmpMethod* method) {
    if (!m_enabled || method == nullptr) {
        return nullptr;
    }
    
    std::lock_guard<std::mutex> lock(m_mutex);
    
    // 检查缓存
    auto it = m_cache.find(methodId);
    if (it != m_cache.end()) {
        it->second.lastUsed = getCurrentTimeMicros();
        it->second.hitCount++;
        m_totalHits++;
        LOGI("JIT缓存命中: methodId=%d", methodId);
        return it->second.nativeCode;
    }
    
    m_totalMisses++;
    
    // 估计代码大小
    size_t codeSize = estimateCodeSize(method);
    if (codeSize == 0) {
        LOGE("无法估计代码大小: methodId=%d", methodId);
        return nullptr;
    }
    
    // 分配可执行内存
    unsigned char* code = (unsigned char*)allocateExecutableMemory(codeSize);
    if (code == nullptr) {
        LOGE("分配可执行内存失败: methodId=%d", methodId);
        return nullptr;
    }
    
    // 生成机器码
    size_t actualSize = 0;
    bool success = false;
    
    std::string arch = getCurrentArch();
    if (arch == "arm64") {
        success = generateARM64Code(method, code, actualSize);
    } else if (arch == "arm") {
        success = generateARMCode(method, code, actualSize);
    } else {
        LOGW("不支持的架构: %s", arch.c_str());
        freeExecutableMemory(code, codeSize);
        return nullptr;
    }
    
    if (!success || actualSize == 0) {
        LOGE("生成机器码失败: methodId=%d", methodId);
        freeExecutableMemory(code, codeSize);
        return nullptr;
    }
    
    // 缓存编译后的代码
    JITCacheEntry entry;
    entry.methodId = methodId;
    entry.nativeCode = code;
    entry.codeSize = actualSize;
    entry.lastUsed = getCurrentTimeMicros();
    entry.hitCount = 0;
    entry.compileTime = getCurrentTimeMicros();
    
    // LRU淘汰
    if (m_cache.size() >= MAX_CACHE_SIZE) {
        evictOldest();
    }
    
    m_cache[methodId] = entry;
    m_totalCompilations++;
    
    LOGI("JIT编译成功: methodId=%d, 代码大小=%zu 字节", methodId, actualSize);
    
    return code;
}

void* VmpJIT::getCompiledCode(int methodId) {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    auto it = m_cache.find(methodId);
    if (it != m_cache.end()) {
        it->second.lastUsed = getCurrentTimeMicros();
        it->second.hitCount++;
        m_totalHits++;
        return it->second.nativeCode;
    }
    
    m_totalMisses++;
    return nullptr;
}

void VmpJIT::clearCache() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    for (auto& entry : m_cache) {
        freeExecutableMemory(entry.second.nativeCode, entry.second.codeSize);
    }
    
    m_cache.clear();
    m_callCount.clear();
    
    LOGI("JIT缓存已清除");
}

void VmpJIT::setHotThreshold(int threshold) {
    if (threshold > 0) {
        m_hotThreshold = threshold;
        LOGI("热点阈值已设置: %d", threshold);
    }
}

std::string VmpJIT::getStats() {
    std::lock_guard<std::mutex> lock(m_mutex);
    
    char buffer[512];
    snprintf(buffer, sizeof(buffer),
             "JIT统计: 编译次数=%lu, 命中次数=%lu, 未命中次数=%lu, "
             "缓存大小=%zu/%d, 热点阈值=%d",
             m_totalCompilations, m_totalHits, m_totalMisses,
             m_cache.size(), MAX_CACHE_SIZE, m_hotThreshold);
    
    return std::string(buffer);
}

void VmpJIT::setEnabled(bool enabled) {
    m_enabled = enabled;
    LOGI("JIT已%s", enabled ? "启用" : "禁用");
}

bool VmpJIT::generateARM64Code(VmpMethod* method, unsigned char* out, size_t& outSize) {
    // ARM64代码生成器
    // 这是一个简化的实现，实际应用中需要完整的指令映射
    
    size_t offset = 0;
    
    for (const auto& insn : method->instructions) {
        // 根据opcode生成ARM64指令
        switch (insn.realOpcode) {
            case 0x0E: // RETURN_VOID
                // RET指令
                out[offset++] = 0xC0;
                out[offset++] = 0x03;
                out[offset++] = 0x5F;
                out[offset++] = 0xD6;
                break;
                
            case 0x90: // ADD_INT
                // 简化的ADD指令示例
                out[offset++] = 0x00;
                out[offset++] = 0x00;
                out[offset++] = 0x00;
                out[offset++] = 0x0B;
                break;
                
            default:
                // 不支持的指令，生成调用解释器的代码
                // 这里应该生成调用VMP解释器的ARM64代码
                // 为了示例，我们生成NOP
                out[offset++] = 0x1F;
                out[offset++] = 0x20;
                out[offset++] = 0x03;
                out[offset++] = 0xD5;
                break;
        }
    }
    
    outSize = offset;
    return offset > 0;
}

bool VmpJIT::generateARMCode(VmpMethod* method, unsigned char* out, size_t& outSize) {
    // ARM代码生成器
    // 这是一个简化的实现
    
    size_t offset = 0;
    
    for (const auto& insn : method->instructions) {
        // 根据opcode生成ARM指令
        switch (insn.realOpcode) {
            case 0x0E: // RETURN_VOID
                // BX LR指令
                out[offset++] = 0x1E;
                out[offset++] = 0xFF;
                out[offset++] = 0x2F;
                out[offset++] = 0xE1;
                break;
                
            default:
                // 不支持的指令，生成NOP
                out[offset++] = 0x00;
                out[offset++] = 0xF0;
                out[offset++] = 0x20;
                out[offset++] = 0xE3;
                break;
        }
    }
    
    outSize = offset;
    return offset > 0;
}

size_t VmpJIT::estimateCodeSize(VmpMethod* method) {
    if (method == nullptr) {
        return 0;
    }
    
    // 估计每条指令平均4字节
    return method->instructions.size() * 4;
}

void VmpJIT::evictOldest() {
    if (m_cache.empty()) {
        return;
    }
    
    // 找到最旧的条目
    auto oldest = m_cache.begin();
    for (auto it = m_cache.begin(); it != m_cache.end(); ++it) {
        if (it->second.lastUsed < oldest->second.lastUsed) {
            oldest = it;
        }
    }
    
    LOGI("淘汰JIT缓存条目: methodId=%d", oldest->first);
    
    // 释放内存
    freeExecutableMemory(oldest->second.nativeCode, oldest->second.codeSize);
    
    // 从缓存中移除
    m_cache.erase(oldest);
}

void* VmpJIT::allocateExecutableMemory(size_t size) {
    // 对齐到页边界
    size_t alignedSize = (size + 0xFFF) & ~0xFFF;
    
    // 分配可执行内存
    void* mem = mmap(nullptr, alignedSize, 
                     PROT_READ | PROT_WRITE | PROT_EXEC,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    
    if (mem == MAP_FAILED) {
        return nullptr;
    }
    
    return mem;
}

void VmpJIT::freeExecutableMemory(void* addr, size_t size) {
    if (addr != nullptr) {
        size_t alignedSize = (size + 0xFFF) & ~0xFFF;
        munmap(addr, alignedSize);
    }
}

bool VmpJIT::isJITSupported() {
    // 检查当前架构是否支持JIT
    std::string arch = getCurrentArch();
    return arch == "arm64" || arch == "arm";
}

std::string VmpJIT::getCurrentArch() {
#if defined(__aarch64__)
    return "arm64";
#elif defined(__arm__)
    return "arm";
#elif defined(__x86_64__)
    return "x86_64";
#elif defined(__i386__)
    return "x86";
#else
    return "unknown";
#endif
}

} // namespace ArkVMP