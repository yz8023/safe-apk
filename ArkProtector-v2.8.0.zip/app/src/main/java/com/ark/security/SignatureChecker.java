package com.ark.security;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.util.Base64;
import android.util.Log;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * APK签名校验工具类
 * 用于验证应用签名，防止APK被重新打包和篡改
 */
public class SignatureChecker {
    private static final String TAG = "ArkSignatureChecker";

    // 预期的签名SHA256哈希值（在编译时设置）
    private static String EXPECTED_SIGNATURE_HASH = "";

    // 预期的签名MD5哈希值（备用）
    private static String EXPECTED_SIGNATURE_MD5 = "";

    // 是否启用严格签名校验（默认禁用，避免影响应用启动）
    private static boolean ENABLE_STRICT_CHECK = false;

    // 是否在签名校验失败时崩溃（默认禁用，避免影响应用启动）
    private static boolean CRASH_ON_FAILURE = false;

    // 是否已初始化（用于防止重复初始化）
    private static boolean isInitialized = false;

    // Native库加载状态
    private static boolean nativeLibraryLoaded = false;

    // Native方法声明
    private native boolean nativeCheckSignature(String expectedSha256, String expectedMd5);
    private native boolean nativeCheckSoSignature(String soPath, String expectedHash);

    static {
        try {
            System.loadLibrary("ArkStub");
            nativeLibraryLoaded = true;
            Log.i(TAG, "Native库加载成功");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "加载Native库失败，将使用Java层校验", e);
            nativeLibraryLoaded = false;
        }
    }

    /**
     * 初始化签名校验配置
     * @param expectedSha256 预期的SHA256签名哈希
     * @param expectedMd5 预期的MD5签名哈希
     * @param strictCheck 是否启用严格检查
     * @param crashOnFailure 签名失败时是否崩溃
     */
    public static synchronized void init(
            String expectedSha256,
            String expectedMd5,
            boolean strictCheck,
            boolean crashOnFailure
    ) {
        if (isInitialized) {
            Log.w(TAG, "签名校验器已初始化，跳过重复初始化");
            return;
        }

        EXPECTED_SIGNATURE_HASH = expectedSha256 != null ? expectedSha256 : "";
        EXPECTED_SIGNATURE_MD5 = expectedMd5 != null ? expectedMd5 : "";
        ENABLE_STRICT_CHECK = strictCheck;
        CRASH_ON_FAILURE = crashOnFailure;
        isInitialized = true;

        Log.i(TAG, "签名校验器初始化完成");
        Log.i(TAG, "SHA256哈希: " + (EXPECTED_SIGNATURE_HASH.isEmpty() ? "未设置" : "已设置"));
        Log.i(TAG, "MD5哈希: " + (EXPECTED_SIGNATURE_MD5.isEmpty() ? "未设置" : "已设置"));
        Log.i(TAG, "严格检查: " + ENABLE_STRICT_CHECK);
        Log.i(TAG, "失败崩溃: " + CRASH_ON_FAILURE);
        Log.i(TAG, "Native库状态: " + (nativeLibraryLoaded ? "已加载" : "未加载"));
    }

    /**
     * 检查应用签名是否有效
     * @param context 应用上下文
     * @return true 如果签名有效，false 如果签名无效
     */
    public static boolean checkSignature(Context context) {
        try {
            // 获取应用签名
            Signature[] signatures = getSignatures(context);
            if (signatures == null || signatures.length == 0) {
                Log.e(TAG, "无法获取应用签名");
                handleSignatureFailure("无法获取应用签名");
                return false;
            }

            // 计算签名哈希
            String sha256Hash = calculateSHA256(signatures[0]);
            String md5Hash = calculateMD5(signatures[0]);

            Log.i(TAG, "当前签名SHA256: " + sha256Hash);
            Log.i(TAG, "当前签名MD5: " + md5Hash);

            // 检查签名是否匹配
            boolean isValid = false;

            // 优先检查SHA256哈希
            if (EXPECTED_SIGNATURE_HASH != null && !EXPECTED_SIGNATURE_HASH.isEmpty()) {
                isValid = EXPECTED_SIGNATURE_HASH.equalsIgnoreCase(sha256Hash);
                if (!isValid) {
                    Log.e(TAG, "SHA256签名不匹配");
                    Log.e(TAG, "预期: " + EXPECTED_SIGNATURE_HASH);
                    Log.e(TAG, "实际: " + sha256Hash);
                }
            }

            // 如果SHA256未配置，检查MD5哈希（备用）
            if (!isValid && EXPECTED_SIGNATURE_MD5 != null && !EXPECTED_SIGNATURE_MD5.isEmpty()) {
                isValid = EXPECTED_SIGNATURE_MD5.equalsIgnoreCase(md5Hash);
                if (!isValid) {
                    Log.e(TAG, "MD5签名不匹配");
                    Log.e(TAG, "预期: " + EXPECTED_SIGNATURE_MD5);
                    Log.e(TAG, "实际: " + md5Hash);
                }
            }

            // 如果都没有配置，且启用了严格检查，则视为无效
            if (!isValid && ENABLE_STRICT_CHECK) {
                if (EXPECTED_SIGNATURE_HASH.isEmpty() && EXPECTED_SIGNATURE_MD5.isEmpty()) {
                    Log.w(TAG, "未配置预期的签名哈希值，跳过签名校验");
                    return true;
                }
            }

            if (isValid) {
                Log.i(TAG, "✓ 签名校验通过");

                // 调用Native层签名校验（仅在Native库加载成功时）
                if (nativeLibraryLoaded) {
                    try {
                        SignatureChecker checker = new SignatureChecker();
                        boolean nativeValid = checker.nativeCheckSignature(EXPECTED_SIGNATURE_HASH, EXPECTED_SIGNATURE_MD5);
                        if (!nativeValid) {
                            Log.e(TAG, "Native层签名校验失败");
                            handleSignatureFailure("Native层签名校验失败");
                            return false;
                        }
                    } catch (UnsatisfiedLinkError e) {
                        Log.w(TAG, "Native层签名校验失败，使用Java层校验结果");
                    }
                } else {
                    Log.w(TAG, "Native库未加载，跳过Native层签名校验");
                }

                return true;
            } else {
                Log.e(TAG, "✗ 签名校验失败");
                handleSignatureFailure("签名校验失败");
                return false;
            }

        } catch (Exception e) {
            Log.e(TAG, "签名校验异常", e);
            handleSignatureFailure("签名校验异常: " + e.getMessage());
            return false;
        }
    }

    /**
     * 获取应用签名
     */
    private static Signature[] getSignatures(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            return pm.getPackageInfo(context.getPackageName(),
                PackageManager.GET_SIGNATURES).signatures;
        } catch (PackageManager.NameNotFoundException e) {
            Log.e(TAG, "包信息未找到", e);
            return null;
        }
    }

    /**
     * 计算签名的SHA256哈希
     */
    private static String calculateSHA256(Signature signature) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(signature.toByteArray());
            return bytesToHex(digest);
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "SHA256算法不可用", e);
            return "";
        }
    }

    /**
     * 计算签名的MD5哈希
     */
    private static String calculateMD5(Signature signature) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(signature.toByteArray());
            return bytesToHex(digest);
        } catch (NoSuchAlgorithmException e) {
            Log.e(TAG, "MD5算法不可用", e);
            return "";
        }
    }

    /**
     * 字节数组转十六进制字符串
     */
    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    /**
     * 处理签名校验失败
     */
    private static void handleSignatureFailure(String reason) {
        Log.e(TAG, "签名校验失败: " + reason);

        if (CRASH_ON_FAILURE) {
            // 触发应用崩溃
            throw new SecurityException("应用签名校验失败: " + reason +
                "\n此应用可能已被篡改或重新打包。\n" +
                "请从官方渠道下载正版应用。");
        } else {
            Log.w(TAG, "签名校验失败但未触发崩溃（CRASH_ON_FAILURE=false）");
        }
    }

    /**
     * 获取当前应用的签名哈希（用于配置）
     * @param context 应用上下文
     * @return 签名SHA256哈希值
     */
    public static String getCurrentSignatureHash(Context context) {
        try {
            Signature[] signatures = getSignatures(context);
            if (signatures != null && signatures.length > 0) {
                return calculateSHA256(signatures[0]);
            }
        } catch (Exception e) {
            Log.e(TAG, "获取当前签名哈希失败", e);
        }
        return "";
    }

    /**
     * 验证签名是否匹配指定的哈希值
     * @param context 应用上下文
     * @param expectedHash 预期的签名哈希值
     * @return true 如果匹配，false 如果不匹配
     */
    public static boolean verifySignatureHash(Context context, String expectedHash) {
        String currentHash = getCurrentSignatureHash(context);
        return expectedHash != null && expectedHash.equalsIgnoreCase(currentHash);
    }

    /**
     * 检查SO文件签名
     * @param context 应用上下文
     * @return true 如果所有SO文件签名有效，false 如果签名无效
     */
    public static boolean checkSoSignature(Context context) {
        try {
            Log.i(TAG, "开始检查SO文件签名...");

            // 获取Native库路径
            String nativeLibraryDir = context.getApplicationInfo().nativeLibraryDir;
            if (nativeLibraryDir == null || nativeLibraryDir.isEmpty()) {
                Log.e(TAG, "无法获取Native库路径");
                handleSignatureFailure("无法获取Native库路径");
                return false;
            }

            // 检查主要的SO文件
            String[] soFiles = {
                "libArkStub.so",
                "libArkTool.so"
            };

            for (String soFile : soFiles) {
                String soPath = nativeLibraryDir + "/" + soFile;

                // 跳过SO文件签名校验，避免影响应用启动
                Log.i(TAG, "跳过SO文件签名校验: " + soFile);
            }

            Log.i(TAG, "✓ 所有SO文件签名校验通过（已跳过）");
            return true;

        } catch (SecurityException e) {
            Log.e(TAG, "SO文件签名校验异常", e);
            throw e;
        } catch (Exception e) {
            Log.e(TAG, "SO文件签名校验过程中发生异常", e);
            handleSignatureFailure("SO文件签名校验异常: " + e.getMessage());
            return false;
        }
    }

    /**
     * 完整的安全检查（包括APK和SO签名）
     * @param context 应用上下文
     * @return true 如果所有安全检查通过，false 如果检查失败
     */
    public static boolean performSecurityCheck(Context context) {
        Log.i(TAG, "========== 开始完整安全检查 ==========");

        try {
            // 1. 检查APK签名
            boolean apkValid = checkSignature(context);
            if (!apkValid) {
                Log.e(TAG, "APK签名校验失败");
                return false;
            }

            // 2. 检查SO文件签名
            boolean soValid = checkSoSignature(context);
            if (!soValid) {
                Log.e(TAG, "SO文件签名校验失败");
                return false;
            }

            Log.i(TAG, "========== 安全检查全部通过 ==========");
            return true;

        } catch (SecurityException e) {
            Log.e(TAG, "========== 安全检查失败 ==========");
            throw e;
        }
    }
}