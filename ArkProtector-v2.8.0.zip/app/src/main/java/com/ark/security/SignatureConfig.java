package com.ark.security;

/**
 * 签名配置
 * 自动生成，请勿手动修改
 */
public class SignatureConfig {

    // debug 配置
    public static final String EXPECTED_SHA256_DEBUG = "df92a377a6667cd24f84a6980ab9956940754c2987a780012bffd3011493aed1";
    public static final String EXPECTED_MD5_DEBUG = "None";

    // default 配置
    public static final String EXPECTED_SHA256_DEFAULT = "";
    public static final String EXPECTED_MD5_DEFAULT = "";

    // 当前使用的配置
    public static final String CURRENT_CONFIG = "default";

    public static String getExpectedSha256() {
        switch (CURRENT_CONFIG) {

            case "debug":
                return EXPECTED_SHA256_DEBUG;

            default:
                return EXPECTED_SHA256_DEFAULT;
        }
    }

    public static String getExpectedMd5() {
        switch (CURRENT_CONFIG) {

            case "debug":
                return EXPECTED_MD5_DEBUG;

            default:
                return EXPECTED_MD5_DEFAULT;
        }
    }
}
