package com.ark.security;

import android.content.Context;
import android.os.Build;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Root检测工具类
 * 用于检测设备是否已root，防止root设备直接dump内存
 *
 * 检测维度：
 * 1. 常见root文件检测
 * 2. Magisk特征检测
 * 3. SuperSU特征检测
 * 4. RootCloak等隐藏root工具检测
 * 5. 系统属性检测
 * 6. 危险应用检测
 */
public class RootDetector {

    /**
     * 安全等级
     */
    public enum SecurityLevel {
        SAFE,           // 安全：未检测到root
        LOW_RISK,       // 低风险：检测到可疑特征
        MEDIUM_RISK,    // 中风险：检测到部分root特征
        HIGH_RISK,      // 高风险：检测到明显root特征
        DANGEROUS       // 危险：确认设备已root
    }

    /**
     * 检测结果
     */
    public static class DetectionResult {
        public SecurityLevel level;
        public List<String> detectedItems;
        public int riskScore;

        public DetectionResult(SecurityLevel level, List<String> detectedItems, int riskScore) {
            this.level = level;
            this.detectedItems = detectedItems;
            this.riskScore = riskScore;
        }

        @Override
        public String toString() {
            return "SecurityLevel: " + level + ", RiskScore: " + riskScore + ", Items: " + detectedItems;
        }
    }

    // 常见root文件路径
    private static final String[] COMMON_ROOT_FILES = {
        "/system/bin/su",
        "/system/xbin/su",
        "/system/sbin/su",
        "/vendor/bin/su",
        "/system/app/SuperSU.apk",
        "/system/app/Superuser.apk",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/su/bin/su"
    };

    // Magisk特征文件路径
    private static final String[] MAGISK_FILES = {
        "/sbin/.magisk",
        "/sbin/.core/mirror",
        "/sbin/.core/img",
        "/sbin/.core/db-0/magisk.db",
        "/data/adb/magisk",
        "/data/adb/magisk.db",
        "/data/adb/magisk_simple",
        "/cache/.disable_magisk",
        "/dev/.magisk.unblock",
        "/magisk/.core/bin",
        "/magisk/.core/dummy",
        "/magisk/.core/img"
    };

    // SuperSU特征文件路径
    private static final String[] SUPERSU_FILES = {
        "/system/app/SuperSU",
        "/system/app/SuperSU.apk",
        "/system/etc/init.d/99SuperSUDaemon",
        "/data/data/eu.chainfire.supersu",
        "/data/data/eu.chainfire.supersu.pro",
        "/system/xbin/daemonsu",
        "/system/bin/daemonsu"
    };

    // RootCloak等隐藏root工具特征
    private static final String[] ROOTCLOAK_FILES = {
        "/data/local/tmp/rootcloak",
        "/data/data/com.devadvance.rootcloak",
        "/data/data/com.devadvance.rootcloakplus",
        "/data/data/com.koushikdutta.superuser",
        "/data/data/com.thirdparty.superuser",
        "/data/data/eu.chainfire.supersu"
    };

    // 危险应用包名
    private static final String[] DANGEROUS_APPS = {
        "com.noshufou.android.su",
        "com.thirdparty.superuser",
        "eu.chainfire.supersu",
        "com.koushikdutta.superuser",
        "com.topjohnwu.magisk",
        "com.kingroot.kinguser",
        "com.kingo.root",
        "com.smedialink.oneclickroot",
        "com.zhiqupk.root.global",
        "com.alephzain.framaroot",
        "com.ramdroid.appquarantine",
        "com.ramdroid.appquarantinepro",
        "com.devadvance.rootcloak",
        "com.devadvance.rootcloakplus",
        "de.robv.android.xposed.installer",
        "com.saurik.substrate",
        "com.zachspong.temprootremovejb",
        "com.amphoras.hidemyroot",
        "com.amphoras.hidemyrootadfree",
        "com.formyhm.hiderootPremium",
        "com.formyhm.hideroot"
    };

    // 危险系统属性
    private static final String[] DANGEROUS_PROPS = {
        "ro.debuggable",
        "ro.secure",
        "service.adb.root",
        "ro.build.selinux"
    };

    /**
     * 执行完整的root检测
     *
     * @param context 上下文
     * @return 检测结果
     */
    public static DetectionResult detect(Context context) {
        List<String> detectedItems = new ArrayList<>();
        int riskScore = 0;

        // 1. 检测常见root文件
        riskScore += detectCommonRootFiles(detectedItems);

        // 2. 检测Magisk特征
        riskScore += detectMagisk(detectedItems);

        // 3. 检测SuperSU特征
        riskScore += detectSuperSU(detectedItems);

        // 4. 检测RootCloak等隐藏root工具
        riskScore += detectRootCloak(detectedItems);

        // 5. 检测系统属性
        riskScore += detectSystemProperties(detectedItems);

        // 6. 检测危险应用
        riskScore += detectDangerousApps(context, detectedItems);

        // 7. 检测可写系统分区
        riskScore += detectWritableSystem(detectedItems);

        // 8. 检测TracerPid（调试器检测）
        riskScore += detectTracerPid(detectedItems);

        // 评估安全等级
        SecurityLevel level = evaluateSecurityLevel(riskScore);

        return new DetectionResult(level, detectedItems, riskScore);
    }

    /**
     * 检测常见root文件
     */
    private static int detectCommonRootFiles(List<String> detectedItems) {
        int score = 0;
        for (String path : COMMON_ROOT_FILES) {
            if (new File(path).exists()) {
                detectedItems.add("Root文件: " + path);
                score += 15;
            }
        }
        return score;
    }

    /**
     * 检测Magisk特征
     */
    private static int detectMagisk(List<String> detectedItems) {
        int score = 0;
        for (String path : MAGISK_FILES) {
            if (new File(path).exists()) {
                detectedItems.add("Magisk特征: " + path);
                score += 20;
            }
        }
        return score;
    }

    /**
     * 检测SuperSU特征
     */
    private static int detectSuperSU(List<String> detectedItems) {
        int score = 0;
        for (String path : SUPERSU_FILES) {
            if (new File(path).exists()) {
                detectedItems.add("SuperSU特征: " + path);
                score += 15;
            }
        }
        return score;
    }

    /**
     * 检测RootCloak等隐藏root工具
     */
    private static int detectRootCloak(List<String> detectedItems) {
        int score = 0;
        for (String path : ROOTCLOAK_FILES) {
            if (new File(path).exists()) {
                detectedItems.add("RootCloak特征: " + path);
                score += 10;
            }
        }
        return score;
    }

    /**
     * 检测系统属性
     */
    private static int detectSystemProperties(List<String> detectedItems) {
        int score = 0;

        // 检测ro.debuggable
        String debuggable = getSystemProperty("ro.debuggable", "0");
        if ("1".equals(debuggable)) {
            detectedItems.add("系统属性: ro.debuggable=1");
            score += 10;
        }

        // 检测ro.secure
        String secure = getSystemProperty("ro.secure", "1");
        if ("0".equals(secure)) {
            detectedItems.add("系统属性: ro.secure=0");
            score += 10;
        }

        // 检测service.adb.root
        String adbRoot = getSystemProperty("service.adb.root", "0");
        if ("1".equals(adbRoot)) {
            detectedItems.add("系统属性: service.adb.root=1");
            score += 10;
        }

        return score;
    }

    /**
     * 检测危险应用
     */
    private static int detectDangerousApps(Context context, List<String> detectedItems) {
        int score = 0;
        for (String packageName : DANGEROUS_APPS) {
            try {
                context.getPackageManager().getPackageInfo(packageName, 0);
                detectedItems.add("危险应用: " + packageName);
                score += 10;
            } catch (Exception e) {
                // 应用未安装
            }
        }
        return score;
    }

    /**
     * 检测可写系统分区
     */
    private static int detectWritableSystem(List<String> detectedItems) {
        int score = 0;

        // 尝试在/system目录创建测试文件
        try {
            File testFile = new File("/system", ".root_test");
            if (testFile.createNewFile()) {
                detectedItems.add("系统分区可写: /system");
                score += 20;
                testFile.delete();
            }
        } catch (Exception e) {
            // 系统分区不可写
        }

        // 尝试在/system/bin目录创建测试文件
        try {
            File testFile = new File("/system/bin", ".root_test");
            if (testFile.createNewFile()) {
                detectedItems.add("系统分区可写: /system/bin");
                score += 20;
                testFile.delete();
            }
        } catch (Exception e) {
            // 系统分区不可写
        }

        return score;
    }

    /**
     * 检测TracerPid（调试器检测）
     */
    private static int detectTracerPid(List<String> detectedItems) {
        int score = 0;

        try {
            // 读取/proc/self/status文件
            java.io.RandomAccessFile reader = new java.io.RandomAccessFile("/proc/self/status", "r");
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("TracerPid:")) {
                    String tracerPid = line.split(":")[1].trim();
                    if (!"0".equals(tracerPid)) {
                        detectedItems.add("调试器检测: TracerPid=" + tracerPid);
                        score += 25;
                    }
                    break;
                }
            }
            reader.close();
        } catch (Exception e) {
            // 读取失败
        }

        return score;
    }

    /**
     * 获取系统属性
     */
    private static String getSystemProperty(String key, String defaultValue) {
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            java.lang.reflect.Method get = c.getMethod("get", String.class, String.class);
            return (String) get.invoke(c, key, defaultValue);
        } catch (Exception e) {
            return defaultValue;
        }
    }

    /**
     * 评估安全等级
     */
    private static SecurityLevel evaluateSecurityLevel(int riskScore) {
        if (riskScore >= 50) {
            return SecurityLevel.DANGEROUS;
        } else if (riskScore >= 30) {
            return SecurityLevel.HIGH_RISK;
        } else if (riskScore >= 15) {
            return SecurityLevel.MEDIUM_RISK;
        } else if (riskScore >= 5) {
            return SecurityLevel.LOW_RISK;
        } else {
            return SecurityLevel.SAFE;
        }
    }

    /**
     * 快速检测（仅检测最明显的root特征）
     *
     * @return true表示设备可能已root
     */
    public static boolean quickDetect() {
        // 检测su命令
        if (new File("/system/bin/su").exists() ||
            new File("/system/xbin/su").exists() ||
            new File("/su/bin/su").exists()) {
            return true;
        }

        // 检测Magisk
        if (new File("/data/adb/magisk").exists()) {
            return true;
        }

        // 检测SuperSU
        if (new File("/system/app/SuperSU.apk").exists()) {
            return true;
        }

        return false;
    }

    /**
     * 获取检测报告
     *
     * @param context 上下文
     * @return 检测报告字符串
     */
    public static String getDetectionReport(Context context) {
        DetectionResult result = detect(context);
        StringBuilder report = new StringBuilder();

        report.append("========== Root检测报告 ==========\n");
        report.append("安全等级: ").append(levelToString(result.level)).append("\n");
        report.append("风险评分: ").append(result.riskScore).append("\n");
        report.append("检测项数量: ").append(result.detectedItems.size()).append("\n");
        report.append("\n检测结果:\n");

        if (result.detectedItems.isEmpty()) {
            report.append("  未检测到root特征\n");
        } else {
            for (String item : result.detectedItems) {
                report.append("  - ").append(item).append("\n");
            }
        }

        report.append("\n建议:\n");
        switch (result.level) {
            case SAFE:
                report.append("  设备安全，建议继续使用\n");
                break;
            case LOW_RISK:
                report.append("  设备存在轻微风险，建议检查已安装应用\n");
                break;
            case MEDIUM_RISK:
                report.append("  设备存在中等风险，建议检查root权限和已安装应用\n");
                break;
            case HIGH_RISK:
                report.append("  设备存在高风险，可能已root，请谨慎使用\n");
                break;
            case DANGEROUS:
                report.append("  设备已root，强烈建议不要在此设备上运行敏感应用\n");
                break;
        }

        report.append("==================================\n");

        return report.toString();
    }

    /**
     * 安全等级转字符串
     */
    private static String levelToString(SecurityLevel level) {
        switch (level) {
            case SAFE: return "安全";
            case LOW_RISK: return "低风险";
            case MEDIUM_RISK: return "中等风险";
            case HIGH_RISK: return "高风险";
            case DANGEROUS: return "危险";
            default: return "未知";
        }
    }
}