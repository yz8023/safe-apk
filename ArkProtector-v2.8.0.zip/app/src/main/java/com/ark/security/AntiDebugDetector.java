package com.ark.security;

import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 反调试检测工具类
 * 用于检测和防范调试器攻击，防止动态分析
 *
 * 检测维度：
 * 1. TracerPid检测
 * 2. 调试端口检测
 * 3. /proc/self/status检测
 * 4. 调试进程检测
 * 5. 线程名称检测
 * 6. 内存映射检测
 * 7. Frida检测（端口 + 特征）
 * 8. Xposed检测（类 + 文件）
 * 9. 内存断点检测
 * 10. Trace检测
 * 11. 模拟器检测
 */
public class AntiDebugDetector {

    private static final String TAG = "AntiDebugDetector";

    /**
     * 检测结果
     */
    public static class DetectionResult {
        public boolean isDebugging;
        public List<String> detectedItems;
        public int riskScore;

        public DetectionResult(boolean isDebugging, List<String> detectedItems, int riskScore) {
            this.isDebugging = isDebugging;
            this.detectedItems = detectedItems;
            this.riskScore = riskScore;
        }

        @Override
        public String toString() {
            return "IsDebugging: " + isDebugging + ", RiskScore: " + riskScore + ", Items: " + detectedItems;
        }
    }

    // 常见调试器进程名
    private static final String[] DEBUGGER_PROCESSES = {
        "gdb",
        "gdbserver",
        "lldb",
        "lldb-server",
        "strace",
        "ltrace",
        "frida-server",
        "xposed",
        "substrate"
    };

    // 常见调试端口
    private static final int[] DEBUG_PORTS = {
        23946,  // JDWP默认端口
        5555,   // ADB默认端口
        5554,
        27042,  // gdbserver默认端口
        1234    // 常见调试端口
    };

    // 是否启用循环检测
    private static boolean enableLoopDetection = false;

    // 检测线程
    private static Thread detectionThread;

    // 检测间隔（毫秒）- 默认5000ms，避免性能问题
    private static long detectionInterval = 5000;

    // 检测回调
    private static DebugDetectionCallback detectionCallback;

    /**
     * 检测回调接口
     */
    public interface DebugDetectionCallback {
        void onDebugDetected(String message);
    }

    /**
     * 执行完整的反调试检测
     *
     * @return 检测结果
     */
    public static DetectionResult detect() {
        List<String> detectedItems = new ArrayList<>();
        int riskScore = 0;

        // 1. TracerPid检测
        riskScore += detectTracerPid(detectedItems);

        // 2. 调试端口检测
        riskScore += detectDebugPorts(detectedItems);

        // 3. /proc/self/status检测
        riskScore += detectProcStatus(detectedItems);

        // 4. 调试进程检测
        riskScore += detectDebuggerProcesses(detectedItems);

        // 5. 线程名称检测
        riskScore += detectThreadNames(detectedItems);

        // 6. 内存映射检测
        riskScore += detectMemoryMaps(detectedItems);

        // 7. Frida检测（端口 + 特征）
        riskScore += detectFrida(detectedItems);

        // 8. Xposed检测（类 + 文件）
        riskScore += detectXposed(detectedItems);

        // 9. 内存断点检测
        riskScore += detectMemoryBreakpoints(detectedItems);

        // 10. Trace检测
        riskScore += detectTrace(detectedItems);

        // 11. 模拟器检测
        riskScore += detectEmulator(detectedItems);

        // 评估是否在调试中
        boolean isDebugging = riskScore > 0;

        return new DetectionResult(isDebugging, detectedItems, riskScore);
    }

    /**
     * 检测TracerPid
     * TracerPid != 0 表示进程正在被调试
     * 修复：使用try-with-resources确保资源释放
     */
    private static int detectTracerPid(List<String> detectedItems) {
        try {
            File statusFile = new File("/proc/self/status");
            if (!statusFile.exists()) {
                return 0;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(statusFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("TracerPid:")) {
                        String tracerPid = line.split(":")[1].trim();
                        if (!"0".equals(tracerPid)) {
                            detectedItems.add("TracerPid检测: TracerPid=" + tracerPid + " (非0表示正在被调试)");
                            Log.w(TAG, "TracerPid detected: " + tracerPid);
                            return 30;
                        }
                        break;
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error detecting TracerPid", e);
        }
        return 0;
    }

    /**
     * 检测调试端口
     */
    private static int detectDebugPorts(List<String> detectedItems) {
        int score = 0;

        for (int port : DEBUG_PORTS) {
            if (isPortOpen(port)) {
                detectedItems.add("调试端口检测: 端口" + port + "已开放");
                score += 15;
                Log.w(TAG, "Debug port detected: " + port);
            }
        }

        return score;
    }

    /**
     * 检测端口是否开放
     * 修复：添加超时时间，避免阻塞
     */
    private static boolean isPortOpen(int port) {
        try {
            java.net.Socket socket = new java.net.Socket();
            socket.connect(new java.net.InetSocketAddress("127.0.0.1", port), 50); // 50ms超时
            socket.setSoTimeout(50);
            socket.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 检测/proc/self/status中的其他调试特征
     * 修复：使用try-with-resources确保资源释放
     */
    private static int detectProcStatus(List<String> detectedItems) {
        int score = 0;

        try {
            File statusFile = new File("/proc/self/status");
            if (!statusFile.exists()) {
                return 0;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(statusFile))) {
                String line;

                while ((line = reader.readLine()) != null) {
                    // 检测State字段
                    if (line.startsWith("State:")) {
                        String state = line.split(":")[1].trim();
                        // t (tracing stop) 表示正在被追踪
                        if (state.startsWith("t")) {
                            detectedItems.add("进程状态检测: State=" + state + " (正在被追踪)");
                            score += 20;
                            Log.w(TAG, "Tracing state detected: " + state);
                        }
                    }

                    // 检测TracerPid（已经在detectTracerPid中检测）
                    if (line.startsWith("TracerPid:")) {
                        String tracerPid = line.split(":")[1].trim();
                        if (!"0".equals(tracerPid)) {
                            detectedItems.add("TracerPid检测: TracerPid=" + tracerPid);
                            score += 20;
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error detecting proc status", e);
        }

        return score;
    }

    /**
     * 检测调试进程
     */
    private static int detectDebuggerProcesses(List<String> detectedItems) {
        int score = 0;

        try {
            File procDir = new File("/proc");
            File[] pidDirs = procDir.listFiles();

            if (pidDirs == null) {
                return 0;
            }

            for (File pidDir : pidDirs) {
                if (!pidDir.isDirectory()) {
                    continue;
                }

                String pid = pidDir.getName();
                if (!pid.matches("\\d+")) {
                    continue;
                }

                // 读取进程的cmdline
                File cmdlineFile = new File(pidDir, "cmdline");
                if (!cmdlineFile.exists()) {
                    continue;
                }

                try {
                    BufferedReader reader = new BufferedReader(new FileReader(cmdlineFile));
                    String cmdline = reader.readLine();
                    reader.close();

                    if (cmdline != null) {
                        for (String debugger : DEBUGGER_PROCESSES) {
                            if (cmdline.contains(debugger)) {
                                detectedItems.add("调试进程检测: PID=" + pid + ", CMD=" + cmdline);
                                score += 20;
                                Log.w(TAG, "Debugger process detected: " + cmdline);
                                break;
                            }
                        }
                    }
                } catch (Exception e) {
                    // 忽略读取失败的进程
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error detecting debugger processes", e);
        }

        return score;
    }

    /**
     * 检测线程名称
     */
    private static int detectThreadNames(List<String> detectedItems) {
        int score = 0;

        try {
            File taskDir = new File("/proc/self/task");
            File[] tidDirs = taskDir.listFiles();

            if (tidDirs == null) {
                return 0;
            }

            for (File tidDir : tidDirs) {
                if (!tidDir.isDirectory()) {
                    continue;
                }

                // 读取线程的comm文件
                File commFile = new File(tidDir, "comm");
                if (!commFile.exists()) {
                    continue;
                }

                try {
                    BufferedReader reader = new BufferedReader(new FileReader(commFile));
                    String comm = reader.readLine();
                    reader.close();

                    if (comm != null) {
                        // 检测可疑的线程名
                        if (comm.contains("gdb") ||
                            comm.contains("debug") ||
                            comm.contains("frida") ||
                            comm.contains("xposed")) {
                            detectedItems.add("可疑线程检测: " + comm);
                            score += 10;
                            Log.w(TAG, "Suspicious thread detected: " + comm);
                        }
                    }
                } catch (Exception e) {
                    // 忽略读取失败的线程
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error detecting thread names", e);
        }

        return score;
    }

    /**
     * 检测内存映射
     * 修复：使用try-with-resources确保资源释放
     */
    private static int detectMemoryMaps(List<String> detectedItems) {
        int score = 0;

        try {
            File mapsFile = new File("/proc/self/maps");
            if (!mapsFile.exists()) {
                return 0;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(mapsFile))) {
                String line;

                while ((line = reader.readLine()) != null) {
                    // 检测可疑的内存映射
                    if (line.contains("gdb") ||
                        line.contains("frida") ||
                        line.contains("xposed") ||
                        line.contains("substrate")) {
                        detectedItems.add("可疑内存映射: " + line.substring(0, Math.min(line.length(), 50)));
                        score += 15;
                        Log.w(TAG, "Suspicious memory map detected");
                        break;
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error detecting memory maps", e);
        }

        return score;
    }

    /**
     * 启动循环检测
     */
    public static void startLoopDetection(DebugDetectionCallback callback) {
        startLoopDetection(callback, detectionInterval);
    }

    /**
     * 启动循环检测
     *
     * @param callback 检测回调
     * @param interval 检测间隔（毫秒）
     */
    public static void startLoopDetection(DebugDetectionCallback callback, long interval) {
        if (detectionThread != null && detectionThread.isAlive()) {
            Log.w(TAG, "Loop detection already running");
            return;
        }

        detectionCallback = callback;
        detectionInterval = interval;
        enableLoopDetection = true;

        detectionThread = new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG, "Loop detection started");

                while (enableLoopDetection) {
                    try {
                        DetectionResult result = detect();

                        if (result.isDebugging) {
                            String message = "调试器检测: " + result.detectedItems;

                            Log.e(TAG, message);

                            // 调用回调
                            if (detectionCallback != null) {
                                detectionCallback.onDebugDetected(message);
                            }

                            // 采取反制措施
                            handleDebuggingDetected(result);
                        }

                        // 等待下一次检测
                        Thread.sleep(detectionInterval);

                    } catch (InterruptedException e) {
                        Log.i(TAG, "Loop detection interrupted");
                        break;
                    } catch (Exception e) {
                        Log.e(TAG, "Error in loop detection", e);
                    }
                }

                Log.i(TAG, "Loop detection stopped");
            }
        });

        detectionThread.setDaemon(true);
        detectionThread.setName("AntiDebugDetector-LoopThread");
        detectionThread.start();
    }

    /**
     * 停止循环检测
     */
    public static void stopLoopDetection() {
        enableLoopDetection = false;
        if (detectionThread != null && detectionThread.isAlive()) {
            detectionThread.interrupt();
        }
        Log.i(TAG, "Loop detection stopped");
    }

    /**
     * 处理检测到调试的情况
     * 修复：改为根据风险评分采取不同策略，避免误报导致崩溃
     */
    private static void handleDebuggingDetected(DetectionResult result) {
        Log.e(TAG, "Debugging detected, riskScore: " + result.riskScore);

        // 根据风险评分采取不同策略
        if (result.riskScore >= 100) {
            // 高风险：立即终止应用
            Log.e(TAG, "High risk debugging detected, terminating app");
            System.exit(1);
        } else if (result.riskScore >= 50) {
            // 中风险：记录日志，但不崩溃
            Log.e(TAG, "Medium risk debugging detected, logging only");
            // 可以在这里添加其他反制措施，如清空敏感数据
        } else {
            // 低风险：仅记录日志
            Log.w(TAG, "Low risk debugging detected, monitoring");
        }
    }

    /**
     * 快速检测（仅检测最明显的调试特征）
     *
     * @return true表示可能正在被调试
     */
    public static boolean quickDetect() {
        // 检测TracerPid
        try {
            File statusFile = new File("/proc/self/status");
            BufferedReader reader = new BufferedReader(new FileReader(statusFile));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("TracerPid:")) {
                    String tracerPid = line.split(":")[1].trim();
                    reader.close();
                    return !"0".equals(tracerPid);
                }
            }
            reader.close();
        } catch (Exception e) {
            // 忽略错误
        }

        return false;
    }

    /**
     * 获取检测报告
     *
     * @return 检测报告字符串
     */
    public static String getDetectionReport() {
        DetectionResult result = detect();
        StringBuilder report = new StringBuilder();

        report.append("========== 反调试检测报告 ==========\n");
        report.append("是否正在调试: ").append(result.isDebugging ? "是" : "否").append("\n");
        report.append("风险评分: ").append(result.riskScore).append("\n");
        report.append("检测项数量: ").append(result.detectedItems.size()).append("\n");
        report.append("\n检测结果:\n");

        if (result.detectedItems.isEmpty()) {
            report.append("  未检测到调试特征\n");
        } else {
            for (String item : result.detectedItems) {
                report.append("  - ").append(item).append("\n");
            }
        }

        report.append("\n建议:\n");
        if (result.isDebugging) {
            report.append("  检测到调试器，建议立即终止应用或采取反制措施\n");
        } else {
            report.append("  未检测到调试器，应用运行在安全环境\n");
        }

        report.append("===================================\n");

        return report.toString();
    }

    /**
     * 设置检测间隔
     */
    public static void setDetectionInterval(long interval) {
        detectionInterval = interval;
        Log.i(TAG, "Detection interval changed to: " + interval + "ms");
    }

    /**
     * 获取检测间隔
     */
    public static long getDetectionInterval() {
        return detectionInterval;
    }

    /**
     * 检测Frida（端口 + 特征）
     * Frida是一个动态插桩工具，常用于逆向分析
     */
    private static int detectFrida(List<String> detectedItems) {
        int score = 0;

        try {
            // 1. 检测Frida端口（27042）
            if (isPortOpen(27042)) {
                detectedItems.add("Frida检测: 端口27042已开放（Frida默认端口）");
                score += 25;
                Log.w(TAG, "Frida port 27042 detected");
            }

            // 2. 检测Frida特征文件
            String[] fridaFiles = {
                "/data/local/tmp/frida-server",
                "/data/local/tmp/frida-agent.so",
                "/data/local/tmp/frida-gadget.so",
                "/system/lib/frida-gadget.so",
                "/system/lib64/frida-gadget.so"
            };

            for (String fridaFile : fridaFiles) {
                if (new File(fridaFile).exists()) {
                    detectedItems.add("Frida检测: 发现Frida文件 " + fridaFile);
                    score += 20;
                    Log.w(TAG, "Frida file detected: " + fridaFile);
                    break;
                }
            }

            // 3. 检测Frida特征进程
            File procDir = new File("/proc");
            File[] pidDirs = procDir.listFiles();

            if (pidDirs != null) {
                for (File pidDir : pidDirs) {
                    if (!pidDir.isDirectory()) {
                        continue;
                    }

                    String pid = pidDir.getName();
                    if (!pid.matches("\\d+")) {
                        continue;
                    }

                    File cmdlineFile = new File(pidDir, "cmdline");
                    if (!cmdlineFile.exists()) {
                        continue;
                    }

                    try {
                        BufferedReader reader = new BufferedReader(new FileReader(cmdlineFile));
                        String cmdline = reader.readLine();
                        reader.close();

                        if (cmdline != null && (cmdline.contains("frida") || cmdline.contains("gadget"))) {
                            detectedItems.add("Frida检测: 发现Frida进程 PID=" + pid + ", CMD=" + cmdline);
                            score += 25;
                            Log.w(TAG, "Frida process detected: " + cmdline);
                            break;
                        }
                    } catch (Exception e) {
                        // 忽略读取失败的进程
                    }
                }
            }

            // 4. 检测Frida特征内存映射 - 修复：使用try-with-resources
            File mapsFile = new File("/proc/self/maps");
            if (mapsFile.exists()) {
                try (BufferedReader reader = new BufferedReader(new FileReader(mapsFile))) {
                    String line;

                    while ((line = reader.readLine()) != null) {
                        if (line.contains("frida") || line.contains("gadget")) {
                            detectedItems.add("Frida检测: 发现Frida内存映射");
                            score += 20;
                            Log.w(TAG, "Frida memory map detected");
                            break;
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error reading Frida memory maps", e);
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "Error detecting Frida", e);
        }

        return score;
    }

    /**
     * 检测Xposed（类 + 文件）
     * Xposed是一个Android Hook框架
     */
    private static int detectXposed(List<String> detectedItems) {
        int score = 0;

        try {
            // 1. 检测Xposed特征文件
            String[] xposedFiles = {
                "/system/bin/app_process32_xposed",
                "/system/bin/app_process64_xposed",
                "/system/lib/libxposed_art.so",
                "/system/lib64/libxposed_art.so",
                "/system/xposed.prop",
                "/cache/recovery/last_log"
            };

            for (String xposedFile : xposedFiles) {
                if (new File(xposedFile).exists()) {
                    detectedItems.add("Xposed检测: 发现Xposed文件 " + xposedFile);
                    score += 20;
                    Log.w(TAG, "Xposed file detected: " + xposedFile);
                    break;
                }
            }

            // 2. 检测Xposed特征环境变量
            try {
                String[] envVars = {
                    "CLASSPATH",
                    "LD_PRELOAD"
                };

                for (String envVar : envVars) {
                    String value = System.getenv(envVar);
                    if (value != null && (value.contains("xposed") || value.contains("XposedBridge"))) {
                        detectedItems.add("Xposed检测: 环境变量 " + envVar + " 包含Xposed特征");
                        score += 15;
                        Log.w(TAG, "Xposed environment variable detected: " + envVar);
                        break;
                    }
                }
            } catch (Exception e) {
                // 忽略环境变量读取错误
            }

            // 3. 检测Xposed特征类（通过反射）
            try {
                Class<?> xposedBridgeClass = Class.forName("de.robv.android.xposed.XposedBridge");
                if (xposedBridgeClass != null) {
                    detectedItems.add("Xposed检测: 发现XposedBridge类");
                    score += 30;
                    Log.w(TAG, "XposedBridge class detected");
                }
            } catch (ClassNotFoundException e) {
                // 未找到XposedBridge类，正常情况
            }

            // 4. 检测Xposed特征堆栈
            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            for (StackTraceElement element : stackTrace) {
                if (element.getClassName().contains("de.robv.android.xposed")) {
                    detectedItems.add("Xposed检测: 堆栈中发现Xposed调用");
                    score += 25;
                    Log.w(TAG, "Xposed stack trace detected");
                    break;
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "Error detecting Xposed", e);
        }

        return score;
    }

    /**
     * 检测内存断点
     * 内存断点是调试器常用的技术
     * 修复：使用try-with-resources确保资源释放
     */
    private static int detectMemoryBreakpoints(List<String> detectedItems) {
        int score = 0;

        try {
            // 检测/proc/self/status中的异常标志
            File statusFile = new File("/proc/self/status");
            if (statusFile.exists()) {
                try (BufferedReader reader = new BufferedReader(new FileReader(statusFile))) {
                    String line;

                    while ((line = reader.readLine()) != null) {
                        // 检测Ptrace字段
                        if (line.startsWith("TracerPid:")) {
                            String tracerPid = line.split(":")[1].trim();
                            if (!"0".equals(tracerPid)) {
                                detectedItems.add("内存断点检测: TracerPid=" + tracerPid + "（可能设置了断点）");
                                score += 15;
                                Log.w(TAG, "Memory breakpoint detected via TracerPid");
                            }
                        }
                    }
                }
            }

            // 检测/proc/self/mem的可写性
            File memFile = new File("/proc/self/mem");
            if (memFile.exists()) {
                try {
                    // 尝试读取/proc/self/mem
                    java.io.RandomAccessFile raf = new java.io.RandomAccessFile(memFile, "r");
                    raf.close();
                    // 如果能正常读取，可能没有设置断点
                } catch (Exception e) {
                    detectedItems.add("内存断点检测: /proc/self/mem访问异常（可能设置了断点）");
                    score += 10;
                    Log.w(TAG, "Memory breakpoint detected via /proc/self/mem");
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "Error detecting memory breakpoints", e);
        }

        return score;
    }

    /**
     * 检测Trace
     * Trace是调试器追踪程序执行的技术
     * 修复：使用try-with-resources确保资源释放
     */
    private static int detectTrace(List<String> detectedItems) {
        int score = 0;

        try {
            // 1. 检测/proc/self/status中的State字段
            File statusFile = new File("/proc/self/status");
            if (statusFile.exists()) {
                try (BufferedReader reader = new BufferedReader(new FileReader(statusFile))) {
                    String line;

                    while ((line = reader.readLine()) != null) {
                        if (line.startsWith("State:")) {
                            String state = line.split(":")[1].trim();
                            // t (tracing stop) 表示正在被追踪
                            if (state.startsWith("t")) {
                                detectedItems.add("Trace检测: State=" + state + "（正在被追踪）");
                                score += 20;
                                Log.w(TAG, "Trace detected via State field");
                            }
                            break;
                        }
                    }
                }
            }

            // 2. 检测strace进程
            File procDir = new File("/proc");
            File[] pidDirs = procDir.listFiles();

            if (pidDirs != null) {
                for (File pidDir : pidDirs) {
                    if (!pidDir.isDirectory()) {
                        continue;
                    }

                    String pid = pidDir.getName();
                    if (!pid.matches("\\d+")) {
                        continue;
                    }

                    File cmdlineFile = new File(pidDir, "cmdline");
                    if (!cmdlineFile.exists()) {
                        continue;
                    }

                    try (BufferedReader reader = new BufferedReader(new FileReader(cmdlineFile))) {
                        String cmdline = reader.readLine();

                        if (cmdline != null && cmdline.contains("strace")) {
                            detectedItems.add("Trace检测: 发现strace进程 PID=" + pid);
                            score += 25;
                            Log.w(TAG, "strace process detected: " + cmdline);
                            break;
                        }
                    } catch (Exception e) {
                        // 忽略读取失败的进程
                    }
                }
            }

            // 3. 检测ltrace进程
            if (pidDirs != null) {
                for (File pidDir : pidDirs) {
                    if (!pidDir.isDirectory()) {
                        continue;
                    }

                    String pid = pidDir.getName();
                    if (!pid.matches("\\d+")) {
                        continue;
                    }

                    File cmdlineFile = new File(pidDir, "cmdline");
                    if (!cmdlineFile.exists()) {
                        continue;
                    }

                    try (BufferedReader reader = new BufferedReader(new FileReader(cmdlineFile))) {
                        String cmdline = reader.readLine();

                        if (cmdline != null && cmdline.contains("ltrace")) {
                            detectedItems.add("Trace检测: 发现ltrace进程 PID=" + pid);
                            score += 25;
                            Log.w(TAG, "ltrace process detected: " + cmdline);
                            break;
                        }
                    } catch (Exception e) {
                        // 忽略读取失败的进程
                    }
                }
            }

        } catch (Exception e) {
            Log.e(TAG, "Error detecting Trace", e);
        }

        return score;
    }

    /**
     * 检测模拟器
     * 模拟器常用于逆向分析和调试
     */
    private static int detectEmulator(List<String> detectedItems) {
        int score = 0;

        try {
            // 1. 检测模拟器特征文件
            String[] emulatorFiles = {
                "/system/lib/libc_malloc_debug_qemu.so",
                "/system/bin/qemu-props",
                "/system/lib/libc_malloc_debug_qemu.so",
                "/system/lib64/libc_malloc_debug_qemu.so",
                "/system/qemu.prop",
                "/dev/socket/qemud",
                "/dev/qemu_pipe"
            };

            for (String emulatorFile : emulatorFiles) {
                if (new File(emulatorFile).exists()) {
                    detectedItems.add("模拟器检测: 发现模拟器文件 " + emulatorFile);
                    score += 15;
                    Log.w(TAG, "Emulator file detected: " + emulatorFile);
                    break;
                }
            }

            // 2. 检测模拟器特征属性 - 修复：移除过于宽泛的检测条件
                            try {
                                String[] emulatorProps = {
                                    "ro.kernel.qemu",  // QEMU内核是明确的模拟器特征
                                    "ro.hardware.goldfish"  // Goldfish是Android模拟器的硬件名称
                                };

                                for (String prop : emulatorProps) {
                                    String value = getSystemProperty(prop);
                                    if (value != null && (value.contains("qemu") || value.contains("goldfish"))) {
                                        detectedItems.add("模拟器检测: 系统属性 " + prop + "=" + value);
                                        score += 10;
                                        Log.w(TAG, "Emulator property detected: " + prop + "=" + value);
                                        break;
                                    }
                                }
                            } catch (Exception e) {
                                // 忽略属性读取错误
                            }

            // 3. 检测模拟器特征设备信息
            try {
                String[] emulatorFeatures = {
                    "ro.build.fingerprint",
                    "ro.product.device",
                    "ro.product.name"
                };

                for (String feature : emulatorFeatures) {
                    String value = getSystemProperty(feature);
                    if (value != null && (value.contains("generic") || value.contains("sdk") || value.contains("android"))) {
                        detectedItems.add("模拟器检测: 设备信息 " + feature + "=" + value);
                        score += 10;
                        Log.w(TAG, "Emulator device detected: " + feature + "=" + value);
                        break;
                    }
                }
            } catch (Exception e) {
                // 忽略设备信息读取错误
            }

            // 4. 检测模拟器特征网络接口
            try {
                File[] networkInterfaces = new File("/sys/class/net").listFiles();
                if (networkInterfaces != null) {
                    for (File iface : networkInterfaces) {
                        String ifaceName = iface.getName();
                        if (ifaceName.contains("virbr") || ifaceName.contains("vboxnet") || ifaceName.contains("docker")) {
                            detectedItems.add("模拟器检测: 发现虚拟网络接口 " + ifaceName);
                            score += 10;
                            Log.w(TAG, "Emulator network interface detected: " + ifaceName);
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                // 忽略网络接口检测错误
            }

            // 5. 检测模拟器特征CPU信息
            try {
                String cpuInfo = readFile("/proc/cpuinfo");
                if (cpuInfo != null) {
                    if (cpuInfo.contains("QEMU") || cpuInfo.contains("Bochs") || cpuInfo.contains("VirtualBox")) {
                        detectedItems.add("模拟器检测: CPU信息包含虚拟化特征");
                        score += 15;
                        Log.w(TAG, "Emulator CPU detected");
                    }
                }
            } catch (Exception e) {
                // 忽略CPU信息读取错误
            }

        } catch (Exception e) {
            Log.e(TAG, "Error detecting Emulator", e);
        }

        return score;
    }

    /**
     * 读取系统属性
     */
    private static String getSystemProperty(String key) {
        try {
            Class<?> c = Class.forName("android.os.SystemProperties");
            java.lang.reflect.Method get = c.getMethod("get", String.class);
            return (String) get.invoke(c, key);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 读取文件内容
     * 修复：使用try-with-resources确保资源释放
     */
    private static String readFile(String path) {
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}