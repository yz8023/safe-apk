package com.ark.security;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;

/**
 * 内存保护工具类
 * 用于保护DEX内存，防止root设备通过内存dump获取原始DEX
 *
 * 保护措施：
 * 1. 内存权限控制（mprotect）
 * 2. CRC校验检测内存篡改
 * 3. 内存加密/解密机制
 * 4. 定期完整性检查
 */
public class MemoryProtector {

    private static final String TAG = "MemoryProtector";

    /**
     * 内存保护级别
     */
    public enum ProtectionLevel {
        NONE,           // 无保护
        LOW,            // 低级保护（仅CRC校验）
        MEDIUM,         // 中级保护（CRC + 内存权限控制）
        HIGH,           // 高级保护（CRC + 内存权限 + 加密）
        MAX             // 最高级保护（所有保护措施 + 定期检查）
    }

    /**
     * 内存保护信息
     */
    public static class MemoryProtectionInfo {
        public long memoryAddress;
        public int size;
        public int crc;
        public ProtectionLevel level;
        public boolean isProtected;
        public long lastCheckTime;

        public MemoryProtectionInfo(long address, int size, int crc, ProtectionLevel level) {
            this.memoryAddress = address;
            this.size = size;
            this.crc = crc;
            this.level = level;
            this.isProtected = false;
            this.lastCheckTime = System.currentTimeMillis();
        }
    }

    // 内存保护信息映射表
    private static Map<String, MemoryProtectionInfo> protectedMemoryMap = new HashMap<>();

    // 加密密钥（实际使用时应该从安全存储获取）
    private static byte[] encryptionKey = new byte[16];

    // 保护级别
    private static ProtectionLevel currentProtectionLevel = ProtectionLevel.MEDIUM;

    // 是否启用定期检查
    private static boolean enablePeriodicCheck = false;

    // 检查间隔（毫秒）
    private static long checkInterval = 5000;

    // 检查线程
    private static Thread checkThread;

    // Native库加载状态
    private static boolean nativeLibraryLoaded = false;

    static {
        // 初始化加密密钥（实际使用时应该从安全位置获取）
        for (int i = 0; i < encryptionKey.length; i++) {
            encryptionKey[i] = (byte) (i * 17);
        }
    }

    /**
     * 初始化内存保护
     *
     * @param context 上下文
     * @param level 保护级别
     */
    public static void init(Context context, ProtectionLevel level) {
        currentProtectionLevel = level;
        Log.i(TAG, "MemoryProtector initialized with level: " + level);

        // 修复：不再自动启用MAX保护级别，避免内存权限错误
        // 如果是root设备，记录警告但不自动提升保护级别
        if (RootDetector.quickDetect()) {
            Log.w(TAG, "Root device detected, but not automatically enabling MAX protection to avoid permission errors");
            Log.w(TAG, "Current protection level: " + currentProtectionLevel);
        }

        // 根据保护级别启用定期检查
        if (currentProtectionLevel == ProtectionLevel.MAX) {
            enablePeriodicCheck = true;
            startPeriodicCheck();
        }
    }

    /**
     * 保护DEX内存
     *
     * @param dexData DEX数据
     * @param dexName DEX名称
     * @return 保护信息
     */
    public static MemoryProtectionInfo protectDexMemory(byte[] dexData, String dexName) {
        if (dexData == null || dexData.length == 0) {
            Log.e(TAG, "DEX data is null or empty");
            return null;
        }

        if (currentProtectionLevel == ProtectionLevel.NONE) {
            Log.w(TAG, "Protection is disabled");
            return null;
        }

        try {
            // 计算CRC校验
            int crc = calculateCRC32(dexData);

            // 创建保护信息
            MemoryProtectionInfo info = new MemoryProtectionInfo(0, dexData.length, crc, currentProtectionLevel);

            // 根据保护级别应用不同的保护措施
            switch (currentProtectionLevel) {
                case LOW:
                    // 仅CRC校验
                    info.isProtected = true;
                    break;

                case MEDIUM:
                    // CRC + 内存权限控制
                    info.isProtected = protectMemoryWithPermissions(dexData);
                    break;

                case HIGH:
                case MAX:
                    // CRC + 内存权限 + 加密
                    info.isProtected = protectMemoryWithEncryption(dexData);
                    break;
            }

            // 保存保护信息
            protectedMemoryMap.put(dexName, info);

            Log.i(TAG, "DEX memory protected: " + dexName + ", level: " + currentProtectionLevel);

            return info;

        } catch (Exception e) {
            Log.e(TAG, "Failed to protect DEX memory: " + dexName, e);
            return null;
        }
    }

    /**
     * 使用权限控制保护内存
     */
    private static boolean protectMemoryWithPermissions(byte[] data) {
        try {
            // 在Native层调用mprotect设置内存为只读
            if (nativeLibraryLoaded) {
                boolean success = nativeSetMemoryReadOnly(data, data.length);
                if (success) {
                    Log.i(TAG, "Memory set to read-only successfully");
                } else {
                    Log.w(TAG, "Failed to set memory read-only");
                }
                return success;
            } else {
                Log.w(TAG, "Native library not loaded, skipping memory permission protection");
                return false;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error setting memory permissions", e);
            return false;
        }
    }

    /**
     * 使用加密保护内存
     */
    private static boolean protectMemoryWithEncryption(byte[] data) {
        try {
            // 先设置内存权限
            boolean permissionsOk = protectMemoryWithPermissions(data);

            // 加密数据（在Native层实现）
            if (nativeLibraryLoaded) {
                boolean encryptionOk = nativeEncryptMemory(data, encryptionKey);
                return permissionsOk && encryptionOk;
            } else {
                Log.w(TAG, "Native library not loaded, skipping memory encryption");
                return permissionsOk;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error encrypting memory", e);
            return false;
        }
    }

    /**
     * 解密内存（运行时需要执行时调用）
     */
    public static boolean decryptMemory(byte[] data, String dexName) {
        if (!protectedMemoryMap.containsKey(dexName)) {
            Log.w(TAG, "DEX not found in protected memory map: " + dexName);
            return false;
        }

        MemoryProtectionInfo info = protectedMemoryMap.get(dexName);

        if (info.level == ProtectionLevel.LOW || info.level == ProtectionLevel.MEDIUM) {
            // 低级和中级保护不需要解密
            return true;
        }

        try {
            if (nativeLibraryLoaded) {
                boolean success = nativeDecryptMemory(data, encryptionKey);
                if (success) {
                    Log.i(TAG, "Memory decrypted successfully: " + dexName);
                } else {
                    Log.e(TAG, "Failed to decrypt memory: " + dexName);
                }
                return success;
            } else {
                Log.w(TAG, "Native library not loaded, skipping memory decryption");
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error decrypting memory: " + dexName, e);
            return false;
        }
    }

    /**
     * 验证内存完整性
     *
     * @param data 内存数据
     * @param dexName DEX名称
     * @return true表示内存完整
     */
    public static boolean verifyMemoryIntegrity(byte[] data, String dexName) {
        if (!protectedMemoryMap.containsKey(dexName)) {
            Log.w(TAG, "DEX not found in protected memory map: " + dexName);
            return false;
        }

        MemoryProtectionInfo info = protectedMemoryMap.get(dexName);

        try {
            // 计算当前CRC
            int currentCRC = calculateCRC32(data);

            // 比较CRC
            boolean integrityOk = (currentCRC == info.crc);

            if (!integrityOk) {
                Log.e(TAG, "Memory integrity check failed: " + dexName);
                Log.e(TAG, "Expected CRC: " + info.crc + ", Actual CRC: " + currentCRC);
            } else {
                Log.i(TAG, "Memory integrity verified: " + dexName);
            }

            // 更新检查时间
            info.lastCheckTime = System.currentTimeMillis();

            return integrityOk;

        } catch (Exception e) {
            Log.e(TAG, "Error verifying memory integrity: " + dexName, e);
            return false;
        }
    }

    /**
     * 计算CRC32校验
     */
    private static int calculateCRC32(byte[] data) {
        java.util.zip.CRC32 crc32 = new java.util.zip.CRC32();
        crc32.update(data);
        return (int) crc32.getValue();
    }

    /**
     * 计算SHA256哈希
     */
    private static String calculateSHA256(byte[] data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data);

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }

            return hexString.toString();
        } catch (Exception e) {
            Log.e(TAG, "Error calculating SHA256", e);
            return "";
        }
    }

    /**
     * 启动定期检查
     */
    private static void startPeriodicCheck() {
        if (checkThread != null && checkThread.isAlive()) {
            Log.w(TAG, "Periodic check thread already running");
            return;
        }

        checkThread = new Thread(new Runnable() {
            @Override
            public void run() {
                Log.i(TAG, "Periodic memory check started");

                while (enablePeriodicCheck) {
                    try {
                        // 检查所有受保护的内存
                        for (Map.Entry<String, MemoryProtectionInfo> entry : protectedMemoryMap.entrySet()) {
                            String dexName = entry.getKey();
                            MemoryProtectionInfo info = entry.getValue();

                            // 读取内存数据（需要在Native层实现）
                            if (nativeLibraryLoaded) {
                                byte[] memoryData = nativeReadMemory(info.memoryAddress, info.size);

                                if (memoryData != null) {
                                    boolean integrityOk = verifyMemoryIntegrity(memoryData, dexName);

                                    if (!integrityOk) {
                                        Log.e(TAG, "Memory tampering detected: " + dexName);

                                        // 内存被篡改，采取防御措施
                                        handleMemoryTampering(dexName);
                                    }
                                }
                            }
                        }

                        // 等待下一次检查
                        Thread.sleep(checkInterval);

                    } catch (InterruptedException e) {
                        Log.i(TAG, "Periodic check interrupted");
                        break;
                    } catch (Exception e) {
                        Log.e(TAG, "Error in periodic check", e);
                    }
                }

                Log.i(TAG, "Periodic memory check stopped");
            }
        });

        checkThread.setDaemon(true);
        checkThread.setName("MemoryProtector-CheckThread");
        checkThread.start();
    }

    /**
     * 停止定期检查
     */
    public static void stopPeriodicCheck() {
        enablePeriodicCheck = false;
        if (checkThread != null && checkThread.isAlive()) {
            checkThread.interrupt();
        }
        Log.i(TAG, "Periodic memory check stopped");
    }

    /**
     * 处理内存篡改
     */
    private static void handleMemoryTampering(String dexName) {
        Log.e(TAG, "Handling memory tampering: " + dexName);

        // 可以采取以下措施：
        // 1. 终止应用
        // 2. 清空内存
        // 3. 显示警告
        // 4. 上报安全事件

        // 这里简单实现：清空内存并终止应用
        try {
            MemoryProtectionInfo info = protectedMemoryMap.get(dexName);
            if (info != null && nativeLibraryLoaded) {
                nativeClearMemory(info.memoryAddress, info.size);
            }

            // 终止应用
            System.exit(1);
        } catch (Exception e) {
            Log.e(TAG, "Error handling memory tampering", e);
        }
    }

    /**
     * 清除所有受保护的内存
     */
    public static void clearAllProtectedMemory() {
        Log.i(TAG, "Clearing all protected memory");

        for (Map.Entry<String, MemoryProtectionInfo> entry : protectedMemoryMap.entrySet()) {
            String dexName = entry.getKey();
            MemoryProtectionInfo info = entry.getValue();

            try {
                if (nativeLibraryLoaded) {
                    nativeClearMemory(info.memoryAddress, info.size);
                    Log.i(TAG, "Memory cleared: " + dexName);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error clearing memory: " + dexName, e);
            }
        }

        protectedMemoryMap.clear();
    }

    /**
     * 获取保护统计信息
     */
    public static String getProtectionStatistics() {
        StringBuilder stats = new StringBuilder();

        stats.append("========== 内存保护统计 ==========\n");
        stats.append("保护级别: ").append(currentProtectionLevel).append("\n");
        stats.append("受保护的DEX数量: ").append(protectedMemoryMap.size()).append("\n");
        stats.append("定期检查: ").append(enablePeriodicCheck ? "启用" : "禁用").append("\n");
        stats.append("检查间隔: ").append(checkInterval).append("ms\n");
        stats.append("Native库状态: ").append(nativeLibraryLoaded ? "已加载" : "未加载").append("\n");
        stats.append("\n详细信息:\n");

        for (Map.Entry<String, MemoryProtectionInfo> entry : protectedMemoryMap.entrySet()) {
            String dexName = entry.getKey();
            MemoryProtectionInfo info = entry.getValue();

            stats.append("  DEX: ").append(dexName).append("\n");
            stats.append("    地址: 0x").append(Long.toHexString(info.memoryAddress)).append("\n");
            stats.append("    大小: ").append(info.size).append(" bytes\n");
            stats.append("    CRC: ").append(info.crc).append("\n");
            stats.append("    保护状态: ").append(info.isProtected ? "已保护" : "未保护").append("\n");
            stats.append("    最后检查: ").append(new java.util.Date(info.lastCheckTime)).append("\n");
        }

        stats.append("==================================\n");

        return stats.toString();
    }

    /**
     * 设置保护级别
     */
    public static void setProtectionLevel(ProtectionLevel level) {
        currentProtectionLevel = level;
        Log.i(TAG, "Protection level changed to: " + level);
    }

    /**
     * 获取保护级别
     */
    public static ProtectionLevel getProtectionLevel() {
        return currentProtectionLevel;
    }

    /**
     * 设置检查间隔
     */
    public static void setCheckInterval(long interval) {
        checkInterval = interval;
        Log.i(TAG, "Check interval changed to: " + interval + "ms");
    }

    // ========== Native方法声明 ==========

    /**
     * Native方法：设置内存为只读
     */
    private native static boolean nativeSetMemoryReadOnly(byte[] data, int size);

    /**
     * Native方法：加密内存
     */
    private native static boolean nativeEncryptMemory(byte[] data, byte[] key);

    /**
     * Native方法：解密内存
     */
    private native static boolean nativeDecryptMemory(byte[] data, byte[] key);

    /**
     * Native方法：读取内存
     */
    private native static byte[] nativeReadMemory(long address, int size);

    /**
     * Native方法：清空内存
     */
    private native static void nativeClearMemory(long address, int size);

    /**
     * Native方法：获取内存地址
     */
    private native static long nativeGetMemoryAddress(byte[] data);

    // 加载Native库
    static {
        try {
            System.loadLibrary("ArkTool");
            nativeLibraryLoaded = true;
            Log.i(TAG, "Native library loaded successfully");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Failed to load native library, memory protection will be limited", e);
            nativeLibraryLoaded = false;
        }
    }
}