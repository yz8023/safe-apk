package com.ark.security;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 安全功能配置管理器
 * 负责读取和管理security_config.json配置文件
 */
public class SecurityConfigManager {
    private static final String TAG = "SecurityConfigManager";
    private static final String CONFIG_FILE = "security_config.json";

    private static SecurityConfigManager instance;
    private JSONObject config;
    private Context context;

    private SecurityConfigManager(Context context) {
        this.context = context.getApplicationContext();
        loadConfig();
    }

    /**
     * 获取单例实例
     */
    public static synchronized SecurityConfigManager getInstance(Context context) {
        if (instance == null) {
            instance = new SecurityConfigManager(context);
        }
        return instance;
    }

    /**
     * 加载配置文件
     */
    private void loadConfig() {
        try {
            AssetManager assetManager = context.getAssets();
            InputStream inputStream = assetManager.open(CONFIG_FILE);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder stringBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
            reader.close();
            inputStream.close();

            config = new JSONObject(stringBuilder.toString());
            Log.i(TAG, "配置文件加载成功");
        } catch (IOException | JSONException e) {
            Log.e(TAG, "加载配置文件失败: " + e.getMessage());
            config = new JSONObject();
        }
    }

    /**
     * 重新加载配置文件
     */
    public void reloadConfig() {
        loadConfig();
    }

    /**
     * 获取完整配置对象
     */
    public JSONObject getConfig() {
        return config;
    }

    /**
     * 检查功能是否启用
     */
    public boolean isFeatureEnabled(String featureName) {
        try {
            JSONObject feature = config.optJSONObject(featureName);
            if (feature == null) {
                Log.w(TAG, "功能配置不存在: " + featureName);
                return false;
            }
            return feature.optBoolean("enabled", false);
        } catch (Exception e) {
            Log.e(TAG, "检查功能启用状态失败: " + featureName + ", " + e.getMessage());
            return false;
        }
    }

    /**
     * 获取功能的配置对象
     */
    public JSONObject getFeatureConfig(String featureName) {
        return config.optJSONObject(featureName);
    }

    /**
     * 获取全局配置
     */
    public JSONObject getGlobalSettings() {
        return config.optJSONObject("global_settings");
    }

    /**
     * 检查全局日志是否启用
     */
    public boolean isLogEnabled() {
        JSONObject global = getGlobalSettings();
        if (global != null) {
            return global.optBoolean("log_enabled", true);
        }
        return true;
    }

    /**
     * 获取日志级别
     */
    public String getLogLevel() {
        JSONObject global = getGlobalSettings();
        if (global != null) {
            return global.optString("log_level", "INFO");
        }
        return "INFO";
    }

    /**
     * 检查是否允许调试构建
     */
    public boolean isAllowDebugBuild() {
        JSONObject global = getGlobalSettings();
        if (global != null) {
            return global.optBoolean("allow_debug_build", true);
        }
        return true;
    }

    /**
     * 检查严格模式
     */
    public boolean isStrictMode() {
        JSONObject global = getGlobalSettings();
        if (global != null) {
            return global.optBoolean("strict_mode", false);
        }
        return false;
    }

    // ==================== 签名校验配置 ====================

    public boolean isSignatureCheckEnabled() {
        return isFeatureEnabled("signature_check");
    }

    public boolean isSignatureStrictMode() {
        JSONObject feature = getFeatureConfig("signature_check");
        if (feature != null) {
            return feature.optBoolean("strict_mode", false);
        }
        return false;
    }

    // ==================== Root检测配置 ====================

    public boolean isRootDetectionEnabled() {
        return isFeatureEnabled("root_detection");
    }

    public int getRootCheckInterval() {
        JSONObject feature = getFeatureConfig("root_detection");
        if (feature != null) {
            return feature.optInt("check_interval_ms", 30000);
        }
        return 30000;
    }

    public String getRootResponseStrategy() {
        JSONObject feature = getFeatureConfig("root_detection");
        if (feature != null) {
            return feature.optString("response_strategy", "HIGH_RISK");
        }
        return "HIGH_RISK";
    }

    // ==================== 反调试配置 ====================

    public boolean isAntiDebugEnabled() {
        return isFeatureEnabled("anti_debug");
    }

    public int getAntiDebugInterval() {
        JSONObject feature = getFeatureConfig("anti_debug");
        if (feature != null) {
            return feature.optInt("detection_interval_ms", 5000);
        }
        return 5000;
    }

    public String getAntiDebugResponseStrategy() {
        JSONObject feature = getFeatureConfig("anti_debug");
        if (feature != null) {
            return feature.optString("response_strategy", "RISK_BASED");
        }
        return "RISK_BASED";
    }

    // ==================== 内存保护配置 ====================

    public boolean isMemoryProtectionEnabled() {
        return isFeatureEnabled("memory_protection");
    }

    public String getMemoryProtectionLevel() {
        JSONObject feature = getFeatureConfig("memory_protection");
        if (feature != null) {
            return feature.optString("protection_level", "MEDIUM");
        }
        return "MEDIUM";
    }

    // ==================== VMP配置 ====================

    public boolean isVmpEnabled() {
        return isFeatureEnabled("vmp");
    }

    public String getVmpExtractionMode() {
        JSONObject feature = getFeatureConfig("vmp");
        if (feature != null) {
            return feature.optString("extraction_mode", "AUTO");
        }
        return "AUTO";
    }

    public List<String> getVmpTargetActivities() {
        List<String> activities = new ArrayList<>();
        try {
            JSONObject feature = getFeatureConfig("vmp");
            if (feature != null) {
                JSONArray array = feature.optJSONArray("target_activities");
                if (array != null) {
                    for (int i = 0; i < array.length(); i++) {
                        activities.add(array.getString(i));
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "获取VMP目标Activity失败: " + e.getMessage());
        }
        return activities;
    }

    // ==================== DEX加密配置 ====================

    public boolean isDexEncryptionEnabled() {
        return isFeatureEnabled("dex_encryption");
    }

    public String getDexEncryptionAlgorithm() {
        JSONObject feature = getFeatureConfig("dex_encryption");
        if (feature != null) {
            return feature.optString("encryption_algorithm", "AES");
        }
        return "AES";
    }

    // ==================== 灰度发布配置 ====================

    public boolean isGrayscaleEnabled() {
        return isFeatureEnabled("grayscale_manager");
    }

    public int getGrayscaleSampleRate() {
        JSONObject feature = getFeatureConfig("grayscale_manager");
        if (feature != null) {
            return feature.optInt("sample_rate", 100);
        }
        return 100;
    }

    public String getGrayscaleVersion() {
        JSONObject feature = getFeatureConfig("grayscale_manager");
        if (feature != null) {
            return feature.optString("version", "1.0");
        }
        return "1.0";
    }

    public Map<String, Boolean> getGrayscaleFeatures() {
        Map<String, Boolean> features = new HashMap<>();
        try {
            JSONObject feature = getFeatureConfig("grayscale_manager");
            if (feature != null) {
                JSONObject featuresObj = feature.optJSONObject("features");
                if (featuresObj != null) {
                    JSONArray names = featuresObj.names();
                    if (names != null) {
                        for (int i = 0; i < names.length(); i++) {
                            String name = names.getString(i);
                            features.put(name, featuresObj.getBoolean(name));
                        }
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "获取灰度功能配置失败: " + e.getMessage());
        }
        return features;
    }

    // ==================== 性能监控配置 ====================

    public boolean isPerformanceMonitorEnabled() {
        return isFeatureEnabled("performance_monitor");
    }

    public int getSlowOperationThreshold() {
        JSONObject feature = getFeatureConfig("performance_monitor");
        if (feature != null) {
            return feature.optInt("slow_threshold_ms", 1000);
        }
        return 1000;
    }

    // ==================== 版本降级管理配置 ====================

    public boolean isDowngradeManagerEnabled() {
        return isFeatureEnabled("downgrade_manager");
    }

    public String getMinSupportedVersion() {
        JSONObject feature = getFeatureConfig("downgrade_manager");
        if (feature != null) {
            return feature.optString("min_supported_version", "1.0");
        }
        return "1.0";
    }

    // ==================== 工具方法 ====================

    /**
     * 获取配置的字符串值
     */
    public String getString(String featureName, String key, String defaultValue) {
        JSONObject feature = getFeatureConfig(featureName);
        if (feature != null) {
            return feature.optString(key, defaultValue);
        }
        return defaultValue;
    }

    /**
     * 获取配置的整数值
     */
    public int getInt(String featureName, String key, int defaultValue) {
        JSONObject feature = getFeatureConfig(featureName);
        if (feature != null) {
            return feature.optInt(key, defaultValue);
        }
        return defaultValue;
    }

    /**
     * 获取配置的布尔值
     */
    public boolean getBoolean(String featureName, String key, boolean defaultValue) {
        JSONObject feature = getFeatureConfig(featureName);
        if (feature != null) {
            return feature.optBoolean(key, defaultValue);
        }
        return defaultValue;
    }

    /**
     * 打印当前配置（用于调试）
     */
    public void printConfig() {
        if (config != null) {
            Log.d(TAG, "当前配置: " + config.toString());
        } else {
            Log.w(TAG, "配置未加载");
        }
    }

    /**
     * 获取配置摘要
     */
    public String getConfigSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append("=== 安全功能配置摘要 ===\n");

        String[] features = {
            "signature_check", "root_detection", "anti_debug", "memory_protection",
            "vmp", "dex_encryption", "class_decryptor", "whitebox_decrypt",
            "dynamic_key_generator", "dex_integrity", "downgrade_manager",
            "grayscale_manager", "performance_monitor", "secure_logger", "so_encryption"
        };

        for (String feature : features) {
            boolean enabled = isFeatureEnabled(feature);
            summary.append(String.format("%-25s: %s\n", feature, enabled ? "启用" : "禁用"));
        }

        return summary.toString();
    }
}