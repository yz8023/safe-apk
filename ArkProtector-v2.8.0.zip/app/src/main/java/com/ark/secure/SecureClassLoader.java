package com.ark.secure;

import android.os.Build;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 安全类加载器 - 实现类粒度DEX加载
 * 避免一次性加载完整DEX文件，提升内存安全性
 */
public class SecureClassLoader extends ClassLoader {
    private static final String TAG = "SecureClassLoader";
    
    // 类数据缓存（仅缓存最近使用的，最多50个）
    private static final int MAX_CACHE_SIZE = 50;
    private final ConcurrentHashMap<String, byte[]> mClassCache = new ConcurrentHashMap<>();
    
    // Native方法
    private static native byte[] decryptClassData(String className);
    private static native void freeClassData(byte[] data);
    
    private final boolean mIsVmpEnabled;
    private final int mApiLevel;
    
    public SecureClassLoader(ClassLoader parent) {
        super(parent);
        mApiLevel = Build.VERSION.SDK_INT;
        // 根据API级别决定是否启用VMP
        mIsVmpEnabled = mApiLevel >= Build.VERSION_CODES.M;
        
        if (mIsVmpEnabled) {
            try {
                System.loadLibrary("ArkStub");
                Log.i(TAG, "SecureClassLoader初始化成功，VMP已启用");
            } catch (UnsatisfiedLinkError e) {
                Log.e(TAG, "加载ArkStub失败，VMP将不可用", e);
            }
        } else {
            Log.i(TAG, "SecureClassLoader初始化成功，VMP未启用（API级别过低）");
        }
    }
    
    @Override
    protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
        // 系统类直接放行
        if (name.startsWith("java.") || name.startsWith("android.") ||
            name.startsWith("androidx.") || name.startsWith("dalvik.")) {
            return super.loadClass(name, resolve);
        }
        
        // 检查是否已加载
        Class<?> existing = findLoadedClass(name);
        if (existing != null) {
            return existing;
        }
        
        try {
            // 尝试从缓存获取
            byte[] classData = mClassCache.get(name);
            if (classData == null) {
                // 从Native层解密
                if (mIsVmpEnabled) {
                    classData = decryptClassData(name);
                    if (classData != null) {
                        // 缓存
                        cacheClassData(name, classData);
                    }
                }
            }
            
            if (classData != null) {
                Class<?> clazz = defineClass(name, classData, 0, classData.length);
                if (resolve) {
                    resolveClass(clazz);
                }
                Log.d(TAG, "成功加载类: " + name);
                return clazz;
            }
        } catch (Exception e) {
            Log.w(TAG, "加载类失败，尝试父类加载器: " + name, e);
        }
        
        // 降级：使用父类加载器
        return super.loadClass(name, resolve);
    }
    
    /**
     * 缓存类数据（LRU策略）
     */
    private void cacheClassData(String name, byte[] data) {
        // LRU缓存管理
        if (mClassCache.size() >= MAX_CACHE_SIZE) {
            // 移除最旧的条目（简单实现）
            String oldest = mClassCache.keys().nextElement();
            byte[] oldData = mClassCache.remove(oldest);
            freeClassData(oldData);
            Log.d(TAG, "缓存已满，移除最旧条目: " + oldest);
        }
        mClassCache.put(name, data);
        Log.d(TAG, "缓存类数据: " + name + ", 大小: " + data.length + " 字节");
    }
    
    /**
     * 清除缓存
     */
    public void clearCache() {
        Log.i(TAG, "清除类缓存");
        for (byte[] data : mClassCache.values()) {
            freeClassData(data);
        }
        mClassCache.clear();
    }
    
    /**
     * 获取缓存统计信息
     */
    public String getCacheStats() {
        return "缓存大小: " + mClassCache.size() + "/" + MAX_CACHE_SIZE;
    }
    
    /**
     * 预加载类（可选）
     */
    public boolean preloadClass(String name) {
        try {
            byte[] classData = decryptClassData(name);
            if (classData != null) {
                cacheClassData(name, classData);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "预加载类失败: " + name, e);
        }
        return false;
    }
    
    /**
     * 批量预加载类
     */
    public void preloadClasses(String[] classNames) {
        Log.i(TAG, "开始批量预加载类，数量: " + classNames.length);
        int successCount = 0;
        for (String className : classNames) {
            if (preloadClass(className)) {
                successCount++;
            }
        }
        Log.i(TAG, "批量预加载完成，成功: " + successCount + "/" + classNames.length);
    }
}
