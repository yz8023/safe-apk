package com.ark.jiagu;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/**
 * 设置模板管理器。
 * 将当前设置保存为命名模板，支持加载、删除、列出模板。
 * 模板数据以 JSON 格式存储在 SharedPreferences 中。
 */
public class ArkSettingsTemplateManager {

    private static final String SP_TEMPLATES = "ark_settings_templates";
    private static final String KEY_TEMPLATES_JSON = "templates_json";

    private final SharedPreferences sp;

    public ArkSettingsTemplateManager(Context context) {
        this.sp = context.getSharedPreferences(SP_TEMPLATES, Context.MODE_PRIVATE);
    }

    /**
     * 保存当前设置为一个模板。
     */
    public boolean saveTemplate(String name, Map<String, Boolean> settings) {
        try {
            JSONObject root = loadJson();
            JSONObject template = new JSONObject();
            for (Map.Entry<String, Boolean> e : settings.entrySet()) {
                template.put(e.getKey(), e.getValue());
            }
            root.put(name, template);
            sp.edit().putString(KEY_TEMPLATES_JSON, root.toString()).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 加载一个模板的设置值。
     */
    public Map<String, Boolean> loadTemplate(String name) {
        try {
            JSONObject root = loadJson();
            JSONObject template = root.optJSONObject(name);
            if (template == null) return Collections.emptyMap();
            Map<String, Boolean> result = new HashMap<>();
            for (Iterator<String> it = template.keys(); it.hasNext(); ) {
                String key = it.next();
                result.put(key, template.optBoolean(key, false));
            }
            return result;
        } catch (Exception e) {
            return Collections.emptyMap();
        }
    }

    /**
     * 删除一个模板。
     */
    public boolean deleteTemplate(String name) {
        try {
            JSONObject root = loadJson();
            if (!root.has(name)) return false;
            root.remove(name);
            sp.edit().putString(KEY_TEMPLATES_JSON, root.toString()).apply();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 获取所有模板名称列表。
     */
    public List<String> listTemplates() {
        try {
            JSONObject root = loadJson();
            List<String> names = new ArrayList<>();
            for (Iterator<String> it = root.keys(); it.hasNext(); ) {
                names.add(it.next());
            }
            Collections.sort(names);
            return names;
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    private JSONObject loadJson() {
        try {
            String json = sp.getString(KEY_TEMPLATES_JSON, "{}");
            return new JSONObject(json);
        } catch (Exception e) {
            return new JSONObject();
        }
    }
}