package com.ark.jiagu.dpt;

import java.io.*;
import java.nio.*;
import java.util.*;

/**
 * CodeItem二进制存储格式
 *
 * 文件布局：
 * | version   : uint16 (LE) | 1=标准版, 2=增强版
 * | dexCount  : uint16 (LE)
 * | dexOffsets[dexCount] : uint32 (LE)  每个DEX数据块在文件中的偏移
 * | 对每个dex:
 * |     methodCount : uint16 (LE)
 * |     对每个方法:
 * |         methodIndex  : uint32 (LE)
 * |         codeOffset   : uint32 (LE)  code_item 在 DEX 中的偏移
 * |         insnsSize    : uint32 (LE)  字节数
 * |         xorKey       : uint32 (LE)  增强版的XOR密钥(标准版=0)
 * |         noiseSeed    : uint32 (LE)  增强版的噪声种子(标准版=0)
 * |         insnsData    : insnsSize 字节
 */
public class DptCodeItemStore {

    private static final int VERSION_STANDARD = 1;
    private static final int VERSION_ENHANCED = 2;
    private final boolean enhanced;

    public DptCodeItemStore(boolean enhanced) {
        this.enhanced = enhanced;
    }

    public void write(File outFile, List<DptCodeExtractor.DexCodeItems> allDexItems) throws Exception {
        int version = enhanced ? VERSION_ENHANCED : VERSION_STANDARD;
        int dexCount = allDexItems.size();

        int headerSize = 4 + dexCount * 4;
        int[] dexOffsets = new int[dexCount];
        int currentOffset = headerSize;

        for (int i = 0; i < dexCount; i++) {
            dexOffsets[i] = currentOffset;
            DptCodeExtractor.DexCodeItems dex = allDexItems.get(i);
            int dexBlockSize = 2; // methodCount
            for (DptCodeExtractor.MethodCodeItem m : dex.methods) {
                dexBlockSize += 4 + 4 + 4 + 4 + 4; // methodIndex + codeOffset + insnsSize + xorKey + noiseSeed
                dexBlockSize += m.originalBytes.length;
            }
            currentOffset += dexBlockSize;
        }

        ByteBuffer buf = ByteBuffer.allocate(currentOffset).order(ByteOrder.LITTLE_ENDIAN);
        buf.putShort((short) version);
        buf.putShort((short) dexCount);
        for (int off : dexOffsets) buf.putInt(off);

        for (DptCodeExtractor.DexCodeItems dex : allDexItems) {
            buf.putShort((short) dex.methods.size());
            for (DptCodeExtractor.MethodCodeItem m : dex.methods) {
                buf.putInt(m.methodIndex);
                buf.putInt(m.codeOffset);
                buf.putInt(m.insnsSize);
                buf.putInt(m.xorKey);
                buf.putInt(m.noiseSeed);
                buf.put(m.originalBytes);
            }
        }

        try (FileOutputStream fos = new FileOutputStream(outFile);
             BufferedOutputStream bos = new BufferedOutputStream(fos)) {
            bos.write(buf.array());
        }
    }
}
