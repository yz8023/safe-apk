package com.ark.jiagu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Protection Rule Engine.
 * Allows users to define custom protection rules that are applied during the protection process.
 * Rules are stored as a simple text file in the work directory.
 *
 * 规则文件格式（每行一条规则）：TYPE|pattern|target
 * - target 可省略（仅对需要目标值的规则类型有意义，如 RENAME_TO）
 * - 以 # 开头的行为注释，空行被忽略
 *
 * 支持的规则类型：
 *   KEEP_CLASS|Lcom/example/MainActivity;        不混淆指定类
 *   KEEP_PACKAGE|Lcom/google/                    不混淆指定包（前缀匹配）
 *   KEEP_METHOD|Lcom/example/Foo;->bar(II)V      不混淆指定方法
 *   KEEP_FIELD|Lcom/example/Foo;->bar:I          不混淆指定字段
 *   RENAME_TO|Lcom/example/Foo;|Lcom/obf/Bar;    重命名为指定名称
 *   EXCLUDE_DEX|classes2.dex                      排除指定DEX
 *   FORCE_RENAME|Lcom/example/Foo;               强制重命名（即使在保护列表中）
 *
 * pattern 支持通配符：以 * 结尾时按前缀匹配，否则按精确匹配。
 * KEEP_PACKAGE 始终按前缀匹配（pattern 即包前缀）。
 */
public class ProtectRules {

    public enum RuleType {
        KEEP_CLASS,      // 不混淆指定类
        KEEP_PACKAGE,    // 不混淆指定包
        KEEP_METHOD,     // 不混淆指定方法
        KEEP_FIELD,      // 不混淆指定字段
        RENAME_TO,       // 重命名为指定名称
        EXCLUDE_DEX,     // 排除指定DEX
        FORCE_RENAME,    // 强制重命名（即使在保护列表中）
    }

    public static class Rule {
        public final RuleType type;
        public final String pattern;
        public final String target;

        public Rule(RuleType type, String pattern, String target) {
            this.type = type;
            this.pattern = pattern;
            this.target = target;
        }
    }

    private final List<Rule> rules = new ArrayList<>();
    private final ProtectionPipeline.LogCallback logCallback;

    public ProtectRules(ProtectionPipeline.LogCallback logCallback) {
        this.logCallback = logCallback;
    }

    /**
     * 从文件加载规则。
     * 格式: TYPE|pattern|target （target可省略）
     * 例如: KEEP_CLASS|Lcom/example/MainActivity;
     *      KEEP_PACKAGE|Lcom/google/
     *      RENAME_TO|Lcom/example/Foo;|Lcom/obf/Bar;
     */
    public void loadRules(File rulesFile) {
        rules.clear();
        if (rulesFile == null || !rulesFile.isFile()) {
            if (logCallback != null) {
                logCallback.log("  规则文件不存在，跳过加载: "
                        + (rulesFile == null ? "null" : rulesFile.getName()));
            }
            return;
        }
        int loaded = 0;
        int skipped = 0;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(rulesFile), StandardCharsets.UTF_8))) {
            String line;
            int lineNo = 0;
            while ((line = reader.readLine()) != null) {
                lineNo++;
                String trimmed = line.trim();
                // 跳过空行和注释
                if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                    continue;
                }
                Rule rule = parseRule(trimmed);
                if (rule != null) {
                    rules.add(rule);
                    loaded++;
                } else {
                    skipped++;
                    if (logCallback != null) {
                        logCallback.log("  规则解析失败(第" + lineNo + "行): " + line);
                    }
                }
            }
        } catch (Exception e) {
            if (logCallback != null) {
                logCallback.log("  加载规则文件失败: " + e.getMessage());
            }
        }
        if (logCallback != null) {
            logCallback.log("  规则加载完成: " + loaded + " 条有效, " + skipped + " 条跳过");
        }
    }

    /**
     * 解析单行规则。
     * 格式: TYPE|pattern|target
     * target 为可选项；RENAME_TO 必须提供 target。
     */
    private Rule parseRule(String line) {
        String[] parts = line.split("\\|", -1);
        if (parts.length < 2) {
            return null;
        }
        String typeStr = parts[0].trim();
        String pattern = parts[1].trim();
        String target = parts.length >= 3 ? parts[2].trim() : null;
        if (typeStr.isEmpty() || pattern.isEmpty()) {
            return null;
        }
        RuleType type;
        try {
            type = RuleType.valueOf(typeStr);
        } catch (IllegalArgumentException e) {
            return null;
        }
        // RENAME_TO 必须有 target
        if (type == RuleType.RENAME_TO && (target == null || target.isEmpty())) {
            return null;
        }
        // 空target归一化为null
        if (target != null && target.isEmpty()) {
            target = null;
        }
        return new Rule(type, pattern, target);
    }

    /**
     * 通配符匹配。
     * pattern 以 * 结尾时按前缀匹配，否则按精确匹配。
     */
    private boolean matches(String pattern, String value) {
        if (pattern == null || value == null) {
            return false;
        }
        if (pattern.endsWith("*")) {
            return value.startsWith(pattern.substring(0, pattern.length() - 1));
        }
        return value.equals(pattern);
    }

    /**
     * 包前缀匹配（KEEP_PACKAGE 专用）。
     * pattern 作为包前缀，如 "Lcom/google/"，匹配该包下所有类。
     * 若 pattern 以 * 结尾则先剥离再前缀匹配。
     */
    private boolean matchesPackage(String pattern, String classDescriptor) {
        if (pattern == null || classDescriptor == null) {
            return false;
        }
        String prefix = pattern.endsWith("*")
                ? pattern.substring(0, pattern.length() - 1) : pattern;
        return classDescriptor.startsWith(prefix);
    }

    /**
     * 检查类是否应该被保护（不混淆）。
     * 命中 KEEP_CLASS 或 KEEP_PACKAGE 规则时返回 true。
     *
     * @param classDescriptor 类描述符，如 Lcom/example/MainActivity;
     */
    public boolean shouldKeepClass(String classDescriptor) {
        if (classDescriptor == null) {
            return false;
        }
        for (Rule rule : rules) {
            if (rule.type == RuleType.KEEP_CLASS) {
                if (matches(rule.pattern, classDescriptor)) {
                    return true;
                }
            } else if (rule.type == RuleType.KEEP_PACKAGE) {
                if (matchesPackage(rule.pattern, classDescriptor)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 检查方法是否应该被保护（不混淆）。
     * 方法签名格式: Lcom/example/Foo;->bar(II)V
     *
     * @param methodSignature 方法签名
     */
    public boolean shouldKeepMethod(String methodSignature) {
        if (methodSignature == null) {
            return false;
        }
        for (Rule rule : rules) {
            if (rule.type == RuleType.KEEP_METHOD) {
                if (matches(rule.pattern, methodSignature)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 检查字段是否应该被保护（不混淆）。
     * 字段签名格式: Lcom/example/Foo;->bar:I
     *
     * @param fieldSignature 字段签名
     */
    public boolean shouldKeepField(String fieldSignature) {
        if (fieldSignature == null) {
            return false;
        }
        for (Rule rule : rules) {
            if (rule.type == RuleType.KEEP_FIELD) {
                if (matches(rule.pattern, fieldSignature)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 获取强制重命名目标。
     * 命中 RENAME_TO 规则时返回其 target；否则返回 null。
     *
     * @param classDescriptor 类描述符，如 Lcom/example/Foo;
     * @return 目标类描述符，如 Lcom/obf/Bar; 未命中时返回 null
     */
    public String getRenameTarget(String classDescriptor) {
        if (classDescriptor == null) {
            return null;
        }
        for (Rule rule : rules) {
            if (rule.type == RuleType.RENAME_TO) {
                if (matches(rule.pattern, classDescriptor)) {
                    return rule.target;
                }
            }
        }
        return null;
    }

    /**
     * 检查类是否被强制重命名（即使在保护列表中）。
     *
     * @param classDescriptor 类描述符
     */
    public boolean shouldForceRename(String classDescriptor) {
        if (classDescriptor == null) {
            return false;
        }
        for (Rule rule : rules) {
            if (rule.type == RuleType.FORCE_RENAME) {
                if (matches(rule.pattern, classDescriptor)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 检查指定DEX是否应被排除（不处理）。
     *
     * @param dexName DEX文件名，如 classes2.dex
     */
    public boolean shouldExcludeDex(String dexName) {
        if (dexName == null) {
            return false;
        }
        for (Rule rule : rules) {
            if (rule.type == RuleType.EXCLUDE_DEX) {
                if (matches(rule.pattern, dexName)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 获取所有规则。
     */
    public List<Rule> getRules() {
        return rules;
    }

    /**
     * 生成默认规则文件（包含格式说明和示例，所有规则均被注释）。
     *
     * @param outputFile 输出文件
     */
    public static void generateDefaultRules(File outputFile) {
        if (outputFile == null) {
            return;
        }
        File parent = outputFile.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(outputFile), StandardCharsets.UTF_8))) {
            writer.println("# Ark Jiagu 保护规则文件");
            writer.println("# 格式: TYPE|pattern|target (target可省略)");
            writer.println("# pattern 以 * 结尾时按前缀匹配，否则按精确匹配");
            writer.println("# 以 # 开头的行为注释，空行被忽略");
            writer.println();
            writer.println("# ===== 不混淆指定类 =====");
            writer.println("# KEEP_CLASS|Lcom/example/MainActivity;");
            writer.println();
            writer.println("# ===== 不混淆指定包（前缀匹配）=====");
            writer.println("# KEEP_PACKAGE|Lcom/google/");
            writer.println("# KEEP_PACKAGE|Lcom/example/model/*");
            writer.println();
            writer.println("# ===== 不混淆指定方法 =====");
            writer.println("# 格式: 类描述符->方法名(参数类型)返回类型");
            writer.println("# KEEP_METHOD|Lcom/example/Foo;->bar(II)V");
            writer.println();
            writer.println("# ===== 不混淆指定字段 =====");
            writer.println("# 格式: 类描述符->字段名:字段类型");
            writer.println("# KEEP_FIELD|Lcom/example/Foo;->bar:I");
            writer.println();
            writer.println("# ===== 重命名为指定名称 =====");
            writer.println("# RENAME_TO|Lcom/example/Foo;|Lcom/obf/Bar;");
            writer.println();
            writer.println("# ===== 排除指定DEX（不处理）=====");
            writer.println("# EXCLUDE_DEX|classes2.dex");
            writer.println();
            writer.println("# ===== 强制重命名（即使在保护列表中）=====");
            writer.println("# FORCE_RENAME|Lcom/example/Foo;");
        } catch (Exception e) {
            // 静默失败：默认规则生成不应中断主流程
        }
    }
}
