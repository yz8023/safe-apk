package com.ark.jiagu.vm;

import android.content.Context;
import com.ark.jiagu.ArkJiaguUtils.LogCallback;
import java.io.File;
import java.io.FileOutputStream;

/**
 * 不启用 VM 保护。
 * 仅生成空 vmp.bin，保证后续 SO 注入/打包流程不因此处缺失而失败。
 */
public class NoneVmEngine implements VmEngine {

    @Override
    public String getName() {
        return "NONE";
    }

    @Override
    public String getDisplayName() {
        return "不启用 VMP";
    }

    @Override
    public boolean requiresNativeBuild() {
        return false;
    }

    @Override
    public void process(Context context, File workDir, VmEngineSettings settings, LogCallback callback) throws Exception {
        File bin = getOutputBin(workDir);
        try (FileOutputStream fos = new FileOutputStream(bin)) {
            // 写入 4 字节空文件头（magic 为空），表示无 VMP 方法
        }
        if (callback != null) {
            callback.log("[VMP] 已跳过，生成空 vmp.bin");
        }
    }

    @Override
    public File getOutputBin(File workDir) {
        return new File(workDir, "vmp.bin");
    }

    @Override
    public File getNativeSourceDir(File workDir) {
        return null;
    }
}
