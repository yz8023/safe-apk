package com.ark.jiagu;

/**
 * Runtime constant-string decryptor.
 *
 * Used by the const-string encryption feature in DexObfuscator.
 * Encrypted strings are prefixed with "ARKS" and contain Base64(XOR(data, key)).
 */
public class StringDecryptor {

    private static final String PREFIX = "ARKS";
    // Must match DexObfuscator.CONST_STRING_XOR_KEY
    private static final byte[] XOR_KEY = new byte[] { 0x41, 0x5A, 0x6B, 0x53 };

    private static final char[] BASE64_TABLE =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
    private static final int[] BASE64_REVERSE = new int[128];

    static {
        for (int i = 0; i < BASE64_REVERSE.length; i++) BASE64_REVERSE[i] = -1;
        for (int i = 0; i < BASE64_TABLE.length; i++) {
            BASE64_REVERSE[BASE64_TABLE[i]] = i;
        }
    }

    /**
     * Decrypt a string if it carries the ARKS marker; otherwise return it unchanged.
     */
    public static String decrypt(String encrypted) {
        if (encrypted == null || !encrypted.startsWith(PREFIX)) {
            return encrypted;
        }
        try {
            String base64 = encrypted.substring(PREFIX.length());
            byte[] data = decodeBase64(base64);
            byte[] decrypted = new byte[data.length];
            for (int i = 0; i < data.length; i++) {
                decrypted[i] = (byte) (data[i] ^ XOR_KEY[i % XOR_KEY.length]);
            }
            return new String(decrypted, "UTF-8");
        } catch (Exception e) {
            // Fail-open: return original encrypted text rather than crash
            return encrypted;
        }
    }

    private static byte[] decodeBase64(String s) {
        if (s == null) return new byte[0];
        int len = s.length();
        int pad = 0;
        if (len >= 1 && s.charAt(len - 1) == '=') pad++;
        if (len >= 2 && s.charAt(len - 2) == '=') pad++;

        int outLen = (len * 3) / 4 - pad;
        byte[] out = new byte[outLen];

        int p = 0;
        int i = 0;
        while (i < len) {
            int c0 = s.charAt(i++);
            int c1 = s.charAt(i++);
            int c2 = i < len ? s.charAt(i++) : 'A';
            int c3 = i < len ? s.charAt(i++) : 'A';

            int b0 = decodeChar(c0);
            int b1 = decodeChar(c1);
            int b2 = decodeChar(c2);
            int b3 = decodeChar(c3);

            out[p++] = (byte) ((b0 << 2) | (b1 >> 4));
            if (p < outLen) out[p++] = (byte) (((b1 & 0x0F) << 4) | (b2 >> 2));
            if (p < outLen) out[p++] = (byte) (((b2 & 0x03) << 6) | b3);
        }
        return out;
    }

    private static int decodeChar(int c) {
        if (c < 0 || c >= BASE64_REVERSE.length) return 0;
        int v = BASE64_REVERSE[c];
        return v < 0 ? 0 : v;
    }
}
