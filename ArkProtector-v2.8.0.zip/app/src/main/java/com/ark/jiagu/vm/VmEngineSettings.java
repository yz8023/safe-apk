package com.ark.jiagu.vm;

import java.util.List;

/**
 * 传给 VM 引擎的处理参数。
 */
public class VmEngineSettings {
    public String soName = "libArkStub.so";
    public String stubClassName = "com.ark.safe.StubApp";
    public String[] methodRules = new String[]{"*.*"};
    public java.util.List<String> keepClasses;
}
