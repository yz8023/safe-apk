package com.ark.jiagu.vm;

import android.content.Context;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.ark.jiagu.ArkJiaguUtils.LogCallback;
import com.nmmedit.apkprotect.ApkProtect;
import com.nmmedit.apkprotect.dex2c.Dex2c;
import com.nmmedit.apkprotect.dex2c.DexConfig;
import com.nmmedit.apkprotect.dex2c.GlobalDexConfig;
import com.nmmedit.apkprotect.dex2c.converter.ClassAnalyzer;
import com.nmmedit.apkprotect.dex2c.converter.instructionrewriter.InstructionRewriter;
import com.nmmedit.apkprotect.dex2c.converter.instructionrewriter.NoneInstructionRewriter;
import com.nmmedit.apkprotect.dex2c.converter.structs.RegisterNativesUtilClassDef;
import com.nmmedit.apkprotect.dex2c.filters.ClassAndMethodFilter;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * nmmp (maoabc/nmmp) VM 保护引擎集成实现。
 *
 * 处理流程：
 * 1. 扫描 workDir 下所有 classes*.dex；
 * 2. 用 nmmp 的 Dex2c 拆分为壳 DEX + 实现 DEX，并生成 C 代码；
 * 3. 在壳 DEX 的静态块中插入 NativeUtils.initClass() 调用；
 * 4. 将处理后的壳 DEX 写回 workDir，覆盖原 DEX；
 * 5. 将生成的 C 代码整理到 nativeSourceDir，供后续 CMake 编译。
 *
 * 注意：nmmvm C 运行时（nmmvm/jna-android）尚未接入 CMake，
 * 当前版本会把生成的 C 源文件保存下来，native 编译与运行时注册需要下一步完成。
 */
public class NmmVmEngine implements VmEngine {

    private static final String NMMP_LIB_NAME = "nmmvm";

    @Override
    public String getName() {
        return "NMMP";
    }

    @Override
    public String getDisplayName() {
        return "nmmp VM（实验性）";
    }

    @Override
    public boolean requiresNativeBuild() {
        return true;
    }

    @Override
    public void process(Context context, File workDir, VmEngineSettings settings, LogCallback callback) throws Exception {
        if (callback != null) {
            callback.log("[VMP] 使用 nmmp VM 保护");
        }

        File codeGeneratedDir = new File(workDir, "nmmp_generated");
        File nativeSourceDir = getNativeSourceDir(workDir);
        File tempDexDir = new File(workDir, "nmmp_temp_dex");
        FileUtils.ensureDirs(codeGeneratedDir, nativeSourceDir, tempDexDir);

        // 1. 收集 DEX 文件
        List<File> dexFiles = collectDexFiles(workDir);
        if (dexFiles.isEmpty()) {
            throw new IOException("workDir 中未找到 classes*.dex");
        }
        if (callback != null) {
            callback.log("[nmmp] 发现 DEX 文件数: " + dexFiles.size());
        }

        // 2. 准备 nmmp 组件
        InstructionRewriter instructionRewriter = new NoneInstructionRewriter();
        ClassAnalyzer classAnalyzer = new ClassAnalyzer();
        for (File dex : dexFiles) {
            classAnalyzer.loadDexFile(dex);
        }

        ClassAndMethodFilter filter = createFilter(settings.methodRules);

        // 3. Dex2c 处理：生成壳 DEX、实现 DEX、C 代码
        GlobalDexConfig globalConfig = Dex2c.handleAllDex(
                dexFiles,
                filter,
                instructionRewriter,
                classAnalyzer,
                codeGeneratedDir
        );
        if (callback != null) {
            callback.log("[nmmp] Dex2c 拆分完成");
        }

        // 4. 生成 JNI_OnLoad 初始化代码
        globalConfig.generateJniInitCode();

        // 5. 注入 registerNatives 调用并写出 DEX
        List<File> outDexFiles = ApkProtect.injectInstructionAndWriteToFile(
                globalConfig,
                Collections.emptySet(),
                60000,
                tempDexDir
        );

        // 6. 在主 DEX 中插入 NativeUtil 注册类
        File mainDex = outDexFiles.get(0);
        File newMainDex = injectNativeUtilClass(mainDex, globalConfig, nativeSourceDir);
        outDexFiles.set(0, newMainDex);

        // 7. 写回 workDir，覆盖原 DEX
        replaceDexFiles(workDir, outDexFiles);

        // 8. 整理生成的 C 代码到 nativeSourceDir
        collectGeneratedCSources(codeGeneratedDir, nativeSourceDir);

        if (callback != null) {
            callback.log("[nmmp] 壳 DEX 与 C 代码已生成: " + nativeSourceDir.getAbsolutePath());
            callback.log("[nmmp] 注意：nmmvm native 运行时未接入 CMake，当前产物仅作为源文件保存");
        }
    }

    @Override
    public File getOutputBin(File workDir) {
        return new File(workDir, "vmp.bin");
    }

    @Override
    public File getNativeSourceDir(File workDir) {
        return new File(workDir, "nmmvm_generated");
    }

    private List<File> collectDexFiles(File dir) {
        List<File> result = new ArrayList<>();
        File[] files = dir.listFiles();
        if (files == null) return result;
        Pattern pattern = Pattern.compile("classes(\\d+)*\\.dex");
        for (File f : files) {
            if (f.isFile() && pattern.matcher(f.getName()).matches()) {
                result.add(f);
            }
        }
        result.sort((a, b) -> {
            int na = extractDexIndex(a.getName());
            int nb = extractDexIndex(b.getName());
            return na - nb;
        });
        return result;
    }

    private int extractDexIndex(String name) {
        if ("classes.dex".equals(name)) return 0;
        Matcher m = Pattern.compile("classes(\\d+)\\.dex").matcher(name);
        return m.matches() ? Integer.parseInt(m.group(1)) : Integer.MAX_VALUE;
    }

    private ClassAndMethodFilter createFilter(String[] rules) {
        final Set<String> classPatterns = new HashSet<>();
        final Set<String> methodPatterns = new HashSet<>();
        for (String rule : rules) {
            // 简单规则："*.*.onCreate" -> 所有类的 onCreate
            // 或者 "com.example.A.onCreate"
            String[] parts = rule.split("\\.");
            if (parts.length >= 2) {
                String method = parts[parts.length - 1];
                StringBuilder cls = new StringBuilder();
                for (int i = 0; i < parts.length - 1; i++) {
                    if (i > 0) cls.append(".");
                    cls.append(parts[i]);
                }
                classPatterns.add(cls.toString());
                methodPatterns.add(method);
            }
        }
        if (classPatterns.isEmpty()) {
            classPatterns.add("*");
            methodPatterns.add("*");
        }

        return new ClassAndMethodFilter() {
            @Override
            public boolean acceptClass(ClassDef classDef) {
                String name = classDef.getType();
                if (!name.startsWith("L") || !name.endsWith(";")) return false;
                name = name.substring(1, name.length() - 1).replace('/', '.');
                for (String p : classPatterns) {
                    if (match(p, name)) return true;
                }
                return false;
            }

            @Override
            public boolean acceptMethod(Method method) {
                String name = method.getName();
                for (String p : methodPatterns) {
                    if (match(p, name)) return true;
                }
                return false;
            }

            private boolean match(String pattern, String value) {
                if ("*".equals(pattern)) return true;
                return value.equals(pattern);
            }
        };
    }

    /**
     * 参考 ApkProtect.internNativeUtilClassDef，在主 DEX 中插入 NativeUtil 注册类。
     */
    private File injectNativeUtilClass(File mainDex, GlobalDexConfig globalConfig, File outDir) throws IOException {
        DexBackedDexFile mainDexFile = DexBackedDexFile.fromInputStream(
                null,
                new BufferedInputStream(new FileInputStream(mainDex)));

        DexPool newDex = new DexPool(mainDexFile.getOpcodes());
        for (ClassDef classDef : mainDexFile.getClasses()) {
            newDex.internClass(classDef);
        }

        List<String> nativeMethodNames = new ArrayList<>();
        for (DexConfig config : globalConfig.getConfigs()) {
            nativeMethodNames.add(config.getRegisterNativesMethodName());
        }

        String registerNativesClassName = globalConfig.getConfigs().get(0).getRegisterNativesClassName();
        newDex.internClass(new RegisterNativesUtilClassDef(
                "L" + registerNativesClassName + ";",
                nativeMethodNames,
                NMMP_LIB_NAME));

        File injectDir = new File(outDir, "injectLoadLib");
        FileUtils.ensureDirs(injectDir);
        File newFile = new File(injectDir, mainDex.getName());
        newDex.writeTo(new FileDataStore(newFile));
        return newFile;
    }

    private void replaceDexFiles(File workDir, List<File> outDexFiles) throws IOException {
        for (int i = 0; i < outDexFiles.size(); i++) {
            String targetName = (i == 0) ? "classes.dex" : String.format("classes%d.dex", i + 1);
            File target = new File(workDir, targetName);
            FileUtils.copy(outDexFiles.get(i), target);
        }
    }

    private void collectGeneratedCSources(File codeGeneratedDir, File nativeSourceDir) throws IOException {
        File[] files = codeGeneratedDir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isFile() && (f.getName().endsWith(".c") || f.getName().endsWith(".h"))) {
                FileUtils.copy(f, new File(nativeSourceDir, f.getName()));
            }
        }
    }

    private static class FileUtils {
        static void ensureDirs(File... dirs) {
            for (File d : dirs) {
                if (!d.exists()) d.mkdirs();
            }
        }

        static void copy(File src, File dst) throws IOException {
            try (FileInputStream fis = new FileInputStream(src);
                 FileOutputStream fos = new FileOutputStream(dst)) {
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) != -1) {
                    fos.write(buf, 0, len);
                }
            }
        }
    }
}
