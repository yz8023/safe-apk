package com.ark.jiagu.dpt;

/**
 * Native方法桥接
 * 声明native方法，由壳SO实现
 *
 * 壳SO需要实现以下方法：
 * - nativeInitDpt: 初始化dpt hook（hook mmap + DefineClass）
 * - nativeLoadCodeItems: 加载CodeItem数据到native内存
 * - nativePatchMethod: 按 dexIndex + methodIndex 填回方法字节码
 */
public class DptNativeBridge {

    static {
        try {
            System.loadLibrary("ArkStub");
        } catch (UnsatisfiedLinkError e) {
            // 壳SO可能已加载
        }
    }

    /**
     * 初始化dpt hook
     * 在JNI_OnLoad或attachBaseContext中调用
     * @param apkPath APK路径
     * @return 0=成功, 非0=失败
     */
    public static native int nativeInitDpt(String apkPath);

    /**
     * 加载CodeItem数据
     * @param data CodeItem二进制数据
     * @param enhanced 是否增强版
     * @return 0=成功
     */
    public static native int nativeLoadCodeItems(byte[] data, boolean enhanced);

    /**
     * 填回方法字节码
     * @param dexIndex DEX索引
     * @param methodIndex 方法索引
     * @param codeBytes 原始字节码
     * @param codeOffset 在DEX中的偏移
     * @param insnsSize 字节码大小
     * @return 0=成功
     */
    public static native int nativePatchMethod(int dexIndex, int methodIndex,
                                                byte[] codeBytes, int codeOffset, int insnsSize);

    /**
     * 获取已填回的方法数量
     */
    public static native int nativeGetPatchedCount();

    /**
     * 校验DEX完整性
     * @param dexData DEX数据
     * @return 0=校验通过
     */
    public static native int nativeVerifyDex(byte[] dexData);
}
