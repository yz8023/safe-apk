package com.ark.jiagu;

import android.os.Handler;
import android.os.Looper;

import com.ark.jiagu.ui.LogEntry;
import com.ark.jiagu.ui.LogLevel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * 高性能日志管理器（Compose 友好）。
 *
 * 核心优化：
 * 1. 不维护大字符串，只输出 [LogEntry] 列表，配合 LazyColumn 避免整页重排。
 * 2. 批量 flush，减少 UI 线程与 Compose recomposition 次数。
 * 3. 根据消息内容自动识别日志级别并着色。
 * 4. 限制内存中条目数量，防止长任务 OOM/卡顿。
 */
public class LogManager {

    private static final int MAX_LOG_CHARS = 50000;
    // 提高批量间隔，降低 Compose 重组次数。原 250ms 在密集日志下会频繁触发
    // semantics 变更检查，导致 OOM。
    private static final long FLUSH_INTERVAL_MS = 500;
    // 单次 flush 上限，配合分段加入策略，避免单次重组条目过多
    private static final int MAX_LOGS_PER_FLUSH = 80;
    private static final int MAX_MEMORY_ENTRIES = 2000;
    // 队列上限：防止日志产生速度远大于消费速度时队列无限增长导致 OOM。
    // 400 条 * 平均 100 字节 ≈ 40KB，远小于单条 LogEntry 的 Compose 重组成本。
    private static final int MAX_QUEUE_SIZE = 400;

    private final Consumer<List<LogEntry>> entriesConsumer;
    private final Handler uiHandler;

    private final ConcurrentLinkedQueue<PendingLog> logQueue = new ConcurrentLinkedQueue<>();
    private final AtomicInteger queueSize = new AtomicInteger(0);

    private volatile boolean verboseLogging = false;
    private volatile boolean flushScheduled = false;
    private volatile boolean loggingEnabled = true;
    private volatile boolean showTimestamp = true;

    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault());

    private final Runnable flushRunnable = new Runnable() {
        @Override
        public void run() {
            flushScheduled = false;
            flushToUi();
        }
    };

    /**
     * @param entriesConsumer 每次批量 flush 时回调，参数为新产生的日志条目列表。
     */
    public LogManager(Consumer<List<LogEntry>> entriesConsumer) {
        this.entriesConsumer = entriesConsumer;
        this.uiHandler = new Handler(Looper.getMainLooper());
    }

    public void log(String message) {
        if (!loggingEnabled || message == null) return;
        enqueue(new PendingLog(formatMessage(message), false));
    }

    public void logVerbose(String message) {
        if (!verboseLogging || message == null) return;
        enqueue(new PendingLog(formatMessage(message), true));
    }

    /**
     * 入队，带容量限制。队列满时丢弃最旧的日志，保证队列不会无限增长导致 OOM。
     */
    private void enqueue(PendingLog pendingLog) {
        // 快速路径：尝试直接入队
        if (queueSize.get() < MAX_QUEUE_SIZE) {
            logQueue.offer(pendingLog);
            int newSize = queueSize.incrementAndGet();
            if (newSize > MAX_QUEUE_SIZE) {
                // 并发竞争导致超限，丢弃最旧的
                PendingLog old = logQueue.poll();
                if (old != null) {
                    queueSize.decrementAndGet();
                }
            }
        } else {
            // 队列已满，丢弃最旧的再入队（保留最新日志）
            logQueue.poll();
            logQueue.offer(pendingLog);
            // size 不变（poll 1 + offer 1）
        }
        scheduleFlush();
    }

    private String formatMessage(String message) {
        if (message.startsWith("======") || message.startsWith("----------->>>")) {
            return message;
        }
        return message;
    }

    public void setShowTimestamp(boolean showTimestamp) {
        this.showTimestamp = showTimestamp;
    }

    public void setVerboseLogging(boolean enabled) {
        this.verboseLogging = enabled;
    }

    public void setLoggingEnabled(boolean enabled) {
        this.loggingEnabled = enabled;
    }

    public void clear() {
        logQueue.clear();
        queueSize.set(0);
        uiHandler.post(() -> {
            if (entriesConsumer != null) {
                entriesConsumer.accept(new ArrayList<>());
            }
        });
    }

    private void scheduleFlush() {
        if (!flushScheduled) {
            flushScheduled = true;
            uiHandler.postDelayed(flushRunnable, FLUSH_INTERVAL_MS);
        }
    }

    private void flushToUi() {
        List<PendingLog> batch = new ArrayList<>(MAX_LOGS_PER_FLUSH);
        int count = 0;
        PendingLog log;
        while (count < MAX_LOGS_PER_FLUSH && (log = logQueue.poll()) != null) {
            batch.add(log);
            count++;
        }
        if (count > 0) {
            queueSize.addAndGet(-count);
        }

        if (count == 0) return;

        final List<LogEntry> entries = new ArrayList<>(count);
        for (PendingLog pending : batch) {
            String timestamp = showTimestamp ? timeFormat.format(new Date()) : "";
            LogLevel level = pending.verbose ? LogLevel.VERBOSE : detectLevel(pending.message);
            String display = pending.message;

            // 阶段标题单独处理，不显示时间戳前缀
            if (isStageTitle(pending.message)) {
                display = pending.message.replace("=", "").replace("-", "").trim();
                level = LogLevel.STAGE;
            }

            entries.add(new LogEntry(timestamp, level, display, pending.message));
        }

        if (entriesConsumer != null) {
            entriesConsumer.accept(entries);
        }

        if (!logQueue.isEmpty()) {
            scheduleFlush();
        }
    }

    private boolean isStageTitle(String message) {
        return message != null && (message.startsWith("======") || message.startsWith("----------->>>"));
    }

    private LogLevel detectLevel(String message) {
        if (message == null) return LogLevel.INFO;
        String lower = message.toLowerCase(Locale.getDefault());
        if (lower.contains("失败") || lower.contains("错误") || lower.contains("error") || lower.contains("failed") || lower.contains("exception")) {
            return LogLevel.ERROR;
        }
        if (lower.contains("完成") || lower.contains("成功") || lower.contains("success") || lower.contains("done")) {
            return LogLevel.SUCCESS;
        }
        if (lower.contains("警告") || lower.contains("注意") || lower.contains("warning") || lower.contains("warn") || lower.contains("conflict")) {
            return LogLevel.WARNING;
        }
        if (lower.contains("开始") || lower.contains("stage") || lower.contains("===")) {
            return LogLevel.STAGE;
        }
        if (lower.contains("debug") || lower.contains("调试")) {
            return LogLevel.DEBUG;
        }
        return LogLevel.INFO;
    }

    public void forceFlush() {
        uiHandler.removeCallbacks(flushRunnable);
        flushScheduled = false;
        uiHandler.post(this::flushToUi);
    }

    private static class PendingLog {
        final String message;
        final boolean verbose;

        PendingLog(String message, boolean verbose) {
            this.message = message;
            this.verbose = verbose;
        }
    }
}
