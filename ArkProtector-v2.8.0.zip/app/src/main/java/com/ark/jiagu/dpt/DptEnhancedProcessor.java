package com.ark.jiagu.dpt;

import com.ark.jiagu.ArkJiaguUtils.LogCallback;
import java.io.*;
import java.nio.*;
import java.util.*;

/**
 * dpt-shell 增强版处理器
 *
 * 在标准版基础上增加：
 * 1. XOR 混淆每个 CodeItem（按 item 独立 xorKey）
 * 2. 存储顺序碎片化/重排（增加静态分析难度，不影响运行时映射）
 * 3. 注入虚假 CodeItem 到独立 decoy 文件（仅作干扰，不进入运行时加载路径）
 *
 * 注意：native 层 DptHook.cpp 当前只支持 XOR 解密，不支持 AES，
 * 因此增强版暂不使用 AES，避免运行时与加固产物不匹配导致闪退。
 */
public class DptEnhancedProcessor {

    private final File workDir;
    private final LogCallback logCallback;
    private final Random random = new Random(System.nanoTime());

    public DptEnhancedProcessor(File workDir, LogCallback logCallback) {
        this.workDir = workDir;
        this.logCallback = logCallback;
    }

    /**
     * 对已提取的 CodeItem 数据进行增强处理，并返回最终可供打包的 bin 文件。
     *
     * @param codeItemFile 标准版已生成的 dpt_codeitems.bin
     * @param allDexItems  各 DEX 的 CodeItem 列表（会被原地修改：重排、补齐 XOR）
     * @return 增强后的 dpt_codeitems.bin 文件
     */
    public File processEnhanced(File codeItemFile, List<DptCodeExtractor.DexCodeItems> allDexItems) throws Exception {
        logCallback.log("  [增强] 开始增强处理...");

        // 1. 确保每个真实 CodeItem 都有独立 XOR 密钥和 noiseSeed
        int realCount = ensureXorAndNoise(allDexItems);
        logCallback.log("  [增强] 真实 CodeItem XOR/Noise 已生成: " + realCount + " 个");

        // 2. 碎片化重排：打乱文件内的存储顺序，运行时仍按 methodIndex 查找
        fragmentCodeItems(allDexItems);
        logCallback.log("  [增强] 碎片化重排完成");

        // 3. 注入虚假 CodeItem 到独立 decoy 文件，不进入运行时加载路径
        int fakeCount = injectFakeCodeItems(allDexItems);
        logCallback.log("  [增强] 虚假 CodeItem 已写入 decoy: " + fakeCount + " 个");

        // 4. 重新写入增强版二进制（version=2）
        DptCodeItemStore store = new DptCodeItemStore(true);
        store.write(codeItemFile, allDexItems);
        logCallback.log("  [增强] 增强版 CodeItem 数据: " + codeItemFile.length() + " 字节");

        return codeItemFile;
    }

    /**
     * 为标准版生成的 CodeItem 补齐 XOR 密钥与 noiseSeed。
     * 标准版在抽取阶段未设置 xorKey 时，此处统一补上随机值，并重新 XOR 原始字节。
     */
    private int ensureXorAndNoise(List<DptCodeExtractor.DexCodeItems> allDexItems) {
        int count = 0;
        for (DptCodeExtractor.DexCodeItems dex : allDexItems) {
            for (DptCodeExtractor.MethodCodeItem item : dex.methods) {
                if (!item.encrypted || item.xorKey == 0) {
                    // 如果之前未被 XOR，先做一次 XOR
                    if (!item.encrypted) {
                        item.xorKey = random.nextInt();
                        item.originalBytes = xorEncrypt(item.originalBytes, item.xorKey);
                        item.encrypted = true;
                    } else if (item.xorKey == 0) {
                        // 已加密但密钥为 0 不会报错，但无意义，替换为非 0 密钥
                        item.xorKey = random.nextInt();
                        item.originalBytes = xorEncrypt(item.originalBytes, item.xorKey);
                    }
                }
                if (item.noiseSeed == 0) {
                    item.noiseSeed = random.nextInt();
                }
                count++;
            }
        }
        return count;
    }

    /**
     * 碎片化重排 CodeItem 顺序。存储顺序被打乱，但方法索引 methodIndex 不变，
     * 因此 native 层构建的 methodIndex->entry 映射仍然正确。
     */
    private void fragmentCodeItems(List<DptCodeExtractor.DexCodeItems> allDexItems) {
        for (DptCodeExtractor.DexCodeItems dex : allDexItems) {
            Collections.shuffle(dex.methods, random);
        }
    }

    /**
     * 生成虚假 CodeItem 并写入独立 decoy 文件。
     * 这些虚假项不进入 dpt_codeitems.bin，因此不会影响运行时 patch。
     */
    private int injectFakeCodeItems(List<DptCodeExtractor.DexCodeItems> allDexItems) throws Exception {
        int fakeCount = 0;
        File decoyFile = new File(workDir, "dpt_decoy.bin");
        try (DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(decoyFile)))) {
            dos.writeShort(0xDEAD); // decoy magic
            dos.writeShort(1);      // version

            for (DptCodeExtractor.DexCodeItems dex : allDexItems) {
                int fakeToAdd = 50 + random.nextInt(100);
                for (int i = 0; i < fakeToAdd; i++) {
                    byte[] fakeBytes = new byte[4 + random.nextInt(60)];
                    random.nextBytes(fakeBytes);
                    // 确保第一个 u2 在合法 Dalvik opcode 范围，静态看更像真代码
                    fakeBytes[0] = (byte) (random.nextInt(0x3F));
                    fakeBytes[1] = (byte) (random.nextInt(0x10));
                    int fakeMethodIndex = 60000 + random.nextInt(5535);
                    int fakeXorKey = random.nextInt();
                    byte[] encrypted = xorEncrypt(fakeBytes, fakeXorKey);

                    dos.writeInt(fakeMethodIndex);
                    dos.writeInt(encrypted.length);
                    dos.writeInt(fakeXorKey);
                    dos.writeInt(random.nextInt()); // noiseSeed
                    dos.write(encrypted);
                    fakeCount++;
                }
            }
        }
        return fakeCount;
    }

    private byte[] xorEncrypt(byte[] data, int key) {
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            int shift = (i & 3) << 3;
            result[i] = (byte) (data[i] ^ ((key >> shift) & 0xFF));
        }
        return result;
    }
}
