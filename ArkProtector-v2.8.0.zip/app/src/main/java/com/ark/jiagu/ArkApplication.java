package com.ark.jiagu;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.ark.security.AntiDebugDetector;
import com.ark.security.MemoryProtector;
import com.ark.security.RootDetector;
import com.ark.security.SecurityConfigManager;
import com.ark.security.SignatureChecker;

/**
 * ArkJiagu应用入口
 * 负责初始化所有安全功能模块
 */
public class ArkApplication extends Application {
    private static final String TAG = "ArkApplication";
    private static Context applicationContext;
    private static SecurityConfigManager configManager;

    // 安全功能实例
    private static RootDetector rootDetector;
    private static AntiDebugDetector antiDebugDetector;
    private static MemoryProtector memoryProtector;
    private static SignatureChecker signatureChecker;

    @Override
    public void onCreate() {
        super.onCreate();

        applicationContext = getApplicationContext();

        Log.i(TAG, "=== ArkJiagu v3.21 启动 ===");

        // 简化初始化，避免卡开屏问题
        // 暂时注释掉安全功能模块的初始化
        // 这些功能对于加固工具本身不是必需的
        
        Log.i(TAG, "=== ArkJiagu 初始化完成 ===");
    }

    /**
     * 初始化配置管理器
     */
    private void initializeConfigManager() {
        try {
            configManager = SecurityConfigManager.getInstance(this);
            Log.i(TAG, "配置管理器初始化成功");
        } catch (Exception e) {
            Log.e(TAG, "配置管理器初始化失败: " + e.getMessage());
        }
    }

    /**
     * 打印配置摘要
     */
    private void printConfigSummary() {
        if (configManager != null) {
            String summary = configManager.getConfigSummary();
            Log.i(TAG, "\n" + summary);
        }
    }

    /**
     * 初始化安全功能模块
     */
    private void initializeSecurityModules() {
        // 签名校验
        if (configManager.isSignatureCheckEnabled()) {
            initializeSignatureChecker();
        } else {
            Log.i(TAG, "签名校验功能已禁用");
        }

        // Root检测
        if (configManager.isRootDetectionEnabled()) {
            initializeRootDetector();
        } else {
            Log.i(TAG, "Root检测功能已禁用");
        }

        // 反调试检测
        if (configManager.isAntiDebugEnabled()) {
            initializeAntiDebugDetector();
        } else {
            Log.i(TAG, "反调试检测功能已禁用");
        }

        // 内存保护
        if (configManager.isMemoryProtectionEnabled()) {
            initializeMemoryProtector();
        } else {
            Log.i(TAG, "内存保护功能已禁用");
        }

        // 初始化native层配置
        initializeNativeConfig();
    }

    /**
     * 初始化签名校验
     */
    private void initializeSignatureChecker() {
        try {
            // 使用静态方法checkSignature，需要传递Context参数
            boolean isValid = SignatureChecker.checkSignature(this);

            if (isValid) {
                Log.i(TAG, "签名校验: 通过");
            } else {
                Log.w(TAG, "签名校验: 失败");

                // 根据配置决定是否严格处理
                if (configManager.isSignatureStrictMode()) {
                    Log.e(TAG, "严格模式：签名校验失败，应用将退出");
                    System.exit(0);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "签名校验初始化失败: " + e.getMessage());
        }
    }

    /**
     * 初始化Root检测
     */
    private void initializeRootDetector() {
        try {
            // 使用静态方法detect，需要传递Context参数
            RootDetector.DetectionResult result = RootDetector.detect(this);
            int riskScore = result.riskScore;
            RootDetector.SecurityLevel level = result.level;

            Log.i(TAG, "Root检测: 风险评分=" + riskScore + ", 安全等级=" + level);

            // 根据响应策略处理
            String strategy = configManager.getRootResponseStrategy();
            handleRootDetectionResult(level, strategy);
        } catch (Exception e) {
            Log.e(TAG, "Root检测初始化失败: " + e.getMessage());
        }
    }

    /**
     * 处理Root检测结果
     */
    private void handleRootDetectionResult(RootDetector.SecurityLevel level, String strategy) {
        switch (level) {
            case DANGEROUS:
                Log.e(TAG, "检测到Root设备，安全等级: 危险");
                if ("HIGH_RISK".equals(strategy) || "DANGEROUS".equals(strategy)) {
                    Log.e(TAG, "响应策略: 应用将退出");
                    System.exit(0);
                }
                break;

            case HIGH_RISK:
                Log.w(TAG, "检测到Root设备，安全等级: 高风险");
                if ("HIGH_RISK".equals(strategy)) {
                    Log.e(TAG, "响应策略: 应用将退出");
                    System.exit(0);
                }
                break;

            case MEDIUM_RISK:
                Log.w(TAG, "检测到Root设备，安全等级: 中风险");
                if ("MEDIUM_RISK".equals(strategy) || "HIGH_RISK".equals(strategy)) {
                    Log.w(TAG, "响应策略: 应用受限运行");
                }
                break;

            case LOW_RISK:
                Log.i(TAG, "检测到Root设备，安全等级: 低风险");
                break;

            case SAFE:
                Log.i(TAG, "Root检测: 安全");
                break;
        }
    }

    /**
     * 初始化反调试检测
     */
    private void initializeAntiDebugDetector() {
        try {
            // AntiDebugDetector使用静态方法detect()进行检测
            AntiDebugDetector.DetectionResult result = AntiDebugDetector.detect();
            
            int interval = configManager.getAntiDebugInterval();
            String strategy = configManager.getAntiDebugResponseStrategy();
            
            Log.i(TAG, "反调试检测: 风险评分=" + result.riskScore + ", 检测项=" + result.detectedItems.size());
            Log.i(TAG, "反调试检测配置: 间隔=" + interval + "ms，策略=" + strategy);
            
            // 如果检测到调试，根据策略处理
            if (result.isDebugging && "IMMEDIATE_CRASH".equals(strategy)) {
                Log.e(TAG, "检测到调试器，应用将退出");
                System.exit(0);
            }
        } catch (Exception e) {
            Log.e(TAG, "反调试检测初始化失败: " + e.getMessage());
        }
    }

    /**
     * 初始化内存保护
     */
    private void initializeMemoryProtector() {
        try {
            // 获取保护级别
            String levelStr = configManager.getMemoryProtectionLevel();
            MemoryProtector.ProtectionLevel level = MemoryProtector.ProtectionLevel.MEDIUM;

            switch (levelStr.toUpperCase()) {
                case "NONE":
                    level = MemoryProtector.ProtectionLevel.NONE;
                    break;
                case "LOW":
                    level = MemoryProtector.ProtectionLevel.LOW;
                    break;
                case "MEDIUM":
                    level = MemoryProtector.ProtectionLevel.MEDIUM;
                    break;
                case "HIGH":
                    level = MemoryProtector.ProtectionLevel.HIGH;
                    break;
                case "MAX":
                    level = MemoryProtector.ProtectionLevel.MAX;
                    break;
                default:
                    Log.w(TAG, "未知的内存保护级别: " + levelStr + "，使用默认MEDIUM");
                    level = MemoryProtector.ProtectionLevel.MEDIUM;
            }

            // 使用静态方法init初始化内存保护
            MemoryProtector.init(this, level);
            Log.i(TAG, "内存保护已启用，级别=" + level);
        } catch (Exception e) {
            Log.e(TAG, "内存保护初始化失败: " + e.getMessage());
        }
    }

    /**
     * 初始化native层配置
     */
    private native void initializeNativeConfig();

    /**
     * 传递安全检测配置到native层。
     * 由Java层在StubApp.onCreate后或JNI_OnLoad后调用，
     * native层将配置保存到全局变量供运行时安全检测使用。
     */
    public native void setSecurityConfig(
            boolean antiEmulator, boolean antiRoot, boolean antiDebugger,
            boolean antiXposed, boolean antiVm, boolean checkApkIntegrity,
            boolean checkMemDisk, boolean checkFridaPipe, boolean checkFridaThread,
            boolean checkAppMultiOpen, boolean checkJavaHook, boolean checkNativeHook,
            boolean checkLocation, boolean checkDevice);

    // 加载native库
    static {
        try {
            System.loadLibrary("ArkStub");
            Log.i(TAG, "native库加载成功");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "native库加载失败: " + e.getMessage());
        }
    }

    // ==================== 公共访问方法 ====================

    public static Context getAppContext() {
        return applicationContext;
    }

    public static SecurityConfigManager getConfigManager() {
        return configManager;
    }

    public static RootDetector getRootDetector() {
        return rootDetector;
    }

    public static AntiDebugDetector getAntiDebugDetector() {
        return antiDebugDetector;
    }

    public static MemoryProtector getMemoryProtector() {
        return memoryProtector;
    }

    public static SignatureChecker getSignatureChecker() {
        return signatureChecker;
    }

    /**
     * 重新加载配置
     */
    public static void reloadConfig() {
        if (configManager != null) {
            configManager.reloadConfig();
            Log.i(TAG, "配置已重新加载");
        }
    }

    /**
     * 动态启用/禁用功能
     */
    public static void setFeatureEnabled(String featureName, boolean enabled) {
        Log.i(TAG, "动态设置功能: " + featureName + " = " + enabled);

        switch (featureName) {
            case "root_detection":
                // Root检测使用静态方法，不需要实例
                Log.i(TAG, "Root检测功能状态: " + enabled);
                break;

            case "anti_debug":
                // AntiDebugDetector使用静态方法detect()进行检测
                if (enabled) {
                    AntiDebugDetector.DetectionResult result = AntiDebugDetector.detect();
                    Log.i(TAG, "反调试检测已执行: " + result.isDebugging);
                } else {
                    Log.i(TAG, "反调试检测功能已禁用");
                }
                break;

            case "memory_protection":
                // MemoryProtector使用静态方法init()进行初始化
                if (enabled) {
                    MemoryProtector.init(applicationContext, MemoryProtector.ProtectionLevel.MEDIUM);
                    Log.i(TAG, "内存保护已启用");
                } else {
                    Log.i(TAG, "内存保护功能已禁用");
                }
                break;
        }
    }
}