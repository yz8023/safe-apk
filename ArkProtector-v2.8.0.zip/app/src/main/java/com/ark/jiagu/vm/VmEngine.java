package com.ark.jiagu.vm;

import android.content.Context;
import com.ark.jiagu.ArkJiaguUtils.LogCallback;
import java.io.File;

/**
 * VM 保护引擎抽象接口。
 * 支持三种模式：
 *  - NONE：不做 VMP，仅生成空 vmp.bin
 *  - ORIGINAL：Arkjiagu 原有 VMP（vmp.bin + VM 调用壳）
 *  - NMMP：maoabc/nmmp 的 dex2c VM 保护
 */
public interface VmEngine {

    /**
     * 引擎唯一标识，用于持久化配置。
     */
    String getName();

    /**
     * 对用户友好的显示名称。
     */
    String getDisplayName();

    /**
     * 是否需要额外编译 native 代码。
     */
    boolean requiresNativeBuild();

    /**
     * 执行 VM 保护处理。
     *
     * @param context   应用上下文
     * @param workDir   工作目录（已解压 DEX）
     * @param settings  加固配置参数
     * @param callback  日志回调
     * @throws Exception 处理失败时抛出
     */
    void process(Context context, File workDir, VmEngineSettings settings, LogCallback callback) throws Exception;

    /**
     * 获取生成的 vmp.bin 文件（可能为空）。
     */
    File getOutputBin(File workDir);

    /**
     * 获取该引擎需要打包进 APK 的额外 native 源文件目录（如有）。
     */
    File getNativeSourceDir(File workDir);
}
