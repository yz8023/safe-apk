package com.ark.jiagu;
import static com.ark.jiagu.ArkSettingsManager.*;
import static com.ark.jiagu.ArkJiaguUtils.*;


import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import com.android.tools.smali.dexlib2.AccessFlags;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.MethodParameter;
import com.android.tools.smali.dexlib2.immutable.ImmutableClassDef;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethod;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethodImplementation;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethodParameter;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction10x;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction21c;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction35c;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodReference;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableStringReference;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.ark.jar.xml2axml.test.Xml2AxmlTool;
import com.ark.jiagu.vm.VmpJiaguEntry;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.widget.SwitchCompat;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class ArkMainActivity extends ComponentActivity {
    private LogManager logManager;
    private final com.ark.jiagu.ui.ArkUiState uiState = new com.ark.jiagu.ui.ArkUiState();
    private static final int REQ_SELECT_APK = 1001;

    private boolean isPermissionDialogShowing = false;
    private boolean hasInitMain = false;

    private android.net.Uri pendingApkUri;
    private File pendingWorkDir;
    private File pendingCopiedApk;


    static {
        System.loadLibrary("ArkTool");
    }

    /*private native byte[] buildEncryptedBlock(byte[] plainData);

    private native byte[] fixDexHeader(byte[] dexData);

    private native boolean isValidDex(byte[] data);

    private native byte[] intToLe4(int value);*/
    private SoNamePreset[] SO_NAME_PRESETS;
    //加密dex的方法
    private native void b(File dexDir, File shellDexFile, String realApplicationName, String  appComponentFactory, byte[] signHash64) throws Exception;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        SO_NAME_PRESETS = loadSoNamePresets();

        com.ark.jiagu.ui.ArkMainActivityExtKt.setArkContent(
                this,
                uiState,
                this::openApkSelector,
                this::startProcess,
                this::clearLog,
                this::showSettingsDialog,
                this::showAboutDialog
        );

        initLogManager();
        checkPermissionOrShowDialog();
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (hasInitMain) {
            return;
        }

        if (hasAllFilePermission()) {
            initMainPage();
        } else {
            showPermissionDialog();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (logManager != null) {
            logManager.forceFlush();
        }
    }

    private void checkPermissionOrShowDialog() {
        if (hasAllFilePermission()) {
            initMainPage();
            return;
        }

        showPermissionDialog();
    }




    private void showPermissionDialog() {
        if (hasAllFilePermission()) {
            initMainPage();
            return;
        }

        if (isPermissionDialogShowing) {
            return;
        }

        isPermissionDialogShowing = true;

        new android.app.AlertDialog.Builder(this)
                .setTitle(R.string.permission_required_title)
                .setMessage(R.string.permission_required_message)
                .setCancelable(false)
                .setPositiveButton(R.string.grant_permission, (dialog, which) -> {
                    isPermissionDialogShowing = false;
                    dialog.dismiss();
                    openAllFilePermissionPage();
                })
                .show();
    }

    private SoNamePreset[] loadSoNamePresets() {
        java.util.ArrayList<SoNamePreset> list = new java.util.ArrayList<>();

        try {
            java.io.InputStream is = getAssets().open("so_name_presets.json");
            java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();

            byte[] buffer = new byte[4096];
            int len;
            while ((len = is.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }

            is.close();

            String json = baos.toString("UTF-8");
            org.json.JSONArray array = new org.json.JSONArray(json);

            for (int i = 0; i < array.length(); i++) {
                org.json.JSONObject obj = array.getJSONObject(i);

                String title = obj.optString("title", "").trim();
                String name = obj.optString("name", "").trim();

                if (title.length() == 0 || name.length() == 0) {
                    continue;
                }

                list.add(new SoNamePreset(title, name));
            }

        } catch (Exception e) {
            e.printStackTrace();

            list.add(new SoNamePreset("Ark默认", "ArkStub"));
        }

        return list.toArray(new SoNamePreset[0]);
    }

    private void initLogManager() {
        logManager = new LogManager(entries -> uiState.appendLogs(entries));
        logManager.setVerboseLogging(false);
        ArkJiaguUtils.ArkSettings initialSettings = readArkSettings(this);
        logManager.setShowTimestamp(initialSettings.showLogTimestamp);
        logManager.log(getString(R.string.log_init));
        logManager.log(getString(R.string.log_wait_apk));
    }

    private void initMainPage() {
        if (hasInitMain) {
            return;
        }
        hasInitMain = true;

        // 异步清理工作目录，避免在主线程卡住
        new Thread(() -> {
            File workDir = getWorkDir();
            cleanWorkDirOnStart(workDir);
        }).start();
    }

    private void clearLog() {
        if (logManager != null) {
            logManager.clear();
        }
        uiState.clearLog();
    }
    private void showAboutDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_about, null);

        Button btnAboutClose = dialogView.findViewById(R.id.btnAboutClose);

        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        btnAboutClose.setOnClickListener(v -> dialog.dismiss());

        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
    }
    private void cleanWorkDirOnStart(File workDir) {
        if (workDir == null || !workDir.exists()) {
            return;
        }

        cleanTempFiles(workDir);
    }


    private void saveArkSettings(
            String soName,
            String stubClassName,
            String savePath,
            boolean enableVmpExtract,
            String vmEngine,
            boolean Debug,
            boolean autoSign,
            boolean useCustomJks,
            String jksPath,
            String jksStorePass,
            String jksAlias,
            String jksKeyPass
    ) {
        android.content.SharedPreferences sp = getSharedPreferences(SP_SETTINGS, MODE_PRIVATE);

        sp.edit()
                .putString(KEY_SO_NAME, soName)
                .putString(KEY_STUB_CLASS_NAME, stubClassName)
                .putString(KEY_SAVE_PATH, savePath)
                .putBoolean(KEY_ENABLE_VMP_EXTRACT, enableVmpExtract)
                .putString(KEY_VM_ENGINE, vmEngine)
                .putBoolean(KEY_DEBUG, Debug)
                .putBoolean(KEY_AUTO_SIGN, autoSign)
                .putBoolean(KEY_USE_CUSTOM_JKS, useCustomJks)
                .putString(KEY_JKS_PATH, jksPath)
                .putString(KEY_JKS_STORE_PASS, jksStorePass)
                .putString(KEY_JKS_ALIAS, jksAlias)
                .putString(KEY_JKS_KEY_PASS, jksKeyPass)
                .apply();
    }



    private boolean isValidJksSettings(String jksPath, String storePass, String alias, String keyPass) {
        if (jksPath == null || jksPath.trim().isEmpty()) {
            Toast.makeText(this, getString(R.string.jks_path_empty), Toast.LENGTH_LONG).show();
            return false;
        }

        File jksFile = new File(jksPath.trim());
        if (!jksFile.exists() || !jksFile.isFile()) {
            Toast.makeText(this, getString(R.string.jks_file_not_found), Toast.LENGTH_LONG).show();
            return false;
        }

        if (storePass == null || storePass.trim().isEmpty()) {
            Toast.makeText(this, getString(R.string.jks_store_pass_empty), Toast.LENGTH_LONG).show();
            return false;
        }

        if (alias == null || alias.trim().isEmpty()) {
            Toast.makeText(this, getString(R.string.jks_alias_empty), Toast.LENGTH_LONG).show();
            return false;
        }

        if (keyPass == null || keyPass.trim().isEmpty()) {
            Toast.makeText(this, getString(R.string.jks_alias_pass_empty), Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }






    private void showSettingsDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_settings, null);

        android.widget.EditText etSoName = dialogView.findViewById(R.id.etSoName);
        android.widget.EditText etSavePath = dialogView.findViewById(R.id.etSavePath);
        android.widget.EditText etStubClassName = dialogView.findViewById(R.id.etStubClassName);
        android.widget.ImageButton btnSoNamePreset = dialogView.findViewById(R.id.btnSoNamePreset);
        Button btnSaveSettings = dialogView.findViewById(R.id.btnSaveSettings);
        android.widget.ImageButton btnClearStubClassName = dialogView.findViewById(R.id.btnClearStubClassName);
        android.widget.ImageButton btnClearSavePath = dialogView.findViewById(R.id.btnClearSavePath);
        android.widget.LinearLayout llCustomJksForm = dialogView.findViewById(R.id.llCustomJksForm);
        android.widget.EditText etJksPath = dialogView.findViewById(R.id.etJksPath);
        android.widget.EditText etJksStorePass = dialogView.findViewById(R.id.etJksStorePass);
        android.widget.EditText etJksAlias = dialogView.findViewById(R.id.etJksAlias);
        android.widget.EditText etJksKeyPass = dialogView.findViewById(R.id.etJksKeyPass);
        android.widget.Spinner spinnerVmEngine = dialogView.findViewById(R.id.spinnerVmEngine);

        // Conflict warning views
        android.widget.LinearLayout layoutConflictWarning = dialogView.findViewById(R.id.layoutConflictWarning);
        android.widget.TextView tvConflictMessage = dialogView.findViewById(R.id.tvConflictMessage);

        ArkSettings settings = readArkSettings(this);
        etStubClassName.setText(settings.stubClassName);
        etSoName.setText(settings.soName);
        etSavePath.setText(settings.savePath);

        // VM 引擎选择器
        android.widget.ArrayAdapter<CharSequence> vmAdapter = android.widget.ArrayAdapter.createFromResource(
                this, R.array.vm_engine_entries, android.R.layout.simple_spinner_item);
        vmAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerVmEngine.setAdapter(vmAdapter);
        String[] vmValues = getResources().getStringArray(R.array.vm_engine_values);
        int vmSelection = 0;
        for (int i = 0; i < vmValues.length; i++) {
            if (vmValues[i].equalsIgnoreCase(settings.vmEngine)) {
                vmSelection = i;
                break;
            }
        }
        spinnerVmEngine.setSelection(vmSelection);

        etJksPath.setText(settings.jksPath);
        etJksStorePass.setText(settings.jksStorePass);
        etJksAlias.setText(settings.jksAlias);
        etJksKeyPass.setText(settings.jksKeyPass);
        llCustomJksForm.setVisibility(settings.useCustomJks ? View.VISIBLE : View.GONE);

        // ===== Helper: set up an included switch item =====
        // Sets label text on the included switch item's TextView

        // ===== Basic toggles =====
        setupSwitchItem(dialogView, R.id.itemVmpExtract, getString(R.string.enable_vmp_extract));
        setupSwitchItem(dialogView, R.id.itemDebug, getString(R.string.debug));
        setupSwitchItem(dialogView, R.id.itemAutoSign, getString(R.string.sign));
        setupSwitchItem(dialogView, R.id.itemUseCustomJks, getString(R.string.jks));

        // ===== Resource protection =====
        setupSwitchItem(dialogView, R.id.itemResourceObfuscation, getString(R.string.resource_obfuscation));
        setupSwitchItem(dialogView, R.id.itemResourceCompression, getString(R.string.resource_compression));
        setupSwitchItem(dialogView, R.id.itemAssetEncryption, getString(R.string.asset_encryption));

        // ===== Code protection =====
        setupSwitchItem(dialogView, R.id.itemDexEncryption, getString(R.string.dex_encryption));
        setupSwitchItem(dialogView, R.id.itemStringEncryption, getString(R.string.string_encryption));
        setupSwitchItem(dialogView, R.id.itemJunkCodeGeneration, getString(R.string.junk_code_generation));

        // ===== Signature verification =====
        setupSwitchItem(dialogView, R.id.itemSignatureBypass, getString(R.string.signature_bypass));

        // ===== Anti-debug (已实现) =====
        setupSwitchItem(dialogView, R.id.itemFridaPipeDetection, getString(R.string.frida_pipe_detection));
        setupSwitchItem(dialogView, R.id.itemFridaThreadDetection, getString(R.string.frida_thread_detection));
        setupSwitchItem(dialogView, R.id.itemMemDiskComparison, getString(R.string.mem_disk_comparison));

        // ===== Obfuscation =====
        setupSwitchItemDisabled(dialogView, R.id.itemProguardObfuscation, getString(R.string.proguard_obfuscation));
        setupSwitchItemDisabled(dialogView, R.id.itemProguardOptimization, getString(R.string.proguard_optimization));
        setupSwitchItem(dialogView, R.id.itemControlFlowObfuscation, getString(R.string.control_flow_obfuscation));
        setupSwitchItem(dialogView, R.id.itemClassRename, getString(R.string.class_rename));
        setupSwitchItem(dialogView, R.id.itemFieldRename, getString(R.string.field_rename));
        setupSwitchItem(dialogView, R.id.itemConstStringEncryption, getString(R.string.const_string_encryption));
        setupSwitchItem(dialogView, R.id.itemMethodOverload, getString(R.string.method_overload));
        setupSwitchItem(dialogView, R.id.itemDebugRemoval, getString(R.string.debug_removal));
        setupSwitchItem(dialogView, R.id.itemLibEncryption, getString(R.string.lib_encryption));

        // ===== Set initial switch states =====
        setSwitchChecked(dialogView, R.id.itemVmpExtract, settings.enableVmpExtract);
        setSwitchChecked(dialogView, R.id.itemDebug, settings.Debug);
        setSwitchChecked(dialogView, R.id.itemAutoSign, settings.autoSign);
        setSwitchChecked(dialogView, R.id.itemUseCustomJks, settings.useCustomJks);
        setSwitchChecked(dialogView, R.id.itemResourceObfuscation, settings.resourceObfuscation);
        setSwitchChecked(dialogView, R.id.itemResourceCompression, settings.resourceCompression);
        setSwitchChecked(dialogView, R.id.itemAssetEncryption, settings.assetEncryption);
        setSwitchChecked(dialogView, R.id.itemDexEncryption, settings.dexEncryption);
        setSwitchChecked(dialogView, R.id.itemStringEncryption, settings.stringEncryption);
        setSwitchChecked(dialogView, R.id.itemJunkCodeGeneration, settings.junkCodeGeneration);
        setSwitchChecked(dialogView, R.id.itemSignatureBypass, settings.signatureBypass);
        setSwitchChecked(dialogView, R.id.itemFridaPipeDetection, settings.fridaPipeDetection);
        setSwitchChecked(dialogView, R.id.itemFridaThreadDetection, settings.fridaThreadDetection);
        setSwitchChecked(dialogView, R.id.itemMemDiskComparison, settings.memDiskComparison);
        setSwitchChecked(dialogView, R.id.itemControlFlowObfuscation, settings.controlFlowObfuscation);
        setSwitchChecked(dialogView, R.id.itemClassRename, settings.classRename);
        setSwitchChecked(dialogView, R.id.itemFieldRename, settings.fieldRename);
        setSwitchChecked(dialogView, R.id.itemConstStringEncryption, settings.constStringEncryption);
        setSwitchChecked(dialogView, R.id.itemMethodOverload, settings.methodOverload);
        setSwitchChecked(dialogView, R.id.itemDebugRemoval, settings.debugRemoval);
        setSwitchChecked(dialogView, R.id.itemLibEncryption, settings.libEncryption);

        // ===== New environment detection toggles (已实现) =====
        setupSwitchItem(dialogView, R.id.itemAntiEmulator, getString(R.string.anti_emulator));
        setupSwitchItem(dialogView, R.id.itemAntiRoot, getString(R.string.anti_root));
        setupSwitchItem(dialogView, R.id.itemAntiDebugger, getString(R.string.anti_debugger));
        setupSwitchItem(dialogView, R.id.itemAntiXposed, getString(R.string.anti_xposed));
        setupSwitchItem(dialogView, R.id.itemAntiVm, getString(R.string.anti_vm));
        setupSwitchItem(dialogView, R.id.itemApkIntegrityCheck, getString(R.string.apk_integrity_check));

        // ===== New advanced obfuscation toggles =====
        setupSwitchItem(dialogView, R.id.itemDexHeaderObfuscation, getString(R.string.dex_header_obfuscation));
        setupSwitchItem(dialogView, R.id.itemSoNameRandomization, getString(R.string.so_name_randomization));
        setupSwitchItem(dialogView, R.id.itemArithmeticObfuscation, getString(R.string.arithmetic_obfuscation));
        setupSwitchItem(dialogView, R.id.itemMultiDexShuffle, getString(R.string.multi_dex_shuffle));

        // Set initial states for new toggles
        setSwitchChecked(dialogView, R.id.itemAntiEmulator, settings.antiEmulator);
        setSwitchChecked(dialogView, R.id.itemAntiRoot, settings.antiRoot);
        setSwitchChecked(dialogView, R.id.itemAntiDebugger, settings.antiDebugger);
        setSwitchChecked(dialogView, R.id.itemAntiXposed, settings.antiXposed);
        setSwitchChecked(dialogView, R.id.itemAntiVm, settings.antiVm);
        setSwitchChecked(dialogView, R.id.itemApkIntegrityCheck, settings.apkIntegrityCheck);
        setSwitchChecked(dialogView, R.id.itemDexHeaderObfuscation, settings.dexHeaderObfuscation);
        setSwitchChecked(dialogView, R.id.itemArithmeticObfuscation, settings.arithmeticObfuscation);
        setSwitchChecked(dialogView, R.id.itemMultiDexShuffle, settings.multiDexShuffle);

        // SO名称随机化实际已默认启用，开关仅做展示
        SwitchCompat swSoNameRand = getSwitch(dialogView, R.id.itemSoNameRandomization);
        if (swSoNameRand != null) {
            swSoNameRand.setChecked(true);
            swSoNameRand.setEnabled(false);
            swSoNameRand.setAlpha(0.6f);
        }

        // ===== Extended feature toggles (已实现: 运行时检测) =====
        setupSwitchItem(dialogView, R.id.itemAppMultiOpen, getString(R.string.app_multi_open));
        setupSwitchItem(dialogView, R.id.itemJavaHook, getString(R.string.java_hook));
        setupSwitchItem(dialogView, R.id.itemNativeHook, getString(R.string.native_hook));
        setupSwitchItem(dialogView, R.id.itemLocationSimulation, getString(R.string.location_simulation));
        setupSwitchItem(dialogView, R.id.itemDeviceModification, getString(R.string.device_modification));

        // ===== Extended feature toggles (开发中) =====
        setupSwitchItem(dialogView, R.id.itemDexStringDecryption, getString(R.string.dex_string_decryption));
        setupSwitchItem(dialogView, R.id.itemReflectionClinitInjection, getString(R.string.reflection_clinit_injection));
        setupSwitchItem(dialogView, R.id.itemProtectRules, getString(R.string.protect_rules));
        setupSwitchItem(dialogView, R.id.itemAdvancedReflection, getString(R.string.advanced_reflection));
        setupSwitchItem(dialogView, R.id.itemArithmeticBranch, getString(R.string.arithmetic_branch));
        setupSwitchItem(dialogView, R.id.itemCallIndirection, getString(R.string.call_indirection));
        setupSwitchItem(dialogView, R.id.itemGotoInsertion, getString(R.string.goto_insertion));
        setupSwitchItem(dialogView, R.id.itemDptShellStandard, getString(R.string.dpt_shell_standard));
        setupSwitchItem(dialogView, R.id.itemDptShellEnhanced, getString(R.string.dpt_shell_enhanced));

        setSwitchChecked(dialogView, R.id.itemAppMultiOpen, settings.appMultiOpen);
        setSwitchChecked(dialogView, R.id.itemJavaHook, settings.javaHook);
        setSwitchChecked(dialogView, R.id.itemNativeHook, settings.nativeHook);
        setSwitchChecked(dialogView, R.id.itemLocationSimulation, settings.locationSimulation);
        setSwitchChecked(dialogView, R.id.itemDeviceModification, settings.deviceModification);
        setSwitchChecked(dialogView, R.id.itemDexStringDecryption, settings.dexStringDecryption);
        setSwitchChecked(dialogView, R.id.itemReflectionClinitInjection, settings.reflectionClinitInjection);
        setSwitchChecked(dialogView, R.id.itemProtectRules, settings.protectRules);
        setSwitchChecked(dialogView, R.id.itemAdvancedReflection, settings.advancedReflection);
        setSwitchChecked(dialogView, R.id.itemArithmeticBranch, settings.arithmeticBranch);
        setSwitchChecked(dialogView, R.id.itemCallIndirection, settings.callIndirection);
        setSwitchChecked(dialogView, R.id.itemGotoInsertion, settings.gotoInsertion);
        setSwitchChecked(dialogView, R.id.itemDptShellStandard, settings.dptShellStandard);
        setSwitchChecked(dialogView, R.id.itemDptShellEnhanced, settings.dptShellEnhanced);

        // ===== Custom JKS toggle =====
        SwitchCompat swUseCustomJks = getSwitch(dialogView, R.id.itemUseCustomJks);
        if (swUseCustomJks != null) {
            swUseCustomJks.setOnCheckedChangeListener((buttonView, isChecked) -> {
                llCustomJksForm.setVisibility(isChecked ? View.VISIBLE : View.GONE);
            });
        }

        // ===== Conflict detection: auto close mutually exclusive switches =====
        final boolean[] syncingConflictSwitch = {false};
        java.util.function.BiConsumer<Integer, Integer> bindExclusiveSwitches = (firstId, secondId) -> {
            SwitchCompat first = getSwitch(dialogView, firstId);
            SwitchCompat second = getSwitch(dialogView, secondId);
            if (first == null || second == null) return;

            first.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (syncingConflictSwitch[0]) return;
                if (isChecked && second.isChecked()) {
                    syncingConflictSwitch[0] = true;
                    second.setChecked(false);
                    syncingConflictSwitch[0] = false;
                    Toast.makeText(this, "已自动关闭冲突选项", Toast.LENGTH_SHORT).show();
                }
            });

            second.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (syncingConflictSwitch[0]) return;
                if (isChecked && first.isChecked()) {
                    syncingConflictSwitch[0] = true;
                    first.setChecked(false);
                    syncingConflictSwitch[0] = false;
                    Toast.makeText(this, "已自动关闭冲突选项", Toast.LENGTH_SHORT).show();
                }
            });
        };

        bindExclusiveSwitches.accept(R.id.itemAutoSign, R.id.itemSignatureBypass);
        bindExclusiveSwitches.accept(R.id.itemResourceObfuscation, R.id.itemAssetEncryption);
        // 两者都会改写方法指令。为了兼容性优先，默认只允许同时启用一种。
        bindExclusiveSwitches.accept(R.id.itemControlFlowObfuscation, R.id.itemJunkCodeGeneration);
        // DPT两种模式功能重复，增强版包含标准版所有能力，互斥启用
        bindExclusiveSwitches.accept(R.id.itemDptShellStandard, R.id.itemDptShellEnhanced);

        // ===== Conflict detection: check current state =====
        Runnable checkConflicts = () -> {
            if (!settings.conflictDetectionEnabled) {
                layoutConflictWarning.setVisibility(View.GONE);
                return;
            }

            boolean autoSign = isSwitchChecked(dialogView, R.id.itemAutoSign);
            boolean sigBypass = isSwitchChecked(dialogView, R.id.itemSignatureBypass);
            boolean resObf = isSwitchChecked(dialogView, R.id.itemResourceObfuscation);
            boolean assetEnc = isSwitchChecked(dialogView, R.id.itemAssetEncryption);
            boolean controlFlow = isSwitchChecked(dialogView, R.id.itemControlFlowObfuscation);
            boolean junkCode = isSwitchChecked(dialogView, R.id.itemJunkCodeGeneration);

            java.util.ArrayList<String> conflicts = new java.util.ArrayList<>();

            if (autoSign && sigBypass) {
                conflicts.add(getString(R.string.conflict_signature_check));
            }
            if (resObf && assetEnc) {
                conflicts.add(getString(R.string.conflict_resource_operations));
            }
            if (controlFlow && junkCode) {
                conflicts.add("控制流混淆与垃圾代码会同时改写指令，已设置为互斥以优先保证兼容性");
            }

            if (conflicts.isEmpty()) {
                layoutConflictWarning.setVisibility(View.GONE);
            } else {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < conflicts.size(); i++) {
                    if (i > 0) sb.append("\n");
                    sb.append("• ").append(conflicts.get(i));
                }
                tvConflictMessage.setText(sb.toString());
                layoutConflictWarning.setVisibility(View.VISIBLE);
            }
        };

        int[] conflictSwitchIds = {
            R.id.itemAutoSign, R.id.itemSignatureBypass,
            R.id.itemResourceObfuscation, R.id.itemAssetEncryption,
            R.id.itemControlFlowObfuscation, R.id.itemJunkCodeGeneration
        };
        for (int id : conflictSwitchIds) {
            SwitchCompat sw = getSwitch(dialogView, id);
            if (sw != null) {
                sw.setOnClickListener(v -> checkConflicts.run());
            }
        }
        checkConflicts.run();

        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        btnSoNamePreset.setOnClickListener(v -> showSoNamePresetDialog(etSoName));
        btnClearStubClassName.setOnClickListener(v -> {
            new android.app.AlertDialog.Builder(this)
                    .setTitle(R.string.confirm_clear_title)
                    .setMessage(R.string.confirm_clear_stub_class)
                    .setPositiveButton(R.string.confirm, (d, w) -> etStubClassName.setText(""))
                    .setNegativeButton(R.string.cancel, null)
                    .show();
        });

        btnClearSavePath.setOnClickListener(v -> {
            new android.app.AlertDialog.Builder(this)
                    .setTitle(R.string.confirm_clear_title)
                    .setMessage(R.string.confirm_clear_save_path)
                    .setPositiveButton(R.string.confirm, (d, w) -> etSavePath.setText(""))
                    .setNegativeButton(R.string.cancel, null)
                    .show();
        });

        btnSaveSettings.setOnClickListener(v -> {
            String soName = etSoName.getText().toString().trim();
            String stubClassName = etStubClassName.getText().toString().trim();
            String savePath = etSavePath.getText().toString().trim();
            boolean enableVmpExtract = isSwitchChecked(dialogView, R.id.itemVmpExtract);
            boolean Debug = isSwitchChecked(dialogView, R.id.itemDebug);
            boolean autoSign = isSwitchChecked(dialogView, R.id.itemAutoSign);
            boolean useCustomJks = isSwitchChecked(dialogView, R.id.itemUseCustomJks);
            String jksPath = etJksPath.getText().toString().trim();
            String jksStorePass = etJksStorePass.getText().toString();
            String jksAlias = etJksAlias.getText().toString().trim();
            String jksKeyPass = etJksKeyPass.getText().toString();
            String vmEngine = vmValues[spinnerVmEngine.getSelectedItemPosition()];

            if (!isValidSoName(soName)) {
                Toast.makeText(this, getString(R.string.invalid_so_name), Toast.LENGTH_LONG).show();
                return;
            }
            if (!isValidStubClassName(stubClassName)) {
                new android.app.AlertDialog.Builder(this)
                        .setTitle(R.string.invalid_stub_class_title)
                        .setMessage(R.string.invalid_stub_class_message)
                        .setPositiveButton(R.string.confirm, null)
                        .show();
                return;
            }
            if (!isValidSavePath(savePath)) {
                Toast.makeText(this, getString(R.string.invalid_save_path), Toast.LENGTH_LONG).show();
                return;
            }
            if (isPathInCacheDir(this, savePath)) {
                Toast.makeText(this, getString(R.string.cache_save_path_not_allowed), Toast.LENGTH_LONG).show();
                return;
            }
            if (useCustomJks && !isValidJksSettings(jksPath, jksStorePass, jksAlias, jksKeyPass)) {
                return;
            }

            // Save basic settings
            saveArkSettings(soName, stubClassName, savePath, enableVmpExtract, vmEngine, Debug,
                    autoSign, useCustomJks, jksPath, jksStorePass, jksAlias, jksKeyPass);

            // Save enhanced settings
            android.content.SharedPreferences sp = getSharedPreferences(SP_SETTINGS, MODE_PRIVATE);
            android.content.SharedPreferences.Editor editor = sp.edit();
            editor.putBoolean(ExtendedArkSettingsManager.KEY_RESOURCE_OBFUSCATION, isSwitchChecked(dialogView, R.id.itemResourceObfuscation));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_RESOURCE_COMPRESSION, isSwitchChecked(dialogView, R.id.itemResourceCompression));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ASSET_ENCRYPTION, isSwitchChecked(dialogView, R.id.itemAssetEncryption));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_DEX_ENCRYPTION, isSwitchChecked(dialogView, R.id.itemDexEncryption));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_STRING_ENCRYPTION, isSwitchChecked(dialogView, R.id.itemStringEncryption));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_JUNK_CODE_GENERATION, isSwitchChecked(dialogView, R.id.itemJunkCodeGeneration));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_SIGNATURE_BYPASS, isSwitchChecked(dialogView, R.id.itemSignatureBypass));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_FRIDA_PIPE_DETECTION, isSwitchChecked(dialogView, R.id.itemFridaPipeDetection));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_FRIDA_THREAD_DETECTION, isSwitchChecked(dialogView, R.id.itemFridaThreadDetection));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_MEM_DISK_COMPARISON, isSwitchChecked(dialogView, R.id.itemMemDiskComparison));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_PROGUARD_OBFUSCATION, isSwitchChecked(dialogView, R.id.itemProguardObfuscation));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_PROGUARD_OPTIMIZATION, isSwitchChecked(dialogView, R.id.itemProguardOptimization));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_CONTROL_FLOW_OBFUSCATION, isSwitchChecked(dialogView, R.id.itemControlFlowObfuscation));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_CLASS_RENAME, isSwitchChecked(dialogView, R.id.itemClassRename));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_FIELD_RENAME, isSwitchChecked(dialogView, R.id.itemFieldRename));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_CONST_STRING_ENCRYPTION, isSwitchChecked(dialogView, R.id.itemConstStringEncryption));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_METHOD_OVERLOAD, isSwitchChecked(dialogView, R.id.itemMethodOverload));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_DEBUG_REMOVAL, isSwitchChecked(dialogView, R.id.itemDebugRemoval));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_LIB_ENCRYPTION, isSwitchChecked(dialogView, R.id.itemLibEncryption));

            // Save new environment detection settings
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ANTI_EMULATOR, isSwitchChecked(dialogView, R.id.itemAntiEmulator));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ANTI_ROOT, isSwitchChecked(dialogView, R.id.itemAntiRoot));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ANTI_DEBUGGER, isSwitchChecked(dialogView, R.id.itemAntiDebugger));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ANTI_XPOSED, isSwitchChecked(dialogView, R.id.itemAntiXposed));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ANTI_VM, isSwitchChecked(dialogView, R.id.itemAntiVm));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_APK_INTEGRITY_CHECK, isSwitchChecked(dialogView, R.id.itemApkIntegrityCheck));

            // Save new advanced obfuscation settings
            editor.putBoolean(ExtendedArkSettingsManager.KEY_DEX_HEADER_OBFUSCATION, isSwitchChecked(dialogView, R.id.itemDexHeaderObfuscation));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_SO_NAME_RANDOMIZATION, isSwitchChecked(dialogView, R.id.itemSoNameRandomization));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ARITHMETIC_OBFUSCATION, isSwitchChecked(dialogView, R.id.itemArithmeticObfuscation));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_MULTI_DEX_SHUFFLE, isSwitchChecked(dialogView, R.id.itemMultiDexShuffle));

            // Save pre-defined extended features
            editor.putBoolean(ExtendedArkSettingsManager.KEY_APP_MULTI_OPEN, isSwitchChecked(dialogView, R.id.itemAppMultiOpen));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_JAVA_HOOK, isSwitchChecked(dialogView, R.id.itemJavaHook));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_NATIVE_HOOK, isSwitchChecked(dialogView, R.id.itemNativeHook));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_LOCATION_SIMULATION, isSwitchChecked(dialogView, R.id.itemLocationSimulation));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_DEVICE_MODIFICATION, isSwitchChecked(dialogView, R.id.itemDeviceModification));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_DEX_STRING_DECRYPTION, isSwitchChecked(dialogView, R.id.itemDexStringDecryption));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_REFLECTION_CLINIT_INJECTION, isSwitchChecked(dialogView, R.id.itemReflectionClinitInjection));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_PROTECT_RULES, isSwitchChecked(dialogView, R.id.itemProtectRules));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ADVANCED_REFLECTION, isSwitchChecked(dialogView, R.id.itemAdvancedReflection));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ARITHMETIC_BRANCH, isSwitchChecked(dialogView, R.id.itemArithmeticBranch));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_CALL_INDIRECTION, isSwitchChecked(dialogView, R.id.itemCallIndirection));
            editor.putBoolean(ExtendedArkSettingsManager.KEY_GOTO_INSERTION, isSwitchChecked(dialogView, R.id.itemGotoInsertion));
            editor.putBoolean("dpt_shell_standard", isSwitchChecked(dialogView, R.id.itemDptShellStandard));
            editor.putBoolean("dpt_shell_enhanced", isSwitchChecked(dialogView, R.id.itemDptShellEnhanced));
            editor.apply();

            Toast.makeText(this, getString(R.string.settings_saved), Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
    }

    // ===== Helper: set label text on an included switch item =====
    private void setupSwitchItem(View root, int includeId, String label) {
        View item = root.findViewById(includeId);
        if (item == null) return;
        android.widget.TextView tvLabel = item.findViewById(R.id.tvSettingLabel);
        if (tvLabel != null) tvLabel.setText(label);
    }

    private void setupSwitchItemDisabled(View root, int includeId, String label) {
        View item = root.findViewById(includeId);
        if (item == null) return;
        android.widget.TextView tvLabel = item.findViewById(R.id.tvSettingLabel);
        if (tvLabel != null) tvLabel.setText(label + " (开发中)");
        SwitchCompat sw = item.findViewById(R.id.swSetting);
        if (sw != null) {
            sw.setEnabled(false);
            sw.setAlpha(0.4f);
            sw.setChecked(false);
        }
        if (tvLabel != null) tvLabel.setAlpha(0.5f);
    }

    // ===== Helper: get SwitchCompat from an included layout =====
    private SwitchCompat getSwitch(View root, int includeId) {
        View item = root.findViewById(includeId);
        if (item == null) return null;
        return item.findViewById(R.id.swSetting);
    }

    // ===== Helper: set switch checked state =====
    private void setSwitchChecked(View root, int includeId, boolean checked) {
        SwitchCompat sw = getSwitch(root, includeId);
        if (sw != null) sw.setChecked(checked);
    }

    // ===== Helper: read switch checked state =====
    private boolean isSwitchChecked(View root, int includeId) {
        SwitchCompat sw = getSwitch(root, includeId);
        return sw != null && sw.isChecked();
    }

    // ===== Log which enhanced features are enabled =====
    private void logEnhancedFeatures(ArkSettings settings) {
        if (settings == null) return;

        java.util.ArrayList<String> enabled = new java.util.ArrayList<>();
        if (settings.resourceObfuscation) enabled.add("资源混淆");
        if (settings.resourceCompression) enabled.add("资源压缩");
        if (settings.assetEncryption) enabled.add("资源加密");
        if (settings.dexEncryption) enabled.add("DEX加密");
        if (settings.stringEncryption) enabled.add("字符串加密");
        if (settings.junkCodeGeneration) enabled.add("垃圾代码");
        if (settings.signatureBypass) enabled.add("签名绕过");
        if (settings.fridaPipeDetection) enabled.add("Frida管道检测");
        if (settings.fridaThreadDetection) enabled.add("Frida线程检测");
        if (settings.memDiskComparison) enabled.add("内存磁盘比较");
        if (settings.proguardObfuscation) enabled.add("ProGuard混淆");
        if (settings.proguardOptimization) enabled.add("ProGuard优化");
        if (settings.controlFlowObfuscation) enabled.add("控制流混淆");
        if (settings.classRename) enabled.add("类重命名");
        if (settings.fieldRename) enabled.add("字段重命名");
        if (settings.constStringEncryption) enabled.add("常量字符串加密");
        if (settings.methodOverload) enabled.add("方法重载");
        if (settings.debugRemoval) enabled.add("调试信息移除");
        if (settings.libEncryption) enabled.add("本地库加密");
        if (settings.antiEmulator) enabled.add("反模拟器");
        if (settings.antiRoot) enabled.add("反Root");
        if (settings.antiDebugger) enabled.add("反调试器");
        if (settings.antiXposed) enabled.add("反Xposed");
        if (settings.antiVm) enabled.add("反虚拟机");
        if (settings.apkIntegrityCheck) enabled.add("APK完整性校验");
        if (settings.dexHeaderObfuscation) enabled.add("DEX头部混淆");
        if (settings.soNameRandomization) enabled.add("SO名称随机化(默认)");
        if (settings.arithmeticObfuscation) enabled.add("算术混淆");
        if (settings.multiDexShuffle) enabled.add("多DEX打乱");
        if (settings.appMultiOpen) enabled.add("应用多开检测");
        if (settings.javaHook) enabled.add("Java Hook检测");
        if (settings.nativeHook) enabled.add("Native Hook检测");
        if (settings.locationSimulation) enabled.add("位置模拟检测");
        if (settings.deviceModification) enabled.add("设备篡改检测");
        if (settings.dexStringDecryption) enabled.add("DEX字符串解密");
        if (settings.reflectionClinitInjection) enabled.add("反射Clinit注入");
        if (settings.protectRules) enabled.add("保护规则");
        if (settings.advancedReflection) enabled.add("高级反射混淆");
        if (settings.arithmeticBranch) enabled.add("算术分支混淆");
        if (settings.callIndirection) enabled.add("调用间接化");
        if (settings.gotoInsertion) enabled.add("Goto插入");
        if (settings.dptShellStandard) enabled.add("DPT函数抽取(标准)");
        if (settings.dptShellEnhanced) enabled.add("DPT函数抽取(增强)");

        if (enabled.isEmpty()) {
            appendLogOnUi("增强功能：未启用任何扩展功能");
        } else {
            appendLogOnUi("增强功能：" + android.text.TextUtils.join("、", enabled));
        }
    }

    // ===== Auto-resolve feature conflicts before processing =====
    // NOTE: This method is kept for backward compatibility but now delegates
    // to ProtectionPipeline.resolveConflicts which uses the updated conflict rules.
    private void resolveFeatureConflicts(ArkSettings settings) {
        if (settings == null) return;

        android.content.SharedPreferences sp = getSharedPreferences(SP_SETTINGS, MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = sp.edit();
        boolean changed = false;

        // Auto-sign (signature verification) vs signature bypass
        if (settings.autoSign && settings.signatureBypass) {
            editor.putBoolean(ExtendedArkSettingsManager.KEY_SIGNATURE_BYPASS, false);
            settings.signatureBypass = false;
            appendLogOnUi("冲突处理：签名校验与签名绕过冲突，已自动禁用签名绕过");
            changed = true;
        }

        // VMP vs DEX encryption: NO LONGER A CONFLICT
        // With the new pipeline (obfuscate → VMP → encrypt), they coexist.

        // Resource obfuscation vs asset encryption
        if (settings.resourceObfuscation && settings.assetEncryption) {
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ASSET_ENCRYPTION, false);
            settings.assetEncryption = false;
            appendLogOnUi("冲突处理：资源混淆与资源加密冲突，已自动禁用资源加密");
            changed = true;
        }

        if (changed) {
            editor.apply();
        }
    }

    private static class SoNamePreset {
        String feature;
        String soName;

        SoNamePreset(String feature, String soName) {
            this.feature = feature;
            this.soName = soName;
        }
    }


    private void showSoNamePresetDialog(android.widget.EditText etSoName) {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_so_name_preset, null);

        android.widget.RadioGroup rgSoNamePreset = dialogView.findViewById(R.id.rgSoNamePreset);
        Button btnConfirmSoNamePreset = dialogView.findViewById(R.id.btnConfirmSoNamePreset);

        for (int i = 0; i < SO_NAME_PRESETS.length; i++) {
            SoNamePreset item = SO_NAME_PRESETS[i];

            android.widget.RadioButton radioButton = new android.widget.RadioButton(this);
            radioButton.setId(10000 + i);
            radioButton.setText(
                    getString(
                            R.string.so_feature_item,
                            item.feature,
                            item.soName
                    )
            );
            radioButton.setTextColor(android.graphics.Color.parseColor("#1F2937"));
            radioButton.setTextSize(14);
            radioButton.setPadding(12, 14, 12, 14);
            radioButton.setSingleLine(false);

            rgSoNamePreset.addView(radioButton);
        }

        android.app.AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create();

        btnConfirmSoNamePreset.setOnClickListener(v -> {
            int checkedId = rgSoNamePreset.getCheckedRadioButtonId();

            if (checkedId == -1) {
                Toast.makeText(this, getString(R.string.select_preset_so_name), Toast.LENGTH_SHORT).show();
                return;
            }

            int index = checkedId - 10000;

            if (index < 0 || index >= SO_NAME_PRESETS.length) {
                Toast.makeText(this, getString(R.string.invalid_selection), Toast.LENGTH_SHORT).show();
                return;
            }

            etSoName.setText(SO_NAME_PRESETS[index].soName);
            etSoName.setSelection(etSoName.getText().length());

            dialog.dismiss();
        });

        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }
    }





    private boolean hasAllFilePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED;
        }

        return true;
    }
    private void openAllFilePermissionPage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception e) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivity(intent);
            }
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(
                    new String[]{
                            android.Manifest.permission.READ_EXTERNAL_STORAGE,
                            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    REQ_STORAGE_PERMISSION
            );
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_STORAGE_PERMISSION) {
            if (hasAllFilePermission()) {
                initMainPage();
            } else {
                Toast.makeText(this, R.string.file_access_permission_denied, Toast.LENGTH_LONG).show();
                showPermissionDialog();
            }
        }
    }
    /**
     * Append log text to UI. Delegates to LogManager for batched rendering.
     */
    private void appendLog(String text) {
        if (logManager != null) {
            logManager.log(text);
        }
    }

    /**
     * Append log from background thread. Delegates to LogManager (thread-safe).
     */
    private void appendLogOnUi(String text) {
        if (logManager != null) {
            logManager.log(text);
        }
    }

    /**
     * Append verbose log (only shown when verbose mode is enabled).
     */
    private void appendLogVerbose(String text) {
        if (logManager != null) {
            logManager.logVerbose(text);
        }
    }

    private void openApkSelector() {
        ArkSettings settings = readArkSettings(this);

        if (settings != null && isPathInCacheDir(this, settings.savePath)) {
            new android.app.AlertDialog.Builder(this)
                    .setTitle(R.string.invalid_save_path_title)
                    .setMessage(R.string.invalid_save_path_message)
                    .setCancelable(false)
                    .setPositiveButton(R.string.modify, (dialog, which) -> {
                        dialog.dismiss();
                        showSettingsDialog();
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
            return;
        }

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.android.package-archive");
        startActivityForResult(intent, REQ_SELECT_APK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_SELECT_APK && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) {
                appendLog("选择文件失败：Uri为空");
                return;
            }

            handleSelectedApk(uri);
        }
    }

    private void handleSelectedApk(Uri uri) {
        pendingApkUri = uri;
        clearLog();

        String originalApkName = getFileNameFromUri(this, uri);
        if (originalApkName == null || originalApkName.trim().isEmpty()) {
            originalApkName = "未知APK.apk";
        }
        uiState.updateApkPath(originalApkName);
        appendLogOnUi("已选择 APK：" + originalApkName);
        appendLogOnUi("点击“开始加固”执行处理");
    }

    private void startProcess() {
        if (pendingApkUri == null) {
            appendLogOnUi("请先选择 APK");
            return;
        }
        uiState.updateProcessing(true);

        new Thread(() -> {
            File workDir = getWorkDir();
            cleanTempFiles(workDir);
            pendingWorkDir = workDir;
            // 重置随机化缓存，确保每次加固生成不同的随机名称
            ArkJiaguUtils.resetRandomizationCache();
            ArkSettings settings = readArkSettings(this);
            try {
                appendLogOnUi("开始处理 APK");

                // 显示随机化后的壳类名和SO名称
                String stubName = ArkJiaguUtils.getValidStubClassNameFromSettings(this);
                String soName = ArkJiaguUtils.getValidSoNameFromSettings(this, this::appendLogOnUi);
                appendLogOnUi("壳类名: " + stubName);
                appendLogOnUi("SO名称: " + soName);

                // Log enhanced feature status
                logEnhancedFeatures(settings);

                // Auto-resolve conflicts before processing (uses new pipeline logic)
                ProtectionPipeline.resolveConflicts(this, settings, this::appendLogOnUi);

                if (!workDir.exists() && !workDir.mkdirs()) {
                    throw new RuntimeException("创建临时目录失败：" + workDir.getAbsolutePath());
                }

                appendLogOnUi("临时目录：" + workDir.getAbsolutePath());

                String originalApkName = getFileNameFromUri(this, pendingApkUri);
                if (originalApkName == null || originalApkName.trim().isEmpty()) {
                    originalApkName = "未知APK.apk";
                }

                File copiedApk = new File(workDir, "待加固.apk");
                pendingCopiedApk = copiedApk;
                copyUriToFile(this, pendingApkUri, copiedApk);

                String appName = readApplicationName(this, copiedApk);
                String appComponentFactory = readAppComponentFactoryName(this, copiedApk);
                appendLogOnUi("原始入口：" + appName);
                if (appComponentFactory != null) {
                    appendLogOnUi("Factory：" + appComponentFactory);
                } else {
                    appendLogOnUi("Factory：无");
                }

                appendLogOnUi("开始解压原始 dex");
                VmpJiaguEntry.extractManifestAndDex(copiedApk, workDir);
                appendLogOnUi("原始 dex 解压完成");

                // ===== Stage 1: DEX Obfuscation (runs BEFORE VMP) ======
                appendLogOnUi("====== 开始 DEX 混淆阶段 ======");
                // 预先生成壳代理Application类名，确保它在混淆阶段被保护
                String stubClassName = getValidStubClassNameFromSettings(this);
                ProtectionPipeline.executeObfuscationStage(
                        workDir, settings,
                        msg -> appendLogOnUi(msg),
                        stubClassName
                );
                appendLogOnUi("====== DEX 混淆阶段完成 ======");

                // ===== Stage 1.5: dpt-shell 函数抽取（在DEX混淆之后、VMP之前） =====
                if (settings.dptShellStandard || settings.dptShellEnhanced) {
                    boolean useEnhanced = settings.dptShellEnhanced;
                    appendLogOnUi("====== 开始 DPT 函数抽取 ======");
                    try {
                        File[] dexFiles = ArkJiaguUtils.getDexFiles(workDir);
                        com.ark.jiagu.dpt.DptCodeExtractor dptExtractor =
                                new com.ark.jiagu.dpt.DptCodeExtractor(workDir,
                                        msg -> appendLogOnUi(msg), useEnhanced);
                        File codeItemFile = dptExtractor.extractAll(dexFiles);

                        // 增强版：再做 XOR/碎片化/虚假项处理
                        if (useEnhanced) {
                            com.ark.jiagu.dpt.DptEnhancedProcessor enhancer =
                                    new com.ark.jiagu.dpt.DptEnhancedProcessor(workDir, msg -> appendLogOnUi(msg));
                            codeItemFile = enhancer.processEnhanced(codeItemFile, dptExtractor.allDexCodeItems);
                        }

                        // 将 dpt_codeitems.bin 和 dpt_config.json 标记为需要打包到 APK
                        if (codeItemFile != null && codeItemFile.exists()) {
                            File dptFlag = new File(workDir, ".dpt_enabled");
                            try (java.io.FileWriter fw = new java.io.FileWriter(dptFlag)) {
                                fw.write(useEnhanced ? "enhanced" : "standard");
                            }
                            appendLogOnUi("  DPT产物已生成，将打包到APK");
                        }
                    } catch (Exception e) {
                        appendLogOnUi("DPT函数抽取失败: " + e.getMessage());
                    }
                    appendLogOnUi("====== DPT 函数抽取完成 ======");
                }

                if (settings.Debug) {
                    File rawDexDebugDir = new File(workDir, DEBUG_RAW_DEX_DIR);
                    copyDexFilesToDir(workDir, rawDexDebugDir);
                    appendLogOnUi("调试模式：已备份混淆后 dex 到：" + rawDexDebugDir.getAbsolutePath());
                }




                appendLogOnUi("开始执行 VMP 处理");

                String vmEngineMode = (settings != null && settings.vmEngine != null)
                        ? settings.vmEngine
                        : com.ark.jiagu.vm.VmEngineFactory.MODE_NONE;
                com.ark.jiagu.vm.VmEngine vmEngine = com.ark.jiagu.vm.VmEngineFactory.create(vmEngineMode);
                appendLogOnUi("当前 VM 引擎：" + vmEngine.getDisplayName());

                com.ark.jiagu.vm.VmEngineSettings vmSettings = new com.ark.jiagu.vm.VmEngineSettings();
                vmSettings.soName = getValidSoNameFromSettings(this, this::appendLogOnUi);
                vmSettings.stubClassName = stubClassName;

                // 默认抽取规则：Activity onCreate，兜底为全方法
                List<String> activityOnCreateList = readActivityOnCreateMethods(this, copiedApk, this::appendLogOnUi);
                if (activityOnCreateList.isEmpty()) {
                    appendLogOnUi("未读取到 Activity，使用默认 onCreate 抽取规则");
                    activityOnCreateList.add("*.*.onCreate");
                } else {
                    appendLogOnUi("读取到 Activity 数量：" + activityOnCreateList.size());
                }
                vmSettings.methodRules = activityOnCreateList.toArray(new String[0]);

                try {
                    vmEngine.process(this, workDir, vmSettings, this::appendLogOnUi);
                    appendLogOnUi("VMP 处理完成");
                } catch (Exception e) {
                    appendLogOnUi("VMP 处理失败：" + e.getMessage());
                    if (settings.Debug) {
                        e.printStackTrace();
                    }
                    // 失败时回退到空 vmp.bin，避免后续打包失败
                    File emptyBin = new File(workDir, "vmp.bin");
                    try (FileOutputStream fos = new FileOutputStream(emptyBin)) {
                    } catch (Exception ignored) {
                    }
                }

                // DEX加密由native层 b() 方法处理，不需要Java层再加密
                // 之前的executeEncryptionStage会在b()之前破坏DEX格式导致"非法dex"错误
                if (settings.dexEncryption) {
                    appendLogOnUi("DEX加密将由native层壳处理");
                }

                if (settings.Debug) {
                    File vmpDexDebugDir = new File(workDir, DEBUG_VMP_DEX_DIR);
                    copyDexFilesToDir(workDir, vmpDexDebugDir);
                    appendLogOnUi("调试模式：已备份 VMP dex 到：" + vmpDexDebugDir.getAbsolutePath());
                }

                File shellDexDir = new File(workDir, "shell");
                if (!shellDexDir.exists() && !shellDexDir.mkdirs()) {
                    throw new RuntimeException("创建壳dex目录失败：" + shellDexDir.getAbsolutePath());
                }

                // 常量字符串加密暂时禁用，不需要注入 StringDecryptor
                boolean needStringDecryptor = false;
                File shellDex = generateShellDex(this, shellDexDir, this::appendLogOnUi, needStringDecryptor);

                byte[] signHash64 = getSignHash64ForShell();

                b(workDir, shellDex, appName, appComponentFactory, signHash64);//在native层加密方法，这里名称改成b防止根据名称知道意思

                File finalShellDex = new File(workDir, "classes.dex");

                try (FileInputStream in = new FileInputStream(shellDex);
                     FileOutputStream out = new FileOutputStream(finalShellDex, false)) {

                    byte[] buffer = new byte[8192];
                    int len;

                    while ((len = in.read(buffer)) != -1) {
                        out.write(buffer, 0, len);
                    }

                    out.flush();
                }

                appendLogOnUi("加密完成：" + finalShellDex.getAbsolutePath());

                extractStubSoByTargetAbi(copiedApk, workDir);

                patchStubSoWithVmpBin(workDir);//将vmp.bin写so文件中

                // ===== Stage 5: Resource Protection =====
                appendLogOnUi("====== 开始资源保护阶段 ======");
                ProtectionPipeline.executeResourceStage(
                        workDir, copiedApk, settings,
                        msg -> appendLogOnUi(msg)
                );
                appendLogOnUi("====== 资源保护阶段完成 ======");

                // ===== Stage 6: Native Library Protection =====
                appendLogOnUi("====== 开始本地库保护阶段 ======");
                // 必须使用与实际写入的SO文件名一致的名称来跳过壳SO
                String actualSoName = ArkJiaguUtils.getValidSoNameFromSettings(this, this::appendLogOnUi);
                String stubSoFileName = "lib" + actualSoName + ".so";
                appendLogOnUi("壳SO文件名（跳过加密）: " + stubSoFileName);
                ProtectionPipeline.executeNativeStage(
                        workDir, settings, stubSoFileName,
                        msg -> appendLogOnUi(msg)
                );
                appendLogOnUi("====== 本地库保护阶段完成 ======");

                // 写入安全检测配置（在APK重打包前）
                ProtectionPipeline.executeSecurityConfigStage(
                        workDir, settings,
                        msg -> appendLogOnUi(msg)
                );
                appendLogOnUi("====== 安全检测配置完成 ======");

                File newManifest = modifyAndroidManifest(copiedApk, workDir);

                File protectedApk = rebuildProtectedApk(copiedApk, workDir, originalApkName);//开始打包APK

                appendLogOnUi("开始进行 ZIPALIGN");
                protectedApk = zipAlignApk(protectedApk);
                appendLogOnUi("ZIPALIGN 完成");


                boolean autoSign = settings != null && settings.autoSign;

                if (autoSign) {
                    appendLogOnUi("检测到已开启自动签名");

                    if (settings.useCustomJks) {
                        protectedApk = ApkSignUtil.signApk(
                                this,
                                protectedApk,
                                new File(settings.jksPath),
                                settings.jksStorePass,
                                settings.jksAlias,
                                settings.jksKeyPass
                        );
                    } else {
                        protectedApk = ApkSignUtil.signApk(this, protectedApk);
                    }

                    appendLogOnUi("APK 签名完成");
                } else {
                    appendLogOnUi("未开启自动签名，跳过签名");
                }

                appendLogOnUi(getString(
                        R.string.protected_apk_output,
                        protectedApk.getAbsolutePath()
                ));
                appendLogOnUi(getString(R.string.protection_completed));

                //只有开启了自动签名的APK，才会弹出提示让安装
                if (autoSign) {
                    File finalProtectedApk = protectedApk;
                    runOnUiThread(() -> {
                        AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                                .setTitle(R.string.protection_complete_title)
                                .setMessage(R.string.install_prompt_message)
                                .setPositiveButton(R.string.install, null)
                                .setNegativeButton(R.string.cancel, (d, w) -> d.dismiss())
                                .setCancelable(false)
                                .create();

                        dialog.show();

                        dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE)
                                .setOnClickListener(v -> installApk(finalProtectedApk));
                    });
                }else{
                    runOnUiThread(() -> {
                        AlertDialog dialog = new android.app.AlertDialog.Builder(this)
                                .setTitle(R.string.protection_complete_title)
                                .setMessage(R.string.manual_sign_message)
                                .setNegativeButton(R.string.ok, (d, w) -> d.dismiss())
                                .setCancelable(false)
                                .create();

                        dialog.show();
                    });
                }

            } catch (Exception e) {
                appendLogOnUi("处理失败：" + e.getMessage());
            } finally {
                if (!settings.Debug) {
                    //appendLogOnUi("非调试模式，开始清理临时目录");
                    cleanTempFiles(workDir);
                    //appendLogOnUi("临时目录清理完成");
                } else {
                    //appendLogOnUi("调试模式，保留临时目录：" + workDir.getAbsolutePath());
                }

                runOnUiThread(() -> uiState.updateProcessing(false));
            }
        }).start();
    }


    private void patchStubSoWithVmpBin(File workDir) throws Exception {
        File vmpBin = new File(workDir, "vmp.bin");
        File libDir = new File(workDir, "lib");
        String soFileName = getValidSoFileNameFromSettings(this, this::appendLogOnUi);

        appendLogOnUi("开始处理字节码文件");//将字节码文件写入到so中
        appendLogOnUi("vmp.bin路径：" + vmpBin.getAbsolutePath());
        appendLogOnUi("so文件名：" + soFileName);

        if (!vmpBin.exists()) {
            // VMP未启用或未抽取到方法时，生成空 vmp.bin，避免后续 SO 写入失败
            if (!vmpBin.createNewFile()) {
                throw new RuntimeException("无法创建空 vmp.bin：" + vmpBin.getAbsolutePath());
            }
            appendLogOnUi("VMP 数据为空，已创建空 vmp.bin");
        }
        if (!vmpBin.isFile()) {
            throw new RuntimeException("vmp.bin 不是文件：" + vmpBin.getAbsolutePath());
        }

        if (!libDir.exists() || !libDir.isDirectory()) {
            throw new RuntimeException("lib目录不存在：" + libDir.getAbsolutePath());
        }

        File[] abiDirs = libDir.listFiles();
        if (abiDirs == null || abiDirs.length == 0) {
            throw new RuntimeException("lib目录下没有ABI目录");
        }

        int successCount = 0;

        for (File abiDir : abiDirs) {
            if (abiDir == null || !abiDir.isDirectory()) {
                continue;
            }

            String abi = abiDir.getName();
            File soFile = new File(abiDir, soFileName);

            appendLogOnUi("检查ABI：" + abi);

            if (!soFile.exists() || !soFile.isFile()) {
                appendLogOnUi("未找到so，跳过：" + soFile.getAbsolutePath());
                continue;
            }

            File tmpFile = new File(abiDir, soFileName + ".section.tmp");

            try {
                appendLogOnUi("开始处理so：" + soFile.getAbsolutePath());
                //appendLogOnUi("原始so大小：" + soFile.length());

                writeVmpBinToElfSection(soFile, vmpBin, tmpFile);

                if (!tmpFile.exists() || tmpFile.length() <= 0) {
                    throw new RuntimeException("临时so生成失败");
                }

                if (!soFile.delete()) {
                    throw new RuntimeException("删除旧so失败：" + soFile.getAbsolutePath());
                }

                if (!tmpFile.renameTo(soFile)) {
                    throw new RuntimeException("替换新so失败：" + soFile.getAbsolutePath());
                }

                appendLogOnUi("so写入完成：" + abi);
                //appendLogOnUi("新so大小：" + soFile.length());

                successCount++;

            } catch (Exception e) {
                appendLogOnUi("so写入失败：" + abi + "，原因：" + e.getMessage());

                if (tmpFile.exists()) {
                    tmpFile.delete();
                }

                if (soFile.exists()) {
                    boolean deleted = soFile.delete();
                    appendLogOnUi("已删除未写入成功的so：" + soFile.getAbsolutePath() + "，结果：" + deleted);
                }
            }
        }

        if (successCount <= 0) {
            throw new RuntimeException("没有任何so成功写入");
        }

        appendLogOnUi("so写入全部完成，成功数量：" + successCount);
    }

    private byte[] getSignHash64ForShell() {
        //由于已移除签名校验的c代码，因此这里不能再返回证书信息，否则so层无法解密
        return null;

        /*try {
            ArkSettings settings = readArkSettings(this);

            if (settings == null || !settings.autoSign) {
                appendLogOnUi("未开启自动签名，签名证书绑定值为空");
                return null;
            }

            String sha256;

            if (settings.useCustomJks) {
                appendLogOnUi("使用自定义证书获取指纹");

                if (!isValidJksSettings(
                        settings.jksPath,
                        settings.jksStorePass,
                        settings.jksAlias,
                        settings.jksKeyPass
                )) {
                    return null;
                }

                sha256 = JksSha256Util.getJksSha256FromFile(
                        new File(settings.jksPath),
                        settings.jksStorePass,
                        settings.jksAlias,
                        settings.jksKeyPass,
                        getCacheDir()
                );
            } else {
                appendLogOnUi("使用内置 Ark.jks 获取 指纹");

                sha256 = JksSha256Util.getArkJksSha256(this);
            }

            if (sha256 == null) {
                appendLogOnUi("证书指纹获取失败：结果为空");
                return null;
            }

            sha256 = sha256.trim();
            sha256 = sha256.toLowerCase(java.util.Locale.ROOT);

            if (sha256.length() != 64) {
                appendLogOnUi("证书指纹长度异常：" + sha256.length());
                return null;
            }

            appendLogOnUi("证书指纹获取成功");
            appendLogOnUi("证书指纹：" + sha256);

            return sha256.getBytes("UTF-8");

        } catch (Exception e) {
            appendLogOnUi("证书指纹获取失败：" + e.getMessage());
            return null;
        }*/
    }

    private void installApk(File apkFile) {
        if (apkFile == null || !apkFile.exists()) {
            Toast.makeText(this, "APK文件不存在", Toast.LENGTH_SHORT).show();
            return;
        }

        // Android 8.0+ 需要检查“安装未知应用”权限
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            if (!getPackageManager().canRequestPackageInstalls()) {
                new android.app.AlertDialog.Builder(this)
                        .setTitle("需要安装权限")
                        .setMessage("请先允许本应用安装未知来源应用")
                        .setPositiveButton("去授权", (dialog, which) -> {
                            dialog.dismiss();

                            Intent intent = new Intent(
                                    android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES
                            );
                            intent.setData(android.net.Uri.parse("package:" + getPackageName()));
                            startActivity(intent);
                        })
                        .setNegativeButton("取消", null)
                        .show();
                return;
            }
        }

        doInstallApk(apkFile);
    }

    private void doInstallApk(File apkFile) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        android.net.Uri apkUri;

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            apkUri = androidx.core.content.FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    apkFile
            );
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } else {
            apkUri = android.net.Uri.fromFile(apkFile);
        }

        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
        startActivity(intent);
    }



    // appendLogOnUi is now defined above, delegating to LogManager






    private File rebuildProtectedApk(File apkFile, File workDir, String originalApkName) throws Exception {
        appendLogOnUi("开始重打包 APK");

        File newClassesDex = new File(workDir, "classes.dex");
        File newManifest = new File(workDir, "AndroidManifest.xml");
        File libDir = new File(workDir, "lib");
        File vmpBin = new File(workDir, "vmp.bin");

        if (!newClassesDex.exists()) {
            throw new RuntimeException("未找到新的 classes.dex");
        }

        if (!newManifest.exists()) {
            throw new RuntimeException("未找到修改后的 AndroidManifest.xml");
        }

        Set<String> skipNames = new HashSet<>();

        ZipFile checkZip = new ZipFile(apkFile);
        try {
            for (int i = 1; ; i++) {
                String dexName = i == 1 ? "classes.dex" : "classes" + i + ".dex";
                ZipEntry entry = checkZip.getEntry(dexName);

                if (entry == null) {
                    break;
                }

                skipNames.add(dexName);
            }
        } finally {
            checkZip.close();
        }

        skipNames.add("AndroidManifest.xml");

        if (libDir.exists() && libDir.isDirectory()) {
            collectLibSkipNames(libDir, libDir, skipNames);
        }

        // 如果工作目录中有修改后的assets/或res/raw/，跳过原始APK中的对应条目
        File assetsDir = new File(workDir, "assets");
        File resRawDir = new File(workDir, "res/raw");
        boolean hasModifiedAssets = false;
        if (assetsDir.isDirectory()) {
            collectAssetSkipNames(assetsDir, "assets", skipNames);
            hasModifiedAssets = true;
        }
        if (resRawDir.isDirectory()) {
            collectAssetSkipNames(resRawDir, "res/raw", skipNames);
            hasModifiedAssets = true;
        }
        // assets.key 文件也需要跳过原始版本（如果有）
        File assetsKey = new File(workDir, "assets.key");
        if (assetsKey.exists()) {
            skipNames.add("assets.key");
            hasModifiedAssets = true;
        }

        File outApk = new File(
                getFinalOutputDir(this, workDir, this::appendLogOnUi),
                buildProtectedApkName(originalApkName)
        );

        ZipFile zipFile = new ZipFile(apkFile);
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(outApk));

        try {
            zos.setLevel(9);

            Enumeration<? extends ZipEntry> entries = zipFile.entries();

            while (entries.hasMoreElements()) {
                ZipEntry oldEntry = entries.nextElement();
                String name = oldEntry.getName();
                if (skipNames.contains(name)) {
                    continue;
                }
                if (oldEntry.isDirectory()) {
                    addDirectoryZipEntry(zos, name, oldEntry);
                    continue;
                }
                InputStream in = zipFile.getInputStream(oldEntry);
                addZipEntryStream(this, zos, name, in, oldEntry);
            }

            addZipEntryStream(this, zos, "classes.dex", new FileInputStream(newClassesDex), null);
            appendLogOnUi("已写入新 classes.dex");

            addZipEntryStream(this, zos, "AndroidManifest.xml", new FileInputStream(newManifest), null);
            appendLogOnUi("已写入新 AndroidManifest.xml");

            /*if (!vmpBin.exists()) {
                throw new RuntimeException("未找到 vmp.bin：" + vmpBin.getAbsolutePath());
            }
            addZipEntryStream(this, zos, "assets/vmp.bin", new FileInputStream(vmpBin), null);
            appendLogOnUi("已写入 assets/vmp.bin");*/

            // 写入 DPT 产物到 assets/
            File dptBin = new File(workDir, "dpt_codeitems.bin");
            File dptConfig = new File(workDir, "dpt_config.json");
            File dptFlag = new File(workDir, ".dpt_enabled");
            if (dptFlag.exists() && dptBin.exists()) {
                addZipEntryStream(this, zos, "assets/dpt_codeitems.bin", new FileInputStream(dptBin), null);
                appendLogOnUi("已写入 assets/dpt_codeitems.bin (" + dptBin.length() + " 字节)");
                if (dptConfig.exists()) {
                    addZipEntryStream(this, zos, "assets/dpt_config.json", new FileInputStream(dptConfig), null);
                }
            }

            if (libDir.exists() && libDir.isDirectory()) {
                addLibDirToZipStream(this, zos, libDir, libDir);
            }

            // 写入修改后的assets/和res/raw/
            if (hasModifiedAssets) {
                appendLogOnUi("开始写入修改后的资源文件");
                int assetCount = 0;
                if (assetsDir.isDirectory()) {
                    assetCount += addDirToZipStream(zos, assetsDir, "assets");
                }
                if (resRawDir.isDirectory()) {
                    assetCount += addDirToZipStream(zos, resRawDir, "res/raw");
                }
                // 写入加密密钥文件
                if (assetsKey.exists()) {
                    addZipEntryStream(this, zos, "assets.key", new FileInputStream(assetsKey), null);
                    assetCount++;
                }
                appendLogOnUi("已写入修改后资源: " + assetCount + " 个文件");
            }

            zos.finish();
        } finally {
            try {
                zos.close();
            } catch (Exception ignored) {
            }

            try {
                zipFile.close();
            } catch (Exception ignored) {
            }
        }

        appendLogOnUi("重打包完成：" + outApk.getAbsolutePath());
        return outApk;
    }







    private void extractStubSoByTargetAbi(File apkFile, File workDir) throws Exception {
        appendLogOnUi("开始读取目标 APK ABI");

        //ArrayList<String> assetAbiList = getAssetAbiList();
        ArrayList<String> selfAbiList = getSelfApkStubAbiList();
        if (selfAbiList.isEmpty()) {
            throw new RuntimeException("/lib 下没有可用 ABI");
        }

        //appendLogOnUi("壳内可用 ABI：" + assetAbiList.toString());

        ArrayList<String> targetAbiList = readApkAbiList(apkFile);
        ArrayList<String> finalAbiList = new ArrayList<>();

        if (targetAbiList.isEmpty()) {
            appendLogOnUi("目标 APK 没有 lib 目录，使用 /lib 下全部 ABI");

            for (String abi : selfAbiList) {
                if ("armeabi".equals(abi)) {
                    appendLogOnUi("跳过 armeabi");
                    continue;
                }
                finalAbiList.add(abi);
            }
        } else {
            appendLogOnUi("目标 APK ABI：" + targetAbiList.toString());
            for (String abi : targetAbiList) {
                if ("armeabi".equals(abi)) {
                    appendLogOnUi("跳过目标 armeabi");
                    continue;
                }
                if (!selfAbiList.contains(abi)) {
                    appendLogOnUi("不支持该 ABI，跳过：" + abi);
                    continue;
                }
                finalAbiList.add(abi);
            }
        }
        if (finalAbiList.isEmpty()) {
            throw new RuntimeException("没有匹配到可解压的 ABI");
        }
        for (String abi : finalAbiList) {
            String soFileName = getValidSoFileNameFromSettings(this, this::appendLogOnUi);
            File outFile = new File(workDir, "lib/" + abi + "/" + soFileName);
            File parent = outFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new RuntimeException("创建 so 输出目录失败：" + parent.getAbsolutePath());
            }
            copySelfApkStubSoToFile(abi, outFile);
        }
    }


    private ArrayList<String> getSelfApkStubAbiList() throws Exception {
        ArrayList<String> abiList = new ArrayList<>();

        String selfApkPath = getApplicationInfo().sourceDir;

        ZipFile zipFile = new ZipFile(selfApkPath);
        Enumeration<? extends ZipEntry> entries = zipFile.entries();

        while (entries.hasMoreElements()) {
            ZipEntry entry = entries.nextElement();
            String name = entry.getName();

            if (!name.startsWith("lib/")) {
                continue;
            }

            String[] parts = name.split("/");
            if (parts.length != 3) {
                continue;
            }

            String abi = parts[1];
            String fileName = parts[2];

            if ("armeabi".equals(abi)) {
                continue;
            }

            if (!"libArkStub.so".equals(fileName)) {
                continue;
            }

            if (!abiList.contains(abi)) {
                abiList.add(abi);
            }
        }

        zipFile.close();
        return abiList;
    }
    private void copySelfApkStubSoToFile(String abi, File outFile) throws Exception {
        String selfApkPath = getApplicationInfo().sourceDir;
        String zipPath = "lib/" + abi + "/libArkStub.so";

        ZipFile zipFile = new ZipFile(selfApkPath);
        ZipEntry entry = zipFile.getEntry(zipPath);

        if (entry == null) {
            zipFile.close();
            throw new RuntimeException("自身 APK 中未找到：" + zipPath);
        }

        InputStream in = zipFile.getInputStream(entry);

        File parent = outFile.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            in.close();
            zipFile.close();
            throw new RuntimeException("创建 so 输出目录失败：" + parent.getAbsolutePath());
        }

        FileOutputStream out = new FileOutputStream(outFile);

        byte[] buffer = new byte[8192];
        int len;
        while ((len = in.read(buffer)) != -1) {
            out.write(buffer, 0, len);
        }

        out.flush();
        out.close();
        in.close();
        zipFile.close();
    }

    private File modifyAndroidManifest(File apkFile, File workDir) throws Exception {
        appendLogOnUi("开始处理 AndroidManifest.xml");

        File manifestAxml = new File(workDir, "AndroidManifest_origin.xml");
        File manifestXml = new File(workDir, "AndroidManifest_decode.xml");
        File manifestNewXml = new File(workDir, "AndroidManifest_modify.xml");
        File manifestNewAxml = new File(workDir, "AndroidManifest.xml");

        try {
            ZipFile zipFile = new ZipFile(apkFile);
            ZipEntry entry = zipFile.getEntry("AndroidManifest.xml");

            if (entry == null) {
                zipFile.close();
                throw new RuntimeException("APK 中未找到 AndroidManifest.xml");
            }

            InputStream in = zipFile.getInputStream(entry);
            FileOutputStream out = new FileOutputStream(manifestAxml);

            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) != -1) {
                out.write(buffer, 0, len);
            }

            out.flush();
            out.close();
            in.close();
            zipFile.close();

            appendLogOnUi("已提取 AndroidManifest.xml");

            Xml2AxmlTool.decode(
                    manifestAxml.getAbsolutePath(),
                    manifestXml.getAbsolutePath()
            );

            //appendLogOnUi("Manifest 反编译完成");

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);

            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(manifestXml);

            Element manifest = document.getDocumentElement();
            if (manifest == null || !"manifest".equals(manifest.getNodeName())) {
                throw new RuntimeException("Manifest XML 结构异常");
            }

            Element application = null;
            for (int i = 0; i < manifest.getChildNodes().getLength(); i++) {
                if (manifest.getChildNodes().item(i) instanceof Element) {
                    Element item = (Element) manifest.getChildNodes().item(i);
                    if ("application".equals(item.getNodeName())) {
                        application = item;
                        break;
                    }
                }
            }
            if (application == null) {
                throw new RuntimeException("Manifest 中未找到 application 标签");
            }
            rewriteApplicationAttributes(this, application);
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
            transformer.transform(
                    new DOMSource(document),
                    new StreamResult(manifestNewXml)
            );
            Xml2AxmlTool.encode2(
                    this,
                    manifestNewXml.getAbsolutePath(),
                    manifestNewAxml.getAbsolutePath()
            );
            return manifestNewAxml;
        } finally {
            deleteFileQuietly(manifestAxml);
            deleteFileQuietly(manifestXml);
            deleteFileQuietly(manifestNewXml);
        }
    }

}
