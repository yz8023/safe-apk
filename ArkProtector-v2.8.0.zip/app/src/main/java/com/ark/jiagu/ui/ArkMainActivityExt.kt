package com.ark.jiagu.ui

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable

/**
 * 供 Java 代码调用的 Compose UI 入口。
 */
fun ComponentActivity.setArkContent(
    uiState: ArkUiState,
    onSelectApk: Runnable,
    onStart: Runnable,
    onClearLog: Runnable,
    onOpenSettings: Runnable,
    onOpenAbout: Runnable
) {
    setContent {
        ArkApp(
            state = uiState,
            onSelectApk = { onSelectApk.run() },
            onStart = { onStart.run() },
            onClearLog = { onClearLog.run() },
            onOpenSettings = { onOpenSettings.run() },
            onOpenAbout = { onOpenAbout.run() }
        )
    }
}
