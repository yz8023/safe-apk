package com.ark.jiagu.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * 承载 ArkMainActivity 的 Compose UI 状态。
 *
 * 日志使用 [LogEntry] 列表 + LazyColumn，避免大字符串重排导致的卡顿。
 */
class ArkUiState {
    companion object {
        // 降低上限以避免 Compose semantics 系统在大量条目下 OOM。
        // 配合 clearAndSetSemantics，已经基本不会触发 semantics 遍历，
        // 这里仍然设置上限防止 SnapshotStateList 无限增长。
        const val MAX_LOG_ENTRIES = 200
        // 批量丢弃阈值：达到上限时一次性移除前 40%，避免频繁 removeAt(0)
        private const val TRIM_COUNT = MAX_LOG_ENTRIES / 5 * 2
    }

    var isProcessing by mutableStateOf(false)

    var selectedApkPath by mutableStateOf("")

    // 使用 SnapshotStateList，Compose 能高效感知增量变化
    val logEntries = mutableStateListOf<LogEntry>()

    // 当前选中的底部导航页：0=Home, 1=Logs, 2=Settings
    var selectedPage by mutableIntStateOf(0)

    // 控制日志页是否自动滚动到底部
    var autoScroll by mutableStateOf(true)

    fun updateProcessing(value: Boolean) {
        isProcessing = value
    }

    fun updateApkPath(path: String) {
        selectedApkPath = path
    }

    fun appendLog(entry: LogEntry) {
        if (logEntries.size >= MAX_LOG_ENTRIES) {
            // 批量丢弃前 40%，避免每次添加都 removeFirst
            repeat(TRIM_COUNT) { logEntries.removeAt(0) }
        }
        logEntries.add(entry)
    }

    fun appendLogs(entries: List<LogEntry>) {
        if (entries.isEmpty()) return
        val overflow = logEntries.size + entries.size - MAX_LOG_ENTRIES
        if (overflow > 0) {
            val removeCount = minOf(logEntries.size, maxOf(overflow, TRIM_COUNT))
            repeat(removeCount) { if (logEntries.isNotEmpty()) logEntries.removeAt(0) }
        }
        // 单次 addAll 控制在 50 条以内，避免单次重组压力过大
        if (entries.size <= 50) {
            logEntries.addAll(entries)
        } else {
            // 大批量时分段加入，每段 50 条
            var i = 0
            while (i < entries.size) {
                val end = minOf(i + 50, entries.size)
                logEntries.addAll(entries.subList(i, end))
                i = end
            }
        }
    }

    fun clearLog() {
        logEntries.clear()
    }
}
