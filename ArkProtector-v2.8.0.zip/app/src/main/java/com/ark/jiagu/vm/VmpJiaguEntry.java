package com.ark.jiagu.vm;

import static com.ark.jiagu.vm.VmpUtils.*;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import com.android.tools.smali.dexlib2.AccessFlags;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.MethodImplementation;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.DexFileFactory;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
public class VmpJiaguEntry {


    /**
     * :TODO
     * 解压 APK 中的 AndroidManifest.xml 和连续合法 dex 文件。
     * 合法 dex：
     * classes.dex
     * classes2.dex
     * classes3.dex
     * ...
     * 如果中间断号，例如没有 classes4.dex，则停止继续解压。
     */
    public static void extractManifestAndDex(File apkFile, File outDir) throws IOException {
        if (apkFile == null || !apkFile.isFile()) {
            throw new IOException("APK文件不存在");
        }

        if (outDir == null) {
            throw new IOException("输出目录为空");
        }

        if (!outDir.exists() && !outDir.mkdirs()) {
            throw new IOException("创建输出目录失败：" + outDir.getAbsolutePath());
        }

        try (ZipFile zipFile = new ZipFile(apkFile)) {
            VMPextractEntry(zipFile, "AndroidManifest.xml", new File(outDir, "AndroidManifest.xml"));

            int index = 1;
            while (true) {
                String dexName = index == 1 ? "classes.dex" : "classes" + index + ".dex";
                ZipEntry dexEntry = zipFile.getEntry(dexName);

                if (dexEntry == null) {
                    break;
                }

                VMPextractEntry(zipFile, dexName, new File(outDir, dexName));
                index++;
            }
        }
    }


    //----------------------------------------------------------------------------------------------------------






    private static void vmpLog(LogCallback callback, String msg) {
        if (callback != null) {
            callback.log(msg);
        }
        // Removed System.out.println to reduce I/O overhead
        // Logcat output is suppressed to prevent performance issues
    }
    public interface LogCallback {
        void log(String msg);
    }
    public static void extractMethodsToBin(File dexDir, String... methodRules) throws IOException {
        extractMethodsToBin(dexDir, null, methodRules);
    }

    /**
     * :TODO
     * 抽取方法到bin
     * */
    public static void extractMethodsToBin(File dexDir, LogCallback logCallback, String... methodRules) throws IOException {
        if (dexDir == null || !dexDir.isDirectory()) {
            throw new IOException("dex目录不存在");
        }

        EXTRACTED_METHOD_MAP.clear();

        List<MethodRule> rules = parseMethodRules(methodRules);
        if (rules.isEmpty()) {
            throw new IOException("抽取规则为空");
        }

        List<ExtractMethodBlock> blocks = new ArrayList<>();

        int nextMethodId = 1;
        int dexIndex = 1;

        while (true) {
            String dexName = dexIndex == 1 ? "classes.dex" : "classes" + dexIndex + ".dex";
            File dexFile = new File(dexDir, dexName);

            if (!dexFile.isFile()) {
                Log.d("VmpJiagu", "dex编号断开，停止扫描：" + dexName);
                break;
            }

            if (!isValidDexFile(dexFile)) {
                vmpLog(logCallback, "跳过非法dex文件：" + dexFile.getAbsolutePath());
                break;
            }

            DexBackedDexFile dex;
            try {
                dex = DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());
            } catch (Throwable e) {
                Log.d("VmpJiagu", "解析dex失败，停止扫描：" + dexFile.getName());
                Log.d("VmpJiagu", "失败原因：" + e.getMessage());
                break;
            }

            for (ClassDef classDef : dex.getClasses()) {
                String javaClassName = dexTypeToJavaName(classDef.getType());

                for (Method method : classDef.getMethods()) {
                    if (!matchAnyRule(rules, javaClassName, method.getName())) {
                        continue;
                    }

                    if (isForbiddenExtractMethod(method)) {
                        continue;
                    }

                    MethodImplementation impl = method.getImplementation();
                    if (impl == null) {
                        continue;
                    }

                    if (hasUnsupportedInvokeDynamicInstruction(impl)) {
                        continue;
                    }

                    ExtractMethodBlock block = new ExtractMethodBlock();

                    block.methodId = nextMethodId++;
                    block.dexName = dexFile.getName();
                    block.className = classDef.getType();
                    block.methodName = method.getName();
                    block.methodSignature = buildMethodSignature(method);
                    block.accessFlags = method.getAccessFlags();
                    block.registerCount = impl.getRegisterCount();
                    block.paramCount = method.getParameters().size();
                    block.returnType = method.getReturnType();
                    block.isStatic = (method.getAccessFlags() & AccessFlags.STATIC.getValue()) != 0;

                    block.parameterTypes = new ArrayList<>();
                    for (CharSequence paramType : method.getParameterTypes()) {
                        block.parameterTypes.add(String.valueOf(paramType));
                    }

                    int codeUnitOffset = 0;
                    for (Instruction instruction : impl.getInstructions()) {
                        block.instructions.add(buildExtractInstruction(
                                instruction,
                                codeUnitOffset
                        ));

                        codeUnitOffset += instruction.getCodeUnits();
                    }

                    block.tryBlocks = buildExtractTryBlocks(impl);

                    blocks.add(block);
                    recordExtractedMethod(block);

                    vmpLog(logCallback, "已抽取 methodId=" + block.methodId
                            + " dex=" + block.dexName);
                }
            }

            dexIndex++;
        }

        File plainBinFile = new File(dexDir, "vmp_plain.bin");
        File binFile = new File(dexDir, "vmp.bin");
        File txtFile = new File(dexDir, "vmp.txt");

        List<ClassIndexEntry> indexEntries = writeVmpBinary(plainBinFile, blocks);
        xorEncryptVmpBinFile(plainBinFile, binFile);
        writeVmpText(txtFile, indexEntries, blocks);

        if (plainBinFile.exists()) {
            plainBinFile.delete();
        }

        vmpLog(logCallback, "抽取完成，总数量=" + blocks.size());
        vmpLog(logCallback, "方法索引表数量=" + indexEntries.size());
    }

    /**
     * :TODO
     * 重组dex
     * */
    public static void rewriteExtractedMethodsToVmCallDex(File dexDir,
                                                          LogCallback logCallback,
                                                          String soName,
                                                          String vmCallClassName) throws IOException {
        if (dexDir == null || !dexDir.isDirectory()) {
            throw new IOException("dex目录不存在");
        }

        if (EXTRACTED_METHOD_MAP.isEmpty()) {
            vmpLog(logCallback, "[跳过] VMP未抽取到任何方法，可能原因：");
            vmpLog(logCallback, "  - 被保护APK中无匹配抽取规则的方法");
            vmpLog(logCallback, "  - 所有方法已被DEX混淆阶段处理");
            vmpLog(logCallback, "  - 跳过dex重写，继续执行后续dex加密");
            // 生成空 vmp.bin，确保后续 SO 注入步骤不会失败
            File emptyBin = new File(dexDir, "vmp.bin");
            if (!emptyBin.exists()) {
                try (FileOutputStream fos = new FileOutputStream(emptyBin)) {
                    // 写入 0 字节
                }
            }
            return;
        }

        if (vmCallClassName == null || vmCallClassName.trim().isEmpty()) {
            throw new IOException("VM调用类名为空");
        }

        String vmpClassType = "L" + vmCallClassName.trim().replace('.', '/') + ";";

        int dexIndex = 1;
        int rewriteCount = 0;

        while (true) {
            String dexName = dexIndex == 1 ? "classes.dex" : "classes" + dexIndex + ".dex";
            File dexFile = new File(dexDir, dexName);

            if (!dexFile.isFile()) {
                Log.d("VmpJiagu", "dex编号断开，停止重写：" + dexName);
                break;
            }

            if (!isValidDexFile(dexFile)) {
                Log.d("VmpJiagu", "跳过非法dex文件：" + dexFile.getAbsolutePath());
                dexIndex++;
                continue;
            }

            if (!hasExtractedMethodInDex(dexName)) {
                Log.d("VmpJiagu", "当前dex没有VMP抽取方法，原样保留：" + dexName);
                vmpLog(logCallback, "当前dex没有VMP抽取方法，原样保留：" + dexName);
                dexIndex++;
                continue;
            }

            DexBackedDexFile dex;
            try {
                dex = DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());
            } catch (Throwable e) {
                Log.d("VmpJiagu", "解析dex失败，跳过重写：" + dexFile.getName());
                Log.d("VmpJiagu", "失败原因：" + e.getMessage());
                vmpLog(logCallback, "解析dex失败，跳过重写：" + dexFile.getName());
                vmpLog(logCallback, "失败原因：" + e.getMessage());
                dexIndex++;
                continue;
            }

            Log.d("VmpJiagu", "开始流式重写dex：" + dexFile.getName());
            vmpLog(logCallback, "开始重写dex：" + dexFile.getName());

            writeCombinedDexStreaming(
                    dexDir,
                    dexIndex,
                    dexName,
                    dex,
                    vmpClassType
            );

            dex = null;
            System.gc();

            rewriteCount++;
            dexIndex++;
        }

        replaceOriginalDexWithCombinedDexKeepOriginal(dexDir);

        vmpLog(logCallback, "VM调用壳重写完成，VM调用类=" + vmpClassType
                + "，实际重写dex数量=" + rewriteCount);

        Log.d("VmpJiagu", "VM调用壳重写完成，VM调用类=" + vmpClassType
                + "，实际重写dex数量=" + rewriteCount);
    }
    static boolean hasExtractedMethodInDex(String dexName) {
        if (dexName == null || EXTRACTED_METHOD_MAP.isEmpty()) {
            return false;
        }

        String prefix = dexName + "|";

        for (String key : EXTRACTED_METHOD_MAP.keySet()) {
            if (key != null && key.startsWith(prefix)) {
                return true;
            }
        }

        return false;
    }
    static void replaceOriginalDexWithCombinedDexKeepOriginal(File dexDir) throws IOException {
        if (dexDir == null || !dexDir.isDirectory()) {
            throw new IOException("dex目录不存在");
        }

        int index = 1;

        while (true) {
            String finalName = index == 1 ? "classes.dex" : "classes" + index + ".dex";
            String tempName = index == 1 ? "classes_c.dex" : "classes" + index + "_c.dex";

            File finalDex = new File(dexDir, finalName);
            File tempDex = new File(dexDir, tempName);

            if (!finalDex.exists() && !tempDex.exists()) {
                break;
            }

            if (tempDex.exists()) {
                if (finalDex.exists() && !finalDex.delete()) {
                    throw new IOException("删除原始dex失败：" + finalDex.getAbsolutePath());
                }

                if (!tempDex.renameTo(finalDex)) {
                    throw new IOException("重命名dex失败："
                            + tempDex.getAbsolutePath()
                            + " -> "
                            + finalDex.getAbsolutePath());
                }

                Log.d("VmpJiagu", "已替换重写dex：" + finalName);
            } else {
                Log.d("VmpJiagu", "未重写dex，原样保留：" + finalName);
            }

            index++;
        }
    }

    /**
     * :TODO
     * 解析bin文件以校验读取是否正常
     * */
    public static void parseVmpBinByMethodId(File binFile, int targetMethodId) throws IOException {
        if (binFile == null || !binFile.isFile()) {
            throw new IOException("bin文件不存在");
        }

        long startNs = System.nanoTime();

        try (RandomAccessFile raf = new RandomAccessFile(binFile, "r")) {
            byte[] magic = new byte[4];
            readFully(raf, magic);

            String magicText = new String(magic, StandardCharsets.UTF_8);
            Log.d("VmpJiagu", "magic=" + magicText);

            if (!"AVMP".equals(magicText)) {
                throw new IOException("bin格式错误，magic不匹配");
            }

            int version = readIntLE(raf);
            Log.d("VmpJiagu", "version=" + version);

            if (version != 5) {
                throw new IOException("当前解析器只支持version=5，当前version=" + version);
            }

            int opcodeMapCount = readIntLE(raf);
            Log.d("VmpJiagu", "opcodeMapCount=" + opcodeMapCount);

            Map<Integer, OpcodeMapEntry> vmOpcodeMap = new LinkedHashMap<>();

            Log.d("VmpJiagu", "========== 解析opcode映射表 ==========");
            for (int i = 0; i < opcodeMapCount; i++) {
                int vmOpcode = readIntLE(raf);
                int realOpcode = readIntLE(raf);
                String realOpcodeName = readStringLE(raf);

                OpcodeMapEntry entry = new OpcodeMapEntry();
                entry.vmOpcode = vmOpcode;
                entry.realOpcode = realOpcode;
                entry.realOpcodeName = realOpcodeName;

                vmOpcodeMap.put(vmOpcode, entry);

                Log.d("VmpJiagu", "map[" + i + "] vmOpcode=0x"
                        + String.format("%02x", vmOpcode)
                        + " -> realOpcode=0x" + Integer.toHexString(realOpcode)
                        + " -> realOpcodeName=" + realOpcodeName);
            }

            int methodIndexCount = readIntLE(raf);
            long indexTableOffset = raf.getFilePointer();

            Log.d("VmpJiagu", "========== 解析methodId索引表 ==========");
            Log.d("VmpJiagu", "methodIndexCount=" + methodIndexCount);
            Log.d("VmpJiagu", "indexTableOffset=" + indexTableOffset);

            ClassIndexEntry targetIndex = null;

            for (int i = 0; i < methodIndexCount; i++) {
                ClassIndexEntry index = new ClassIndexEntry();
                index.methodId = readIntLE(raf);
                index.offset = readLongLE(raf);
                index.size = readIntLE(raf);

                Log.d("VmpJiagu", "index[" + i + "] methodId=" + index.methodId
                        + " offset=" + index.offset
                        + " size=" + index.size);

                if (index.methodId == targetMethodId) {
                    targetIndex = index;
                }
            }

            if (targetIndex == null) {
                long endNs = System.nanoTime();
                Log.d("VmpJiagu", "未找到目标methodId：" + targetMethodId);
                Log.d("VmpJiagu", "解析耗时=" + ((endNs - startNs) / 1000000.0) + " ms");
                return;
            }

            Log.d("VmpJiagu", "========================================");
            Log.d("VmpJiagu", "命中目标索引");
            Log.d("VmpJiagu", "targetMethodId=" + targetMethodId);
            Log.d("VmpJiagu", "blockOffset=" + targetIndex.offset);
            Log.d("VmpJiagu", "blockSize=" + targetIndex.size);
            Log.d("VmpJiagu", "开始seek到数据块地址：" + targetIndex.offset);

            raf.seek(targetIndex.offset);

            long blockStartPos = raf.getFilePointer();

            int methodId = readIntLE(raf);
            String dexName = readStringLE(raf);
            String className = readStringLE(raf);
            String methodName = readStringLE(raf);
            String methodSignature = readStringLE(raf);
            int accessFlags = readIntLE(raf);
            int registerCount = readIntLE(raf);
            int paramCount = readIntLE(raf);
            String returnType = readStringLE(raf);
            int isStaticValue = readIntLE(raf);

            int parameterTypeCount = readIntLE(raf);
            List<String> parameterTypes = new ArrayList<>();
            for (int i = 0; i < parameterTypeCount; i++) {
                parameterTypes.add(readStringLE(raf));
            }

            int instructionCount = readIntLE(raf);

            Log.d("VmpJiagu", "========================================");
            Log.d("VmpJiagu", "开始解析目标方法数据块");
            Log.d("VmpJiagu", "blockStartPos=" + blockStartPos);
            Log.d("VmpJiagu", "methodId=" + methodId);
            Log.d("VmpJiagu", "dexName=" + dexName);
            Log.d("VmpJiagu", "className=" + className);
            Log.d("VmpJiagu", "methodName=" + methodName);
            Log.d("VmpJiagu", "methodSignature=" + methodSignature);
            Log.d("VmpJiagu", "accessFlags=0x" + Integer.toHexString(accessFlags));
            Log.d("VmpJiagu", "registerCount=" + registerCount);
            Log.d("VmpJiagu", "paramCount=" + paramCount);
            Log.d("VmpJiagu", "returnType=" + returnType);
            Log.d("VmpJiagu", "isStatic=" + (isStaticValue != 0));
            Log.d("VmpJiagu", "parameterTypes=" + parameterTypes);
            Log.d("VmpJiagu", "instructionCount=" + instructionCount);

            for (int insnIndex = 0; insnIndex < instructionCount; insnIndex++) {
                long insnOffset = raf.getFilePointer();

                int codeUnitOffset = readIntLE(raf);
                int vmOpcode = readIntLE(raf);
                String formatName = readStringLE(raf);
                int codeUnits = readIntLE(raf);

                int regCount = readIntLE(raf);
                List<Integer> registers = new ArrayList<>();
                for (int i = 0; i < regCount; i++) {
                    registers.add(readIntLE(raf));
                }

                int literalType = readIntLE(raf);
                long literalValue = readLongLE(raf);

                int offsetType = readIntLE(raf);
                int offsetValue = readIntLE(raf);

                int referenceType = readIntLE(raf);
                String referenceData = readStringLE(raf);
                int extraReferenceType = readIntLE(raf);
                String extraReferenceData = readStringLE(raf);
                OpcodeMapEntry opcodeEntry = vmOpcodeMap.get(vmOpcode);

                Log.d("VmpJiagu", "");
                Log.d("VmpJiagu", "  instruction[" + insnIndex + "]");
                Log.d("VmpJiagu", "    insnOffset=" + insnOffset);
                Log.d("VmpJiagu", "    vmOpcode=0x" + String.format("%02x", vmOpcode));

                if (opcodeEntry != null) {
                    Log.d("VmpJiagu", "    mapRealOpcode=0x" + Integer.toHexString(opcodeEntry.realOpcode));
                    Log.d("VmpJiagu", "    mapRealOpcodeName=" + opcodeEntry.realOpcodeName);
                } else {
                    Log.d("VmpJiagu", "    mapRealOpcode=未找到");
                    Log.d("VmpJiagu", "    mapRealOpcodeName=未找到");
                }

                Log.d("VmpJiagu", "    codeUnitOffset=" + codeUnitOffset);
                Log.d("VmpJiagu", "    formatName=" + formatName);
                Log.d("VmpJiagu", "    codeUnits=" + codeUnits);
                Log.d("VmpJiagu", "    registerCount=" + regCount);
                Log.d("VmpJiagu", "    registers=" + registers);
                Log.d("VmpJiagu", "    literalType=" + literalType);
                Log.d("VmpJiagu", "    literalValue=" + literalValue);
                Log.d("VmpJiagu", "    offsetType=" + offsetType);
                Log.d("VmpJiagu", "    offsetValue=" + offsetValue);
                Log.d("VmpJiagu", "    referenceType=" + referenceType);
                Log.d("VmpJiagu", "    referenceData=" + referenceData);
                Log.d("VmpJiagu", "    extraReferenceType=" + extraReferenceType);
                Log.d("VmpJiagu", "    extraReferenceData=" + extraReferenceData);
            }

            int tryBlockCount = readIntLE(raf);

            Log.d("VmpJiagu", "");
            Log.d("VmpJiagu", "tryBlockCount=" + tryBlockCount);

            for (int i = 0; i < tryBlockCount; i++) {
                int startCodeAddress = readIntLE(raf);
                int codeUnitCount = readIntLE(raf);
                int handlerCount = readIntLE(raf);

                Log.d("VmpJiagu", "  tryBlock[" + i + "]");
                Log.d("VmpJiagu", "    startCodeAddress=" + startCodeAddress);
                Log.d("VmpJiagu", "    codeUnitCount=" + codeUnitCount);
                Log.d("VmpJiagu", "    handlerCount=" + handlerCount);

                for (int h = 0; h < handlerCount; h++) {
                    String exceptionType = readStringLE(raf);
                    int handlerCodeAddress = readIntLE(raf);

                    Log.d("VmpJiagu", "      handler[" + h + "]");
                    Log.d("VmpJiagu", "        exceptionType=" + exceptionType);
                    Log.d("VmpJiagu", "        handlerCodeAddress=" + handlerCodeAddress);
                }
            }

            long blockEndPos = raf.getFilePointer();
            long parsedSize = blockEndPos - blockStartPos;

            Log.d("VmpJiagu", "========================================");
            Log.d("VmpJiagu", "目标methodId解析完成：" + targetMethodId);
            Log.d("VmpJiagu", "blockEndPos=" + blockEndPos);
            Log.d("VmpJiagu", "parsedBlockSize=" + parsedSize);
            Log.d("VmpJiagu", "indexBlockSize=" + targetIndex.size);

            if (parsedSize != targetIndex.size) {
                Log.d("VmpJiagu", "警告：解析出来的数据块大小和索引表记录不一致");
            }

            long endNs = System.nanoTime();
            Log.d("VmpJiagu", "解析耗时=" + ((endNs - startNs) / 1000000.0) + " ms");
        }
    }

}