package com.ark.jiagu;

/**
 * 扩展的设置管理器，包含所有新功能的设置键
 */
public class ExtendedArkSettingsManager {
    
    // 资源保护类功能
    public static final String KEY_RESOURCE_OBFUSCATION = "resource_obfuscation";
    public static final String KEY_RESOURCE_COMPRESSION = "resource_compression";
    public static final String KEY_ASSET_ENCRYPTION = "asset_encryption";
    
    // 代码保护类功能
    public static final String KEY_DEX_ENCRYPTION = "dex_encryption";
    public static final String KEY_STRING_ENCRYPTION = "string_encryption";
    public static final String KEY_JUNK_CODE_GENERATION = "junk_code_generation";
    
    // 签名验证类功能
    public static final String KEY_SIGNATURE_BYPASS = "signature_bypass";
    
    // 反调试/反注入类功能
    public static final String KEY_FRIDA_PIPE_DETECTION = "frida_pipe_detection";
    public static final String KEY_FRIDA_THREAD_DETECTION = "frida_thread_detection";
    public static final String KEY_MEM_DISK_COMPARISON = "mem_disk_comparison";
    
    // 虚拟化技术类功能
    public static final String KEY_APP_MULTI_OPEN = "app_multi_open";
    public static final String KEY_JAVA_HOOK = "java_hook";
    public static final String KEY_NATIVE_HOOK = "native_hook";
    public static final String KEY_LOCATION_SIMULATION = "location_simulation";
    public static final String KEY_DEVICE_MODIFICATION = "device_modification";
    
    // 加壳技术类功能
    public static final String KEY_DEX_STRING_DECRYPTION = "dex_string_decryption";
    public static final String KEY_REFLECTION_CLINIT_INJECTION = "reflection_clinit_injection";
    public static final String KEY_PROTECT_RULES = "protect_rules";
    
    // 混淆技术类功能
    public static final String KEY_PROGUARD_OBFUSCATION = "proguard_obfuscation";
    public static final String KEY_PROGUARD_OPTIMIZATION = "proguard_optimization";
    public static final String KEY_CONTROL_FLOW_OBFUSCATION = "control_flow_obfuscation";
    
    // Obfuscapk混淆技术
    public static final String KEY_ADVANCED_REFLECTION = "advanced_reflection";
    public static final String KEY_ARITHMETIC_BRANCH = "arithmetic_branch";
    public static final String KEY_CALL_INDIRECTION = "call_indirection";
    public static final String KEY_CLASS_RENAME = "class_rename";
    public static final String KEY_CONST_STRING_ENCRYPTION = "const_string_encryption";
    public static final String KEY_DEBUG_REMOVAL = "debug_removal";
    public static final String KEY_FIELD_RENAME = "field_rename";
    public static final String KEY_GOTO_INSERTION = "goto_insertion";
    public static final String KEY_LIB_ENCRYPTION = "lib_encryption";
    public static final String KEY_METHOD_OVERLOAD = "method_overload";
    
    // 冲突检测配置
    public static final String KEY_CONFLICT_DETECTION_ENABLED = "conflict_detection_enabled";

    // ===== 新增：环境检测类功能 =====
    public static final String KEY_ANTI_EMULATOR = "anti_emulator";
    public static final String KEY_ANTI_ROOT = "anti_root";
    public static final String KEY_ANTI_DEBUGGER = "anti_debugger";
    public static final String KEY_ANTI_XPOSED = "anti_xposed";
    public static final String KEY_APK_INTEGRITY_CHECK = "apk_integrity_check";

    // ===== 新增：高级混淆类功能 =====
    public static final String KEY_DEX_HEADER_OBFUSCATION = "dex_header_obfuscation";
    public static final String KEY_SO_NAME_RANDOMIZATION = "so_name_randomization";
    public static final String KEY_ARITHMETIC_OBFUSCATION = "arithmetic_obfuscation";
    public static final String KEY_MULTI_DEX_SHUFFLE = "multi_dex_shuffle";
    public static final String KEY_ANTI_VM = "anti_vm";

    // ===== 类名过滤设置（用于字段重命名/类重命名时排除常见类） =====
    /** 0=全部处理, 1=排除常见类, 2=指定DEX */
    public static final String KEY_CLASS_FILTER_MODE = "class_filter_mode";
    /** 自定义排除的类名前缀，逗号分隔 */
    public static final String KEY_EXCLUDED_CLASS_PREFIXES = "excluded_class_prefixes";
    /** 排除常见类开关 */
    public static final String KEY_EXCLUDE_COMMON_CLASSES = "exclude_common_classes";
    
    /**
     * 检查功能冲突
     * 注意：VMP与DEX加密不再冲突，因为新的管线顺序（混淆→VMP→加密）
     * 中，DEX加密只加密壳DEX，VMP处理原始DEX，两者操作目标不同。
     */
    public static boolean hasConflict(String feature1, String feature2) {
        // 签名校验与签名绕过冲突
        if ((feature1.equals(KEY_SIGNATURE_BYPASS) && feature2.equals(ArkSettingsManager.KEY_AUTO_SIGN)) ||
            (feature1.equals(ArkSettingsManager.KEY_AUTO_SIGN) && feature2.equals(KEY_SIGNATURE_BYPASS))) {
            return true;
        }
        
        // 资源操作冲突
        if ((feature1.equals(KEY_RESOURCE_OBFUSCATION) && feature2.equals(KEY_ASSET_ENCRYPTION)) ||
            (feature1.equals(KEY_ASSET_ENCRYPTION) && feature2.equals(KEY_RESOURCE_OBFUSCATION))) {
            return true;
        }
        
        // VMP抽代码与DEX加密：不再冲突
        // 新管线中DEX加密在VMP之后执行，只加密壳DEX
        
        return false;
    }
    
    /**
     * 获取功能分类
     */
    public static String getFeatureCategory(String featureKey) {
        if (featureKey.startsWith("resource_") || featureKey.equals(KEY_ASSET_ENCRYPTION)) {
            return "resource_protection";
        } else if (featureKey.startsWith("dex_") || featureKey.startsWith("string_") || 
                   featureKey.startsWith("junk_") || featureKey.startsWith("proguard_") ||
                   featureKey.startsWith("control_flow_") || featureKey.startsWith("advanced_") ||
                   featureKey.startsWith("arithmetic_") || featureKey.startsWith("call_") ||
                   featureKey.startsWith("class_") || featureKey.startsWith("const_") ||
                   featureKey.startsWith("debug_") || featureKey.startsWith("field_") ||
                   featureKey.startsWith("goto_") || featureKey.startsWith("lib_") ||
                   featureKey.startsWith("method_")) {
            return "code_protection";
        } else if (featureKey.startsWith("signature_")) {
            return "signature_verification";
        } else if (featureKey.startsWith("frida_") || featureKey.startsWith("mem_")) {
            return "anti_debug";
        } else if (featureKey.startsWith("app_") || featureKey.startsWith("java_") ||
                   featureKey.startsWith("native_") || featureKey.startsWith("location_") ||
                   featureKey.startsWith("device_")) {
            return "virtualization";
        } else if (featureKey.startsWith("dex_string_") || featureKey.startsWith("reflection_") ||
                   featureKey.startsWith("protect_")) {
            return "shell_technology";
        }
        return "other";
    }
}