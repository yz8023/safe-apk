package com.ark.jiagu;

import android.content.Context;
import android.content.res.AssetManager;

import java.io.*;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

/**
 * Runtime resource decryptor utilities for ARKE (XOR encrypted) and
 * ARKC (deflate compressed) assets produced by ResourceProtector.
 *
 * <p>AssetManager is final and cannot be reliably wrapped in Java on all
 * Android versions. Therefore this class provides the decrypt/decompress
 * primitives; the actual interception is best done in the native shell
 * (hooking AAssetManager). For Java-level fallback, callers can use
 * {@link #openDecryptedAsset(AssetManager, String)}.</p>
 */
public class ArkResourceDecryptor {

    private static final byte[] MAGIC_ENCRYPTED = new byte[] { 'A', 'R', 'K', 'E' };
    private static final byte[] MAGIC_COMPRESSED = new byte[] { 'A', 'R', 'K', 'C' };

    private static volatile byte[] sAssetKey = null;
    private static volatile boolean sKeyLoaded = false;

    /**
     * Load the XOR key from assets/assets.key.
     */
    public static synchronized void loadKey(Context context) {
        if (sKeyLoaded) return;
        sKeyLoaded = true;
        try {
            InputStream is = context.getAssets().open("assets.key");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[1024];
            int len;
            while ((len = is.read(buf)) != -1) {
                baos.write(buf, 0, len);
            }
            is.close();
            sAssetKey = baos.toByteArray();
        } catch (IOException e) {
            sAssetKey = null;
        }
    }

    /**
     * Open an asset and transparently decrypt/decompress it if needed.
     * This is a Java-level fallback; it reads the whole asset into memory.
     */
    public static InputStream openDecryptedAsset(AssetManager assets, String fileName) throws IOException {
        loadKeyIfNeeded(null);
        InputStream is = assets.open(fileName);
        byte[] data = readAll(is);
        byte[] processed = processAssetData(data);
        return new ByteArrayInputStream(processed);
    }

    private static void loadKeyIfNeeded(Context context) {
        if (!sKeyLoaded && context != null) {
            loadKey(context);
        }
    }

    /**
     * Decrypt/decompress asset data if it has ARKE/ARKC magic header.
     */
    public static byte[] processAssetData(byte[] data) {
        if (data == null || data.length < 4) return data;

        if (matchesMagic(data, MAGIC_ENCRYPTED)) {
            if (sAssetKey == null) return data;
            byte[] encrypted = new byte[data.length - 4];
            System.arraycopy(data, 4, encrypted, 0, encrypted.length);
            byte[] decrypted = new byte[encrypted.length];
            for (int i = 0; i < encrypted.length; i++) {
                decrypted[i] = (byte) (encrypted[i] ^ sAssetKey[i % sAssetKey.length]);
            }
            return decrypted;
        }

        if (matchesMagic(data, MAGIC_COMPRESSED)) {
            byte[] compressed = new byte[data.length - 4];
            System.arraycopy(data, 4, compressed, 0, compressed.length);
            return decompressData(compressed);
        }

        return data;
    }

    private static boolean matchesMagic(byte[] data, byte[] magic) {
        for (int i = 0; i < magic.length; i++) {
            if (i >= data.length || data[i] != magic[i]) return false;
        }
        return true;
    }

    private static byte[] decompressData(byte[] compressed) {
        Inflater inflater = new Inflater();
        inflater.setInput(compressed);
        ByteArrayOutputStream baos = new ByteArrayOutputStream(compressed.length * 2);
        byte[] buf = new byte[8192];
        try {
            while (!inflater.finished()) {
                int count = inflater.inflate(buf);
                if (count <= 0) break;
                baos.write(buf, 0, count);
            }
        } catch (DataFormatException e) {
            return compressed;
        } finally {
            inflater.end();
        }
        return baos.toByteArray();
    }

    private static byte[] readAll(InputStream is) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int len;
        while ((len = is.read(buf)) != -1) {
            baos.write(buf, 0, len);
        }
        is.close();
        return baos.toByteArray();
    }
}
