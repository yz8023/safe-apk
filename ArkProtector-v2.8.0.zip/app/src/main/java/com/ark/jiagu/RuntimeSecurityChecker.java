package com.ark.jiagu;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.provider.Settings;
import android.system.Os;
import android.text.TextUtils;
import android.util.Log;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * RuntimeSecurityChecker - 运行时安全检测器
 *
 * 此类会被编译进shell DEX，在被保护App的StubApp.onCreate中调用。
 * 提供14项运行时安全检测功能，所有检测方法均为static方法，返回boolean。
 * true表示检测到风险，false表示安全。
 *
 * 所有方法都有try-catch包裹，保证不会因检测逻辑导致应用崩溃。
 * 检测到风险时通过android.util.Log.w输出日志。
 *
 * 兼容Android 5.0+ (API 21+)，不使用任何需要权限的API。
 */
public class RuntimeSecurityChecker {

    private static final String TAG = "ArkSec";

    /** SharedPreferences名称，用于存储安全配置 */
    private static final String PREF_NAME = "ark_sec_cfg";

    private static volatile boolean initialized = false;

    // ==================== 检测开关（从native config或SharedPreferences读取） ====================

    private static volatile boolean checkEmulator = false;
    private static volatile boolean checkRoot = false;
    private static volatile boolean checkDebugger = false;
    private static volatile boolean checkXposed = false;
    private static volatile boolean checkVm = false;
    private static volatile boolean checkFridaPipe = false;
    private static volatile boolean checkFridaThread = false;
    private static volatile boolean checkMemDisk = false;
    private static volatile boolean checkApkIntegrity = false;
    private static volatile boolean checkAppMultiOpen = false;
    private static volatile boolean checkJavaHook = false;
    private static volatile boolean checkNativeHook = false;
    private static volatile boolean checkLocationSimulation = false;
    private static volatile boolean checkDeviceModification = false;
    private static volatile boolean checkDexString = false;

    // ==================== 预存校验值 ====================

    /** 预存的APK签名SHA-256哈希 */
    private static volatile String storedSignatureHash = null;
    /** 预期的包名 */
    private static volatile String expectedPackageName = null;
    /** 预存的classes.dex文件大小 */
    private static volatile long storedDexSize = -1;
    /** 预存的classes.dex前64字节（十六进制） */
    private static volatile String storedDexHeaderHex = null;
    /** 预存的classes.dex字符串池SHA-256哈希 */
    private static volatile String storedDexStringHash = null;

    // ==================== 初始化 ====================

    /**
     * 从SharedPreferences或native config读取配置。
     * 在StubApp.onCreate中调用，初始化检测开关和预存校验值。
     *
     * @param context 应用上下文
     */
    public static void init(Context context) {
        if (initialized) {
            return;
        }
        if (context == null) {
            initialized = true;
            return;
        }
        try {
            android.content.SharedPreferences prefs =
                    context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

            // 读取检测开关
            checkEmulator = prefs.getBoolean("check_emulator", false);
            checkRoot = prefs.getBoolean("check_root", false);
            checkDebugger = prefs.getBoolean("check_debugger", false);
            checkXposed = prefs.getBoolean("check_xposed", false);
            checkVm = prefs.getBoolean("check_vm", false);
            checkFridaPipe = prefs.getBoolean("check_frida_pipe", false);
            checkFridaThread = prefs.getBoolean("check_frida_thread", false);
            checkMemDisk = prefs.getBoolean("check_mem_disk", false);
            checkApkIntegrity = prefs.getBoolean("check_apk_integrity", false);
            checkAppMultiOpen = prefs.getBoolean("check_app_multi_open", false);
            checkJavaHook = prefs.getBoolean("check_java_hook", false);
            checkNativeHook = prefs.getBoolean("check_native_hook", false);
            checkLocationSimulation = prefs.getBoolean("check_location_sim", false);
            checkDeviceModification = prefs.getBoolean("check_device_mod", false);
            checkDexString = prefs.getBoolean("check_dex_string", false);

            // 读取预存校验值
            storedSignatureHash = prefs.getString("stored_sig_hash", null);
            expectedPackageName = prefs.getString("expected_pkg", null);
            storedDexSize = prefs.getLong("stored_dex_size", -1);
            storedDexHeaderHex = prefs.getString("stored_dex_header", null);
            storedDexStringHash = prefs.getString("stored_dex_string_hash", null);

            // 如果没有预存包名，使用当前包名
            if (TextUtils.isEmpty(expectedPackageName)) {
                expectedPackageName = context.getPackageName();
            }

            initialized = true;
            Log.i(TAG, "RuntimeSecurityChecker initialized (15 checks available)");
        } catch (Exception e) {
            Log.w(TAG, "init error: " + e.getMessage());
            initialized = true;
        }
    }

    /**
     * 编程式设置检测配置（供加固管道调用）。
     *
     * @param emulator           反模拟器
     * @param root               反Root
     * @param debugger           反调试
     * @param xposed             反Xposed
     * @param vm                 反虚拟机
     * @param fridaPipe          Frida管道检测
     * @param fridaThread        Frida线程检测
     * @param memDisk            内存磁盘比较
     * @param apkIntegrity       APK完整性校验
     * @param appMultiOpen       应用多开检测
     * @param javaHook           Java Hook检测
     * @param nativeHook         Native Hook检测
     * @param locationSimulation 位置模拟检测
     * @param deviceModification 设备篡改检测
     * @param dexString          DEX字符串解密检测
     */
    public static void setConfig(
            boolean emulator, boolean root, boolean debugger, boolean xposed,
            boolean vm, boolean fridaPipe, boolean fridaThread, boolean memDisk,
            boolean apkIntegrity, boolean appMultiOpen, boolean javaHook,
            boolean nativeHook, boolean locationSimulation, boolean deviceModification,
            boolean dexString) {
        checkEmulator = emulator;
        checkRoot = root;
        checkDebugger = debugger;
        checkXposed = xposed;
        checkVm = vm;
        checkFridaPipe = fridaPipe;
        checkFridaThread = fridaThread;
        checkMemDisk = memDisk;
        checkApkIntegrity = apkIntegrity;
        checkAppMultiOpen = appMultiOpen;
        checkJavaHook = javaHook;
        checkNativeHook = nativeHook;
        checkLocationSimulation = locationSimulation;
        checkDeviceModification = deviceModification;
        checkDexString = dexString;
        initialized = true;
    }

    /**
     * 设置预存的APK签名哈希。
     *
     * @param hash SHA-256哈希（十六进制字符串）
     */
    public static void setStoredSignatureHash(String hash) {
        storedSignatureHash = hash;
    }

    /**
     * 设置预期的包名。
     *
     * @param packageName 预期包名
     */
    public static void setExpectedPackageName(String packageName) {
        expectedPackageName = packageName;
    }

    /**
     * 设置预存的DEX文件大小。
     *
     * @param size DEX文件大小（字节）
     */
    public static void setStoredDexSize(long size) {
        storedDexSize = size;
    }

    /**
     * 设置预存的DEX头部（前64字节）。
     *
     * @param headerHex DEX前64字节的十六进制字符串
     */
    public static void setStoredDexHeader(String headerHex) {
        storedDexHeaderHex = headerHex;
    }

    /**
     * 设置预存的DEX字符串池哈希。
     *
     * @param hash DEX字符串池的SHA-256哈希（十六进制字符串）
     */
    public static void setStoredDexStringHash(String hash) {
        storedDexStringHash = hash;
    }

    // ==================== 执行所有检测 ====================

    /**
     * 执行所有已启用的检测。
     * 按顺序执行所有检测项，返回是否有任何风险被检测到。
     *
     * @param context 应用上下文
     * @return true表示至少有一项检测到风险，false表示全部安全
     */
    public static boolean runAllChecks(Context context) {
        if (!initialized) {
            init(context);
        }

        boolean anyRisk = false;
        int checkCount = 0;
        int riskCount = 0;

        if (checkEmulator) {
            checkCount++;
            if (detectEmulator()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkRoot) {
            checkCount++;
            if (detectRoot()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkDebugger) {
            checkCount++;
            if (detectDebugger()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkXposed) {
            checkCount++;
            if (detectXposed()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkVm) {
            checkCount++;
            if (detectVm(context)) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkFridaPipe) {
            checkCount++;
            if (detectFridaPipe()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkFridaThread) {
            checkCount++;
            if (detectFridaThread()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkMemDisk) {
            checkCount++;
            if (detectMemDiskMismatch(context)) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkApkIntegrity) {
            checkCount++;
            if (detectApkIntegrity(context)) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkAppMultiOpen) {
            checkCount++;
            if (detectAppMultiOpen()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkJavaHook) {
            checkCount++;
            if (detectJavaHook()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkNativeHook) {
            checkCount++;
            if (detectNativeHook()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkLocationSimulation) {
            checkCount++;
            if (detectLocationSimulation(context)) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkDeviceModification) {
            checkCount++;
            if (detectDeviceModification()) {
                riskCount++;
                anyRisk = true;
            }
        }
        if (checkDexString) {
            checkCount++;
            if (detectDexStringDecryption(context)) {
                riskCount++;
                anyRisk = true;
            }
        }

        Log.i(TAG, "Security check complete: " + checkCount + " checks executed, "
                + riskCount + " risks detected");
        return anyRisk;
    }

    // ==================== 1. 反模拟器检测 ====================

    /**
     * 检测是否运行在模拟器环境中。
     * 通过检查Build属性和/proc/cpuinfo来判断。
     *
     * @return true表示检测到模拟器，false表示安全
     */
    public static boolean detectEmulator() {
        try {
            // 检查Build.FINGERPRINT是否包含"generic"或"unknown"
            if (Build.FINGERPRINT != null) {
                String fp = Build.FINGERPRINT.toLowerCase();
                if (fp.contains("generic") || fp.contains("unknown")) {
                    Log.w(TAG, "[Emulator] FINGERPRINT suspicious: " + Build.FINGERPRINT);
                    return true;
                }
            }

            // 检查Build.MODEL是否包含"Emulator"、"SDK"、"Google SDK"
            if (Build.MODEL != null) {
                String model = Build.MODEL.toLowerCase();
                if (model.contains("emulator") || model.contains("sdk")
                        || model.contains("google sdk")) {
                    Log.w(TAG, "[Emulator] MODEL suspicious: " + Build.MODEL);
                    return true;
                }
            }

            // 检查Build.HARDWARE是否包含"goldfish"或"ranchu"
            if (Build.HARDWARE != null) {
                String hw = Build.HARDWARE.toLowerCase();
                if (hw.contains("goldfish") || hw.contains("ranchu")) {
                    Log.w(TAG, "[Emulator] HARDWARE suspicious: " + Build.HARDWARE);
                    return true;
                }
            }

            // 检查Build.PRODUCT是否包含"sdk"、"google_sdk"、"sdk_x86"
            if (Build.PRODUCT != null) {
                String product = Build.PRODUCT.toLowerCase();
                if (product.contains("sdk") || product.contains("google_sdk")
                        || product.contains("sdk_x86")) {
                    Log.w(TAG, "[Emulator] PRODUCT suspicious: " + Build.PRODUCT);
                    return true;
                }
            }

            // 检查Build.BRAND是否以"generic"开头
            if (Build.BRAND != null && Build.BRAND.toLowerCase().startsWith("generic")) {
                Log.w(TAG, "[Emulator] BRAND suspicious: " + Build.BRAND);
                return true;
            }

            // 检查Build.DEVICE是否以"generic"开头
            if (Build.DEVICE != null && Build.DEVICE.toLowerCase().startsWith("generic")) {
                Log.w(TAG, "[Emulator] DEVICE suspicious: " + Build.DEVICE);
                return true;
            }

            // 检查/proc/cpuinfo是否包含"GOLDFISH"
            String cpuinfo = readFileString("/proc/cpuinfo");
            if (cpuinfo != null && cpuinfo.contains("GOLDFISH")) {
                Log.w(TAG, "[Emulator] /proc/cpuinfo contains GOLDFISH");
                return true;
            }

            // 检查Build.MANUFACTURER
            if (Build.MANUFACTURER != null
                    && Build.MANUFACTURER.toLowerCase().contains("genymotion")) {
                Log.w(TAG, "[Emulator] MANUFACTURER suspicious: " + Build.MANUFACTURER);
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[Emulator] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 2. 反Root检测 ====================

    /** 常见的Root相关文件路径 */
    private static final String[] ROOT_PATHS = {
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su",
            "/su/bin/su",
            "/system/app/SuperSU",
            "/system/app/SuperSU.apk",
            "/system/etc/init.d/99SuperSUDaemon",
            "/dev/com.koushikdutta.superuser.daemon/",
            "/system/xbin/daemonsu"
    };

    /**
     * 检测设备是否已Root。
     * 通过检查Root文件路径、Build.TAGS、su命令和系统属性来判断。
     *
     * @return true表示检测到Root，false表示安全
     */
    public static boolean detectRoot() {
        try {
            // 检查常用Root路径
            for (String path : ROOT_PATHS) {
                try {
                    if (new File(path).exists()) {
                        Log.w(TAG, "[Root] Found suspicious file: " + path);
                        return true;
                    }
                } catch (Exception e) {
                    // 路径检查失败，继续检查下一个
                }
            }

            // 检查Build.TAGS是否包含"test-keys"
            if (Build.TAGS != null && Build.TAGS.contains("test-keys")) {
                Log.w(TAG, "[Root] Build.TAGS contains test-keys: " + Build.TAGS);
                return true;
            }

            // 尝试执行"which su"命令
            try {
                Process process = Runtime.getRuntime().exec(new String[]{"which", "su"});
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(process.getInputStream()));
                String line = reader.readLine();
                reader.close();
                process.destroy();
                if (line != null && !line.trim().isEmpty()) {
                    Log.w(TAG, "[Root] 'which su' returned: " + line.trim());
                    return true;
                }
            } catch (Exception e) {
                // which命令执行失败，不一定是Root
            }

            // 检查ro.debuggable属性
            String debuggable = getSystemProperty("ro.debuggable");
            if ("1".equals(debuggable)) {
                Log.w(TAG, "[Root] ro.debuggable=1 (debuggable build)");
                return true;
            }

            // 检查ro.secure属性
            String secure = getSystemProperty("ro.secure");
            if ("0".equals(secure)) {
                Log.w(TAG, "[Root] ro.secure=0 (insecure build)");
                return true;
            }

            // 检查Magisk相关属性
            String magiskVersion = getSystemProperty("ro.magisk.version");
            if (!TextUtils.isEmpty(magiskVersion) && !"unknown".equals(magiskVersion)) {
                Log.w(TAG, "[Root] Magisk detected, version: " + magiskVersion);
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[Root] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 3. 反调试检测 ====================

    /**
     * 检测是否正在被调试器附加。
     * 通过检查Debug.isDebuggerConnected、TracerPid和wchan来判断。
     *
     * @return true表示检测到调试器，false表示安全
     */
    public static boolean detectDebugger() {
        try {
            // 检查android.os.Debug.isDebuggerConnected()
            if (android.os.Debug.isDebuggerConnected()) {
                Log.w(TAG, "[Debugger] Debugger is connected");
                return true;
            }

            // 读取/proc/self/status检查TracerPid字段
            String status = readFileString("/proc/self/status");
            if (status != null) {
                String[] lines = status.split("\n");
                for (String line : lines) {
                    if (line.startsWith("TracerPid:")) {
                        try {
                            String pidStr = line.substring("TracerPid:".length()).trim();
                            int tracerPid = Integer.parseInt(pidStr);
                            if (tracerPid != 0) {
                                Log.w(TAG, "[Debugger] TracerPid=" + tracerPid
                                        + " (process is being traced)");
                                return true;
                            }
                        } catch (NumberFormatException e) {
                            // 解析失败，忽略
                        }
                        break;
                    }
                }
            }

            // 检查/proc/self/wchan是否包含ptrace
            String wchan = readFileString("/proc/self/wchan");
            if (wchan != null && wchan.trim().contains("ptrace")) {
                Log.w(TAG, "[Debugger] wchan contains 'ptrace': " + wchan.trim());
                return true;
            }

            // 检查当前进程的调试器附加状态（通过ro.debuggable）
            String debuggable = getSystemProperty("ro.debuggable");
            if ("1".equals(debuggable) && android.os.Debug.isDebuggerConnected()) {
                Log.w(TAG, "[Debugger] Debuggable build with active debugger");
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[Debugger] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 4. 反Xposed检测 ====================

    /**
     * 检测是否安装了Xposed框架。
     * 通过检查XposedBridge类、栈帧和/proc/self/maps来判断。
     *
     * @return true表示检测到Xposed，false表示安全
     */
    public static boolean detectXposed() {
        try {
            // 尝试加载de.robv.android.xposed.XposedBridge类
            try {
                Class.forName("de.robv.android.xposed.XposedBridge");
                Log.w(TAG, "[Xposed] XposedBridge class loaded successfully");
                return true;
            } catch (ClassNotFoundException e) {
                // 类未找到，继续检查
            }

            // 检查栈帧中是否包含de.robv.android.xposed
            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            if (stackTrace != null) {
                for (StackTraceElement element : stackTrace) {
                    String className = element.getClassName();
                    if (className != null && className.contains("de.robv.android.xposed")) {
                        Log.w(TAG, "[Xposed] Found in stack trace: " + className);
                        return true;
                    }
                }
            }

            // 检查/proc/self/maps中是否加载了xposed相关so
            String maps = readFileString("/proc/self/maps");
            if (maps != null) {
                String lowerMaps = maps.toLowerCase();
                if (lowerMaps.contains("xposed") || lowerMaps.contains("xposedbridge")
                        || lowerMaps.contains("xposed_art") || lowerMaps.contains("libxposed")) {
                    Log.w(TAG, "[Xposed] Found xposed library in /proc/self/maps");
                    return true;
                }
            }

            // 检查Xposed相关系统属性
            String xposedProp = getSystemProperty("init.svc.xposed");
            if (!TextUtils.isEmpty(xposedProp) && !"unknown".equals(xposedProp)) {
                Log.w(TAG, "[Xposed] Found xposed service: " + xposedProp);
                return true;
            }

            // 检查EdXposed (新一代Xposed)
            try {
                Class.forName("de.robv.android.xposed.XposedHelpers");
                Log.w(TAG, "[Xposed] XposedHelpers class found");
                return true;
            } catch (ClassNotFoundException e) {
                // 未找到
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[Xposed] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 5. 反虚拟机检测 ====================

    /** 已知的虚拟空间/多开应用包名 */
    private static final String[] VIRTUAL_SPACE_PKGS = {
            "com.bly.dkplat",           // DualSpace
            "com.lbe.parallel",         // Parallel Space
            "com.lbe.parallel.intl",    // Parallel Space国际版
            "com.excelliance.dualaid",  // DualAid
            "com.ludashi.dualspace",    // DualSpace
            "com.jumobile.multiapp",    // 多开分身
            "com.facebook.katana",      // 检查路径是否包含
    };

    /** 虚拟空间相关文件路径 */
    private static final String[] VM_FILES = {
            "/data/data/com.bly.dkplat",
            "/data/data/com.lbe.parallel",
            "/data/data/com.excelliance.dualaid",
            "/data/data/com.ludashi.dualspace",
            "/data/data/com.jumobile.multiapp",
    };

    /**
     * 检测是否运行在虚拟机/虚拟空间环境中。
     * 通过检查虚拟空间路径、包名一致性和数据目录来判断。
     *
     * @param context 应用上下文
     * @return true表示检测到虚拟环境，false表示安全
     */
    public static boolean detectVm(Context context) {
        try {
            // 检查是否运行在VMOS、Parallel Space等虚拟环境
            String cmdline = readFileString("/proc/self/cmdline");
            if (cmdline != null) {
                String process = cmdline.replace("\0", "").trim();
                for (String pkg : VIRTUAL_SPACE_PKGS) {
                    if (process.contains(pkg)) {
                        Log.w(TAG, "[VM] Running inside virtual space: " + process);
                        return true;
                    }
                }
            }

            // 检查包名是否被重命名（对比实际包名和预期包名）
            if (context != null && !TextUtils.isEmpty(expectedPackageName)) {
                String actualPkg = context.getPackageName();
                if (!expectedPackageName.equals(actualPkg)) {
                    Log.w(TAG, "[VM] Package name mismatch: expected="
                            + expectedPackageName + ", actual=" + actualPkg);
                    return true;
                }
            }

            // 检查/data/data/路径是否与预期一致
            if (context != null) {
                String dataDir = null;
                try {
                    dataDir = context.getApplicationInfo().dataDir;
                } catch (Exception e) {
                    dataDir = context.getFilesDir().getParent();
                }
                if (dataDir != null) {
                    for (String pkg : VIRTUAL_SPACE_PKGS) {
                        if (dataDir.contains(pkg)) {
                            Log.w(TAG, "[VM] Data directory contains virtual space: " + dataDir);
                            return true;
                        }
                    }
                    // 检查路径中是否包含异常的虚拟空间标识
                    if (dataDir.contains("/virtual/") || dataDir.contains("/dualspace/")
                            || dataDir.contains("/parallel/")) {
                        Log.w(TAG, "[VM] Suspicious data directory path: " + dataDir);
                        return true;
                    }
                }
            }

            // 检查是否有虚拟空间相关文件
            for (String vmFile : VM_FILES) {
                try {
                    if (new File(vmFile).exists()) {
                        Log.w(TAG, "[VM] Virtual space app detected: " + vmFile);
                        return true;
                    }
                } catch (Exception e) {
                    // 跳过
                }
            }

            // 检查/proc/self/maps中是否加载了虚拟空间库
            String maps = readFileString("/proc/self/maps");
            if (maps != null) {
                String lowerMaps = maps.toLowerCase();
                if (lowerMaps.contains("com.bly.dkplat") || lowerMaps.contains("com.lbe.parallel")
                        || lowerMaps.contains("virtualapp") || lowerMaps.contains("virtualapp")) {
                    Log.w(TAG, "[VM] Virtual space library found in maps");
                    return true;
                }
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[VM] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 6. Frida管道检测 ====================

    /** Frida默认端口 */
    private static final int[] FRIDA_PORTS = {27042, 27043, 27045};

    /**
     * 检测Frida通过管道/socket连接。
     * 遍历/proc/self/fd/，检查frida相关管道和异常socket连接。
     *
     * @return true表示检测到Frida管道，false表示安全
     */
    public static boolean detectFridaPipe() {
        try {
            // 遍历/proc/self/fd/，检查是否有frida相关管道
            File fdDir = new File("/proc/self/fd");
            File[] fds = fdDir.listFiles();
            if (fds != null) {
                for (File fd : fds) {
                    try {
                        String linkTarget = Os.readlink(fd.getAbsolutePath());
                        if (linkTarget != null) {
                            String lower = linkTarget.toLowerCase();
                            // 检查frida相关管道
                            if (lower.contains("frida")) {
                                Log.w(TAG, "[FridaPipe] Found frida pipe: " + linkTarget);
                                return true;
                            }
                            // 检查linjector相关文件
                            if (lower.contains("linjector")) {
                                Log.w(TAG, "[FridaPipe] Found linjector: " + linkTarget);
                                return true;
                            }
                            // 检查异常socket连接到frida默认端口
                            if (lower.contains("socket") || lower.contains("pipe:")) {
                                // 进一步检查socket信息
                                if (lower.contains("frida") || lower.contains("linjector")) {
                                    Log.w(TAG, "[FridaPipe] Suspicious connection: " + linkTarget);
                                    return true;
                                }
                            }
                        }
                    } catch (Exception e) {
                        // readlink失败，跳过此fd
                    }
                }
            }

            // 检查/proc/net/tcp中是否有连接到frida默认端口的socket
            String tcp = readFileString("/proc/net/tcp");
            if (tcp != null) {
                for (int port : FRIDA_PORTS) {
                    String portHex = String.format("%04X", port);
                    if (tcp.contains(":" + portHex)) {
                        Log.w(TAG, "[FridaPipe] Found connection to frida port: " + port);
                        return true;
                    }
                }
            }

            // 检查/proc/net/tcp6
            String tcp6 = readFileString("/proc/net/tcp6");
            if (tcp6 != null) {
                for (int port : FRIDA_PORTS) {
                    String portHex = String.format("%04X", port);
                    if (tcp6.contains(":" + portHex)) {
                        Log.w(TAG, "[FridaPipe] Found IPv6 connection to frida port: " + port);
                        return true;
                    }
                }
            }

            // 检查linjector相关文件
            String[] linjectorFiles = {
                    "/data/local/tmp/linjector",
                    "/data/local/tmp/frida-server",
                    "/data/local/tmp/frida-agent",
            };
            for (String file : linjectorFiles) {
                try {
                    if (new File(file).exists()) {
                        Log.w(TAG, "[FridaPipe] Found frida/linjector file: " + file);
                        return true;
                    }
                } catch (Exception e) {
                    // 跳过
                }
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[FridaPipe] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 7. Frida线程检测 ====================

    /** Frida相关线程名称 */
    private static final String[] FRIDA_THREAD_NAMES = {
            "gmain",
            "gdbus",
            "gum-js-loop",
            "frida",
            "pool-frida",
            "frida-gadget",
            "linjector"
    };

    /**
     * 检测Frida通过线程活动。
     * 读取/proc/self/task/下所有线程的comm文件，检查是否有Frida相关线程名。
     *
     * @return true表示检测到Frida线程，false表示安全
     */
    public static boolean detectFridaThread() {
        try {
            File taskDir = new File("/proc/self/task");
            File[] tasks = taskDir.listFiles();
            if (tasks == null) {
                return false;
            }

            for (File task : tasks) {
                try {
                    String comm = readFileString(task.getAbsolutePath() + "/comm");
                    if (comm != null) {
                        comm = comm.trim();
                        for (String fridaName : FRIDA_THREAD_NAMES) {
                            if (comm.equals(fridaName) || comm.startsWith(fridaName)) {
                                Log.w(TAG, "[FridaThread] Found frida thread: " + comm
                                        + " (tid=" + task.getName() + ")");
                                return true;
                            }
                        }
                    }
                } catch (Exception e) {
                    // 读取线程comm失败，跳过
                }
            }

            // 额外检查：读取/proc/self/status中的线程数
            // Frida注入通常会创建多个线程
            String status = readFileString("/proc/self/status");
            if (status != null) {
                for (String line : status.split("\n")) {
                    if (line.startsWith("Threads:")) {
                        try {
                            String countStr = line.substring("Threads:".length()).trim();
                            int threadCount = Integer.parseInt(countStr);
                            // 正常应用线程数一般不超过50，Frida注入后通常会增加10+线程
                            // 这里只做记录，不直接判定
                        } catch (NumberFormatException e) {
                            // 忽略
                        }
                        break;
                    }
                }
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[FridaThread] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 8. 内存磁盘比较 ====================

    /** DEX文件魔数 */
    private static final byte[] DEX_MAGIC = {0x64, 0x65, 0x78, 0x0a}; // "dex\n"

    /**
     * 检测DEX文件是否在运行时被修改。
     * 读取APK中的classes.dex，比较文件大小和前64字节。
     * 如果不匹配说明DEX被运行时修改。
     *
     * @param context 应用上下文
     * @return true表示检测到DEX被修改，false表示安全
     */
    public static boolean detectMemDiskMismatch(Context context) {
        ZipFile zipFile = null;
        InputStream is = null;
        try {
            if (context == null) {
                return false;
            }

            String apkPath = context.getApplicationInfo().sourceDir;
            if (TextUtils.isEmpty(apkPath)) {
                return false;
            }

            File apkFile = new File(apkPath);
            if (!apkFile.exists()) {
                Log.w(TAG, "[MemDisk] APK file not found: " + apkPath);
                return false;
            }

            zipFile = new ZipFile(apkFile);
            ZipEntry dexEntry = zipFile.getEntry("classes.dex");
            if (dexEntry == null) {
                Log.w(TAG, "[MemDisk] classes.dex not found in APK");
                return false;
            }

            long dexSize = dexEntry.getSize();
            byte[] header = new byte[64];

            is = zipFile.getInputStream(dexEntry);
            int bytesRead = is.read(header);

            // 检查DEX魔数是否正确
            if (bytesRead >= 4) {
                if (header[0] != DEX_MAGIC[0] || header[1] != DEX_MAGIC[1]
                        || header[2] != DEX_MAGIC[2] || header[3] != DEX_MAGIC[3]) {
                    Log.w(TAG, "[MemDisk] DEX magic mismatch, file may be corrupted or modified");
                    return true;
                }
            }

            // 与预存的大小比较
            if (storedDexSize > 0 && dexSize != storedDexSize) {
                Log.w(TAG, "[MemDisk] DEX size mismatch: expected=" + storedDexSize
                        + ", actual=" + dexSize);
                return true;
            }

            // 与预存的头部比较
            if (!TextUtils.isEmpty(storedDexHeaderHex) && bytesRead >= 64) {
                String actualHeaderHex = bytesToHex(header);
                if (!storedDexHeaderHex.equalsIgnoreCase(actualHeaderHex)) {
                    Log.w(TAG, "[MemDisk] DEX header mismatch (first 64 bytes)");
                    return true;
                }
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[MemDisk] detection error: " + e.getMessage());
            return false;
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (Exception e) {
                // 忽略关闭异常
            }
            try {
                if (zipFile != null) {
                    zipFile.close();
                }
            } catch (Exception e) {
                // 忽略关闭异常
            }
        }
    }

    // ==================== 9. APK完整性校验 ====================

    /**
     * 校验APK签名完整性。
     * 读取APK的签名信息，与预存的签名哈希比较。
     * 如果不匹配说明APK被重新签名或篡改。
     *
     * @param context 应用上下文
     * @return true表示检测到签名异常，false表示安全
     */
    public static boolean detectApkIntegrity(Context context) {
        try {
            if (context == null) {
                return false;
            }

            PackageManager pm = context.getPackageManager();
            if (pm == null) {
                return false;
            }

            PackageInfo packageInfo;
            try {
                packageInfo = pm.getPackageInfo(
                        context.getPackageName(),
                        PackageManager.GET_SIGNATURES);
            } catch (PackageManager.NameNotFoundException e) {
                Log.w(TAG, "[ApkIntegrity] Package not found");
                return false;
            }

            if (packageInfo.signatures == null || packageInfo.signatures.length == 0) {
                Log.w(TAG, "[ApkIntegrity] No signatures found in APK");
                return true; // 没有签名是可疑的
            }

            // 计算第一个签名的SHA-256哈希
            Signature signature = packageInfo.signatures[0];
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(signature.toByteArray());
            String actualHash = bytesToHex(hashBytes);

            // 与预存的签名哈希比较
            if (!TextUtils.isEmpty(storedSignatureHash)) {
                if (!storedSignatureHash.equalsIgnoreCase(actualHash)) {
                    Log.w(TAG, "[ApkIntegrity] Signature hash mismatch: expected="
                            + storedSignatureHash + ", actual=" + actualHash);
                    return true;
                }
            } else {
                // 没有预存哈希，只记录当前哈希
                Log.i(TAG, "[ApkIntegrity] Current signature hash: " + actualHash
                        + " (no stored hash for comparison)");
            }

            // 检查APK文件是否被修改（通过文件大小和时间戳）
            String apkPath = context.getApplicationInfo().sourceDir;
            if (!TextUtils.isEmpty(apkPath)) {
                File apkFile = new File(apkPath);
                if (apkFile.exists()) {
                    // 检查APK是否可写（正常安装的APK不应该是可写的）
                    if (apkFile.canWrite()) {
                        Log.w(TAG, "[ApkIntegrity] APK file is writable: " + apkPath);
                        return true;
                    }
                }
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[ApkIntegrity] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 10. 应用多开检测 ====================

    /** 多开应用包名 */
    private static final String[] MULTI_OPEN_PKGS = {
            "com.bly.dkplat",           // DualSpace
            "com.lbe.parallel",         // Parallel Space
            "com.lbe.parallel.intl",    // Parallel Space国际版
            "com.excelliance.dualaid",  // DualAid
            "com.ludashi.dualspace",    // DualSpace
            "com.jumobile.multiapp",    // 多开分身
    };

    /**
     * 检测应用是否运行在多开环境中。
     * 通过检查进程路径、cgroup中的uid和包名路径匹配来判断。
     *
     * @return true表示检测到多开环境，false表示安全
     */
    public static boolean detectAppMultiOpen() {
        try {
            // 检查当前进程路径是否包含多开应用包名
            String cmdline = readFileString("/proc/self/cmdline");
            if (cmdline != null) {
                String process = cmdline.replace("\0", "").trim();
                for (String pkg : MULTI_OPEN_PKGS) {
                    if (process.contains(pkg)) {
                        Log.w(TAG, "[MultiOpen] Running in multi-open env: " + process);
                        return true;
                    }
                }
            }

            // 检查/proc/self/cgroup是否包含异常uid
            String cgroup = readFileString("/proc/self/cgroup");
            if (cgroup != null) {
                String[] lines = cgroup.split("\n");
                for (String line : lines) {
                    // 检查uid是否在正常范围（应用uid通常 >= 10000）
                    if (line.contains("uid_")) {
                        int uidStart = line.indexOf("uid_");
                        if (uidStart >= 0) {
                            try {
                                String uidPart = line.substring(uidStart + 4);
                                String[] parts = uidPart.split("[^0-9]");
                                if (parts.length > 0 && !parts[0].isEmpty()) {
                                    int uid = Integer.parseInt(parts[0]);
                                    // 系统uid范围（< 10000）在多开环境中可能出现
                                    if (uid > 0 && uid < 10000) {
                                        Log.w(TAG, "[MultiOpen] Abnormal uid in cgroup: " + uid);
                                        // uid异常可能是多开环境的特征
                                        // 但不直接返回true，需要结合其他检查
                                    }
                                }
                            } catch (NumberFormatException e) {
                                // 忽略
                            }
                        }
                    }
                }
            }

            // 检查包名路径是否与uid匹配
            // 在多开环境中，应用的uid可能被重新分配
            String maps = readFileString("/proc/self/maps");
            if (maps != null) {
                String lowerMaps = maps.toLowerCase();
                for (String pkg : MULTI_OPEN_PKGS) {
                    if (lowerMaps.contains(pkg.toLowerCase())) {
                        Log.w(TAG, "[MultiOpen] Multi-open package found in maps: " + pkg);
                        return true;
                    }
                }
            }

            // 检查/proc/self/maps中是否有多开框架的库
            if (maps != null) {
                String lowerMaps = maps.toLowerCase();
                if (lowerMaps.contains("virtualapp") || lowerMaps.contains("virtualcore")
                        || lowerMaps.contains("parallelspace") || lowerMaps.contains("dualspace")) {
                    Log.w(TAG, "[MultiOpen] Virtual app framework detected in maps");
                    return true;
                }
            }

            // 检查是否有共享的data目录（多开应用通常使用重定向的data目录）
            String mounts = readFileString("/proc/self/mounts");
            if (mounts != null) {
                String lowerMounts = mounts.toLowerCase();
                for (String pkg : MULTI_OPEN_PKGS) {
                    if (lowerMounts.contains(pkg.toLowerCase())) {
                        Log.w(TAG, "[MultiOpen] Multi-open package in mounts: " + pkg);
                        return true;
                    }
                }
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[MultiOpen] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 11. Java Hook检测 ====================

    /**
     * 检测Java层是否被Hook。
     * 检查关键系统方法的字段是否被替换，以及栈深度是否异常。
     *
     * @return true表示检测到Java Hook，false表示安全
     */
    public static boolean detectJavaHook() {
        try {
            // 检查ActivityThread的mInstrumentation字段是否被替换
            try {
                Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
                Method currentMethod = activityThreadClass.getDeclaredMethod("currentActivityThread");
                Object activityThread = currentMethod.invoke(null);
                if (activityThread != null) {
                    Field field = activityThreadClass.getDeclaredField("mInstrumentation");
                    field.setAccessible(true);
                    Object instrumentation = field.get(activityThread);
                    if (instrumentation != null) {
                        String className = instrumentation.getClass().getName();
                        if (!"android.app.Instrumentation".equals(className)) {
                            Log.w(TAG, "[JavaHook] Instrumentation replaced: " + className);
                            return true;
                        }
                    }
                }
            } catch (Exception e) {
                // 反射失败，可能被限制
            }

            // 检查PackageManager是否被代理
            try {
                Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
                Field pmField = activityThreadClass.getDeclaredField("sPackageManager");
                pmField.setAccessible(true);
                Object pm = pmField.get(null);
                if (pm != null) {
                    String pmClassName = pm.getClass().getName();
                    if (!pmClassName.contains("ApplicationPackageManager")) {
                        Log.w(TAG, "[JavaHook] PackageManager proxied: " + pmClassName);
                        return true;
                    }
                }
            } catch (Exception e) {
                // 反射失败
            }

            // 检查栈深度是否异常（Hook框架会添加额外栈帧）
            try {
                int[] depthHolder = new int[1];
                measureStackDepth(depthHolder, 0);
                // 正常应用的栈深度通常在200-800之间
                // Hook框架注入会减少可用栈深度
                // 这里不做硬性判断，只记录
            } catch (StackOverflowError e) {
                // StackOverflowError是预期的
            }

            // 检查是否有已知的Hook框架类加载器
            try {
                ClassLoader cl = RuntimeSecurityChecker.class.getClassLoader();
                while (cl != null) {
                    String clName = cl.getClass().getName();
                    if (clName.contains("DexClassLoader") || clName.contains("PathClassLoader")) {
                        // 正常的Android类加载器，继续检查父加载器
                    } else if (clName.contains("Hook") || clName.contains("Xposed")
                            || clName.contains("Epic") || clName.contains("SandHook")) {
                        Log.w(TAG, "[JavaHook] Suspicious classloader: " + clName);
                        return true;
                    }
                    cl = cl.getParent();
                }
            } catch (Exception e) {
                // 忽略
            }

            // 检查StackOverflowError的栈深度是否异常
            // 如果Hook框架插入了大量栈帧，递归深度会显著降低
            int normalStackDepth = measureNormalStackDepth();
            if (normalStackDepth > 0 && normalStackDepth < 100) {
                // 栈深度异常低，可能存在大量Hook注入
                Log.w(TAG, "[JavaHook] Abnormal stack depth: " + normalStackDepth);
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[JavaHook] detection error: " + e.getMessage());
            return false;
        }
    }

    /**
     * 递归测量栈深度直到StackOverflowError。
     */
    private static void measureStackDepth(int[] depth, int current) {
        depth[0] = current;
        measureStackDepth(depth, current + 1);
    }

    /**
     * 测量正常栈深度（捕获StackOverflowError后的深度值）。
     *
     * @return 栈深度，-1表示测量失败
     */
    private static int measureNormalStackDepth() {
        try {
            int[] depth = new int[1];
            measureStackDepth(depth, 0);
            return depth[0]; // 正常情况不会执行到这里
        } catch (StackOverflowError e) {
            // 从异常栈中估算深度
            StackTraceElement[] trace = e.getStackTrace();
            return trace != null ? trace.length : -1;
        } catch (Exception e) {
            return -1;
        }
    }

    // ==================== 12. Native Hook检测 ====================

    /** 已知的Native Hook框架库名 */
    private static final String[] NATIVE_HOOK_LIBS = {
            "libsubstrate",
            "substrate",
            "libxhook",
            "xhook",
            "libPLTHook",
            "libbhook",
            "libshadowhook",
            "shadowhook",
            "libriru",
            "riru",
            "libwhale",
            "whale",
            "libepic",
            "epic",
            "libart-hook",
            "libnhook",
            "libndkhook",
            "libbaiduhook",
            "libbytehook",
            "bytehook",
            "libDexHelper",      // 部分加固工具的Hook库
            "libtencentbkhook",
    };

    /**
     * 检测Native层是否被Hook。
     * 读取/proc/self/maps检查是否有异常so加载，
     * 检查是否有Substrate、xHook、PLT Hook相关so。
     *
     * @return true表示检测到Native Hook，false表示安全
     */
    public static boolean detectNativeHook() {
        try {
            String maps = readFileString("/proc/self/maps");
            if (maps == null) {
                return false;
            }

            String lowerMaps = maps.toLowerCase();

            // 检查是否有已知的Hook框架库
            for (String lib : NATIVE_HOOK_LIBS) {
                if (lowerMaps.contains(lib.toLowerCase())) {
                    Log.w(TAG, "[NativeHook] Found hook library: " + lib);
                    return true;
                }
            }

            // 检查是否有从/data/data目录加载的异常so
            // 正常的系统so不应该从应用数据目录加载
            String[] lines = maps.split("\n");
            for (String line : lines) {
                String lowerLine = line.toLowerCase();
                // 检查从临时目录加载的so
                if (lowerLine.contains("/data/local/tmp/")
                        || lowerLine.contains("/data/data/")
                        && lowerLine.contains(".so")
                        && !lowerLine.contains(getCurrentPackageName())) {
                    // 检查是否是已知的合法库
                    boolean isKnownLib = false;
                    for (String lib : NATIVE_HOOK_LIBS) {
                        if (lowerLine.contains(lib.toLowerCase())) {
                            isKnownLib = true;
                            break;
                        }
                    }
                    if (isKnownLib) {
                        Log.w(TAG, "[NativeHook] Suspicious lib from data dir: " + line.trim());
                        return true;
                    }
                }

                // 检查是否有匿名映射的可执行区域（常见于inline hook）
                if (lowerLine.contains("r-xp") && (lowerLine.contains("[anon:")
                        || lowerLine.contains("[bss]"))) {
                    // 匿名可执行内存区域可能是inline hook注入的代码
                    // 这里只做记录，不直接判定
                }
            }

            // 检查libc函数地址是否在正常范围
            // 通过检查/proc/self/maps中libc.so的加载地址范围
            try {
                String libcPath = null;
                long libcStart = 0;
                long libcEnd = 0;
                for (String line : lines) {
                    if (line.contains("libc.so") && line.contains("r-xp")) {
                        String[] parts = line.trim().split("\\s+");
                        if (parts.length > 0) {
                            String[] addrRange = parts[0].split("-");
                            if (addrRange.length == 2) {
                                libcStart = Long.parseLong(addrRange[0], 16);
                                libcEnd = Long.parseLong(addrRange[1], 16);
                                libcPath = parts[parts.length - 1];
                                break;
                            }
                        }
                    }
                }
                // 如果libc.so被加载在异常地址范围，可能是被重定位Hook
                // 这里只做记录
            } catch (Exception e) {
                // 忽略
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[NativeHook] detection error: " + e.getMessage());
            return false;
        }
    }

    /**
     * 获取当前进程的包名（从/proc/self/cmdline读取）。
     *
     * @return 包名字符串，如果读取失败返回空字符串
     */
    private static String getCurrentPackageName() {
        try {
            String cmdline = readFileString("/proc/self/cmdline");
            if (cmdline != null) {
                return cmdline.replace("\0", "").trim();
            }
        } catch (Exception e) {
            // 忽略
        }
        return "";
    }

    // ==================== 13. 位置模拟检测 ====================

    /**
     * 检测是否使用了位置模拟。
     * 检查Settings.Secure.ALLOW_MOCK_LOCATION和模拟位置相关App。
     *
     * @param context 应用上下文
     * @return true表示检测到位置模拟，false表示安全
     */
    public static boolean detectLocationSimulation(Context context) {
        try {
            if (context == null) {
                return false;
            }

            // 检查Settings.Secure.ALLOW_MOCK_LOCATION（旧版API，但仍可用于检测）
            try {
                int mockLocation = Settings.Secure.getInt(
                        context.getContentResolver(),
                        Settings.Secure.ALLOW_MOCK_LOCATION,
                        0);
                if (mockLocation != 0) {
                    Log.w(TAG, "[LocationSim] Mock location enabled in settings");
                    return true;
                }
            } catch (Exception e) {
                // 设置项可能在新版Android中不存在
            }

            // 检查是否有模拟位置相关App安装
            try {
                PackageManager pm = context.getPackageManager();
                if (pm != null) {
                    List<PackageInfo> packages = pm.getInstalledPackages(
                            PackageManager.GET_PERMISSIONS);
                    if (packages != null) {
                        for (PackageInfo pkg : packages) {
                            if (pkg.requestedPermissions != null) {
                                for (String perm : pkg.requestedPermissions) {
                                    if ("android.permission.ACCESS_MOCK_LOCATION".equals(perm)) {
                                        // 排除系统应用
                                        if (!isSystemApp(pkg)) {
                                            Log.w(TAG, "[LocationSim] Mock location app installed: "
                                                    + pkg.packageName);
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                // 在Android 11+上，包可见性限制可能导致查询结果不完整
                // 这是正常的，不视为错误
            }

            // 检查是否有已知的GPS欺骗应用
            String[] gpsSpooferPkgs = {
                    "com.theappninjas.gpsjoystick",
                    "com.evezzon.fakegps",
                    "com.incorporateapps.fakegps",
                    "com.incorporateapps.fakegps.route",
                    "com.newgengps.fakegps",
                    "ru.gavrikov.mockgps",
                    "com.blogspot.newapphorizons.fakegps",
            };
            try {
                PackageManager pm = context.getPackageManager();
                if (pm != null) {
                    for (String pkg : gpsSpooferPkgs) {
                        try {
                            pm.getPackageInfo(pkg, 0);
                            Log.w(TAG, "[LocationSim] Known GPS spoofer installed: " + pkg);
                            return true;
                        } catch (PackageManager.NameNotFoundException e) {
                            // 应用未安装
                        }
                    }
                }
            } catch (Exception e) {
                // 忽略
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[LocationSim] detection error: " + e.getMessage());
            return false;
        }
    }

    /**
     * 检查给定的Location对象是否来自模拟位置提供者。
     * 此方法可在接收到位置更新时调用。
     *
     * @param location Location对象
     * @return true表示位置来自模拟提供者，false表示正常
     */
    public static boolean isMockLocation(android.location.Location location) {
        if (location == null) {
            return false;
        }
        try {
            // 尝试调用isFromMockProvider() (API 18+，API 31已废弃但仍可用)
            try {
                Method method = location.getClass().getMethod("isFromMockProvider");
                Object result = method.invoke(location);
                if (result instanceof Boolean && (Boolean) result) {
                    Log.w(TAG, "[LocationSim] Location is from mock provider");
                    return true;
                }
            } catch (NoSuchMethodException e) {
                // 方法不存在
            }

            // 尝试调用isMock() (API 31+)
            try {
                Method method = location.getClass().getMethod("isMock");
                Object result = method.invoke(location);
                if (result instanceof Boolean && (Boolean) result) {
                    Log.w(TAG, "[LocationSim] Location is mock (API 31+)");
                    return true;
                }
            } catch (NoSuchMethodException e) {
                // 方法不存在
            }
        } catch (Exception e) {
            // 忽略
        }
        return false;
    }

    // ==================== 14. 设备篡改检测 ====================

    /** Magisk相关属性 */
    private static final String[] MAGISK_PROPS = {
            "ro.magisk.version",
            "ro.magisk.versioncode",
            "init.svc.magisk_pfs",
            "init.svc.magisk_pfsd",
            "init.svc.magisk_postfs",
            "ro.boot.magisk",
    };

    /** Magisk相关文件路径 */
    private static final String[] MAGISK_FILES = {
            "/sbin/.magisk",
            "/data/adb/magisk",
            "/data/adb/modules",
            "/cache/.disable_magisk",
            "/dev/.magisk.unblock",
            "/system/bin/magisk",
            "/data/adb/magisk.db",
    };

    /**
     * 检测设备是否被篡改。
     * 检查Build属性是否被篡改、指纹一致性和Magisk相关属性。
     *
     * @return true表示检测到设备篡改，false表示安全
     */
    public static boolean detectDeviceModification() {
        try {
            // 检查ro.build.fingerprint与Build.FINGERPRINT是否一致
            String buildFingerprint = Build.FINGERPRINT;
            String propFingerprint = getSystemProperty("ro.build.fingerprint");
            if (!TextUtils.isEmpty(buildFingerprint) && !TextUtils.isEmpty(propFingerprint)) {
                if (!buildFingerprint.equals(propFingerprint)) {
                    Log.w(TAG, "[DeviceMod] Fingerprint mismatch: Build=" + buildFingerprint
                            + ", Property=" + propFingerprint);
                    return true;
                }
            }

            // 检查ro.boot.verifiedbootstate
            String verifiedBootState = getSystemProperty("ro.boot.verifiedbootstate");
            if (!TextUtils.isEmpty(verifiedBootState)) {
                if ("orange".equals(verifiedBootState) || "yellow".equals(verifiedBootState)) {
                    Log.w(TAG, "[DeviceMod] Verified boot state: " + verifiedBootState
                            + " (device may be unlocked)");
                    return true;
                }
            }

            // 检查ro.boot.vbmeta.device_state
            String deviceState = getSystemProperty("ro.boot.vbmeta.device_state");
            if (!TextUtils.isEmpty(deviceState) && "unlocked".equals(deviceState)) {
                Log.w(TAG, "[DeviceMod] Device state: unlocked");
                return true;
            }

            // 检查Magisk相关属性
            for (String prop : MAGISK_PROPS) {
                String value = getSystemProperty(prop);
                if (!TextUtils.isEmpty(value) && !"unknown".equals(value)) {
                    Log.w(TAG, "[DeviceMod] Magisk property found: " + prop + "=" + value);
                    return true;
                }
            }

            // 检查Magisk相关文件
            for (String file : MAGISK_FILES) {
                try {
                    if (new File(file).exists()) {
                        Log.w(TAG, "[DeviceMod] Magisk file found: " + file);
                        return true;
                    }
                } catch (Exception e) {
                    // 跳过
                }
            }

            // 检查Build属性是否被篡改
            // 比较Build.FINGERPRINT和ro.build.fingerprint的哈希
            String buildDisplayId = Build.DISPLAY;
            String propDisplayId = getSystemProperty("ro.build.display.id");
            if (!TextUtils.isEmpty(buildDisplayId) && !TextUtils.isEmpty(propDisplayId)) {
                if (!buildDisplayId.equals(propDisplayId)) {
                    Log.w(TAG, "[DeviceMod] Display ID mismatch: Build=" + buildDisplayId
                            + ", Property=" + propDisplayId);
                    return true;
                }
            }

            // 检查SELinux状态（Magisk可能修改SELinux）
            String selinux = getSystemProperty("ro.build.selinux");
            if (!TextUtils.isEmpty(selinux) && selinux.contains("0")) {
                // SELinux被禁用
                Log.w(TAG, "[DeviceMod] SELinux may be disabled: " + selinux);
                // 不直接返回true，因为某些设备可能默认禁用
            }

            // 检查/proc/self/status中的SELinux上下文
            // 检查ro.boot.veritymode
            String verityMode = getSystemProperty("ro.boot.veritymode");
            if (!TextUtils.isEmpty(verityMode) && "disabled".equals(verityMode)) {
                Log.w(TAG, "[DeviceMod] Verity mode disabled");
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[DeviceMod] detection error: " + e.getMessage());
            return false;
        }
    }

    // ==================== 辅助方法 ====================

    /**
     * 读取文件内容为字符串。
     *
     * @param path 文件路径
     * @return 文件内容字符串，读取失败返回null
     */
    private static String readFileString(String path) {
        BufferedReader reader = null;
        try {
            StringBuilder sb = new StringBuilder();
            reader = new BufferedReader(new FileReader(path));
            char[] buffer = new char[4096];
            int len;
            while ((len = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, len);
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (Exception e) {
                    // 忽略
                }
            }
        }
    }

    /**
     * 通过反射读取系统属性。
     * 使用android.os.SystemProperties隐藏API。
     *
     * @param name 属性名称
     * @return 属性值，读取失败返回空字符串
     */
    private static String getSystemProperty(String name) {
        try {
            Class<?> spClass = Class.forName("android.os.SystemProperties");
            Method getMethod = spClass.getDeclaredMethod("get", String.class);
            Object result = getMethod.invoke(null, name);
            if (result instanceof String) {
                return (String) result;
            }
        } catch (Exception e) {
            // 反射失败
        }
        return "";
    }

    /**
     * 将字节数组转换为十六进制字符串。
     *
     * @param bytes 字节数组
     * @return 十六进制字符串
     */
    private static String bytesToHex(byte[] bytes) {
        if (bytes == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b & 0xFF));
        }
        return sb.toString();
    }

    /**
     * 检查应用是否为系统应用。
     *
     * @param pkg PackageInfo对象
     * @return true表示是系统应用
     */
    private static boolean isSystemApp(PackageInfo pkg) {
        if (pkg == null || pkg.applicationInfo == null) {
            return false;
        }
        return (pkg.applicationInfo.flags
                & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0;
    }

    // ==================== 15. DEX字符串解密检测 ====================

    /**
     * 检测DEX文件中的字符串是否被运行时修改。
     * 读取APK中的classes.dex，计算DEX字符串池的SHA-256哈希，
     * 与预存的哈希比较。如果不匹配说明DEX被运行时hook修改（如Frida动态解密字符串）。
     *
     * @param context 应用上下文
     * @return true表示检测到DEX字符串被修改（风险），false表示安全
     */
    public static boolean detectDexStringDecryption(Context context) {
        ZipFile zipFile = null;
        InputStream is = null;
        try {
            if (context == null) {
                return false;
            }

            String apkPath = context.getApplicationInfo().sourceDir;
            if (TextUtils.isEmpty(apkPath)) {
                return false;
            }

            File apkFile = new File(apkPath);
            if (!apkFile.exists()) {
                Log.w(TAG, "[DexString] APK file not found: " + apkPath);
                return false;
            }

            zipFile = new ZipFile(apkFile);
            ZipEntry dexEntry = zipFile.getEntry("classes.dex");
            if (dexEntry == null) {
                Log.w(TAG, "[DexString] classes.dex not found in APK");
                return false;
            }

            // 读取整个DEX文件到内存
            is = zipFile.getInputStream(dexEntry);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int len;
            while ((len = is.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }
            byte[] dexBytes = baos.toByteArray();

            // 计算DEX字符串池哈希
            String actualHash = computeDexStringPoolHash(dexBytes);
            if (actualHash == null) {
                Log.w(TAG, "[DexString] Failed to compute string pool hash");
                return false;
            }

            // 与预存哈希比较
            if (TextUtils.isEmpty(storedDexStringHash)) {
                // 没有预存哈希，只记录当前哈希
                Log.i(TAG, "[DexString] Current string pool hash: " + actualHash
                        + " (no stored hash for comparison)");
                return false;
            }

            if (!storedDexStringHash.equalsIgnoreCase(actualHash)) {
                Log.w(TAG, "[DexString] String pool hash mismatch: expected="
                        + storedDexStringHash + ", actual=" + actualHash);
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.w(TAG, "[DexString] detection error: " + e.getMessage());
            return false;
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (Exception e) {
                // 忽略关闭异常
            }
            try {
                if (zipFile != null) {
                    zipFile.close();
                }
            } catch (Exception e) {
                // 忽略关闭异常
            }
        }
    }

    /**
     * 计算DEX字符串池的SHA-256哈希。
     * 解析DEX文件格式，遍历所有字符串数据，计算哈希。
     *
     * DEX文件格式：
     * - 偏移56: string_ids_size (uint)
     * - 偏移60: string_ids_off (uint)
     * - string_ids: 每项4字节，指向string_data_item的偏移
     * - string_data_item: uleb128(字符串长度) + MUTF-8数据 + null字节
     *
     * @param dexBytes DEX文件字节数组
     * @return 字符串池的SHA-256哈希（十六进制字符串），失败返回null
     */
    private static String computeDexStringPoolHash(byte[] dexBytes) {
        try {
            if (dexBytes == null || dexBytes.length < 112) {
                return null;
            }

            // 验证DEX魔数 "dex\n"
            if (dexBytes[0] != 'd' || dexBytes[1] != 'e'
                    || dexBytes[2] != 'x' || dexBytes[3] != '\n') {
                Log.w(TAG, "[DexString] Invalid DEX magic");
                return null;
            }

            ByteBuffer bb = ByteBuffer.wrap(dexBytes).order(ByteOrder.LITTLE_ENDIAN);

            // 读取string_ids_size (偏移56) 和 string_ids_off (偏移60)
            bb.position(56);
            int stringIdsSize = bb.getInt();
            long stringIdsOff = bb.getInt() & 0xFFFFFFFFL;

            if (stringIdsSize <= 0 || stringIdsOff <= 0
                    || stringIdsOff + (long) stringIdsSize * 4 > dexBytes.length) {
                Log.w(TAG, "[DexString] Invalid string_ids table: size=" + stringIdsSize
                        + ", off=" + stringIdsOff);
                return null;
            }

            MessageDigest md = MessageDigest.getInstance("SHA-256");

            // 遍历所有字符串，将字符串数据喂给摘要算法
            for (int i = 0; i < stringIdsSize; i++) {
                bb.position((int) stringIdsOff + i * 4);
                int strDataOff = bb.getInt();
                if (strDataOff <= 0 || strDataOff >= dexBytes.length) {
                    continue;
                }

                // 跳过uleb128编码的字符串长度
                int pos = strDataOff;
                while (pos < dexBytes.length && (dexBytes[pos] & 0x80) != 0) {
                    pos++;
                }
                pos++; // 跳过uleb128的最后一个字节

                // 读取MUTF-8字符串数据直到null字节
                int start = pos;
                while (pos < dexBytes.length && dexBytes[pos] != 0) {
                    pos++;
                }

                // 将字符串数据喂给摘要算法
                md.update(dexBytes, start, pos - start);
                md.update((byte) 0x00); // 分隔符
            }

            byte[] hashBytes = md.digest();
            return bytesToHex(hashBytes);
        } catch (Exception e) {
            Log.w(TAG, "[DexString] computeDexStringPoolHash error: " + e.getMessage());
            return null;
        }
    }

    // ==================== 获取检测结果摘要 ====================

    /**
     * 执行所有已启用的检测并返回详细结果摘要。
     *
     * @param context 应用上下文
     * @return 检测结果摘要字符串
     */
    public static String getCheckResultSummary(Context context) {
        if (!initialized) {
            init(context);
        }

        StringBuilder sb = new StringBuilder();
        sb.append("=== RuntimeSecurityChecker Results ===\n");

        if (checkEmulator) {
            sb.append("  Emulator:        ").append(detectEmulator() ? "RISK" : "OK").append("\n");
        }
        if (checkRoot) {
            sb.append("  Root:            ").append(detectRoot() ? "RISK" : "OK").append("\n");
        }
        if (checkDebugger) {
            sb.append("  Debugger:        ").append(detectDebugger() ? "RISK" : "OK").append("\n");
        }
        if (checkXposed) {
            sb.append("  Xposed:          ").append(detectXposed() ? "RISK" : "OK").append("\n");
        }
        if (checkVm) {
            sb.append("  VirtualMachine:  ").append(detectVm(context) ? "RISK" : "OK").append("\n");
        }
        if (checkFridaPipe) {
            sb.append("  FridaPipe:       ").append(detectFridaPipe() ? "RISK" : "OK").append("\n");
        }
        if (checkFridaThread) {
            sb.append("  FridaThread:     ").append(detectFridaThread() ? "RISK" : "OK").append("\n");
        }
        if (checkMemDisk) {
            sb.append("  MemDiskMismatch: ").append(detectMemDiskMismatch(context) ? "RISK" : "OK").append("\n");
        }
        if (checkApkIntegrity) {
            sb.append("  ApkIntegrity:    ").append(detectApkIntegrity(context) ? "RISK" : "OK").append("\n");
        }
        if (checkAppMultiOpen) {
            sb.append("  AppMultiOpen:    ").append(detectAppMultiOpen() ? "RISK" : "OK").append("\n");
        }
        if (checkJavaHook) {
            sb.append("  JavaHook:        ").append(detectJavaHook() ? "RISK" : "OK").append("\n");
        }
        if (checkNativeHook) {
            sb.append("  NativeHook:      ").append(detectNativeHook() ? "RISK" : "OK").append("\n");
        }
        if (checkLocationSimulation) {
            sb.append("  LocationSim:     ").append(detectLocationSimulation(context) ? "RISK" : "OK").append("\n");
        }
        if (checkDeviceModification) {
            sb.append("  DeviceMod:       ").append(detectDeviceModification() ? "RISK" : "OK").append("\n");
        }
        if (checkDexString) {
            sb.append("  DexString:       ").append(detectDexStringDecryption(context) ? "RISK" : "OK").append("\n");
        }

        sb.append("=== End of Results ===");
        return sb.toString();
    }
}
