package com.ark.jiagu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.SecureRandom;

/**
 * Native Library Protection Engine.
 *
 * Encrypts .so files in the lib/ directory to prevent direct analysis.
 * At runtime, the shell decrypts the .so files before loading them.
 *
 * Runs after SO patching (vmp.bin injection), before APK rebuild.
 */
public class NativeProtector {

    private static final String TAG = "NativeProtector";
    private final File workDir;
    private final ProtectionPipeline.LogCallback logCallback;
    private final SecureRandom random = new SecureRandom();

    // Magic header for encrypted SO files
    private static final byte[] ENCRYPTED_MAGIC = {0x41, 0x52, 0x4B, 0x53}; // "ARKS"

    public NativeProtector(File workDir, ProtectionPipeline.LogCallback logCallback) {
        this.workDir = workDir;
        this.logCallback = logCallback;
    }

    /**
     * Encrypt all .so files in the lib/ directory.
     * The stub SO (containing vmp.bin) is NOT encrypted - it must be loadable
     * by the system dlopen. Instead, it decrypts the other SO files at runtime.
     *
     * @param stubSoName The name of the stub SO file to skip (e.g. "libArkStub.so")
     */
    public void encryptLibraries(String stubSoName) {
        File libDir = new File(workDir, "lib");
        if (!libDir.isDirectory()) {
            logCallback.log("  无lib目录，跳过本地库加密");
            return;
        }

        int encryptedCount = 0;

        File[] abiDirs = libDir.listFiles(File::isDirectory);
        if (abiDirs == null) {
            logCallback.log("  无ABI子目录");
            return;
        }

        for (File abiDir : abiDirs) {
            File[] soFiles = abiDir.listFiles((dir, name) -> name.endsWith(".so"));
            if (soFiles == null) continue;

            for (File soFile : soFiles) {
                // Skip the stub SO - it must remain unencrypted for dlopen
                if (stubSoName != null && soFile.getName().equals(stubSoName)) {
                    logCallback.log("  跳过壳SO: " + soFile.getName());
                    continue;
                }

                try {
                    encryptSingleSo(soFile);
                    encryptedCount++;
                } catch (Exception e) {
                    logCallback.log("  加密SO失败: " + soFile.getName() + " - " + e.getMessage());
                }
            }
        }

        logCallback.log("  共加密 " + encryptedCount + " 个SO文件");
    }

    /**
     * Encrypt a single .so file using XOR with a random key.
     */
    private void encryptSingleSo(File soFile) throws IOException {
        byte[] originalData = readFile(soFile);

        // Generate random XOR key
        byte[] key = new byte[32];
        random.nextBytes(key);

        // Build encrypted data: magic + key length + key + encrypted data
        byte[] encryptedData = new byte[originalData.length + ENCRYPTED_MAGIC.length];

        // XOR encrypt the SO data
        for (int i = 0; i < originalData.length; i++) {
            encryptedData[i + ENCRYPTED_MAGIC.length] = (byte) (originalData[i] ^ key[i % key.length]);
        }

        // Prepend magic header
        System.arraycopy(ENCRYPTED_MAGIC, 0, encryptedData, 0, ENCRYPTED_MAGIC.length);

        // Write encrypted data back
        writeFile(soFile, encryptedData);

        // Save key alongside the SO file
        File keyFile = new File(soFile.getParentFile(), soFile.getName() + ".key");
        writeFile(keyFile, key);

        logCallback.log("  已加密: " + soFile.getName() + " (" + originalData.length + " bytes)");
    }

    private byte[] readFile(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            return data;
        }
    }

    private void writeFile(File file, byte[] data) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(data);
            fos.flush();
        }
    }
}
