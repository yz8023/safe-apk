package com.ark.jiagu;

import android.content.Context;
import android.util.Log;

import java.io.File;

/**
 * Protection Pipeline Orchestrator.
 *
 * Defines the correct order of protection stages:
 *
 *   1. DEX Obfuscation  (class/field rename, string encryption, control flow, junk code, debug removal)
 *   2. VMP Extraction   (extract method bodies to vmp.bin)
 *   3. VMP Rewrite      (rewrite extracted methods to VM call stubs)
 *   4. DEX Encryption   (native-layer encryption via b())
 *   5. Shell Packing    (generate shell DEX, patch SO, modify manifest)
 *   6. APK Rebuild      (zipalign, sign)
 *
 * Key insight: Obfuscation must run BEFORE VMP because:
 *   - VMP extraction reads method implementations from DEX
 *   - If we obfuscate first, the VMP processes already-obfuscated code
 *   - String encryption / class rename done before VMP means the vmp.bin
 *     contains obfuscated method bodies, making reverse engineering harder
 *
 * VMP and DEX encryption CAN coexist:
 *   - VMP processes the original DEX files (classes.dex, classes2.dex, ...)
 *   - DEX encryption (via b()) encrypts the shell/loader DEX, not the VMP-processed DEX
 *   - The VMP-processed DEX files are loaded at runtime by the shell
 *
 * The old conflict detection (VMP vs DEX encryption) was incorrect and has been removed.
 */
public class ProtectionPipeline {

    private static final String TAG = "ArkPipeline";

    public interface LogCallback {
        void log(String message);
    }

    /**
     * Execute DEX obfuscation stage (runs BEFORE VMP).
     * This is the key change: obfuscate the DEX first, then VMP extracts from
     * the already-obfuscated code.
     *
     * @param workDir Working directory containing extracted DEX files
     * @param settings Current protection settings
     * @param logCallback Log output callback
     * @return true if any obfuscation was applied
     */
    public static boolean executeObfuscationStage(
            File workDir,
            ArkJiaguUtils.ArkSettings settings,
            LogCallback logCallback
    ) {
        return executeObfuscationStage(workDir, settings, logCallback, null);
    }

    public static boolean executeObfuscationStage(
            File workDir,
            ArkJiaguUtils.ArkSettings settings,
            LogCallback logCallback,
            String stubClassName
    ) {
        if (settings == null) return false;

        // Check if any obfuscation feature is enabled
        boolean anyApplied = settings.debugRemoval || settings.classRename ||
                settings.fieldRename || settings.controlFlowObfuscation ||
                settings.junkCodeGeneration || settings.methodOverload ||
                settings.dexHeaderObfuscation || settings.multiDexShuffle ||
                settings.arithmeticObfuscation || settings.gotoInsertion ||
                settings.dptShellStandard || settings.dptShellEnhanced;

        if (!anyApplied) {
            logCallback.log("未启用任何混淆功能，跳过DEX混淆");
            return false;
        }

        // Log which features are enabled
        if (settings.debugRemoval) logCallback.log("开始移除调试信息");
        if (settings.classRename) logCallback.log("开始类名混淆");
        if (settings.fieldRename) logCallback.log("开始字段重命名");
        if (settings.controlFlowObfuscation) logCallback.log("开始控制流混淆");
        if (settings.junkCodeGeneration) logCallback.log("开始垃圾代码注入");
        if (settings.methodOverload) logCallback.log("开始方法重载混淆");
        if (settings.dexHeaderObfuscation) logCallback.log("开始DEX头部混淆");
        if (settings.multiDexShuffle) logCallback.log("开始多DEX打乱");
        if (settings.arithmeticObfuscation) logCallback.log("开始算术混淆");
        if (settings.gotoInsertion) logCallback.log("开始Goto插入混淆");

        // 常量字符串加密已具备实现但分支偏移在校验环境下仍不稳定，暂不启用
        if (settings.constStringEncryption) logCallback.log("  [跳过] 常量字符串加密：分支偏移校验待完善，暂不影响输出");

        // Execute ALL transformations in one pass and write modified DEX to disk
        // 传入stubClassName确保壳代理Application类被保护，不被类重命名破坏
        DexObfuscator obfuscator = new DexObfuscator(workDir, logCallback, stubClassName);
        obfuscator.processAndWriteAll(settings);

        logCallback.log("DEX混淆阶段完成，已写入混淆后的DEX文件");
        return true;
    }

    /**
     * DEX encryption is handled by the native b() method.
     *
     * The native b() function:
     *   1. Reads DEX files from the work directory
     *   2. Validates DEX magic header (dex\n035\0)
     *   3. Encrypts the original DEX files with native encryption
     *   4. Generates the shell DEX
     *   5. Patches the stub SO
     *
     * IMPORTANT: Do NOT encrypt DEX files in Java before b() runs.
     * The previous implementation used DexEncryptor to XOR-encrypt DEX files
     * with an "ARKE" magic header BEFORE b(), which caused b() to reject
     * them as "非法 dex" (illegal DEX). The native code already handles
     * DEX encryption as part of the shell packing process.
     *
     * This method is now a no-op. It's kept for API compatibility.
     *
     * @param workDir Working directory
     * @param settings Current settings
     * @param logCallback Log callback
     * @return always false (encryption handled by native code)
     */
    public static boolean executeEncryptionStage(
            File workDir,
            ArkJiaguUtils.ArkSettings settings,
            LogCallback logCallback
    ) {
        // No-op: DEX encryption is handled by native b() method
        return false;
    }

    /**
     * Execute resource protection stage.
     * Runs before APK rebuild, after DEX processing.
     *
     * @param workDir Working directory
     * @param copiedApk Original APK file
     * @param settings Current settings
     * @param logCallback Log callback
     */
    public static void executeResourceStage(
            File workDir,
            File copiedApk,
            ArkJiaguUtils.ArkSettings settings,
            LogCallback logCallback
    ) {
        if (settings == null) return;

        // 先从APK中提取assets/和res/raw/到工作目录
        boolean needAssets = settings.resourceObfuscation || settings.resourceCompression || settings.assetEncryption;
        if (needAssets && copiedApk != null && copiedApk.isFile()) {
            logCallback.log("开始提取assets资源");
            extractAssetsFromApk(copiedApk, workDir, logCallback);
        }

        if (settings.resourceObfuscation) {
            logCallback.log("开始资源混淆");
            ResourceProtector protector = new ResourceProtector(workDir, copiedApk, logCallback);
            protector.obfuscateResources();
            logCallback.log("资源混淆完成");
        }

        if (settings.resourceCompression) {
            logCallback.log("开始资源压缩");
            ResourceProtector protector = new ResourceProtector(workDir, copiedApk, logCallback);
            protector.compressResources();
            logCallback.log("资源压缩完成");
        }

        if (settings.assetEncryption) {
            logCallback.log("开始资源加密");
            ResourceProtector protector = new ResourceProtector(workDir, copiedApk, logCallback);
            protector.encryptAssets();
            logCallback.log("资源加密完成");
        }
    }

    /**
     * 从APK中提取assets/和res/raw/到工作目录
     */
    private static void extractAssetsFromApk(File apkFile, File workDir, LogCallback logCallback) {
        int extractedCount = 0;
        try (java.util.zip.ZipFile zipFile = new java.util.zip.ZipFile(apkFile)) {
            java.util.Enumeration<? extends java.util.zip.ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                java.util.zip.ZipEntry entry = entries.nextElement();
                String name = entry.getName();
                if (entry.isDirectory()) continue;

                // 提取 assets/ 和 res/raw/ 下的文件
                if (name.startsWith("assets/") || name.startsWith("res/raw/")) {
                    File outFile = new File(workDir, name);
                    outFile.getParentFile().mkdirs();
                    try (java.io.InputStream in = zipFile.getInputStream(entry);
                         java.io.FileOutputStream out = new java.io.FileOutputStream(outFile)) {
                        byte[] buffer = new byte[8192];
                        int len;
                        while ((len = in.read(buffer)) != -1) {
                            out.write(buffer, 0, len);
                        }
                    }
                    extractedCount++;
                }
            }
        } catch (Exception e) {
            logCallback.log("  提取assets失败: " + e.getMessage());
        }
        logCallback.log("  提取assets资源: " + extractedCount + " 个文件");
    }

    /**
     * Execute native library protection stage.
     * Runs after SO patching, before APK rebuild.
     *
     * @param workDir Working directory
     * @param settings Current settings
     * @param logCallback Log callback
     */
    public static void executeNativeStage(
            File workDir,
            ArkJiaguUtils.ArkSettings settings,
            String stubSoFileName,
            LogCallback logCallback
    ) {
        if (settings == null) return;

        if (settings.libEncryption) {
            logCallback.log("开始本地库加密");
            NativeProtector protector = new NativeProtector(workDir, logCallback);
            protector.encryptLibraries(stubSoFileName);
            logCallback.log("本地库加密完成");
        }
    }

    /**
     * Write security configuration file for the protected APK.
     * This file is read by the shell at runtime to enable/disable security checks.
     *
     * @param workDir Working directory
     * @param settings Current settings
     * @param logCallback Log callback
     */
    public static void executeSecurityConfigStage(
            File workDir,
            ArkJiaguUtils.ArkSettings settings,
            LogCallback logCallback
    ) {
        if (settings == null) return;

        // Check if any security feature is enabled
        boolean anyEnabled = settings.antiEmulator || settings.antiRoot ||
                settings.antiDebugger || settings.antiXposed || settings.antiVm ||
                settings.apkIntegrityCheck || settings.memDiskComparison ||
                settings.fridaPipeDetection || settings.fridaThreadDetection ||
                settings.appMultiOpen || settings.javaHook || settings.nativeHook ||
                settings.locationSimulation || settings.deviceModification;

        if (!anyEnabled) {
            logCallback.log("未启用运行时安全检测，跳过配置写入");
            return;
        }

        logCallback.log("开始写入安全检测配置");
        try {
            // Write security config as a simple binary file
            // Format: magic(4) + version(4) + flags(14 bytes, one per feature)
            java.io.FileOutputStream fos = new java.io.FileOutputStream(
                    new File(workDir, "ark_security.bin"));
            java.io.DataOutputStream dos = new java.io.DataOutputStream(fos);

            // Magic: "ARSE"
            dos.writeByte(0x41);
            dos.writeByte(0x52);
            dos.writeByte(0x53);
            dos.writeByte(0x45);

            // Version
            dos.writeInt(1);

            // Flags (14 bytes)
            dos.writeByte(settings.antiEmulator ? 1 : 0);
            dos.writeByte(settings.antiRoot ? 1 : 0);
            dos.writeByte(settings.antiDebugger ? 1 : 0);
            dos.writeByte(settings.antiXposed ? 1 : 0);
            dos.writeByte(settings.antiVm ? 1 : 0);
            dos.writeByte(settings.apkIntegrityCheck ? 1 : 0);
            dos.writeByte(settings.memDiskComparison ? 1 : 0);
            dos.writeByte(settings.fridaPipeDetection ? 1 : 0);
            dos.writeByte(settings.fridaThreadDetection ? 1 : 0);
            dos.writeByte(settings.appMultiOpen ? 1 : 0);
            dos.writeByte(settings.javaHook ? 1 : 0);
            dos.writeByte(settings.nativeHook ? 1 : 0);
            dos.writeByte(settings.locationSimulation ? 1 : 0);
            dos.writeByte(settings.deviceModification ? 1 : 0);

            dos.flush();
            dos.close();
            fos.close();

            int enabledCount = 0;
            if (settings.antiEmulator) enabledCount++;
            if (settings.antiRoot) enabledCount++;
            if (settings.antiDebugger) enabledCount++;
            if (settings.antiXposed) enabledCount++;
            if (settings.antiVm) enabledCount++;
            if (settings.apkIntegrityCheck) enabledCount++;
            if (settings.memDiskComparison) enabledCount++;
            if (settings.fridaPipeDetection) enabledCount++;
            if (settings.fridaThreadDetection) enabledCount++;
            if (settings.appMultiOpen) enabledCount++;
            if (settings.javaHook) enabledCount++;
            if (settings.nativeHook) enabledCount++;
            if (settings.locationSimulation) enabledCount++;
            if (settings.deviceModification) enabledCount++;

            logCallback.log("安全检测配置已写入: " + enabledCount + " 项检测已启用");
        } catch (Exception e) {
            logCallback.log("写入安全配置失败: " + e.getMessage());
        }
    }

    /**
     * Check for feature conflicts.
     * NOTE: VMP and DEX encryption NO LONGER conflict because they operate
     * on different targets (VMP processes original DEX, encryption processes shell DEX).
     *
     * @param settings Current settings
     * @return Array of conflict descriptions, empty if no conflicts
     */
    public static String[] checkConflicts(ArkJiaguUtils.ArkSettings settings) {
        if (settings == null) return new String[0];

        java.util.ArrayList<String> conflicts = new java.util.ArrayList<>();

        // Auto-sign vs signature bypass still conflicts
        if (settings.autoSign && settings.signatureBypass) {
            conflicts.add("自动签名（签名校验）与签名绕过冲突");
        }

        // Resource obfuscation vs asset encryption still conflicts
        // (both modify resource structure, can cause corruption)
        if (settings.resourceObfuscation && settings.assetEncryption) {
            conflicts.add("资源混淆与资源加密冲突");
        }

        if (settings.controlFlowObfuscation && settings.junkCodeGeneration) {
            conflicts.add("控制流混淆与垃圾代码会同时改写方法指令，兼容模式下只能选择一个");
        }

        // VMP vs DEX encryption: NO LONGER A CONFLICT
        // With the new pipeline order (obfuscate → VMP → encrypt),
        // DEX encryption only encrypts the shell DEX, while VMP processes
        // the original DEX files. They operate on different targets.

        return conflicts.toArray(new String[0]);
    }

    /**
     * Auto-resolve conflicts by disabling the lower-priority feature.
     */
    public static void resolveConflicts(
            Context context,
            ArkJiaguUtils.ArkSettings settings,
            LogCallback logCallback
    ) {
        if (settings == null) return;

        android.content.SharedPreferences sp = context.getSharedPreferences(
                ArkSettingsManager.SP_SETTINGS, Context.MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = sp.edit();
        boolean changed = false;

        if (settings.autoSign && settings.signatureBypass) {
            editor.putBoolean(ExtendedArkSettingsManager.KEY_SIGNATURE_BYPASS, false);
            settings.signatureBypass = false;
            logCallback.log("冲突处理：签名校验与签名绕过冲突，已自动禁用签名绕过");
            changed = true;
        }

        if (settings.resourceObfuscation && settings.assetEncryption) {
            editor.putBoolean(ExtendedArkSettingsManager.KEY_ASSET_ENCRYPTION, false);
            settings.assetEncryption = false;
            logCallback.log("冲突处理：资源混淆与资源加密冲突，已自动禁用资源加密");
            changed = true;
        }

        if (settings.controlFlowObfuscation && settings.junkCodeGeneration) {
            editor.putBoolean(ExtendedArkSettingsManager.KEY_JUNK_CODE_GENERATION, false);
            settings.junkCodeGeneration = false;
            logCallback.log("冲突处理：控制流混淆与垃圾代码同时改写指令，已自动禁用垃圾代码以优先保证兼容性");
            changed = true;
        }

        if (changed) {
            editor.apply();
        }
    }
}
