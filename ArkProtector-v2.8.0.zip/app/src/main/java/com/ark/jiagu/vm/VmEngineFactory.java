package com.ark.jiagu.vm;

/**
 * VM 引擎工厂，根据配置名称创建对应引擎实例。
 */
public class VmEngineFactory {

    public static final String MODE_NONE = "NONE";
    public static final String MODE_ORIGINAL = "ORIGINAL";
    public static final String MODE_NMMP = "NMMP";

    public static VmEngine create(String mode) {
        if (MODE_NMMP.equalsIgnoreCase(mode)) {
            return new NmmVmEngine();
        }
        if (MODE_ORIGINAL.equalsIgnoreCase(mode)) {
            return new OriginalVmEngine();
        }
        return new NoneVmEngine();
    }

    public static String[] getAvailableModes() {
        return new String[]{MODE_NONE, MODE_ORIGINAL, MODE_NMMP};
    }

    public static String getDisplayName(String mode) {
        return create(mode).getDisplayName();
    }
}
