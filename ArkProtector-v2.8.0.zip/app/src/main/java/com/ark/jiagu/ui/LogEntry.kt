package com.ark.jiagu.ui

import androidx.compose.ui.graphics.Color

/**
 * 单条日志条目。
 */
data class LogEntry(
    val timestamp: String,
    val level: LogLevel,
    val message: String,
    val rawText: String = message
) {
    val displayText: String
        get() = if (timestamp.isEmpty()) message else "[$timestamp] $message"
}

enum class LogLevel(val color: Color) {
    VERBOSE(Color(0xFF9E9E9E)),
    DEBUG(Color(0xFF2196F3)),
    INFO(Color(0xFFEEEEEE)),
    SUCCESS(Color(0xFF4CAF50)),
    WARNING(Color(0xFFFFC107)),
    ERROR(Color(0xFFF44336)),
    STAGE(Color(0xFF6750A4))
}
