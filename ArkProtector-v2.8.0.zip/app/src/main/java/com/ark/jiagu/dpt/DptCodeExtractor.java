package com.ark.jiagu.dpt;

import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedMethod;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.MethodImplementation;
import com.ark.jiagu.ArkJiaguUtils.LogCallback;

import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.zip.Adler32;

/**
 * dpt-shell 函数抽取器（参考 luoyesiqiu/dpt-shell 实现，并做安全加固）
 *
 * 核心流程：
 * 1. 读取 DEX 的 CodeItem，按小端序解析 header
 * 2. 把原始 insns 字节保存到 bin 文件
 * 3. 在 DEX 中原地写入 return stub
 * 4. 新增一个寄存器作为返回值寄存器，避免污染原方法中的已有寄存器
 * 5. 重新计算 DEX adler32 checksum
 * 6. 运行时由 native 层还原
 */
public class DptCodeExtractor {

    private final File workDir;
    private final LogCallback logCallback;
    private final boolean enhanced;

    public final List<DexCodeItems> allDexCodeItems = new ArrayList<>();
    private int totalExtracted = 0;
    private int totalSkipped = 0;

    public DptCodeExtractor(File workDir, LogCallback logCallback, boolean enhanced) {
        this.workDir = workDir;
        this.logCallback = logCallback;
        this.enhanced = enhanced;
    }

    public File extractAll(File[] dexFiles) throws Exception {
        String tag = enhanced ? "增强版" : "标准版";
        logCallback.log("====== 开始函数抽取（dpt-shell " + tag + "） ======");

        for (int i = 0; i < dexFiles.length; i++) {
            DexCodeItems dexItems = extractDex(dexFiles[i], i);
            if (dexItems != null) allDexCodeItems.add(dexItems);
        }

        logCallback.log("  抽取总计: " + totalExtracted + " 方法, 跳过 " + totalSkipped + " 方法");

        File codeItemFile = new File(workDir, "dpt_codeitems.bin");
        DptCodeItemStore store = new DptCodeItemStore(enhanced);
        store.write(codeItemFile, allDexCodeItems);
        logCallback.log("  CodeItem数据: " + codeItemFile.length() + " 字节");

        File configFile = new File(workDir, "dpt_config.json");
        writeConfig(configFile, dexFiles.length);

        logCallback.log("====== 函数抽取完成 ======");
        return codeItemFile;
    }

    private DexCodeItems extractDex(File dexFile, int dexIndex) throws Exception {
        String dexName = dexFile.getName();
        logCallback.log("  处理: " + dexName);

        byte[] dexData = readFile(dexFile);
        ByteBuffer dexBuf = ByteBuffer.wrap(dexData).order(ByteOrder.LITTLE_ENDIAN);
        DexBackedDexFile dex = DexBackedDexFile.fromInputStream(Opcodes.getDefault(),
                new BufferedInputStream(new ByteArrayInputStream(dexData)));

        // 统计 code offset 出现次数（跳过共享代码）
        Map<Integer, Integer> codeOffsetCount = new HashMap<>();
        for (ClassDef classDef : dex.getClasses()) {
            for (Method method : classDef.getMethods()) {
                MethodImplementation impl = method.getImplementation();
                if (impl == null) continue;
                int codeOff = getCodeOffset(impl);
                if (codeOff > 0) codeOffsetCount.merge(codeOff, 1, Integer::sum);
            }
        }

        List<MethodCodeItem> methodItems = new ArrayList<>();
        File tempDex = new File(workDir, dexName + ".dpt.tmp");
        writeFile(tempDex, dexData);
        RandomAccessFile raf = new RandomAccessFile(tempDex, "rw");

        int extracted = 0, skipped = 0;
        for (ClassDef classDef : dex.getClasses()) {
            for (Method method : classDef.getMethods()) {
                MethodImplementation impl = method.getImplementation();
                if (impl == null) { skipped++; continue; }

                String methodName = method.getName();
                // 跳过构造函数和类初始化器
                if ("<init>".equals(methodName) || "<clinit>".equals(methodName)) {
                    skipped++;
                    continue;
                }

                int codeOffset = getCodeOffset(impl);
                if (codeOffset == 0) { skipped++; continue; }

                if (codeOffsetCount.getOrDefault(codeOffset, 0) > 1) { skipped++; continue; }

                // 使用小端序 ByteBuffer 读取 CodeItem header
                int registersSize = dexBuf.getShort(codeOffset) & 0xFFFF;
                int insSize = dexBuf.getShort(codeOffset + 2) & 0xFFFF;
                int outsSize = dexBuf.getShort(codeOffset + 4) & 0xFFFF;
                int triesSize = dexBuf.getShort(codeOffset + 6) & 0xFFFF;
                int debugInfoOff = dexBuf.getInt(codeOffset + 8);
                int insnsCount = dexBuf.getInt(codeOffset + 12);
                int insnsBytes = insnsCount * 2;

                if (insnsBytes == 0) { skipped++; continue; }

                // 跳过含 try-catch 的方法
                if (triesSize > 0) { skipped++; continue; }

                String returnType = method.getReturnType();

                // 新增一个（宽返回类型两个）寄存器作为返回值寄存器
            boolean isWideReturn = "J".equals(returnType) || "D".equals(returnType);
            int regIncrement = isWideReturn ? 2 : 1;
            int newReg = registersSize;
            if (newReg > 65535 - regIncrement) { skipped++; continue; }

            ReturnStub stub = generateReturnStub(returnType, newReg, insnsBytes);
            if (stub == null) { skipped++; continue; }

                int methodIndex = 0;
                if (method instanceof DexBackedMethod) {
                    methodIndex = ((DexBackedMethod) method).getMethodIndex();
                } else {
                    skipped++;
                    continue;
                }

                int insnsOffset = codeOffset + 16;

                // 读取原始字节码
                byte[] originalBytes = new byte[insnsBytes];
                raf.seek(insnsOffset);
                raf.readFully(originalBytes);

                // 在 DEX 中原地写入 return stub，其余 NOP 填充
                raf.seek(insnsOffset);
                byte[] stubBytes = new byte[insnsBytes];
                System.arraycopy(stub.data, 0, stubBytes, 0, stub.data.length);
                raf.write(stubBytes);

                // 更新 registers_size：新增一个或两个寄存器
                raf.seek(codeOffset);
                raf.writeShort(registersSize + regIncrement);

                // 清除 debug_info_off
                if (debugInfoOff != 0) {
                    raf.seek(codeOffset + 8);
                    raf.writeInt(0);
                }

                MethodCodeItem item = new MethodCodeItem();
                item.methodIndex = methodIndex;
                item.codeOffset = codeOffset;
                item.insnsSize = insnsBytes;
                item.originalBytes = originalBytes;
                item.returnType = returnType;

                if (enhanced) {
                    item.encrypted = true;
                    item.xorKey = (int)(Math.random() * 0xFFFFFFFFL);
                    item.originalBytes = xorEncrypt(item.originalBytes, item.xorKey);
                    item.noiseSeed = (int)(Math.random() * 0xFFFFFFFFL);
                }

                methodItems.add(item);
                extracted++;
            }
        }

        raf.close();

        if (extracted > 0) {
            byte[] modifiedDex = readFile(tempDex);
            // 重新计算并写入 DEX checksum
            fixDexChecksum(modifiedDex);
            writeFile(dexFile, modifiedDex);
        }
        tempDex.delete();

        totalExtracted += extracted;
        totalSkipped += skipped;
        logCallback.log("    " + dexName + ": 抽取" + extracted + "方法, 跳过" + skipped + "方法");

        if (methodItems.isEmpty()) return null;
        return new DexCodeItems(dexIndex, dexName, methodItems);
    }

    private static class ReturnStub {
        byte[] data;
        ReturnStub(byte[] data) { this.data = data; }
    }

    /**
     * 生成 return stub，使用新增寄存器 newReg 作为返回值寄存器。
     * 这样不会污染原方法中已存在的任何寄存器。
     *
     * 根据 newReg 大小选择 const/4 或 const/16；根据返回类型选择 return 变体。
     */
    private ReturnStub generateReturnStub(String returnType, int newReg, int insnsBytes) {
        ByteBuffer buf = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);

        if ("V".equals(returnType)) {
            // return-void (2 bytes)
            if (insnsBytes < 2) return null;
            buf.putShort((short) 0x000e);
        } else {
            // const newReg, 0
            if (newReg <= 15) {
                // const/4 vA, #imm4: 低8位=opcode(0x12), 8-11位=寄存器A, 12-15位=立即数B
                // 格式：AAAA BBBB opop -> 小端序: (A << 8) | (B << 12) | 0x12
                // B=0, A=newReg
                // const/4 + return = 4 bytes total
                if (insnsBytes < 4) return null;
                short insn = (short)((newReg << 8) | 0x12);
                buf.putShort(insn);
            } else if (newReg <= 255) {
                // const/16 vAA, #imm16: opcode 0x13, 然后 AA, 然后 imm16 (little endian)
                // const/16 + return = 6 bytes total
                if (insnsBytes < 6) return null;
                buf.putShort((short)(0x1300 | (newReg & 0xff)));
                buf.putShort((short) 0);
            } else {
                // const vAA, #imm32: opcode 0x14, 然后 AA, 然后 imm32
                // const + return = 8 bytes total
                if (insnsBytes < 8) return null;
                buf.putShort((short)(0x1400 | (newReg & 0xff)));
                buf.putInt(0);
            }

            // return newReg
            if ("J".equals(returnType) || "D".equals(returnType)) {
                // return-wide vAA: opcode 0x10
                if (newReg > 255) return null;
                buf.putShort((short)(0x1000 | (newReg & 0xff)));
            } else if ("I".equals(returnType) || "F".equals(returnType) || "Z".equals(returnType) ||
                       "B".equals(returnType) || "S".equals(returnType) || "C".equals(returnType)) {
                // return vAA: opcode 0x0f
                if (newReg > 255) return null;
                buf.putShort((short)(0x0f00 | (newReg & 0xff)));
            } else {
                // return-object vAA: opcode 0x11
                if (newReg > 255) return null;
                buf.putShort((short)(0x1100 | (newReg & 0xff)));
            }
        }

        byte[] result = new byte[buf.position()];
        buf.rewind();
        buf.get(result);
        return new ReturnStub(result);
    }

    private byte[] xorEncrypt(byte[] data, int key) {
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            int shift = (i & 3) << 3;
            result[i] = (byte) (data[i] ^ ((key >> shift) & 0xFF));
        }
        return result;
    }

    /**
     * 重新计算并写入 DEX adler32 checksum
     */
    private void fixDexChecksum(byte[] dexData) {
        if (dexData == null || dexData.length < 12) return;
        dexData[8] = 0; dexData[9] = 0; dexData[10] = 0; dexData[11] = 0;
        Adler32 adler = new Adler32();
        adler.update(dexData, 0, dexData.length);
        int checksum = (int) adler.getValue();
        ByteBuffer.wrap(dexData).order(ByteOrder.LITTLE_ENDIAN).putInt(8, checksum);
    }

    private void writeConfig(File configFile, int dexCount) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"version\":").append(enhanced ? 2 : 1).append(",\"enhanced\":").append(enhanced);
        sb.append(",\"dexCount\":").append(dexCount);
        sb.append(",\"totalMethods\":").append(totalExtracted);
        sb.append(",\"codeItemFile\":\"dpt_codeitems.bin\"");
        sb.append("}");
        try (FileWriter fw = new FileWriter(configFile)) { fw.write(sb.toString()); }
    }

    private byte[] readFile(File f) throws Exception {
        byte[] data = new byte[(int) f.length()];
        try (FileInputStream fis = new FileInputStream(f)) {
            int read = 0;
            while (read < data.length) {
                int r = fis.read(data, read, data.length - read);
                if (r < 0) break;
                read += r;
            }
        }
        return data;
    }

    private void writeFile(File f, byte[] data) throws Exception {
        try (FileOutputStream fos = new FileOutputStream(f)) { fos.write(data); }
    }

    private int getCodeOffset(MethodImplementation impl) {
        try {
            if (impl instanceof com.android.tools.smali.dexlib2.dexbacked.DexBackedMethodImplementation) {
                java.lang.reflect.Field f = impl.getClass().getDeclaredField("codeOffset");
                f.setAccessible(true);
                return f.getInt(impl);
            }
        } catch (Exception e) { }
        return 0;
    }

    public static class MethodCodeItem {
        public int methodIndex;
        public int codeOffset;
        public int insnsSize;
        public byte[] originalBytes;
        public String returnType;
        public boolean encrypted = false;
        public int xorKey = 0;
        public int noiseSeed = 0;
    }

    public static class DexCodeItems {
        public int dexIndex;
        public String dexName;
        public List<MethodCodeItem> methods;
        public DexCodeItems(int dexIndex, String dexName, List<MethodCodeItem> methods) {
            this.dexIndex = dexIndex; this.dexName = dexName; this.methods = methods;
        }
    }
}
