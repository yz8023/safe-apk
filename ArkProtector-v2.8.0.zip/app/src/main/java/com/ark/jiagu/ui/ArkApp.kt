package com.ark.jiagu.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.ark.jiagu.ArkSettingsTemplateManager
import com.ark.jiagu.ui.theme.ArkTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArkApp(
    state: ArkUiState,
    onSelectApk: () -> Unit,
    onStart: () -> Unit,
    onClearLog: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit
) {
    ArkTheme {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Text(
                            text = "Ark Protector",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                    },
                    actions = {
                        // 设置按钮：直接导航到设置页面
                        IconButton(onClick = { state.selectedPage = 2 }) {
                            Icon(Icons.Outlined.Settings, contentDescription = "设置")
                        }
                        IconButton(onClick = onOpenAbout) {
                            Icon(Icons.Outlined.Info, contentDescription = "关于")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(tonalElevation = 8.dp) {
                    NavigationBarItem(
                        selected = state.selectedPage == 0,
                        onClick = { state.selectedPage = 0 },
                        icon = {
                            Icon(
                                if (state.selectedPage == 0) Icons.Filled.Home else Icons.Outlined.Home,
                                contentDescription = null
                            )
                        },
                        label = { Text("首页") },
                        alwaysShowLabel = false
                    )
                    NavigationBarItem(
                        selected = state.selectedPage == 1,
                        onClick = { state.selectedPage = 1 },
                        icon = {
                            Icon(
                                if (state.selectedPage == 1) Icons.Filled.Terminal else Icons.Outlined.Terminal,
                                contentDescription = null
                            )
                        },
                        label = { Text("日志") },
                        alwaysShowLabel = false
                    )
                    NavigationBarItem(
                        selected = state.selectedPage == 2,
                        onClick = { state.selectedPage = 2 },
                        icon = {
                            Icon(
                                if (state.selectedPage == 2) Icons.Filled.Settings else Icons.Outlined.Settings,
                                contentDescription = null
                            )
                        },
                        label = { Text("设置") },
                        alwaysShowLabel = false
                    )
                }
            },
            floatingActionButton = {
                if (state.selectedPage == 1) {
                    FloatingActionButton(onClick = onClearLog) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "清空日志")
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
            ) {
                when (state.selectedPage) {
                    0 -> HomePage(state, onSelectApk, onStart)
                    1 -> LogsPage(state)
                    2 -> SettingsPage()
                }
            }
        }
    }
}

@Composable
private fun HomePage(
    state: ArkUiState,
    onSelectApk: () -> Unit,
    onStart: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        StatusCard(state)

        ElevatedCard(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "选择目标 APK",
                    style = MaterialTheme.typography.titleMedium
                )
                OutlinedTextField(
                    value = state.selectedApkPath,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("APK 路径") },
                    placeholder = { Text("点击右侧按钮选择 APK 文件") },
                    trailingIcon = {
                        IconButton(onClick = onSelectApk) {
                            Icon(Icons.Default.FolderOpen, contentDescription = "选择 APK")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = onStart,
                    enabled = !state.isProcessing && state.selectedApkPath.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.isProcessing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(if (state.isProcessing) "加固中..." else "开始加固")
                }
            }
        }
    }
}

@Composable
private fun StatusCard(state: ArkUiState) {
    val statusText = if (state.isProcessing) "正在处理" else "就绪"
    val containerColor = if (state.isProcessing) {
        MaterialTheme.colorScheme.secondaryContainer
    } else {
        MaterialTheme.colorScheme.primaryContainer
    }

    ElevatedCard(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = containerColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = statusText,
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
                text = "By Forinxy · 开源学习项目",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LogsPage(state: ArkUiState) {
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current

    // 自动滚动到底部（仅当 autoScroll 开启且日志变化时）
    androidx.compose.runtime.LaunchedEffect(state.logEntries.size, state.autoScroll) {
        if (state.autoScroll && state.logEntries.isNotEmpty()) {
            listState.animateScrollToItem(state.logEntries.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "运行日志 (${state.logEntries.size})",
                style = MaterialTheme.typography.titleMedium
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = state.autoScroll,
                    onClick = { state.autoScroll = !state.autoScroll },
                    label = { Text("自动滚动") },
                    leadingIcon = if (state.autoScroll) {
                        {
                            Icon(
                                Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    } else null
                )
                // 复制全部按钮
                FilterChip(
                    selected = false,
                    onClick = {
                        if (state.logEntries.isNotEmpty()) {
                            val text = state.logEntries.joinToString("\n") { it.displayText }
                            clipboardManager.setText(AnnotatedString(text))
                            android.widget.Toast.makeText(context, "已复制全部日志", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    label = { Text("复制") },
                    leadingIcon = {
                        Icon(
                             Icons.Outlined.ContentCopy,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            // 整个日志面板对外暴露为一个 semantics 节点，避免内部成百上千个 Text 节点
            // 被无障碍系统遍历导致 OOM。
            modifier = Modifier
                .fillMaxSize()
                .clearAndSetSemantics {}
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    // 双击空白区域复制全部日志
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                if (state.logEntries.isNotEmpty()) {
                                    val text = state.logEntries.joinToString("\n") { it.displayText }
                                    clipboardManager.setText(AnnotatedString(text))
                                    android.widget.Toast.makeText(context, "已复制全部日志", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
            ) {
                if (state.logEntries.isEmpty()) {
                    Text(
                        text = "暂无日志",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.align(Alignment.Center),
                        textAlign = TextAlign.Center
                    )
                } else {
                    androidx.compose.foundation.lazy.LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        itemsIndexed(
                            items = state.logEntries,
                            // 使用 index 作为 key 的一部分，避免条目移除时全表重组
                            key = { index, _ -> index }
                        ) { _, entry ->
                            LogItem(
                                entry = entry,
                                onLongPress = {
                                    val text = entry.displayText
                                    clipboardManager.setText(AnnotatedString(text))
                                    android.widget.Toast.makeText(context, "已复制该日志", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LogItem(entry: LogEntry, onLongPress: () -> Unit) {
    val isStage = entry.level == LogLevel.STAGE
    if (isStage) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
            // 单条日志不进入无障碍树，避免 LazyColumn 中可见项被 semantics 系统收集
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clearAndSetSemantics {}
                .combinedClickable(
                    onClick = {},
                    onLongClick = onLongPress
                )
        ) {
            Text(
                text = entry.message,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
    } else {
        Text(
            text = entry.displayText,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            color = when (entry.level) {
                LogLevel.ERROR -> MaterialTheme.colorScheme.error
                LogLevel.WARNING -> LogLevel.WARNING.color
                LogLevel.SUCCESS -> LogLevel.SUCCESS.color
                LogLevel.DEBUG -> LogLevel.DEBUG.color
                LogLevel.VERBOSE -> LogLevel.VERBOSE.color
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            },
            modifier = Modifier
                .fillMaxWidth()
                .clearAndSetSemantics {}
                .combinedClickable(
                    onClick = {},
                    onLongClick = onLongPress
                )
        )
    }
}

// ====================================================================
// 设置页面 - 全新重构：LazyColumn + 可折叠分区 + 完整基础设置 + 安全防护
// ====================================================================

// 设置键常量（与 ArkSettingsManager / ExtendedArkSettingsManager 保持一致）
private const val SP_SETTINGS = "ark_settings"
private const val KEY_RESOURCE_OBFUSCATION = "resource_obfuscation"
private const val KEY_RESOURCE_COMPRESSION = "resource_compression"
private const val KEY_ASSET_ENCRYPTION = "asset_encryption"
private const val KEY_DEX_ENCRYPTION = "dex_encryption"
private const val KEY_STRING_ENCRYPTION = "string_encryption"
private const val KEY_JUNK_CODE = "junk_code_generation"
private const val KEY_SIGNATURE_BYPASS = "signature_bypass"
private const val KEY_FRIDA_PIPE = "frida_pipe_detection"
private const val KEY_FRIDA_THREAD = "frida_thread_detection"
private const val KEY_MEM_DISK = "mem_disk_comparison"
private const val KEY_CONTROL_FLOW = "control_flow_obfuscation"
private const val KEY_CLASS_RENAME = "class_rename"
private const val KEY_FIELD_RENAME = "field_rename"
private const val KEY_CONST_STRING = "const_string_encryption"
private const val KEY_METHOD_OVERLOAD = "method_overload"
private const val KEY_DEBUG_REMOVAL = "debug_removal"
private const val KEY_LIB_ENCRYPTION = "lib_encryption"
private const val KEY_ANTI_EMULATOR = "anti_emulator"
private const val KEY_ANTI_ROOT = "anti_root"
private const val KEY_ANTI_DEBUGGER = "anti_debugger"
private const val KEY_ANTI_XPOSED = "anti_xposed"
private const val KEY_ANTI_VM = "anti_vm"
private const val KEY_APK_INTEGRITY = "apk_integrity_check"
private const val KEY_DEX_HEADER = "dex_header_obfuscation"
private const val KEY_SO_NAME_RAND = "so_name_randomization"
private const val KEY_ARITHMETIC = "arithmetic_obfuscation"
private const val KEY_MULTI_DEX = "multi_dex_shuffle"
private const val KEY_APP_MULTI_OPEN = "app_multi_open"
private const val KEY_JAVA_HOOK = "java_hook"
private const val KEY_NATIVE_HOOK = "native_hook"
private const val KEY_LOCATION_SIM = "location_simulation"
private const val KEY_DEVICE_MOD = "device_modification"
private const val KEY_DEX_STRING_DEC = "dex_string_decryption"
private const val KEY_REFLECTION_CLINIT = "reflection_clinit_injection"
private const val KEY_PROTECT_RULES = "protect_rules"
private const val KEY_ADVANCED_REFLECTION = "advanced_reflection"
private const val KEY_ARITHMETIC_BRANCH = "arithmetic_branch"
private const val KEY_CALL_INDIRECTION = "call_indirection"
private const val KEY_GOTO_INSERTION = "goto_insertion"
private const val KEY_DPT_STANDARD = "dpt_shell_standard"
private const val KEY_DPT_ENHANCED = "dpt_shell_enhanced"
private const val KEY_AUTO_SIGN = "auto_sign"
private const val KEY_DEBUG = "debug"
private const val KEY_VMP_EXTRACT = "enable_vmp_extract"
private const val KEY_USE_CUSTOM_JKS = "use_custom_jks"
private const val KEY_ENABLE_VMP = "enable_vmp_extract"
private const val KEY_CONFLICT_DETECTION = "conflict_detection_enabled"

// ===== 新增安全防护功能键 =====
private const val KEY_ANTI_REPACKAGE = "anti_repackage"
private const val KEY_ANTI_MEM_DUMP = "anti_mem_dump"
private const val KEY_ANTI_INJECTION = "anti_injection"
private const val KEY_SO_SANDBOX = "so_sandbox"
private const val KEY_DEX_VIRTUALIZATION = "dex_virtualization"
private const val KEY_ANTI_DYNAMIC_DEBUG = "anti_dynamic_debug"
private const val KEY_DATA_FILE_PROTECT = "data_file_protect"

// 冲突组定义：每组内的功能互斥，启用全部时只随机选一个
private data class ConflictGroup(val name: String, val keys: List<String>)

private val CONFLICT_GROUPS = listOf(
    ConflictGroup("签名验证", listOf(KEY_AUTO_SIGN, KEY_SIGNATURE_BYPASS)),
    ConflictGroup("资源保护", listOf(KEY_RESOURCE_OBFUSCATION, KEY_ASSET_ENCRYPTION)),
    ConflictGroup("代码混淆", listOf(KEY_CONTROL_FLOW, KEY_JUNK_CODE)),
    ConflictGroup("DPT壳", listOf(KEY_DPT_STANDARD, KEY_DPT_ENHANCED))
)

// 所有开关设置项的定义
private data class SettingItem(
    val key: String,
    val label: String,
    val category: String,
    val description: String = "",
    val isEnabled: Boolean = true
)

private val ALL_SETTINGS = listOf(
    // ===== 资源保护 =====
    SettingItem(KEY_RESOURCE_OBFUSCATION, "资源混淆", "资源保护", "混淆资源文件名称"),
    SettingItem(KEY_RESOURCE_COMPRESSION, "资源压缩", "资源保护", "压缩资源文件减少体积"),
    SettingItem(KEY_ASSET_ENCRYPTION, "资产加密", "资源保护", "加密 assets 目录文件"),

    // ===== 代码保护 =====
    SettingItem(KEY_DEX_ENCRYPTION, "DEX加密", "代码保护", "加密 DEX 文件"),
    SettingItem(KEY_STRING_ENCRYPTION, "字符串加密", "代码保护", "加密字符串常量"),
    SettingItem(KEY_JUNK_CODE, "垃圾代码", "代码保护", "插入无意义代码"),
    SettingItem(KEY_DEX_STRING_DEC, "DEX字符串解密", "代码保护", "运行时解密 DEX 字符串"),
    SettingItem(KEY_REFLECTION_CLINIT, "反射Clinit注入", "代码保护", "通过反射注入 clinit"),
    SettingItem(KEY_PROTECT_RULES, "保护规则", "代码保护", "自定义保护规则"),
    SettingItem(KEY_LIB_ENCRYPTION, "本地库加密", "代码保护", "加密 native 库"),

    // ===== 签名验证 =====
    SettingItem(KEY_SIGNATURE_BYPASS, "签名绕过", "签名验证", "绕过签名校验"),
    SettingItem(KEY_AUTO_SIGN, "自动签名", "签名验证", "打包后自动签名"),

    // ===== 反调试 =====
    SettingItem(KEY_FRIDA_PIPE, "Frida管道检测", "反调试", "检测 Frida 管道"),
    SettingItem(KEY_FRIDA_THREAD, "Frida线程检测", "反调试", "检测 Frida 线程"),
    SettingItem(KEY_MEM_DISK, "内存磁盘比较", "反调试", "比较内存与磁盘文件"),
    SettingItem(KEY_JAVA_HOOK, "Java Hook检测", "反调试", "检测 Java Hook 框架"),
    SettingItem(KEY_NATIVE_HOOK, "Native Hook检测", "反调试", "检测 Native Hook 框架"),

    // ===== 混淆 =====
    SettingItem(KEY_CONTROL_FLOW, "控制流混淆", "混淆", "混淆控制流"),
    SettingItem(KEY_CLASS_RENAME, "类重命名", "混淆", "重命名类名"),
    SettingItem(KEY_FIELD_RENAME, "字段重命名", "混淆", "重命名字段名"),
    SettingItem(KEY_CONST_STRING, "常量字符串加密", "混淆", "加密常量字符串"),
    SettingItem(KEY_METHOD_OVERLOAD, "方法重载", "混淆", "重载方法名"),
    SettingItem(KEY_DEBUG_REMOVAL, "调试信息移除", "混淆", "移除调试信息"),
    SettingItem(KEY_ADVANCED_REFLECTION, "高级反射混淆", "混淆"),
    SettingItem(KEY_ARITHMETIC_BRANCH, "算术分支混淆", "混淆"),
    SettingItem(KEY_CALL_INDIRECTION, "调用间接化", "混淆"),
    SettingItem(KEY_GOTO_INSERTION, "Goto插入", "混淆"),
    SettingItem(KEY_DPT_STANDARD, "DPT函数抽取(标准)", "混淆"),
    SettingItem(KEY_DPT_ENHANCED, "DPT函数抽取(增强)", "混淆"),

    // ===== 环境检测 =====
    SettingItem(KEY_ANTI_EMULATOR, "反模拟器", "环境检测"),
    SettingItem(KEY_ANTI_ROOT, "反Root", "环境检测"),
    SettingItem(KEY_ANTI_DEBUGGER, "反调试器", "环境检测"),
    SettingItem(KEY_ANTI_XPOSED, "反Xposed", "环境检测"),
    SettingItem(KEY_ANTI_VM, "反虚拟机", "环境检测"),
    SettingItem(KEY_APK_INTEGRITY, "APK完整性校验", "环境检测"),
    SettingItem(KEY_LOCATION_SIM, "位置模拟检测", "环境检测"),
    SettingItem(KEY_DEVICE_MOD, "设备篡改检测", "环境检测"),
    SettingItem(KEY_APP_MULTI_OPEN, "应用多开检测", "环境检测"),

    // ===== 高级混淆 =====
    SettingItem(KEY_DEX_HEADER, "DEX头部混淆", "高级混淆"),
    SettingItem(KEY_SO_NAME_RAND, "SO名称随机化", "高级混淆"),
    SettingItem(KEY_ARITHMETIC, "算术混淆", "高级混淆"),
    SettingItem(KEY_MULTI_DEX, "多DEX打乱", "高级混淆"),

    // ===== 安全防护（新增市场功能） =====
    SettingItem(KEY_ANTI_REPACKAGE, "防二次打包", "安全防护", "防止 APK 被反编译后重新打包"),
    SettingItem(KEY_ANTI_MEM_DUMP, "防内存dump", "安全防护", "防止运行时内存被转储提取"),
    SettingItem(KEY_ANTI_INJECTION, "防注入", "安全防护", "防止动态库注入攻击"),
    SettingItem(KEY_SO_SANDBOX, "SO代码沙箱", "安全防护", "在沙箱环境中运行 native 代码"),
    SettingItem(KEY_DEX_VIRTUALIZATION, "DEX指令虚拟化", "安全防护", "将 DEX 字节码转为虚拟机指令执行"),
    SettingItem(KEY_ANTI_DYNAMIC_DEBUG, "防动态调试", "安全防护", "检测并阻止动态调试器附加"),
    SettingItem(KEY_DATA_FILE_PROTECT, "数据文件保护", "安全防护", "保护应用数据文件不被篡改或提取"),
)

// 分类显示顺序与图标定义
private data class CategoryInfo(
    val key: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

private val CATEGORY_ORDER = listOf(
    CategoryInfo("资源保护", "资源保护", Icons.Outlined.Shield),
    CategoryInfo("代码保护", "代码保护", Icons.Outlined.Code),
    CategoryInfo("签名验证", "签名验证", Icons.Outlined.VerifiedUser),
    CategoryInfo("反调试", "反调试", Icons.Outlined.BugReport),
    CategoryInfo("混淆", "混淆", Icons.Outlined.AutoFixHigh),
    CategoryInfo("环境检测", "环境检测", Icons.Outlined.DevicesOther),
    CategoryInfo("高级混淆", "高级混淆", Icons.Outlined.Engineering),
    CategoryInfo("安全防护", "安全防护", Icons.Outlined.Security)
)

// 按分类分组的设置项
private val SETTINGS_BY_CATEGORY: Map<String, List<SettingItem>> by lazy {
    ALL_SETTINGS.groupBy { it.category }
}

// ====================================================================
// 设置页面主入口
// ====================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsPage() {
    val context = LocalContext.current
    val sp = context.getSharedPreferences(SP_SETTINGS, android.content.Context.MODE_PRIVATE)
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()

    // 当前设置值的状态
    var settingsValues by remember { mutableStateOf(loadAllSettings(sp)) }
    // 模板相关状态
    var templateName by remember { mutableStateOf("") }
    var savedTemplates by remember { mutableStateOf<List<String>>(emptyList()) }
    var showTemplateMenu by remember { mutableStateOf(false) }
    // 冲突警告
    var conflictMessage by remember { mutableStateOf("") }
    // 折叠状态
    var basicExpanded by remember { mutableStateOf(true) }
    var expandedCategories by remember { mutableStateOf(mutableSetOf<String>()) }

    // 基础设置值
    var soName by remember { mutableStateOf(sp.getString("so_name", "x3g") ?: "x3g") }
    var stubClass by remember { mutableStateOf(sp.getString("stub_class_name", "com.ark.safe.StubApp") ?: "com.ark.safe.StubApp") }
    var savePath by remember { mutableStateOf(sp.getString("save_path", "/storage/emulated/0/") ?: "/storage/emulated/0/") }
    var vmEngine by remember { mutableStateOf(sp.getString("vm_engine", "NONE") ?: "NONE") }
    var debugMode by remember { mutableStateOf(sp.getBoolean("debug", false)) }
    var vmpExtract by remember { mutableStateOf(sp.getBoolean("enable_vmp_extract", false)) }
    var autoSign by remember { mutableStateOf(sp.getBoolean("auto_sign", false)) }
    var useCustomJks by remember { mutableStateOf(sp.getBoolean(KEY_USE_CUSTOM_JKS, false)) }
    var jksPath by remember { mutableStateOf(sp.getString("custom_jks_path", "") ?: "") }
    var jksStorePassword by remember { mutableStateOf(sp.getString("custom_jks_store_password", "") ?: "") }
    var jksAlias by remember { mutableStateOf(sp.getString("custom_jks_alias", "") ?: "") }
    var jksKeyPassword by remember { mutableStateOf(sp.getString("custom_jks_key_password", "") ?: "") }

    // 加载模板列表
    fun refreshTemplates() {
        val tm = ArkSettingsTemplateManager(context)
        savedTemplates = tm.listTemplates()
    }

    // 刷新时加载
    LaunchedEffect(Unit) {
        refreshTemplates()
    }

    // 切换分类折叠
    fun toggleCategory(category: String) {
        val current = expandedCategories.toMutableSet()
        if (current.contains(category)) current.remove(category) else current.add(category)
        expandedCategories = current
    }

    // 处理开关变更（含冲突检测）- 优化：只更新特定设置，不重新加载所有设置
    fun handleToggle(item: SettingItem, newValue: Boolean) {
        if (newValue) {
            val conflictGroup = CONFLICT_GROUPS.find { g -> item.key in g.keys }
            if (conflictGroup != null) {
                val otherEnabled = conflictGroup.keys.filter { it != item.key }
                    .any { settingsValues[it] == true }
                if (otherEnabled) {
                    val editor = sp.edit()
                    val newValues = settingsValues.toMutableMap()
                    conflictGroup.keys.forEach { k ->
                        val enabled = k == item.key
                        editor.putBoolean(k, enabled)
                        newValues[k] = enabled
                    }
                    editor.apply()
                    conflictMessage = "已自动关闭「${conflictGroup.name}」中的其他选项"
                    settingsValues = newValues
                    return
                }
            }
            sp.edit().putBoolean(item.key, true).apply()
            conflictMessage = ""
            settingsValues = settingsValues + (item.key to true)
        } else {
            sp.edit().putBoolean(item.key, false).apply()
            settingsValues = settingsValues + (item.key to false)
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // ===== 快速操作栏 =====
        item(key = "quick_actions") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        enableAllWithConflict(sp, settingsValues)
                        // 直接更新内存中的状态，避免重新加载
                        val newValues = mutableMapOf<String, Boolean>()
                        val processedGroups = mutableSetOf<String>()
                        ALL_SETTINGS.forEach { item ->
                            val group = CONFLICT_GROUPS.find { g -> item.key in g.keys }
                            if (group != null) {
                                if (group.name !in processedGroups) {
                                    processedGroups.add(group.name)
                                    val randomKey = group.keys.random()
                                    group.keys.forEach { k -> newValues[k] = (k == randomKey) }
                                }
                            } else {
                                newValues[item.key] = true
                            }
                        }
                        settingsValues = newValues
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Outlined.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("一键启用", style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(
                    onClick = {
                        disableAll(sp)
                        // 直接更新内存中的状态，避免重新加载
                        settingsValues = ALL_SETTINGS.associate { it.key to false }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Outlined.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("一键禁用", style = MaterialTheme.typography.labelMedium)
                }
                OutlinedButton(
                    onClick = { showTemplateMenu = !showTemplateMenu },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("模板", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        // ===== 冲突警告 =====
        if (conflictMessage.isNotEmpty()) {
            item(key = "conflict_warning") {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Outlined.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            conflictMessage,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = { conflictMessage = "" },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Outlined.Close, contentDescription = "关闭", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // ===== 模板面板（可折叠） =====
        if (showTemplateMenu) {
            item(key = "template_panel") {
                ElevatedCard(
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .animateContentSize()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                Icons.Outlined.Bookmarks,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("设置模板", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.weight(1f))
                            IconButton(
                                onClick = { showTemplateMenu = false },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Outlined.Close, contentDescription = "关闭", modifier = Modifier.size(16.dp))
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = templateName,
                                onValueChange = { templateName = it },
                                placeholder = { Text("模板名称") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (templateName.isNotBlank()) {
                                        val tm = ArkSettingsTemplateManager(context)
                                        tm.saveTemplate(templateName.trim(), settingsValues)
                                        templateName = ""
                                        refreshTemplates()
                                        android.widget.Toast.makeText(context, "模板已保存", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Outlined.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("保存", style = MaterialTheme.typography.labelMedium)
                            }
                        }

                        if (savedTemplates.isNotEmpty()) {
                            Spacer(Modifier.height(12.dp))
                            HorizontalDivider()
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "已保存的模板",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(4.dp))
                            savedTemplates.forEach { name ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 2.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Outlined.Restore,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            name,
                                            style = MaterialTheme.typography.bodyMedium,
                                            modifier = Modifier.weight(1f)
                                        )
                                        TextButton(
                                            onClick = {
                                                val tm = ArkSettingsTemplateManager(context)
                                                val template = tm.loadTemplate(name)
                                                applyTemplate(sp, template)
                                                // 直接更新内存中的状态，避免重新加载
                                                val newValues = ALL_SETTINGS.associate { it.key to false }.toMutableMap()
                                                template.forEach { (key, value) -> newValues[key] = value }
                                                settingsValues = newValues
                                                android.widget.Toast.makeText(context, "已应用模板: $name", android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Text("应用", style = MaterialTheme.typography.labelSmall)
                                        }
                                        IconButton(
                                            onClick = {
                                                templateName = name
                                                android.widget.Toast.makeText(context, "输入同名模板名称并保存即可覆盖", android.widget.Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Outlined.Edit, contentDescription = "编辑", modifier = Modifier.size(16.dp))
                                        }
                                        IconButton(
                                            onClick = {
                                                val tm = ArkSettingsTemplateManager(context)
                                                tm.deleteTemplate(name)
                                                refreshTemplates()
                                                android.widget.Toast.makeText(context, "已删除: $name", android.widget.Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                Icons.Outlined.Delete,
                                                contentDescription = "删除",
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ===== 基础设置卡片（可折叠） =====
        item(key = "basic_settings_header") {
            ElevatedCard(
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize()
                ) {
                    // 折叠头部（可点击）
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { basicExpanded = !basicExpanded }
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Outlined.Tune,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "基础设置",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        val rotationAngle by animateFloatAsState(
                            targetValue = if (basicExpanded) 180f else 0f,
                            label = "basic_expand_rotation"
                        )
                        Icon(
                            Icons.Default.KeyboardArrowDown,
                            contentDescription = if (basicExpanded) "收起" else "展开",
                            modifier = Modifier.rotate(rotationAngle)
                        )
                    }

                    if (basicExpanded) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // SO 名称
                            var showSoNamePresetDialog by remember { mutableStateOf(false) }

                            SettingsTextField(
                                label = "SO 名称",
                                value = soName,
                                onValueChange = {
                                    soName = it
                                    sp.edit().putString("so_name", it).apply()
                                },
                                trailingIcon = {
                                    Row {
                                        // 预设按钮
                                        IconButton(onClick = { showSoNamePresetDialog = true }) {
                                            Icon(Icons.Outlined.List, contentDescription = "选择预设", modifier = Modifier.size(18.dp))
                                        }
                                        // 随机选择按钮
                                        IconButton(onClick = {
                                            // 从所有预设的特征文件中随机选择
                                            val allFeatureNames = listOf(
                                                "ArkStub", "jiagu", "jiagu_vip", "tup", "shell-super",
                                                "shell-superv", "SecShell", "DexHelper", "ijiami.ajm",
                                                "ijiami.dat", "chaosvmp", "egis", "aliprotect.dat",
                                                "fakejni", "ashield", "baiduprotect", "sagittarius6",
                                                "nqshield", "nesec", "APKProtect", "dexprotector",
                                                "kwscmm", "x3g", "itsec", "apssec", "rsprotect",
                                                "uusafe", "cmvmp", "reincp", "mxldd", "senshudo",
                                                "arm_protect", "omas", "pairipcore", "venSec",
                                                "ahope", "covault-appsec", "zprotect", "EP_arm",
                                                "shadowsafety", "沐雪", "Master-Mu"
                                            )
                                            val randomName = allFeatureNames.random()
                                            soName = randomName
                                            sp.edit().putString("so_name", randomName).apply()
                                        }) {
                                            Icon(Icons.Outlined.Casino, contentDescription = "随机选择", modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            )

                            // SO 名称预设对话框
                            if (showSoNamePresetDialog) {
                                // 从 JSON 加载预设
                                data class SoPreset(val title: String, val name: String, val category: String)
                                val allPresets = remember {
                                    try {
                                        val json = context.assets.open("so_name_presets.json")
                                            .bufferedReader().use { it.readText() }
                                        val arr = org.json.JSONArray(json)
                                        (0 until arr.length()).map { i ->
                                            val obj = arr.getJSONObject(i)
                                            SoPreset(
                                                obj.getString("title"),
                                                obj.getString("name"),
                                                obj.optString("category", "其他")
                                            )
                                        }
                                    } catch (e: Exception) {
                                        listOf(SoPreset("Ark默认", "ArkStub", "基础"))
                                    }
                                }
                                val categories = remember(allPresets) {
                                    listOf("全部") + allPresets.map { it.category }.distinct()
                                }
                                var selectedCategory by remember { mutableStateOf("全部") }
                                var searchText by remember { mutableStateOf("") }
                                var selectedPreset by remember { mutableStateOf(soName) }

                                val filteredPresets = remember(selectedCategory, searchText, allPresets) {
                                    allPresets.filter { p ->
                                        (selectedCategory == "全部" || p.category == selectedCategory) &&
                                        (searchText.isEmpty() || p.title.contains(searchText, ignoreCase = true) || p.name.contains(searchText, ignoreCase = true))
                                    }
                                }

                                AlertDialog(
                                    onDismissRequest = { showSoNamePresetDialog = false },
                                    title = {
                                        Column {
                                            Text("SO 名称预设", style = MaterialTheme.typography.titleMedium)
                                            Text("共 ${allPresets.size} 个预设方案",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    text = {
                                        Column(modifier = Modifier.fillMaxWidth()) {
                                            // 搜索框
                                            OutlinedTextField(
                                                value = searchText,
                                                onValueChange = { searchText = it },
                                                placeholder = { Text("搜索厂商或名称...") },
                                                leadingIcon = {
                                                    Icon(Icons.Outlined.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                                                },
                                                trailingIcon = {
                                                    if (searchText.isNotEmpty()) {
                                                        IconButton(onClick = { searchText = "" }) {
                                                            Icon(Icons.Outlined.Clear, contentDescription = "清除", modifier = Modifier.size(16.dp))
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                                singleLine = true,
                                                textStyle = MaterialTheme.typography.bodySmall
                                            )

                                            // 分类标签 - 可滚动
                                            androidx.compose.foundation.lazy.LazyRow(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                modifier = Modifier.padding(bottom = 8.dp)
                                            ) {
                                                items(categories) { cat ->
                                                    FilterChip(
                                                        selected = selectedCategory == cat,
                                                        onClick = { selectedCategory = cat },
                                                        label = {
                                                            Text(cat, style = MaterialTheme.typography.labelSmall)
                                                        },
                                                        leadingIcon = if (selectedCategory == cat) {
                                                            { Icon(Icons.Outlined.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                                        } else null
                                                    )
                                                }
                                            }

                                            // 预设列表
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .heightIn(max = 320.dp)
                                                    .verticalScroll(rememberScrollState()),
                                                verticalArrangement = Arrangement.spacedBy(2.dp)
                                            ) {
                                                if (filteredPresets.isEmpty()) {
                                                    Text("无匹配结果",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        modifier = Modifier.padding(16.dp))
                                                }
                                                filteredPresets.forEach { preset ->
                                                    val isSelected = selectedPreset == preset.name
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .clip(RoundedCornerShape(10.dp))
                                                            .clickable { selectedPreset = preset.name }
                                                            .background(
                                                                if (isSelected)
                                                                    MaterialTheme.colorScheme.primaryContainer
                                                                else
                                                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                                                            )
                                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        // 选择指示器
                                                        Box(
                                                            modifier = Modifier
                                                                .size(20.dp)
                                                                .clip(RoundedCornerShape(6.dp))
                                                                .background(
                                                                    if (isSelected)
                                                                        MaterialTheme.colorScheme.primary
                                                                    else
                                                                        MaterialTheme.colorScheme.outlineVariant
                                                                ),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            if (isSelected) {
                                                                Icon(Icons.Outlined.Check, contentDescription = null,
                                                                    modifier = Modifier.size(14.dp),
                                                                    tint = MaterialTheme.colorScheme.onPrimary)
                                                            }
                                                        }
                                                        Spacer(Modifier.width(10.dp))
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(preset.title,
                                                                style = MaterialTheme.typography.bodyMedium,
                                                                color = if (isSelected)
                                                                    MaterialTheme.colorScheme.onPrimaryContainer
                                                                else
                                                                    MaterialTheme.colorScheme.onSurface)
                                                            Text("lib${preset.name}.so",
                                                                style = MaterialTheme.typography.bodySmall,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                                                        }
                                                        // 分类标签
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                                                        ) {
                                                            Text(preset.category,
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        Button(onClick = {
                                            soName = selectedPreset
                                            sp.edit().putString("so_name", selectedPreset).apply()
                                            showSoNamePresetDialog = false
                                        }) {
                                            Text("确定")
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(onClick = { showSoNamePresetDialog = false }) {
                                            Text("取消")
                                        }
                                    }
                                )
                            }

                            // 壳类名
                            SettingsTextField(
                                label = "壳类名 (Stub Class)",
                                value = stubClass,
                                onValueChange = {
                                    stubClass = it
                                    sp.edit().putString("stub_class_name", it).apply()
                                },
                                trailingIcon = {
                                    if (stubClass.isNotEmpty()) {
                                        IconButton(onClick = {
                                            stubClass = ""
                                            sp.edit().putString("stub_class_name", "").apply()
                                        }) {
                                            Icon(Icons.Outlined.Clear, contentDescription = "清除", modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            )

                            // 保存路径
                            SettingsTextField(
                                label = "保存路径",
                                value = savePath,
                                onValueChange = {
                                    savePath = it
                                    sp.edit().putString("save_path", it).apply()
                                },
                                trailingIcon = {
                                    if (savePath.isNotEmpty()) {
                                        IconButton(onClick = {
                                            savePath = ""
                                            sp.edit().putString("save_path", "").apply()
                                        }) {
                                            Icon(Icons.Outlined.Clear, contentDescription = "清除", modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            )

                            // VM 引擎选择
                            Column {
                                Text(
                                    "VM 引擎",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("NONE" to "不使用", "ORIGINAL" to "原版", "NMMP" to "NMMP").forEach { (value, label) ->
                                        FilterChip(
                                            selected = vmEngine == value,
                                            onClick = {
                                                vmEngine = value
                                                sp.edit().putString("vm_engine", value).apply()
                                            },
                                            label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                            leadingIcon = if (vmEngine == value) {
                                                {
                                                    Icon(
                                                        Icons.Default.Check,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            } else null
                                        )
                                    }
                                }
                            }

                            HorizontalDivider()

                            // 基础开关
                            SettingToggleRow(
                                label = "调试模式",
                                description = "启用调试输出",
                                checked = debugMode,
                                onCheckedChange = {
                                    debugMode = it
                                    sp.edit().putBoolean("debug", it).apply()
                                }
                            )

                            SettingToggleRow(
                                label = "VMP 抽取",
                                description = "启用 VMP 函数抽取",
                                checked = vmpExtract,
                                onCheckedChange = {
                                    vmpExtract = it
                                    sp.edit().putBoolean("enable_vmp_extract", it).apply()
                                }
                            )

                            SettingToggleRow(
                                label = "自动签名",
                                description = "打包后自动签名",
                                checked = autoSign,
                                onCheckedChange = {
                                    autoSign = it
                                    sp.edit().putBoolean("auto_sign", it).apply()
                                }
                            )

                            // 自定义 JKS 开关
                            SettingToggleRow(
                                label = "使用自定义签名文件",
                                description = "使用自定义 JKS keystore 进行签名",
                                checked = useCustomJks,
                                onCheckedChange = {
                                    useCustomJks = it
                                    sp.edit().putBoolean(KEY_USE_CUSTOM_JKS, it).apply()
                                }
                            )

                            // 自定义 JKS 表单（展开/收起）
                            if (useCustomJks) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .animateContentSize()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .padding(14.dp)
                                            .animateContentSize(),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(
                                            "JKS 签名配置",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        SettingsTextField(
                                            label = "JKS 文件路径",
                                            value = jksPath,
                                            onValueChange = {
                                                jksPath = it
                                                sp.edit().putString("custom_jks_path", it).apply()
                                            }
                                        )
                                        SettingsTextField(
                                            label = "Store 密码",
                                            value = jksStorePassword,
                                            onValueChange = {
                                                jksStorePassword = it
                                                sp.edit().putString("custom_jks_store_password", it).apply()
                                            }
                                        )
                                        SettingsTextField(
                                            label = "别名 (Alias)",
                                            value = jksAlias,
                                            onValueChange = {
                                                jksAlias = it
                                                sp.edit().putString("custom_jks_alias", it).apply()
                                            }
                                        )
                                        SettingsTextField(
                                            label = "Key 密码",
                                            value = jksKeyPassword,
                                            onValueChange = {
                                                jksKeyPassword = it
                                                sp.edit().putString("custom_jks_key_password", it).apply()
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }

        // ===== 分类设置区域 =====
        items(items = CATEGORY_ORDER, key = { "category_${it.key}" }) { catInfo ->
            val categoryItems = SETTINGS_BY_CATEGORY[catInfo.key] ?: return@items
            val isExpanded = expandedCategories.contains(catInfo.key)

            ElevatedCard(
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize()
                ) {
                    // 分类头部（可点击折叠/展开）
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { toggleCategory(catInfo.key) }
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            catInfo.icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                catInfo.label,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "${categoryItems.size} 项功能",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        // 已启用数量指示
                        val enabledCount = categoryItems.count { settingsValues[it.key] == true }
                        if (enabledCount > 0) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text(
                                    "$enabledCount",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        val rotationAngle by animateFloatAsState(
                            targetValue = if (isExpanded) 180f else 0f,
                            label = "category_expand_rotation_${catInfo.key}"
                        )
                        Icon(
                            Icons.Default.KeyboardArrowDown,
                            contentDescription = if (isExpanded) "收起" else "展开",
                            modifier = Modifier.rotate(rotationAngle),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // 展开内容
                    if (isExpanded) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            categoryItems.forEach { item ->
                                val currentValue = settingsValues[item.key] ?: false
                                val conflictGroup = CONFLICT_GROUPS.find { g -> item.key in g.keys }
                                SettingToggleCard(
                                    label = item.label,
                                    description = item.description,
                                    checked = currentValue,
                                    hasConflict = conflictGroup != null,
                                    onCheckedChange = { newValue ->
                                        handleToggle(item, newValue)
                                    }
                                )
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                    }
                }
            }
        }

        // 底部留白
        item(key = "bottom_spacer") {
            Spacer(Modifier.height(80.dp))
        }
    }
}

// ====================================================================
// 辅助组合函数
// ====================================================================

/** 基础设置中的文本输入行 */
@Composable
private fun SettingsTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    trailingIcon: @Composable (() -> Unit)? = null
) {
    Column {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            trailingIcon = trailingIcon,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
            )
        )
    }
}

/** 基础设置中的开关行（紧凑样式） */
@Composable
private fun SettingToggleRow(
    label: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (description.isNotEmpty()) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}

/** 分类内的设置开关卡片 */
@Composable
private fun SettingToggleCard(
    label: String,
    description: String,
    checked: Boolean,
    hasConflict: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val colors = MaterialTheme.colorScheme
    val borderColor = remember(hasConflict, checked, colors) {
        if (hasConflict && checked) colors.tertiary else colors.outlineVariant
    }
    val bgColor = remember(checked, colors) {
        if (checked) colors.secondaryContainer.copy(alpha = 0.5f) else colors.surface
    }
    val textColor = remember(checked, colors) {
        if (checked) colors.onSecondaryContainer else colors.onSurface
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        tonalElevation = if (checked) 2.dp else 0.dp,
        border = BorderStroke(
            width = if (hasConflict && checked) 1.5.dp else 0.5.dp,
            color = borderColor
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = textColor
                )
                if (description.isNotEmpty()) {
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (hasConflict) {
                    Text(
                        text = "互斥功能",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange
            )
        }
    }
}

// ====================================================================
// 工具函数
// ====================================================================

/** 从 SharedPreferences 读取所有设置 */
private fun loadAllSettings(sp: android.content.SharedPreferences): Map<String, Boolean> {
    val result = mutableMapOf<String, Boolean>()
    ALL_SETTINGS.forEach { item ->
        result[item.key] = sp.getBoolean(item.key, false)
    }
    return result
}

/** 一键启用全部（自动处理冲突组） */
private fun enableAllWithConflict(sp: android.content.SharedPreferences, current: Map<String, Boolean>) {
    val editor = sp.edit()
    val processedGroups = mutableSetOf<String>()

    ALL_SETTINGS.forEach { item ->
        val group = CONFLICT_GROUPS.find { g -> item.key in g.keys }
        if (group != null) {
            // 冲突组：只随机开启一个
            if (group.name !in processedGroups) {
                processedGroups.add(group.name)
                val randomKey = group.keys.random()
                group.keys.forEach { k ->
                    editor.putBoolean(k, k == randomKey)
                }
            }
        } else {
            // 无冲突，直接开启
            editor.putBoolean(item.key, true)
        }
    }
    editor.apply()
}

/** 一键禁用全部 */
private fun disableAll(sp: android.content.SharedPreferences) {
    val editor = sp.edit()
    ALL_SETTINGS.forEach { item ->
        editor.putBoolean(item.key, false)
    }
    editor.apply()
}

/** 应用模板设置 */
private fun applyTemplate(sp: android.content.SharedPreferences, template: Map<String, Boolean>) {
    val editor = sp.edit()
    // 先全部禁用
    ALL_SETTINGS.forEach { item ->
        editor.putBoolean(item.key, false)
    }
    // 再应用模板
    template.forEach { (key, value) ->
        editor.putBoolean(key, value)
    }
    editor.apply()
}
