package com.ark.jiagu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Resource Protection Engine.
 *
 * Handles three resource protection modes:
 *   1. obfuscateResources(): Obfuscate assets directory (safe, no resources.arsc modification)
 *   2. compressResources(): Compress non-compressed files in assets (safe)
 *   3. encryptAssets(): Encrypt files in the assets/ directory with XOR + key file
 *
 * IMPORTANT: This class does NOT rename files in res/ subdirectories because that
 * would require updating resources.arsc, which is complex and error-prone.
 * Only assets/ (which are accessed by path, not resource ID) are safe to rename.
 */
public class ResourceProtector {

    private static final String TAG = "ResourceProtector";
    private final File workDir;
    private final File apkFile;
    private final ProtectionPipeline.LogCallback logCallback;
    private final SecureRandom random = new SecureRandom();

    public ResourceProtector(File workDir, File apkFile, ProtectionPipeline.LogCallback logCallback) {
        this.workDir = workDir;
        this.apkFile = apkFile;
        this.logCallback = logCallback;
    }

    /**
     * Obfuscate asset file names and shuffle asset directory structure.
     * Only touches assets/ directory - res/ is left untouched to avoid
     * resources.arsc inconsistency.
     *
     * SAFETY: Skip flutter_assets/ and visual/config files to avoid breaking UI.
     */
    public void obfuscateResources() {
        File assetsDir = new File(workDir, "assets");
        if (!assetsDir.isDirectory()) {
            // Flutter应用assets在 flutter_assets/ 子目录
            File flutterAssets = new File(assetsDir, "flutter_assets");
            if (flutterAssets.isDirectory()) {
                logCallback.log("  发现Flutter assets目录: assets/flutter_assets/");
            } else {
                logCallback.log("  [跳过] 无assets目录");
                return;
            }
        } else {
            // 检查是否是Flutter应用
            File flutterAssets = new File(assetsDir, "flutter_assets");
            if (flutterAssets.isDirectory()) {
                logCallback.log("  发现Flutter assets目录: assets/flutter_assets/");
            }
        }

        int renamedCount = 0;
        if (assetsDir.isDirectory()) {
            renamedCount = obfuscateAssetFiles(assetsDir, "");
        }

        // Also shuffle res/raw files (safe - accessed by path, not resource ID)
        File resRawDir = new File(workDir, "res/raw");
        if (resRawDir.isDirectory()) {
            File[] files = resRawDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile() && canModifyResourceFile(file, "obfuscate")) {
                        String obfName = generateObfuscatedName(file.getName());
                        File newFile = new File(resRawDir, obfName);
                        if (!file.renameTo(newFile)) {
                            try {
                                copyFile(file, newFile);
                                file.delete();
                                renamedCount++;
                            } catch (IOException e) {
                                logCallback.log("  重命名失败: " + file.getName());
                            }
                        } else {
                            renamedCount++;
                        }
                    }
                }
            }
        }

        logCallback.log("  资源混淆: 混淆 " + renamedCount + " 个assets/raw文件");
    }

    private int obfuscateAssetFiles(File dir, String prefix) {
        int count = 0;
        File[] files = dir.listFiles();
        if (files == null) return 0;

        // Skip flutter_assets directory entirely - Flutter strictly depends on path names
        if (dir.getName().equals("flutter_assets") || prefix.contains("flutter_assets/")) {
            logCallback.log("  [保护] 跳过Flutter assets目录: " + prefix + dir.getName());
            return 0;
        }

        // Shuffle file order within directory
        List<File> fileList = new ArrayList<>();
        for (File f : files) fileList.add(f);
        Collections.shuffle(fileList, random);

        for (File file : fileList) {
            if (file.isDirectory()) {
                count += obfuscateAssetFiles(file, prefix + file.getName() + "/");
            } else if (file.isFile()) {
                // Skip key files, already-encrypted files, and protected file types
                String name = file.getName();
                if (name.endsWith(".key") || name.endsWith(".enc")) continue;
                if (!canModifyResourceFile(file, "obfuscate")) continue;

                String obfName = generateObfuscatedName(name);
                File newFile = new File(dir, obfName);
                if (!file.renameTo(newFile)) {
                    try {
                        copyFile(file, newFile);
                        file.delete();
                        count++;
                    } catch (IOException e) {
                        logCallback.log("  assets混淆失败: " + name);
                    }
                } else {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * Determine whether a resource file can be safely obfuscated/compressed/encrypted.
     * Flutter assets and visual/config files must remain untouched to avoid UI breakage.
     */
    private boolean canModifyResourceFile(File file, String operation) {
        String name = file.getName().toLowerCase();
        String path = file.getAbsolutePath().toLowerCase();

        // Never touch flutter_assets - Flutter uses exact paths
        if (path.contains("/flutter_assets/") || path.endsWith("/flutter_assets")) {
            return false;
        }

        // Visual assets: icons, images, fonts - must remain accessible
        if (name.endsWith(".png") || name.endsWith(".jpg") || name.endsWith(".jpeg")
                || name.endsWith(".gif") || name.endsWith(".webp") || name.endsWith(".svg")
                || name.endsWith(".ico") || name.endsWith(".bmp")
                || name.endsWith(".ttf") || name.endsWith(".otf") || name.endsWith(".woff") || name.endsWith(".woff2")) {
            return false;
        }

        // Config files often parsed by framework code expecting exact names
        if (name.endsWith(".json") || name.endsWith(".xml") || name.endsWith(".yaml")
                || name.endsWith(".yml") || name.endsWith(".properties") || name.endsWith(".txt")) {
            return false;
        }

        // Key files
        if (name.endsWith(".key") || name.endsWith(".enc")) {
            return false;
        }

        return true;
    }

    /**
     * Compress large files in assets/ directory.
     * Uses GZIP format with a custom header so the shell can identify compressed files.
     * Does NOT touch res/ files (they may be in specific formats like binary XML).
     */
    public void compressResources() {
        File assetsDir = new File(workDir, "assets");
        if (!assetsDir.isDirectory()) {
            logCallback.log("  [跳过] 无assets目录");
            return;
        }

        int compressedCount = 0;
        compressedCount = compressDirectory(assetsDir);

        logCallback.log("  资源压缩: 压缩 " + compressedCount + " 个文件");
    }

    private int compressDirectory(File dir) {
        int count = 0;
        File[] files = dir.listFiles();
        if (files == null) return 0;

        // Skip flutter_assets directory entirely
        String path = dir.getAbsolutePath().toLowerCase();
        if (path.contains("/flutter_assets") || dir.getName().equals("flutter_assets")) {
            logCallback.log("  [保护] 跳过Flutter assets目录压缩");
            return 0;
        }

        for (File file : files) {
            if (file.isDirectory()) {
                count += compressDirectory(file);
            } else if (file.isFile()) {
                // Only compress files > 1KB that are not already compressed and are safe to modify
                if (file.length() > 1024 && !isCompressedFormat(file.getName()) && canModifyResourceFile(file, "compress")) {
                    try {
                        byte[] data = readFile(file);
                        byte[] compressed = compressData(data);
                        if (compressed.length < data.length) {
                            // Write with ARKC magic header so shell can identify
                            byte[] output = new byte[4 + compressed.length];
                            output[0] = 0x41; // A
                            output[1] = 0x52; // R
                            output[2] = 0x4B; // K
                            output[3] = 0x43; // C
                            System.arraycopy(compressed, 0, output, 4, compressed.length);
                            writeFile(file, output);
                            count++;
                        }
                    } catch (IOException e) {
                        logCallback.log("  压缩失败: " + file.getName());
                    }
                }
            }
        }
        return count;
    }

    /**
     * Encrypt files in the assets/ directory using XOR encryption.
     * Also encrypts files in res/raw/ if present.
     * Writes a key file for the shell to decrypt at runtime.
     */
    public void encryptAssets() {
        File assetsDir = new File(workDir, "assets");
        File resRawDir = new File(workDir, "res/raw");

        if (!assetsDir.isDirectory() && !resRawDir.isDirectory()) {
            logCallback.log("  无assets/res/raw目录，跳过资源加密");
            return;
        }

        int encryptedCount = 0;
        byte[] key = new byte[32];
        random.nextBytes(key);

        if (assetsDir.isDirectory()) {
            encryptedCount += encryptDirectory(assetsDir, key);
        }
        if (resRawDir.isDirectory()) {
            encryptedCount += encryptDirectory(resRawDir, key);
        }

        // Save key for shell to decrypt at runtime
        File keyFile = new File(workDir, "assets.key");
        try {
            writeFile(keyFile, key);
        } catch (IOException e) {
            logCallback.log("  保存加密密钥失败");
        }

        logCallback.log("  资源加密: 加密 " + encryptedCount + " 个文件");
    }

    private int encryptDirectory(File dir, byte[] key) {
        int count = 0;
        File[] files = dir.listFiles();
        if (files == null) return 0;

        // Skip flutter_assets directory entirely
        String path = dir.getAbsolutePath().toLowerCase();
        if (path.contains("/flutter_assets") || dir.getName().equals("flutter_assets")) {
            logCallback.log("  [保护] 跳过Flutter assets目录加密");
            return 0;
        }

        for (File file : files) {
            if (file.isDirectory()) {
                count += encryptDirectory(file, key);
            } else if (!file.getName().endsWith(".key") && !file.getName().endsWith(".enc") && canModifyResourceFile(file, "encrypt")) {
                try {
                    byte[] data = readFile(file);
                    // Add ARKE magic header so shell can identify encrypted files
                    byte[] encrypted = new byte[data.length];
                    for (int i = 0; i < data.length; i++) {
                        encrypted[i] = (byte) (data[i] ^ key[i % key.length]);
                    }
                    // Write with magic header
                    byte[] output = new byte[4 + encrypted.length];
                    output[0] = 0x41; // A
                    output[1] = 0x52; // R
                    output[2] = 0x4B; // K
                    output[3] = 0x45; // E
                    System.arraycopy(encrypted, 0, output, 4, encrypted.length);
                    writeFile(file, output);
                    count++;
                } catch (IOException e) {
                    logCallback.log("  加密失败: " + file.getName());
                }
            }
        }
        return count;
    }

    // ===== Utility methods =====

    private String generateObfuscatedName(String originalName) {
        String ext = "";
        int dotIndex = originalName.lastIndexOf('.');
        if (dotIndex >= 0) {
            ext = originalName.substring(dotIndex);
        }

        StringBuilder sb = new StringBuilder();
        int len = 6 + random.nextInt(6);
        String chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        for (int i = 0; i < len; i++) {
            sb.append(chars.charAt(random.nextInt(chars.length())));
        }
        sb.append(ext);
        return sb.toString();
    }

    private boolean isCompressedFormat(String fileName) {
        String lower = fileName.toLowerCase();
        return lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg")
                || lower.endsWith(".gif") || lower.endsWith(".webp") || lower.endsWith(".zip")
                || lower.endsWith(".gz") || lower.endsWith(".so") || lower.endsWith(".enc")
                || lower.endsWith(".key");
    }

    private byte[] compressData(byte[] data) throws IOException {
        java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
        java.util.zip.Deflater deflater = new java.util.zip.Deflater(java.util.zip.Deflater.BEST_COMPRESSION);
        deflater.setInput(data);
        deflater.finish();
        byte[] buffer = new byte[8192];
        while (!deflater.finished()) {
            int count = deflater.deflate(buffer);
            bos.write(buffer, 0, count);
        }
        deflater.end();
        return bos.toByteArray();
    }

    private byte[] readFile(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            return data;
        }
    }

    private void writeFile(File file, byte[] data) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(file)) {
            fos.write(data);
            fos.flush();
        }
    }

    private void copyFile(File src, File dst) throws IOException {
        try (FileInputStream fis = new FileInputStream(src);
             FileOutputStream fos = new FileOutputStream(dst)) {
            byte[] buffer = new byte[8192];
            int len;
            while ((len = fis.read(buffer)) != -1) {
                fos.write(buffer, 0, len);
            }
        }
    }
}
