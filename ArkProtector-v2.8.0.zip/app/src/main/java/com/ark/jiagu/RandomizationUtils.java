package com.ark.jiagu;

import java.security.SecureRandom;
import java.util.Random;

/**
 * 随机化工具类
 * 用于生成随机的SO名称、类名、方法名等，防止被一键解包工具识别
 */
public class RandomizationUtils {

    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    private static final String ALPHANUMERIC = "abcdefghijklmnopqrstuvwxyz0123456789";
    private static final int DEFAULT_RANDOM_LENGTH = 8;
    
    /**
     * 默认特征键
     */
    public static final String DEFAULT_FEATURE_KEY = "ark_default_feature_key";

    /**
     * 生成随机字符串
     * @param length 字符串长度
     * @param useNumeric 是否包含数字
     * @return 随机字符串
     */
    public static String generateRandomString(int length, boolean useNumeric) {
        if (length <= 0) {
            length = DEFAULT_RANDOM_LENGTH;
        }

        String charset = useNumeric ? ALPHANUMERIC : ALPHABET;
        StringBuilder sb = new StringBuilder(length);
        Random random = new SecureRandom();

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(charset.length());
            sb.append(charset.charAt(index));
        }

        return sb.toString();
    }

    /**
     * 生成随机SO名称（lib前缀 + 随机名称 + .so后缀）
     * @param customPrefix 自定义前缀（可选）
     * @return 随机SO名称
     */
    public static String generateRandomSoName(String customPrefix) {
        String randomName = generateRandomString(12, false);
        String prefix = (customPrefix != null && !customPrefix.isEmpty()) ? customPrefix : "lib";
        return prefix + randomName + ".so";
    }

    /**
     * 生成随机SO名称（不带lib和.so后缀）
     * @return 随机SO名称
     */
    public static String generateRandomSoName() {
        return generateRandomString(12, false);
    }

    /**
     * 生成随机类名
     * @param packageName 包名
     * @param customPrefix 自定义前缀（可选）
     * @return 随机类名
     */
    public static String generateRandomClassName(String packageName, String customPrefix) {
        String randomName = generateRandomString(10, false);
        String prefix = (customPrefix != null && !customPrefix.isEmpty()) ? customPrefix : "Ark";

        // 首字母大写
        String className = prefix + Character.toUpperCase(randomName.charAt(0)) + randomName.substring(1);

        if (packageName != null && !packageName.isEmpty()) {
            return packageName + "." + className;
        }

        return className;
    }

    /**
     * 生成随机类名（不带包名）
     * @return 随机类名
     */
    public static String generateRandomClassName() {
        String randomName = generateRandomString(10, false);
        // 首字母大写
        return Character.toUpperCase(randomName.charAt(0)) + randomName.substring(1);
    }

    /**
     * 生成随机方法名
     * @param customPrefix 自定义前缀（可选）
     * @return 随机方法名
     */
    public static String generateRandomMethodName(String customPrefix) {
        String randomName = generateRandomString(8, false);
        String prefix = (customPrefix != null && !customPrefix.isEmpty()) ? customPrefix : "ark";

        // 首字母小写
        String methodName = prefix + Character.toLowerCase(randomName.charAt(0)) + randomName.substring(1);

        return methodName;
    }

    /**
     * 生成随机特征字符串
     * @param length 字符串长度
     * @return 随机特征字符串
     */
    public static String generateRandomFeatureString(int length) {
        return generateRandomString(length, true);
    }

    /**
     * 生成随机特征键
     * @return 随机特征键
     */
    public static String generateRandomFeatureKey() {
        return generateRandomString(8, true);
    }

    /**
     * 混淆类名（将原始类名转换为混淆后的名称）
     * @param originalClassName 原始类名
     * @param customFeature 自定义特征字符串
     * @return 混淆后的类名
     */
    public static String obfuscateClassName(String originalClassName, String customFeature) {
        if (originalClassName == null || originalClassName.isEmpty()) {
            return originalClassName;
        }

        // 提取包名和类名
        int lastDotIndex = originalClassName.lastIndexOf('.');
        String packageName = lastDotIndex > 0 ? originalClassName.substring(0, lastDotIndex) : "";
        String simpleClassName = lastDotIndex > 0 ? originalClassName.substring(lastDotIndex + 1) : originalClassName;

        // 生成混淆后的类名
        String obfuscatedName = generateRandomString(10, false);
        obfuscatedName = Character.toUpperCase(obfuscatedName.charAt(0)) + obfuscatedName.substring(1);

        // 如果有自定义特征，添加到混淆名称中
        if (customFeature != null && !customFeature.isEmpty()) {
            obfuscatedName = customFeature + obfuscatedName;
        }

        if (!packageName.isEmpty()) {
            return packageName + "." + obfuscatedName;
        }

        return obfuscatedName;
    }

    /**
     * 验证随机化配置的有效性
     * @param soName SO名称
     * @param className 类名
     * @return 是否有效
     */
    public static boolean validateRandomizationConfig(String soName, String className) {
        // 验证SO名称
        if (soName != null && !soName.isEmpty()) {
            if (!soName.startsWith("lib") || !soName.endsWith(".so")) {
                return false;
            }
            if (soName.length() < 6) { // lib + 至少1个字符 + .so
                return false;
            }
        }

        // 验证类名
        if (className != null && !className.isEmpty()) {
            if (className.contains(" ") || className.contains("\t") || className.contains("\n")) {
                return false;
            }
            if (!className.matches("^[a-zA-Z_$][a-zA-Z0-9_$]*(\\.[a-zA-Z_$][a-zA-Z0-9_$]*)*$")) {
                return false;
            }
        }

        return true;
    }

    /**
     * 生成随机的VMP section名称
     * @param customFeature 自定义特征字符串
     * @return 随机section名称
     */
    public static String generateRandomSectionName(String customFeature) {
        String randomName = generateRandomString(6, false);
        String prefix = (customFeature != null && !customFeature.isEmpty()) ? customFeature : ".ark";

        return "." + prefix + randomName;
    }
}
