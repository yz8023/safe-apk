package com.ark.jiagu.dpt;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.util.Log;
import dalvik.system.PathClassLoader;
import java.io.*;
import java.lang.reflect.*;
import java.nio.*;
import java.util.*;

/**
 * dpt-shell运行时代理Application
 *
 * 职责（与dpt-shell的ProxyApplication对应）：
 * 1. attachBaseContext: 读取CodeItem数据，合并dexElements
 * 2. 通过反射调用native方法填回字节码（或Java层填回）
 * 3. onCreate: 替换为真实Application并调用其onCreate
 *
 * 注意：本项目已有壳SO(native层)，此代理Application负责：
 * - 读取dpt_codeitems.bin
 * - 将CodeItem数据传递给native壳
 * - 合并dexElements
 * - 替换Application
 */
public class DptProxyApplication extends Application {

    private static final String TAG = "DptProxy";
    private static final String CODEITEM_ASSET = "dpt_codeitems.bin";
    private static final String CONFIG_ASSET = "dpt_config.json";
    private static final String FRAGMENT_MAP_ASSET = "dpt_fragment.map";

    private String realApplicationName = null;
    private Application realApplication = null;
    private boolean enhanced = false;
    private int globalXorKey = 0;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        try {
            // 1. 读取配置
            readConfig(base);

            // 2. 读取CodeItem数据
            byte[] codeItemData = readAsset(base, CODEITEM_ASSET);
            if (codeItemData == null) {
                // 没有CodeItem数据，说明函数抽取未执行或失败，直接返回
                return;
            }

            // 3. 解析CodeItem数据并构建索引
            CodeItemIndex index = parseCodeItems(codeItemData);

            // 4. 尝试通过native壳填回（如果有native方法可用）
            try {
                // 由 DptNativeBridge 将完整 CodeItem 二进制传给壳 SO，native 层统一解析并 patch
                DptNativeBridge.nativeLoadCodeItems(codeItemData, enhanced);
            } catch (UnsatisfiedLinkError e) {
                // native方法不可用，使用Java层填回
                javaPatchCodeItems(base, index);
            }

            // 5. 合并dexElements
            combineDexElements(base);

        } catch (Throwable e) {
            // 出错时不能让应用崩溃，继续启动，但记录日志便于排查
            Log.e(TAG, "DPT attachBaseContext 失败", e);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            replaceApplication();
            if (realApplication != null) {
                realApplication.onCreate();
            }
        } catch (Throwable e) {
            Log.e(TAG, "DPT replaceApplication 失败", e);
        }
    }

    /**
     * 读取配置文件
     */
    private void readConfig(Context ctx) {
        try {
            byte[] configData = readAsset(ctx, CONFIG_ASSET);
            if (configData != null) {
                String json = new String(configData, "UTF-8");
                enhanced = json.contains("\"enhanced\":true");
                // 解析xorKey如果存在
                int idx = json.indexOf("\"xorKey\":");
                if (idx >= 0) {
                    int start = idx + 9;
                    int end = json.indexOf(",", start);
                    if (end < 0) end = json.indexOf("}", start);
                    if (end > start) {
                        globalXorKey = Integer.parseInt(json.substring(start, end).trim());
                    }
                }
            }
        } catch (Exception e) {
            // 忽略
        }
    }

    /**
     * 读取APK中的asset文件
     */
    private byte[] readAsset(Context ctx, String name) {
        try {
            InputStream is = ctx.getAssets().open(name);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            int len;
            while ((len = is.read(buffer)) != -1) {
                baos.write(buffer, 0, len);
            }
            is.close();
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    // ===== CodeItem索引结构 =====

    static class CodeItemEntry {
        int methodIndex;
        int codeOffset;   // DEX 文件中该方法的 CodeItem 偏移（单位：字节）
        int insnsSize;
        int xorKey;
        int noiseSeed;
        byte[] insnsData;
    }

    static class CodeItemIndex {
        // dexIndex -> (methodIndex -> CodeItemEntry)
        Map<Integer, Map<Integer, CodeItemEntry>> dexMap = new HashMap<>();
        boolean enhanced = false;
    }

    /**
     * 解析CodeItem二进制数据
     * 与DptCodeItemStore.write对应
     */
    private CodeItemIndex parseCodeItems(byte[] data) {
        CodeItemIndex index = new CodeItemIndex();
        ByteBuffer buf = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);

        int version = buf.getShort() & 0xFFFF;
        index.enhanced = (version == 2);
        int dexCount = buf.getShort() & 0xFFFF;

        int[] dexOffsets = new int[dexCount];
        for (int i = 0; i < dexCount; i++) {
            dexOffsets[i] = buf.getInt();
        }

        for (int d = 0; d < dexCount; d++) {
            buf.position(dexOffsets[d]);
            int methodCount = buf.getShort() & 0xFFFF;
            Map<Integer, CodeItemEntry> methodMap = new HashMap<>();

            for (int m = 0; m < methodCount; m++) {
                CodeItemEntry entry = new CodeItemEntry();
                entry.methodIndex = buf.getInt();
                entry.codeOffset = buf.getInt();
                entry.insnsSize = buf.getInt();
                entry.xorKey = buf.getInt();
                entry.noiseSeed = buf.getInt();
                entry.insnsData = new byte[entry.insnsSize];
                buf.get(entry.insnsData);

                // 如果加密了，解密
                if (entry.xorKey != 0) {
                    entry.insnsData = xorDecrypt(entry.insnsData, entry.xorKey);
                }

                methodMap.put(entry.methodIndex, entry);
            }
            index.dexMap.put(d, methodMap);
        }

        return index;
    }

    /**
     * XOR解密
     */
    private byte[] xorDecrypt(byte[] data, int key) {
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            int shift = (i & 3) << 3;
            result[i] = (byte) (data[i] ^ ((key >> shift) & 0xFF));
        }
        return result;
    }

    /**
     * Java层填回CodeItem（备用方案）
     * 通过反射修改DexFile内存中的方法字节码
     * 注意：此方案需要API级别支持，且可能不稳定
     */
    private void javaPatchCodeItems(Context ctx, CodeItemIndex index) {
        // Java层无法直接修改DEX内存
        // 需要依赖native壳的DefineClass hook
        // 此处仅为占位，实际填回由native壳完成
    }

    /**
     * 合并dexElements
     * 与dpt-shell的combineDexElements对应
     * 将壳DEX的dexElements与原DEX合并
     */
    private void combineDexElements(Context ctx) {
        try {
            // 获取当前ClassLoader
            ClassLoader classLoader = ctx.getClassLoader();
            Class<?> baseDexClassLoaderClass = Class.forName("dalvik.system.BaseDexClassLoader");
            Field pathListField = baseDexClassLoaderClass.getDeclaredField("pathList");
            pathListField.setAccessible(true);
            Object pathList = pathListField.get(classLoader);

            // 获取dexElements
            Class<?> dexPathListClass = Class.forName("dalvik.system.DexPathList");
            Field dexElementsField = dexPathListClass.getDeclaredField("dexElements");
            dexElementsField.setAccessible(true);
            Object[] originElements = (Object[]) dexElementsField.get(pathList);

            // 原始APK的sourceDir
            String sourceDir = ctx.getApplicationInfo().sourceDir;
            String nativeLibDir = ctx.getApplicationInfo().nativeLibraryDir;

            // 创建新的ClassLoader加载原始DEX
            PathClassLoader newLoader = new PathClassLoader(sourceDir, nativeLibDir, ClassLoader.getSystemClassLoader());
            Object newPathList = pathListField.get(newLoader);
            Object[] newElements = (Object[]) dexElementsField.get(newPathList);

            // 合并: origin在前, new在后
            Object[] combined = (Object[]) Array.newInstance(originElements.getClass().getComponentType(),
                    originElements.length + newElements.length);
            System.arraycopy(originElements, 0, combined, 0, originElements.length);
            System.arraycopy(newElements, 0, combined, originElements.length, newElements.length);

            // 写回
            dexElementsField.set(pathList, combined);

        } catch (Throwable e) {
            // 忽略
        }
    }

    /**
     * 替换Application
     * 与dpt-shell的replaceApplication对应
     */
    private void replaceApplication() {
        try {
            // 从配置或Meta-INF中读取真实Application类名
            // 这里从AndroidManifest.xml的备份中读取
            realApplicationName = getRealApplicationName();
            if (realApplicationName == null || realApplicationName.isEmpty()) {
                realApplicationName = "android.app.Application";
            }

            if ("android.app.Application".equals(realApplicationName)) {
                realApplication = this;
                return;
            }

            // 创建真实Application实例
            Class<?> realAppClass = Class.forName(realApplicationName);
            realApplication = (Application) realAppClass.newInstance();

            // 调用attachBaseContext
            Method attachMethod = Application.class.getDeclaredMethod("attach", Context.class);
            attachMethod.setAccessible(true);
            attachMethod.invoke(realApplication, this);

            // 替换ActivityThread中的Application
            replaceInActivityThread();

        } catch (Throwable e) {
            realApplication = this;
        }
    }

    /**
     * 在ActivityThread中替换Application
     */
    private void replaceInActivityThread() {
        try {
            Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
            Method currentMethod = activityThreadClass.getDeclaredMethod("currentActivityThread");
            currentMethod.setAccessible(true);
            Object activityThread = currentMethod.invoke(null);

            // 替换mInitialApplication
            Field initialAppField = activityThreadClass.getDeclaredField("mInitialApplication");
            initialAppField.setAccessible(true);
            initialAppField.set(activityThread, realApplication);

            // 替换mAllApplications中的代理Application
            Field allAppsField = activityThreadClass.getDeclaredField("mAllApplications");
            allAppsField.setAccessible(true);
            @SuppressWarnings("unchecked")
            ArrayList<Application> allApps = (ArrayList<Application>) allAppsField.get(activityThread);
            for (int i = 0; i < allApps.size(); i++) {
                if (allApps.get(i) == this) {
                    allApps.set(i, realApplication);
                }
            }

            // 替换LoadedApk中的mApplication
            Field packagesField = activityThreadClass.getDeclaredField("mPackages");
            packagesField.setAccessible(true);
            // 获取当前包信息并替换Application
            // 简化处理：直接修改LoadedApk

        } catch (Throwable e) {
            // 忽略
        }
    }

    /**
     * 获取真实Application类名
     * 从APK的meta-data或配置中读取
     */
    private String getRealApplicationName() {
        // 尝试从asset读取
        try {
            byte[] configData = readAsset(getBaseContext(), CONFIG_ASSET);
            if (configData != null) {
                String json = new String(configData, "UTF-8");
                int idx = json.indexOf("\"appName\":");
                if (idx >= 0) {
                    int start = json.indexOf("\"", idx + 10) + 1;
                    int end = json.indexOf("\"", start);
                    if (end > start) {
                        return json.substring(start, end);
                    }
                }
            }
        } catch (Exception e) {
            // 忽略
        }
        return "android.app.Application";
    }

    @Override
    public String getPackageName() {
        if (realApplicationName != null && !realApplicationName.isEmpty()) {
            return "";
        }
        return super.getPackageName();
    }
}
