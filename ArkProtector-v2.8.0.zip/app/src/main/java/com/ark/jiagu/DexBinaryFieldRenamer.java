package com.ark.jiagu;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;
import java.util.zip.Adler32;

/**
 * 直接操作 DEX 二进制格式的字段重命名器。
 *
 * 与 dexlib2 的 DexPool 方式（需要为每个类创建 ImmutableClassDef 对象）不同，
 * 本类直接在 DEX 文件的字符串表上做替换，无需为每个类创建对象，也无需重新编码整个 DEX。
 *
 * 原理：
 * - DEX 中字段名通过 field_ids.name_idx 指向 string_ids 表
 * - string_ids 中的 string_data_off 指向实际字符串数据
 * - 重命名时只需将新字符串数据写入，更新 string_data_off 即可
 * - 无需改动 class_defs、field_ids、code_items 等任何其他结构
 * - 由于 field_id 的 name_idx 不变，所有指令对 field_id 的引用自动生效
 *
 * 内存占用：仅加载 DEX 文件字节数组 + 少量字符串映射，不创建任何类对象。
 * 对于 17910 个类、2572 个字段，预计内存占用 < 100MB，远低于 384MB 堆限制。
 */
public class DexBinaryFieldRenamer {

    private final Map<String, String> fieldRenameMap;
    private final Set<String> classesWithNativeMethods;
    private final Set<String> protectedClasses;
    private final List<String> protectedPrefixes;

    /**
     * @param fieldRenameMap          Key: "类描述符->字段名:字段类型", Value: 新字段名
     * @param classesWithNativeMethods 含有 native 方法的类描述符集合
     * @param protectedClasses        受保护的类描述符（精确匹配 + 前缀匹配）
     */
    public DexBinaryFieldRenamer(Map<String, String> fieldRenameMap,
                                  Set<String> classesWithNativeMethods,
                                  Set<String> protectedClasses) {
        this.fieldRenameMap = fieldRenameMap;
        this.classesWithNativeMethods = classesWithNativeMethods;
        this.protectedClasses = protectedClasses;
        this.protectedPrefixes = new ArrayList<>();
        // 分离精确匹配和前缀匹配
        for (String p : protectedClasses) {
            if (p.endsWith("/")) {
                protectedPrefixes.add(p);
            }
        }
    }

    /**
     * 直接在 DEX 文件上执行字段重命名（原地修改）。
     * @return true 表示成功，false 表示失败或无需修改
     */
    public boolean renameFields(File dexFile) {
        byte[] data;
        try {
            data = java.nio.file.Files.readAllBytes(dexFile.toPath());
        } catch (IOException e) {
            return false;
        }

        ByteBuffer buf = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);

        // ===== 解析 DEX 头部 =====
        int fileSize = buf.getInt(0x20);
        int stringIdsSize = buf.getInt(0x38);
        int stringIdsOff = buf.getInt(0x3C);
        int typeIdsSize = buf.getInt(0x40);
        int typeIdsOff = buf.getInt(0x44);
        int fieldIdsSize = buf.getInt(0x50);
        int fieldIdsOff = buf.getInt(0x54);

        // ===== 解析 type_ids，获取所有类型描述符 =====
        // type_ids 是一个数组，每个元素是 4 字节的 string_idx
        String[] typeDescriptors = new String[typeIdsSize];
        for (int i = 0; i < typeIdsSize; i++) {
            int strIdx = buf.getInt(typeIdsOff + i * 4);
            typeDescriptors[i] = readString(data, stringIdsOff, buf, strIdx);
        }

        // ===== 解析 field_ids，找出需要重命名的字段 =====
        // field_id 条目: class_idx(2) + type_idx(2) + name_idx(4) = 8 字节
        // 按 name_idx 分组，检查共享字符串情况
        // key: name_idx, value: 使用该字符串的 field_id 索引列表
        Map<Integer, List<Integer>> nameToFieldIds = new HashMap<>();
        for (int i = 0; i < fieldIdsSize; i++) {
            int off = fieldIdsOff + i * 8;
            int nameIdx = buf.getInt(off + 4);
            nameToFieldIds.computeIfAbsent(nameIdx, k -> new ArrayList<>()).add(i);
        }

        // 收集所有需要重命名的 field_id 索引及其新名字
        // key: name_idx, value: 新名字（如果该 name_idx 的所有字段都一致重命名）
        // 对于共享字符串但部分字段不重命名的情况，跳过这些字段
        Map<Integer, String> renameTargets = new LinkedHashMap<>();
        // 记录被跳过的字段（共享字符串冲突）
        int skippedDueToConflict = 0;

        for (int i = 0; i < fieldIdsSize; i++) {
            int off = fieldIdsOff + i * 8;
            int classIdx = buf.getShort(off) & 0xFFFF;
            int nameIdx = buf.getInt(off + 4);
            String classDesc = typeDescriptors[classIdx];
            if (classDesc == null) continue;

            // 跳过受保护类
            if (isProtectedClass(classDesc)) continue;
            if (classesWithNativeMethods.contains(classDesc)) continue;

            // 获取字段名
            String fieldName = readString(data, stringIdsOff, buf, nameIdx);
            String fieldType = classIdx < typeIdsSize ? typeDescriptors[buf.getShort(off + 2) & 0xFFFF] : "";

            String key = classDesc + "->" + fieldName + ":" + fieldType;
            String newName = fieldRenameMap.get(key);
            if (newName == null) continue;

            // 检查共享字符串冲突
            List<Integer> sharers = nameToFieldIds.get(nameIdx);
            if (sharers != null && sharers.size() > 1) {
                // 该字符串被多个字段共享
                // 检查是否所有共享者也都要重命名为同一个名字
                boolean allSame = true;
                for (int otherIdx : sharers) {
                    if (otherIdx == i) continue;
                    int otherOff = fieldIdsOff + otherIdx * 8;
                    int otherClassIdx = buf.getShort(otherOff) & 0xFFFF;
                    String otherClassDesc = typeDescriptors[otherClassIdx];
                    String otherName = readString(data, stringIdsOff, buf, otherIdx);
                    int otherTypeIdx = buf.getShort(otherOff + 2) & 0xFFFF;
                    String otherType = otherTypeIdx < typeIdsSize ? typeDescriptors[otherTypeIdx] : "";
                    String otherKey = otherClassDesc + "->" + otherName + ":" + otherType;
                    String otherNewName = fieldRenameMap.get(otherKey);
                    if (!newName.equals(otherNewName)) {
                        allSame = false;
                        break;
                    }
                }
                if (!allSame) {
                    skippedDueToConflict++;
                    continue;
                }
            }

            // 检查是否已处理过此 name_idx
            String existing = renameTargets.get(nameIdx);
            if (existing != null && !existing.equals(newName)) {
                // 同一 name_idx 被要求映射到不同新名字，不可能，跳过
                skippedDueToConflict++;
                continue;
            }
            renameTargets.put(nameIdx, newName);
        }

        if (renameTargets.isEmpty()) {
            return true; // 无需修改
        }

        // ===== 执行字符串替换 =====
        // 先尝试在原始位置替换（等长或更短时），否则追加到文件末尾
        // 输出缓冲区：原始数据 + 新字符串数据
        ByteArrayOutputStream newStringsBuf = new ByteArrayOutputStream(4096);

        for (Map.Entry<Integer, String> entry : renameTargets.entrySet()) {
            int nameIdx = entry.getKey();
            String newName = entry.getValue();

            int oldStrOff = buf.getInt(stringIdsOff + nameIdx * 4);
            int oldStrLen = getMutf8ByteLength(data, oldStrOff);
            byte[] newStrBytes = encodeMutf8(newName);
            int newStrLen = newStrBytes.length;

            if (newStrLen <= oldStrLen) {
                // 新名字 <= 旧名字的字节长度，可以在原地覆盖
                // 新字符串长度（含 null 终止符）<= 旧字符串长度，直接覆盖
                // 注意：MUTF-8 字符串包含 ULEB128 编码的字符数 + 数据 + null 终止符
                // oldStrOff 指向 ULEB128 字符数，后面是数据
                // 我们需要找到数据和 null 终止符的位置
                int ulebSize = getUleb128Size(data, oldStrOff);
                int dataStart = oldStrOff + ulebSize;
                // 旧数据长度 = oldStrLen - ulebSize (含 null 终止符)
                int oldDataLen = oldStrLen - ulebSize;
                // 新数据长度 = newStrLen (含 null 终止符)
                if (newStrLen <= oldDataLen) {
                    // 可以直接覆盖数据部分，不需要变动 ULEB128 字符数
                    System.arraycopy(newStrBytes, 0, data, dataStart, newStrLen);
                    // 如果新数据更短，用 null 填充剩余空间（实际上是覆盖旧字符串的尾部）
                    if (newStrLen < oldDataLen) {
                        Arrays.fill(data, dataStart + newStrLen, dataStart + oldDataLen, (byte) 0);
                    }
                } else {
                    // 新数据比旧数据长但总字节 <= oldStrLen，需要更新 ULEB128 字符数
                    // 重新编码整个字符串区域
                    byte[] fullNewStr = encodeMutf8StringEntry(newName);
                    System.arraycopy(fullNewStr, 0, data, oldStrOff, fullNewStr.length);
                    if (fullNewStr.length < oldStrLen) {
                        Arrays.fill(data, oldStrOff + fullNewStr.length, oldStrOff + oldStrLen, (byte) 0);
                    }
                }
            } else {
                // 新名字更长，追加到文件末尾
                int newOff = fileSize + newStringsBuf.size();
                byte[] newStrEntry = encodeMutf8StringEntry(newName);
                try {
                    newStringsBuf.write(newStrEntry);
                } catch (IOException e) {
                    return false;
                }
                // 更新 string_ids 中的偏移量
                // 注意：这里操作的是原始 data 数组，追加数据在 newStringsBuf 中
                // 在最终输出时，newStringsBuf 会被追加到 data 末尾
                // 但我们需要在 data 中更新 string_ids 偏移
                // 由于我们不能直接修改 ByteBuffer，操作 byte[] 数组
                int strIdOff = stringIdsOff + nameIdx * 4;
                // 写入新偏移（小端序）
                data[strIdOff] = (byte) (newOff & 0xFF);
                data[strIdOff + 1] = (byte) ((newOff >> 8) & 0xFF);
                data[strIdOff + 2] = (byte) ((newOff >> 16) & 0xFF);
                data[strIdOff + 3] = (byte) ((newOff >> 24) & 0xFF);
            }
        }

        // ===== 构建输出 =====
        byte[] newStringsData = newStringsBuf.toByteArray();
        int newFileSize = fileSize + newStringsData.length;
        byte[] output = Arrays.copyOf(data, newFileSize);
        if (newStringsData.length > 0) {
            System.arraycopy(newStringsData, 0, output, fileSize, newStringsData.length);
        }

        // ===== 更新文件头中的 file_size =====
        // file_size 在偏移 0x20 处，4 字节小端序
        output[0x20] = (byte) (newFileSize & 0xFF);
        output[0x21] = (byte) ((newFileSize >> 8) & 0xFF);
        output[0x22] = (byte) ((newFileSize >> 16) & 0xFF);
        output[0x23] = (byte) ((newFileSize >> 24) & 0xFF);

        // ===== 更新校验和（Adler-32，从字节 12 到文件末尾） =====
        // 校验和在偏移 0x08 处，4 字节小端序
        // 先清零校验和字段
        output[0x08] = 0;
        output[0x09] = 0;
        output[0x0A] = 0;
        output[0x0B] = 0;
        // 计算 Adler-32
        Adler32 adler = new Adler32();
        adler.update(output, 12, newFileSize - 12);
        int checksum = (int) adler.getValue();
        output[0x08] = (byte) (checksum & 0xFF);
        output[0x09] = (byte) ((checksum >> 8) & 0xFF);
        output[0x0A] = (byte) ((checksum >> 16) & 0xFF);
        output[0x0B] = (byte) ((checksum >> 24) & 0xFF);

        // ===== 写入文件 =====
        File tempFile = new File(dexFile.getAbsolutePath() + ".frn");
        try (FileOutputStream fos = new FileOutputStream(tempFile)) {
            fos.write(output);
            fos.flush();
        } catch (IOException e) {
            tempFile.delete();
            return false;
        }

        // 替换原文件
        if (!tempFile.renameTo(dexFile)) {
            try {
                java.nio.file.Files.copy(tempFile.toPath(), dexFile.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                tempFile.delete();
            } catch (IOException e) {
                tempFile.delete();
                return false;
            }
        }

        return true;
    }

    // ===== 工具方法 =====

    /** 读取 DEX 中的 MUTF-8 字符串 */
    private String readString(byte[] data, int stringIdsOff, ByteBuffer buf, int strIdx) {
        int strOff = buf.getInt(stringIdsOff + strIdx * 4);
        if (strOff <= 0 || strOff >= data.length) return "";
        int ulebSize = getUleb128Size(data, strOff);
        int chars = readUleb128(data, strOff);
        int pos = strOff + ulebSize;
        StringBuilder sb = new StringBuilder(chars);
        int read = 0;
        while (read < chars && pos < data.length) {
            int b = data[pos] & 0xFF;
            if (b < 0x80) {
                sb.append((char) b);
                pos++;
            } else if ((b & 0xE0) == 0xC0) {
                int b2 = data[pos + 1] & 0x3F;
                sb.append((char) ((b & 0x1F) << 6 | b2));
                pos += 2;
            } else if ((b & 0xF0) == 0xE0) {
                int b2 = data[pos + 1] & 0x3F;
                int b3 = data[pos + 2] & 0x3F;
                sb.append((char) ((b & 0x0F) << 12 | b2 << 6 | b3));
                pos += 3;
            }
            read++;
        }
        return sb.toString();
    }

    /** 读取 ULEB128 编码的值 */
    private int readUleb128(byte[] data, int offset) {
        int result = 0;
        int shift = 0;
        int pos = offset;
        while (true) {
            int b = data[pos] & 0xFF;
            result |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) break;
            shift += 7;
            pos++;
        }
        return result;
    }

    /** 获取 ULEB128 编码的字节数 */
    private int getUleb128Size(byte[] data, int offset) {
        int pos = offset;
        while ((data[pos] & 0x80) != 0) pos++;
        return pos - offset + 1;
    }

    /** 获取 MUTF-8 字符串条目（ULEB128 字符数 + 数据 + null 终止符）的总字节数 */
    private int getMutf8ByteLength(byte[] data, int offset) {
        int ulebSize = getUleb128Size(data, offset);
        int chars = readUleb128(data, offset);
        int pos = offset + ulebSize;
        int read = 0;
        while (read < chars && pos < data.length) {
            int b = data[pos] & 0xFF;
            if (b < 0x80) {
                pos++;
            } else if ((b & 0xE0) == 0xC0) {
                pos += 2;
            } else if ((b & 0xF0) == 0xE0) {
                pos += 3;
            } else {
                pos++; // 4-byte (supplementary)
            }
            read++;
        }
        // 跳过 null 终止符
        if (pos < data.length && data[pos] == 0) pos++;
        return pos - offset;
    }

    /** 将字符串编码为 MUTF-8 字节（不含 ULEB128 字符数，含 null 终止符） */
    private byte[] encodeMutf8(String str) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(str.length() + 1);
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c == 0) {
                bos.write(0xC0);
                bos.write(0x80);
            } else if (c < 0x80) {
                bos.write(c);
            } else if (c < 0x800) {
                bos.write(0xC0 | (c >> 6));
                bos.write(0x80 | (c & 0x3F));
            } else {
                bos.write(0xE0 | (c >> 12));
                bos.write(0x80 | ((c >> 6) & 0x3F));
                bos.write(0x80 | (c & 0x3F));
            }
        }
        bos.write(0); // null 终止符
        return bos.toByteArray();
    }

    /** 将字符串编码为完整的 MUTF-8 字符串条目（ULEB128 字符数 + 数据 + null 终止符） */
    private byte[] encodeMutf8StringEntry(String str) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(str.length() + 5);
        try {
            writeUleb128(bos, str.length());
            bos.write(encodeMutf8(str));
        } catch (IOException e) {
            // 不可能发生
        }
        return bos.toByteArray();
    }

    /** 写入 ULEB128 编码的值 */
    private void writeUleb128(OutputStream os, int value) throws IOException {
        do {
            int b = value & 0x7F;
            value >>>= 7;
            if (value != 0) b |= 0x80;
            os.write(b);
        } while (value != 0);
    }

    /** 判断类是否受保护 */
    private boolean isProtectedClass(String desc) {
        if (protectedClasses.contains(desc)) return true;
        for (String prefix : protectedPrefixes) {
            if (desc.startsWith(prefix)) return true;
        }
        return false;
    }
}