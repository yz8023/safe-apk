package com.ark.jiagu.vm;

import android.content.Context;
import com.ark.jiagu.ArkJiaguUtils.LogCallback;
import java.io.File;
import static com.ark.jiagu.vm.VmpJiaguEntry.extractMethodsToBin;
import static com.ark.jiagu.vm.VmpJiaguEntry.rewriteExtractedMethodsToVmCallDex;

/**
 * Arkjiagu 原有 VMP 引擎。
 * 抽取方法到 vmp.bin，并改写 DEX 中的方法为 VM 调用壳。
 */
public class OriginalVmEngine implements VmEngine {

    @Override
    public String getName() {
        return "ORIGINAL";
    }

    @Override
    public String getDisplayName() {
        return "Ark VMP（原版）";
    }

    @Override
    public boolean requiresNativeBuild() {
        return false;
    }

    @Override
    public void process(Context context, File workDir, VmEngineSettings settings, LogCallback callback) throws Exception {
        if (callback != null) {
            callback.log("[VMP] 使用 Ark 原版 VM 保护");
        }

        // 将通用 LogCallback 适配到 VmpJiaguEntry 内部接口
        VmpJiaguEntry.LogCallback vmLog = (callback != null)
                ? msg -> callback.log(msg)
                : msg -> {};

        extractMethodsToBin(workDir, vmLog, settings.methodRules);
        rewriteExtractedMethodsToVmCallDex(workDir, vmLog, settings.soName, settings.stubClassName);

        if (callback != null) {
            callback.log("[VMP] 原版 VM 保护处理完成");
        }
    }

    @Override
    public File getOutputBin(File workDir) {
        return new File(workDir, "vmp.bin");
    }

    @Override
    public File getNativeSourceDir(File workDir) {
        return null;
    }
}
