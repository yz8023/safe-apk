package com.ark.jiagu;

import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.AccessFlags;
import com.android.tools.smali.dexlib2.MethodHandleType;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.Field;
import com.android.tools.smali.dexlib2.iface.MethodImplementation;
import com.android.tools.smali.dexlib2.iface.TryBlock;
import com.android.tools.smali.dexlib2.iface.ExceptionHandler;
import com.android.tools.smali.dexlib2.iface.MethodParameter;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.OffsetInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction21t;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction22t;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction31t;
import com.android.tools.smali.dexlib2.iface.instruction.ThreeRegisterInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction23x;
import com.android.tools.smali.dexlib2.iface.reference.CallSiteReference;
import com.android.tools.smali.dexlib2.iface.reference.FieldReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodHandleReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodProtoReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.iface.reference.StringReference;
import com.android.tools.smali.dexlib2.iface.reference.TypeReference;
import com.android.tools.smali.dexlib2.iface.reference.Reference;
import com.android.tools.smali.dexlib2.iface.Annotation;
import com.android.tools.smali.dexlib2.iface.AnnotationElement;
import com.android.tools.smali.dexlib2.iface.value.EncodedValue;
import com.android.tools.smali.dexlib2.iface.value.TypeEncodedValue;
import com.android.tools.smali.dexlib2.iface.value.FieldEncodedValue;
import com.android.tools.smali.dexlib2.iface.value.MethodEncodedValue;
import com.android.tools.smali.dexlib2.iface.value.EnumEncodedValue;
import com.android.tools.smali.dexlib2.iface.value.ArrayEncodedValue;
import com.android.tools.smali.dexlib2.iface.value.AnnotationEncodedValue;
import com.android.tools.smali.dexlib2.immutable.ImmutableAnnotation;
import com.android.tools.smali.dexlib2.immutable.ImmutableAnnotationElement;
import com.android.tools.smali.dexlib2.immutable.value.ImmutableTypeEncodedValue;
import com.android.tools.smali.dexlib2.immutable.value.ImmutableFieldEncodedValue;
import com.android.tools.smali.dexlib2.immutable.value.ImmutableMethodEncodedValue;
import com.android.tools.smali.dexlib2.immutable.value.ImmutableEnumEncodedValue;
import com.android.tools.smali.dexlib2.immutable.value.ImmutableArrayEncodedValue;
import com.android.tools.smali.dexlib2.immutable.value.ImmutableAnnotationEncodedValue;
import com.android.tools.smali.dexlib2.immutable.value.ImmutableEncodedValue;
import com.android.tools.smali.dexlib2.immutable.value.ImmutableEncodedValueFactory;
import com.android.tools.smali.dexlib2.immutable.ImmutableClassDef;
import com.android.tools.smali.dexlib2.immutable.ImmutableExceptionHandler;
import com.android.tools.smali.dexlib2.immutable.ImmutableField;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethod;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethodImplementation;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethodParameter;
import com.android.tools.smali.dexlib2.immutable.ImmutableTryBlock;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction10x;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction10t;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction11n;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction11x;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction20t;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction21t;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction22t;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction31t;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction21s;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction21c;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction22c;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction23x;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction31c;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction31i;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction35c;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction3rc;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction45cc;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableInstruction4rcc;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableCallSiteReference;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableFieldReference;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodHandleReference;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodProtoReference;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodReference;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableStringReference;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableTypeReference;
import com.android.tools.smali.dexlib2.iface.instruction.formats.ArrayPayload;
import com.android.tools.smali.dexlib2.iface.instruction.formats.PackedSwitchPayload;
import com.android.tools.smali.dexlib2.iface.instruction.formats.SparseSwitchPayload;
import com.android.tools.smali.dexlib2.iface.instruction.SwitchElement;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutablePackedSwitchPayload;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableSparseSwitchPayload;
import com.android.tools.smali.dexlib2.immutable.instruction.ImmutableSwitchElement;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

import com.ark.jar.xml2axml.AxmlUtils;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.Adler32;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * DEX Obfuscation Engine - REAL implementation using dexlib2 DexPool writer.
 *
 * Safety notes:
 * - String encryption is DISABLED (needs runtime decryptor stub, otherwise crashes)
 * - Field rename properly updates ALL references: field definitions + FieldReference instructions
 *   (cross-class), skipping native-method classes, serialVersionUID, annotated/synthetic/enum fields
 * - Class rename properly updates ALL reference types: TypeReference, FieldReference, MethodReference
 * - Control flow / junk code / goto insertion properly handle register allocation (const/4 for v0-v15, const/16 for v16+)
 *   The three header-modifying passes are mutually exclusive per method (priority: controlFlow > junkCode > gotoInsertion)
 */
public class DexObfuscator {

    private final File workDir;
    private final ProtectionPipeline.LogCallback logCallback;
    private final SecureRandom random = new SecureRandom();

    private static final String[] PROTECTED_PREFIXES = {
            "Landroid/", "Landroidx/", "Ljava/", "Lkotlin/",
            "Lcom/google/", "Lcom/android/", "Lorg/", "Lcom/ark/",
            // 常见SDK前缀（使用反射或类名加载，不能重命名）
            "Lio/flutter/", "Lio/flutter/plugins/", "Ldagger/", "Lhilt/",
            "Lcom/squareup/", "Lretrofit2/", "Lokhttp3/", "Lcom/bumptech/glide/",
            "Lcom/facebook/", "Lcom/google/firebase/", "Lcom/google/android/gms/",
            "Landroidx/work/", "Landroidx/lifecycle/", "Landroidx/room/",
            // Manifest入口类常见依赖SDK：这些库大量依赖反射、启动器、ServiceLoader或运行时生成代码
            "Lcom/lzf/", "Lcom/starburst/", "Lcom/bytedance/",
            "Lcom/baseflow/", "Ldev/fluttercommunity/"
    };

    private static final String CHARS = "abcdefghijklmnopqrstuvwxyz";
    private static final String CHARS_EXT = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";

    // ===== 常量字符串加密 =====
    // 加密后字符串的前缀标记，shell运行时检测到此前缀会自动解密
    private static final String CONST_STRING_ENC_PREFIX = "ARKS";
    // XOR加密密钥（与shell解密器保持一致）
    private static final byte[] CONST_STRING_XOR_KEY = {0x41, 0x5A, 0x6B, 0x53};

    private final Map<String, String> classRenameMap = new HashMap<>();
    // 字段重命名映射表
    // Key格式: "类描述符->字段名->字段类型"，如 "Lcom/test/Foo;->bar:I"
    // Value: 新字段名
    private final Map<String, String> fieldRenameMap = new HashMap<>();
    // 被重命名字段所属的原始类集合，用于快速判断一个类是否需要字段引用重映射
    private final Set<String> fieldRenamedOwners = new HashSet<>();
    // 含有 native 方法的类集合（二进制重命名器需要）
    private final Set<String> classesWithNativeMethods = new HashSet<>();
    private final Set<String> protectedClasses = new HashSet<>();

    public DexObfuscator(File workDir, ProtectionPipeline.LogCallback logCallback) {
        this(workDir, logCallback, null);
    }

    public DexObfuscator(File workDir, ProtectionPipeline.LogCallback logCallback, String stubClassName) {
        this.workDir = workDir;
        this.logCallback = logCallback;
        // 解析AndroidManifest.xml，提取入口类名（不能被重命名）
        loadProtectedClassesFromManifest();
        // 壳代理Application类必须被保护，否则类重命名会修改它导致Manifest引用失效
        if (stubClassName != null && !stubClassName.isEmpty()) {
            String desc = classNameToDescriptor(stubClassName);
            if (desc != null && !desc.isEmpty()) {
                protectedClasses.add(desc);
                protectedClasses.add(desc + "$Factory;");
                logCallback.log("  保护壳代理Application: " + desc);
            }
        }

        // 保护运行时字符串解密器类，防止其被重命名导致解密调用失败
        protectedClasses.add("Lcom/ark/jiagu/StringDecryptor;");
    }

    /**
     * 从AndroidManifest.xml中提取所有入口类名。
     * 这些类不能被重命名，否则AndroidManifest.xml中的引用会失效导致应用崩溃。
     */
    private void loadProtectedClassesFromManifest() {
        File manifestBinary = new File(workDir, "AndroidManifest.xml");
        if (!manifestBinary.isFile()) {
            logCallback.log("  未找到AndroidManifest.xml，跳过入口类保护");
            return;
        }

        logCallback.log("  开始解析AndroidManifest.xml...");
        try {
            // 解码二进制AXML为明文XML
            File manifestDecoded = new File(workDir, "_manifest_for_obf.xml");
            com.ark.jar.xml2axml.test.Xml2AxmlTool.decode(
                    manifestBinary.getAbsolutePath(),
                    manifestDecoded.getAbsolutePath()
            );

            // 解析XML
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(manifestDecoded);

            // 1. 从 activity/service/receiver/provider/application 标签提取类名
            //    这些标签的 android:name 一定是类名，必须保护，否则Manifest引用失效
            //    同时从 meta-data android:name 提取看起来像类名的值（Initializer等）
            //    不处理 meta-data android:value（几乎从不是类名）
            extractClassNames(doc.getDocumentElement());

            // 清理临时文件
            manifestDecoded.delete();

            logCallback.log("  Manifest保护类: " + protectedClasses.size() + " 个");
            for (String cls : protectedClasses) {
                logCallback.log("    保护: " + cls);
            }
        } catch (Throwable e) {
            logCallback.log("  解析AndroidManifest失败: " + e.getClass().getName() + ": " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void extractClassNames(Element element) {
        if (element == null) return;

        String tagName = element.getTagName();
        // activity, service, receiver, provider, application 标签
        // 这些标签的 android:name 属性一定是一个类名
        if ("activity".equals(tagName) || "service".equals(tagName) ||
            "receiver".equals(tagName) || "provider".equals(tagName) ||
            "application".equals(tagName)) {
            String name = getAttribute(element, "name");
            if (name != null && !name.isEmpty()) {
                String descriptor = classNameToDescriptor(name, element);
                addProtectedClassAndPackage(descriptor);
            }
        }

        // meta-data 标签：只有 android:name 看起来像类名时才保护
        // android:value 几乎从不是类名（通常是资源引用、数字、配置值），不处理
        if ("meta-data".equals(tagName)) {
            String name = getAttribute(element, "name");
            if (name != null && !name.isEmpty()) {
                // 只处理明确是类名的 meta-data name
                // 常见合法模式：
                //   androidx.startup.INITIALIZER -> 不包含点后跟小写字母开头（是包名不是类名）
                //   com.example.MyInitializer -> 合法类名（最后一段以大写字母开头）
                //   com.google.android.gms.version -> 不是类名（最后一段是小写）
                if (isValidClassName(name)) {
                    String descriptor = classNameToDescriptor(name, element);
                    addProtectedClassAndPackage(descriptor);
                }
            }
            // 不处理 android:value，它几乎从不是类名
        }

        // 递归处理子元素
        NodeList children = element.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            Node child = children.item(i);
            if (child instanceof Element) {
                extractClassNames((Element) child);
            }
        }
    }

    /**
     * 保护Manifest入口类及其所在包。
     *
     * 仅保护入口类本身不够：ContentProvider、Initializer、Service在启动阶段会继续加载同包
     * 辅助类。若这些辅助类被类名混淆、字段重命名或方法头插桩，ART会在应用启动前直接
     * VerifyError。因此Manifest入口类按包前缀保护，优先保证可启动。
     */
    private void addProtectedClassAndPackage(String descriptor) {
        if (descriptor == null || descriptor.isEmpty()) return;
        protectedClasses.add(descriptor);
        int idx = descriptor.lastIndexOf('/');
        if (idx > 1) {
            protectedClasses.add(descriptor.substring(0, idx + 1));
        }
    }

    /**
     * 检查字符串是否看起来像一个合法的Java类名。
     * 规则：
     * 1. 不以数字开头
     * 2. 不包含 @ : / # 等非类名字符
     * 3. 最后一段（类名部分）以大写字母开头，或者包含 $ （内部类）
     * 4. 至少包含一个点（完全限定名）
     * 5. 不以 . 开头时，至少要有包名.类名的结构
     */
    private boolean isValidClassName(String name) {
        if (name == null || name.isEmpty()) return false;

        // 相对类名（以.开头），交给 classNameToDescriptor 处理
        if (name.startsWith(".")) return true;

        // 排除明显不是类名的模式
        if (name.contains("@") || name.contains(":") || name.contains("/") ||
            name.contains("#") || name.contains("*") || name.contains(" ")) {
            return false;
        }

        // 排除纯数字
        if (name.matches("\\d+")) return false;

        // 排除资源引用（@xxx）
        if (name.startsWith("@")) return false;

        // 必须包含至少一个点（完全限定类名）
        int lastDot = name.lastIndexOf('.');
        if (lastDot < 0) return false;

        // 获取最后一段（类名部分）
        String lastPart = name.substring(lastDot + 1);
        if (lastPart.isEmpty()) return false;

        // 类名部分必须以大写字母开头，或包含$（内部类）
        // 常见非类名：androidx.startup, com.google.android.gms.version
        // 常见类名：com.example.MyClass, androidx.startup.Initializer
        char firstChar = lastPart.charAt(0);
        if (!Character.isUpperCase(firstChar) && !lastPart.contains("$")) {
            return false;
        }

        // 排除明显不是类名的常量名：全大写且含下划线（如 FILE_PROVIDER_PATHS）
        // 或全大写（如 NORMAL_THEME, GOOGLE_API_ACTIVITY）
        // Java类名使用驼峰命名，全大写+下划线是常量/枚举/资源名
        if (lastPart.matches("^[A-Z][A-Z0-9_]*$") && lastPart.contains("_")) {
            return false;
        }

        // 排除Theme/Style资源引用（Flutter/系统主题名，不是类名）
        // 例如 NormalTheme, LaunchTheme 等
        if (lastPart.endsWith("Theme") || lastPart.endsWith("Style")) {
            // 虽然有类名可能以Theme结尾，但Manifest中的theme引用99%不是类名
            // 为安全起见，判断：如果包名是系统/Flutter包，且不是已知Activity/Service类名，跳过
            String lowerName = name.toLowerCase();
            if (lowerName.contains("io.flutter") || lowerName.contains("android:theme") ||
                lowerName.contains("@style") || lastPart.endsWith("Theme")) {
                // 保留真正的Activity类名：以Activity结尾的视为类名
                if (!lastPart.endsWith("Activity")) {
                    return false;
                }
            }
        }

        return true;
    }

    private String getAttribute(Element element, String localName) {
        String androidName = "android:" + localName;
        String value = element.getAttribute(androidName);
        if (value == null || value.isEmpty()) {
            value = element.getAttribute(localName);
        }
        return value;
    }

    /**
     * 完整类名转描述符（相对路径需要Element来获取package）
     */
    private String classNameToDescriptor(String name, Element element) {
        if (name.startsWith(".")) {
            // 相对路径，需要加上package名
            String pkg = getPackageName(element);
            if (pkg != null) {
                name = pkg + name;
            } else {
                return null; // 无法确定完整类名，跳过
            }
        }
        return "L" + name.replace('.', '/') + ";";
    }

    /**
     * 完整类名转描述符（简化版，不含相对路径）
     */
    private String classNameToDescriptor(String name) {
        if (name == null || name.isEmpty()) return null;
        if (name.startsWith("L") && name.endsWith(";")) return name;
        return "L" + name.replace('.', '/') + ";";
    }

    private String getPackageName(Element element) {
        Node parent = element.getParentNode();
        while (parent != null && parent instanceof Element) {
            Element el = (Element) parent;
            if ("manifest".equals(el.getTagName())) {
                return el.getAttribute("package");
            }
            parent = parent.getParentNode();
        }
        return null;
    }

    // ===== Main entry =====

    public void processAndWriteAll(ArkJiaguUtils.ArkSettings settings) {
        boolean doRename = settings.classRename;
        boolean doFieldRename = settings.fieldRename;
        boolean doStringEnc = settings.stringEncryption || settings.constStringEncryption;
        boolean doControlFlow = settings.controlFlowObfuscation;
        boolean doJunkCode = settings.junkCodeGeneration;
        boolean doDebugRemoval = settings.debugRemoval;
        boolean doMethodOverload = settings.methodOverload;
        boolean doMultiDexShuffle = settings.multiDexShuffle;
        boolean doArithmeticObf = settings.arithmeticObfuscation;
        boolean doGotoInsertion = settings.gotoInsertion;
        boolean doDexHeaderObf = settings.dexHeaderObfuscation;
        boolean doArithmeticBranch = settings.arithmeticBranch;
        boolean doCallIndirection = settings.callIndirection;
        boolean doAdvancedReflection = settings.advancedReflection;
        // 常量字符串加密已实现，但分支偏移在校验器下仍不稳定，暂不启用
        boolean doConstStringEnc = false;
        boolean doReflectionClinitInjection = settings.reflectionClinitInjection;

        // 方法级字符串加密需要运行时解密桩，目前没有实现
        if (doStringEnc) {
            logCallback.log("  [跳过] 方法级字符串加密：运行时解密桩开发中");
            doStringEnc = false;
        }

        if (doRename) {
            logCallback.log("开始构建全局类名映射表");
            // 扫描DEX中的字符串常量，保护被Class.forName()等反射引用的类
            scanStringConstantsForClassNames();
            // scanStringConstantsForClassNames 遍历了所有 DEX 的所有指令，产生大量临时对象
            // 主动提示 GC，为后续 buildGlobalRenameMaps 释放内存
            System.gc();
            buildGlobalRenameMaps();
            logCallback.log("全局类名映射完成: " + classRenameMap.size() + " 个类");
        }
        // 字段重命名：构建全局字段重命名映射表（已实现跨类引用更新）
        if (doFieldRename) {
            logCallback.log("开始构建全局字段重命名映射表");
            System.gc();
            int fieldRenameFilterMode = settings.classFilterMode;
            if (settings.excludeCommonClasses) fieldRenameFilterMode = 1;
            buildFieldRenameMaps(fieldRenameFilterMode, settings.excludedClassPrefixes);
            logCallback.log("全局字段重命名映射完成: " + fieldRenameMap.size() + " 个字段");
            System.gc();
        }

        int dexIndex = 1;
        int totalRenamed = 0, totalCfObf = 0, totalJunk = 0;
        int totalOverload = 0, totalShuffle = 0, totalArith = 0, totalGoto = 0;
        int totalReflClinit = 0, totalArithBranch = 0, totalCallIndir = 0, totalAdvRefl = 0;
        int totalConstStr = 0, totalFieldRenamed = 0;

        while (true) {
            String dexName = dexIndex == 1 ? "classes.dex" : "classes" + dexIndex + ".dex";
            File dexFile = new File(workDir, dexName);
            if (!dexFile.isFile()) break;

            try {
                com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile dex =
                        DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());

                List<ClassDef> modifiedClasses = new ArrayList<>();
                int renamed = 0, cfObf = 0, junk = 0, overload = 0, shuffle = 0, arith = 0, gotoCnt = 0, arithBranch = 0, callIndir = 0, advRefl = 0, reflClinit = 0, constStr = 0, fieldRenamedCnt = 0;
                // 追踪已被代码插入功能修改的方法，确保每个方法只被一个插入功能修改
                // 多个功能同时修改同一方法会导致相对跳转偏移失效
                Set<String> codeModifiedMethods = new HashSet<>();

                int classFilterMode = settings.classFilterMode;
                // 如果用户开启了排除常见类开关，强制设置过滤模式为1
                if (settings.excludeCommonClasses) {
                    classFilterMode = 1;
                }
                String excludedPrefixes = settings.excludedClassPrefixes;
                for (ClassDef classDef : dex.getClasses()) {
                    // 每处理 1000 个类输出一次进度，避免用户觉得卡死
                    int processed = modifiedClasses.size();
                    if (processed > 0 && processed % 1000 == 0) {
                        logCallback.log("  " + dexName + " 处理中: " + processed + " 个类");
                    }
                    try {
                        String clsType = classDef.getType();
                        // 类名过滤：如果该类应被过滤，则跳过所有变换，直接以原始形式保留在DEX中
                        // 这能显著减少需要处理的类数，降低内存占用，避免写入时OOM闪退
                        boolean shouldProcess = shouldProcessClass(clsType, classFilterMode, excludedPrefixes);
                        if (!shouldProcess) {
                            // 未修改的类直接用 DexBackedClassDef，不创建 ImmutableClassDef 对象
                            // 这避免了为每个类创建深拷贝对象，减少 50-100MB 内存占用
                            modifiedClasses.add(classDef);
                            continue;
                        }

                        // 惰性创建 ImmutableClassDef：仅当类确实需要变换时才创建
                        // 大多数类（保护类、无变换匹配的类）可以直接用 DexBackedClassDef
                        ImmutableClassDef modified = null;

                        // 1. debugRemoval
                        if (doDebugRemoval) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            modified = stripDebugInfo(modified);
                        }
                        // 2. classRename / fieldRename
                        if (doRename && classRenameMap.containsKey(modified != null ? modified.getType() : classDef.getType())) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            modified = applyClassRename(modified, classRenameMap.get(modified.getType()));
                            renamed++;
                        } else if (doRename) {
                            // 优化：仅当类实际引用了被重命名的类时才调用 remapAllReferences
                            // 这避免了为 17910 个类中的每一个都创建 ImmutableClassDef 对象
                            if (classReferencesRenamedClass(classDef)) {
                                if (modified == null) modified = ImmutableClassDef.of(classDef);
                                modified = remapAllReferences(modified);
                            }
                        } else if (doFieldRename) {
                            // 字段重命名：跳过 immutalbe-class 级别的处理，改为在 DEX 写入后
                            // 通过 DexBinaryFieldRenamer 直接在 DEX 二进制上修改字符串表。
                            // 这种方式避免为 17910 个类创建 ImmutableClassDef 对象，
                            // 内存占用从 OOM 级别降到 < 50MB，并且速度极快。
                            // 注意：这里只统计，不修改 modified 对象
                            fieldRenamedCnt += countRenamedFieldsInClass(modified != null ? modified : ImmutableClassDef.of(classDef));
                        }
                        // 2b. constStringEncryption
                        if (doConstStringEnc) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyConstStringEncryption(modified, cnt);
                            constStr += cnt[0];
                        }
                        // 3. methodOverload
                        if (doMethodOverload) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyMethodOverload(modified, cnt);
                            overload += cnt[0];
                        }
                        // 4. multiDexShuffle
                        if (doMultiDexShuffle) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyMultiDexShuffle(modified, cnt);
                            shuffle += cnt[0];
                        }
                        // 5. arithmeticObfuscation (不修改方法头，安全)
                        if (doArithmeticObf) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyArithmeticObfuscation(modified, cnt);
                            arith += cnt[0];
                        }

                        // ===== 代码插入功能：互斥执行，每个方法只被一个功能修改 =====
                        // 优先级：controlFlow > junkCode > arithmeticBranch > callIndirection > advancedReflection > reflectionClinit > gotoInsertion
                        // 这样避免多个功能同时修改方法头导致相对跳转偏移失效

                        // 7. controlFlow（最高优先级）
                        if (doControlFlow) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyControlFlow(modified, cnt, codeModifiedMethods);
                            cfObf += cnt[0];
                        }
                        // 8. junkCode（与 controlFlow 互斥）
                        if (doJunkCode) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyJunkCodeEx(modified, cnt, codeModifiedMethods);
                            junk += cnt[0];
                        }
                        // 6b. arithmeticBranch（与 controlFlow/junkCode 互斥）
                        if (doArithmeticBranch) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyArithmeticBranchEx(modified, cnt, codeModifiedMethods);
                            arithBranch += cnt[0];
                        }
                        // 6c. callIndirection（与上述互斥）
                        if (doCallIndirection) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyCallIndirectionEx(modified, cnt, codeModifiedMethods);
                            callIndir += cnt[0];
                        }
                        // 6d. advancedReflection（与上述互斥）
                        if (doAdvancedReflection) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyAdvancedReflectionEx(modified, cnt, codeModifiedMethods);
                            advRefl += cnt[0];
                        }
                        // 6e. reflectionClinitInjection（与上述互斥）
                        if (doReflectionClinitInjection) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyReflectionClinitInjectionEx(modified, cnt, codeModifiedMethods);
                            reflClinit += cnt[0];
                        }
                        // 6. gotoInsertion（最低优先级，与上述全部互斥）
                        if (doGotoInsertion) {
                            if (modified == null) modified = ImmutableClassDef.of(classDef);
                            int[] cnt = {0};
                            modified = applyGotoInsertionEx(modified, cnt, codeModifiedMethods);
                            gotoCnt += cnt[0];
                        }

                        if (modified != null) {
                            modifiedClasses.add(modified);
                        } else {
                            // 没有变换被应用，直接用 DexBackedClassDef，零对象创建
                            modifiedClasses.add(classDef);
                        }
                    } catch (Exception e) {
                        logCallback.log("  类处理失败，尝试降级处理: " + classDef.getType() + " - " + e.getMessage());
                        // 修复：如果该类在 classRenameMap 中，其他类已经引用了它的新名字，
                        // 必须确保此类以新名字存在，否则会导致 "Unresolved Reference" 崩溃。
                        // 降级策略1：跳过控流/垃圾代码，仅做类名重映射+引用更新
                        try {
                            ImmutableClassDef fallback = ImmutableClassDef.of(classDef);
                            if (doRename && classRenameMap.containsKey(fallback.getType())) {
                                // 此类必须被重命名以保持跨DEX一致性
                                fallback = applyClassRename(fallback, classRenameMap.get(fallback.getType()));
                                renamed++;
                            } else if (doRename) {
                                fallback = remapAllReferences(fallback);
                            } else if (doFieldRename) {
                                // 字段重命名：跳过类级处理，后续由 DexBinaryFieldRenamer 二进制修补
                                // 降级时不做任何字段重命名操作，避免创建不必要的对象
                            }
                            if (doDebugRemoval) {
                                fallback = stripDebugInfo(fallback);
                            }
                            modifiedClasses.add(fallback);
                            logCallback.log("    降级处理成功(仅重映射): " + classDef.getType());
                        } catch (Exception e2) {
                            // 降级策略2：remapAllReferences + 手动改类名
                            logCallback.log("    降级1失败，尝试降级2: " + classDef.getType() + " - " + e2.getMessage());
                            try {
                                ImmutableClassDef fallback2 = ImmutableClassDef.of(classDef);
                                if (doRename) {
                                    fallback2 = remapAllReferences(fallback2);
                                    // 如果此类需要重命名，手动替换类名
                                    if (classRenameMap.containsKey(fallback2.getType())) {
                                        String newType = classRenameMap.get(fallback2.getType());
                                        List<Field> f2Fields = new ArrayList<>();
                                        for (Field f : fallback2.getStaticFields()) f2Fields.add(ImmutableField.of(f));
                                        for (Field f : fallback2.getInstanceFields()) f2Fields.add(ImmutableField.of(f));
                                        List<ImmutableMethod> f2Methods = new ArrayList<>();
                                        for (Method mth : fallback2.getMethods()) f2Methods.add(ImmutableMethod.of(mth));
                                        fallback2 = new ImmutableClassDef(newType, fallback2.getAccessFlags(),
                                                fallback2.getSuperclass(), fallback2.getInterfaces(),
                                                fallback2.getSourceFile(), fallback2.getAnnotations(),
                                                f2Fields, f2Methods);
                                        renamed++;
                                    }
                                }
                                modifiedClasses.add(fallback2);
                                logCallback.log("    降级2成功: " + classDef.getType());
                            } catch (Exception e3) {
                                // 降级策略3（最后手段）：至少保证引用被更新
                                logCallback.log("    降级2也失败，尝试降级3: " + classDef.getType() + " - " + e3.getMessage());
                                try {
                                    ImmutableClassDef fallback3 = remapAllReferences(ImmutableClassDef.of(classDef));
                                    if (classRenameMap.containsKey(fallback3.getType())) {
                                        String newType = classRenameMap.get(fallback3.getType());
                                        List<Field> f3Fields = new ArrayList<>();
                                        for (Field f : fallback3.getStaticFields()) f3Fields.add(ImmutableField.of(f));
                                        for (Field f : fallback3.getInstanceFields()) f3Fields.add(ImmutableField.of(f));
                                        List<ImmutableMethod> f3Methods = new ArrayList<>();
                                        for (Method mth : fallback3.getMethods()) f3Methods.add(ImmutableMethod.of(mth));
                                        fallback3 = new ImmutableClassDef(newType, fallback3.getAccessFlags(),
                                                fallback3.getSuperclass(), fallback3.getInterfaces(),
                                                fallback3.getSourceFile(), fallback3.getAnnotations(),
                                                f3Fields, f3Methods);
                                        renamed++;
                                    }
                                    modifiedClasses.add(fallback3);
                                } catch (Exception e4) {
                                    logCallback.log("    所有降级均失败，保留原始: " + classDef.getType());
                                    modifiedClasses.add(ImmutableClassDef.of(classDef));
                                }
                            }
                        }
                    }
                }

                // 阶段性提示大DEX用户当前仍在处理，避免UI长时间无响应被系统杀死
                if (modifiedClasses.size() > 1000) {
                    int totalClasses = dex.getClasses().size();
                    int filtered = totalClasses - modifiedClasses.size();
                    logCallback.log("  " + dexName + " 已处理 " + modifiedClasses.size() + " 个类" +
                            (filtered > 0 ? " (已过滤 " + filtered + " 个类)" : "") +
                            "，准备写入...");
                }

                // ===== 关键优化：在写入前释放原始 DEX 的内存映射，避免 MappedByteBuffer + DexPool 双倍内存 =====
                // DexBackedDexFile 内部持有 MappedByteBuffer，占用 10-50MB 的虚拟内存。
                // 此时 modifiedClasses 已经持有所有修改后的类，原始 DEX 不再需要。
                // 在写入前释放它，为 DexPool 腾出内存空间。
                Opcodes opcodes = dex.getOpcodes();
                // 注意：不要缓存 dex.getClasses() 到列表中！DexBackedClassDef 对象持有
                // 对 DexBackedDexFile 的引用，会阻止 MappedByteBuffer 被 GC 回收。
                // 如果写入失败需要重试，从备份文件重新加载 DEX。
                dex = null; // 释放 MappedByteBuffer
                // 主动 GC，通知虚拟机回收 mmap 区域
                System.gc();

                // 修复：先写入临时文件，成功后再替换原文件，避免写入失败导致DEX损坏
                // 先备份原始 DEX，用于混淆后验证失败时回滚
                File backupFile = new File(workDir, dexName + ".orig");
                java.nio.file.Files.copy(dexFile.toPath(), backupFile.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);

                File tempFile = new File(workDir, dexName + ".tmp");
                if (!writeDexSafely(null, modifiedClasses, opcodes, tempFile, dexName, doRename)) {
                    throw new RuntimeException("安全写入失败: " + dexName);
                }

                // 验证写入的 DEX 是否可正常加载
                boolean dexValid = false;
                try {
                    DexFileFactory.loadDexFile(tempFile, Opcodes.getDefault());
                    dexValid = true;
                } catch (Exception vex) {
                    logCallback.log("  [警告] 混淆后DEX验证失败，回滚到原始DEX: " + dexName + " - " + vex.getMessage());
                }

                if (dexValid) {
                    // 验证通过，替换原文件
                    if (dexFile.delete()) {
                        if (!tempFile.renameTo(dexFile)) {
                            java.nio.file.Files.copy(tempFile.toPath(), dexFile.toPath(),
                                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                            tempFile.delete();
                        }
                    } else {
                        java.nio.file.Files.copy(tempFile.toPath(), dexFile.toPath(),
                                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                        tempFile.delete();
                    }
                } else {
                    // 验证失败，用原始 DEX 替换
                    tempFile.delete();
                    java.nio.file.Files.copy(backupFile.toPath(), dexFile.toPath(),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    logCallback.log("  [回滚] 已恢复原始DEX: " + dexName);
                }
                backupFile.delete();
                logCallback.log("  DEX已写入磁盘: " + dexFile.getName() + " (" + dexFile.length() + " bytes)");

                // ===== 字段重命名：二进制修补模式 =====
                // 在主循环中跳过了字段重命名（避免创建 ImmutableClassDef 对象），
                // 现在直接在已写入的 DEX 文件上修补字符串表。
                // 这种方式不会为每个类创建对象，内存占用极小，速度极快。
                if (doFieldRename && !fieldRenameMap.isEmpty()) {
                    try {
                        DexBinaryFieldRenamer renamer = new DexBinaryFieldRenamer(
                                fieldRenameMap, classesWithNativeMethods, protectedClasses);
                        if (renamer.renameFields(dexFile)) {
                            logCallback.log("  " + dexName + " 字段二进制重命名完成");
                        } else {
                            logCallback.log("  [警告] " + dexName + " 字段二进制重命名失败，跳过");
                        }
                    } catch (Exception e) {
                        logCallback.log("  [警告] " + dexName + " 字段二进制重命名异常: " + e.getMessage());
                    }
                }

                // 大DEX处理完后主动建议GC，释放remap过程中产生的大量临时对象
                if (modifiedClasses.size() > 500) {
                    System.gc();
                }

                // DEX头部混淆：在DEX写入磁盘后，向文件末尾追加随机padding（不影响加载）
                if (doDexHeaderObf) {
                    applyDexHeaderObfuscation(dexFile);
                }

                totalRenamed += renamed;
                totalCfObf += cfObf;
                totalJunk += junk;
                totalOverload += overload;
                totalShuffle += shuffle;
                totalArith += arith;
                totalGoto += gotoCnt;
                totalReflClinit += reflClinit;
                totalArithBranch += arithBranch;
                totalCallIndir += callIndir;
                totalAdvRefl += advRefl;
                totalConstStr += constStr;
                totalFieldRenamed += fieldRenamedCnt;

                StringBuilder sb = new StringBuilder("  " + dexName + ": " + modifiedClasses.size() + "类");
                if (doRename) sb.append(", 混淆").append(renamed).append("类");
                if (doMethodOverload) sb.append(", 重载").append(overload).append("法");
                if (doMultiDexShuffle) sb.append(", 打乱").append(shuffle).append("类");
                if (doArithmeticObf) sb.append(", 算术").append(arith).append("处");
                if (doGotoInsertion) sb.append(", goto").append(gotoCnt).append("法");
                if (doReflectionClinitInjection) sb.append(", clinit").append(reflClinit).append("法");
                if (doArithmeticBranch) sb.append(", 分支").append(arithBranch).append("处");
                if (doCallIndirection) sb.append(", 间接").append(callIndir).append("处");
                if (doAdvancedReflection) sb.append(", 反射").append(advRefl).append("处");
                if (doControlFlow) sb.append(", 控流").append(cfObf).append("法");
                if (doJunkCode) sb.append(", 垃圾").append(junk).append("法");
                if (doConstStringEnc) sb.append(", 字符串加密").append(constStr).append("处");
                logCallback.log(sb.toString());
            } catch (Exception e) {
                logCallback.log("  [失败] 处理DEX失败: " + dexName + " - " + e.getMessage());
                // 重试：保留所有混淆功能，但跳过高风险的字段重命名和方法重载
                // （这两个最容易导致Multiple definitions错误）
                logCallback.log("  [重试] 跳过字段重命名和方法重载，保留其余混淆功能");
                // 实际清空 fieldRenameMap，确保重试时 remapAllReferences 不再执行字段重命名
                Map<String, String> savedFieldRenameMap = new HashMap<>(fieldRenameMap);
                fieldRenameMap.clear();
                try {
                    com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile retryDex =
                            DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());
                    Opcodes retryOpcodes = retryDex.getOpcodes();
                    // 注意：不要缓存 DexBackedClassDef 列表！这些对象持有对 DexBackedDexFile 的引用，
                    // 会阻止 MappedByteBuffer 被 GC 回收。直接在循环中迭代 retryDex.getClasses()。
                    System.gc();
                    List<ClassDef> modifiedClasses = new ArrayList<>();
                    int renamed = 0, cfObf = 0, junk = 0, overload = 0, shuffle = 0, arith = 0, gotoCnt = 0, arithBranch = 0, callIndir = 0, advRefl = 0, reflClinit = 0, constStr = 0;
                    Set<String> retryModified = new HashSet<>();
                    for (ClassDef classDef : retryDex.getClasses()) {
                        try {
                            ImmutableClassDef modified = ImmutableClassDef.of(classDef);
                            if (doDebugRemoval) modified = stripDebugInfo(modified);
                            if (doRename && classRenameMap.containsKey(modified.getType())) {
                                modified = applyClassRename(modified, classRenameMap.get(modified.getType()));
                                renamed++;
                            } else if (doRename) {
                                modified = remapAllReferences(modified);
                            }
                            // 3. 字段重命名 - 已通过清空 fieldRenameMap 实际跳过
                            // 4. 方法重载 - 跳过（高风险）
                            if (doMultiDexShuffle) { int[] c = {0}; modified = applyMultiDexShuffle(modified, c); shuffle += c[0]; }
                            if (doArithmeticObf) { int[] c = {0}; modified = applyArithmeticObfuscation(modified, c); arith += c[0]; }
                            // 互斥代码插入
                            if (doControlFlow) { int[] c = {0}; modified = applyControlFlow(modified, c, retryModified); cfObf += c[0]; }
                            if (doJunkCode) { int[] c = {0}; modified = applyJunkCodeEx(modified, c, retryModified); junk += c[0]; }
                            if (doArithmeticBranch) { int[] c = {0}; modified = applyArithmeticBranchEx(modified, c, retryModified); arithBranch += c[0]; }
                            if (doCallIndirection) { int[] c = {0}; modified = applyCallIndirectionEx(modified, c, retryModified); callIndir += c[0]; }
                            if (doAdvancedReflection) { int[] c = {0}; modified = applyAdvancedReflectionEx(modified, c, retryModified); advRefl += c[0]; }
                            if (doReflectionClinitInjection) { int[] c = {0}; modified = applyReflectionClinitInjectionEx(modified, c, retryModified); reflClinit += c[0]; }
                            if (doGotoInsertion) { int[] c = {0}; modified = applyGotoInsertionEx(modified, c, retryModified); gotoCnt += c[0]; }
                            if (doConstStringEnc) { int[] c = {0}; modified = applyConstStringEncryption(modified, c); constStr += c[0]; }
                            modifiedClasses.add(modified);
                        } catch (Exception e2) {
                            logCallback.log("    [降级] 类处理失败: " + classDef.getType() + " - " + e2.getMessage());
                            try {
                                ImmutableClassDef fb = remapAllReferences(ImmutableClassDef.of(classDef));
                                if (doRename && classRenameMap.containsKey(fb.getType())) {
                                    String newType = classRenameMap.get(fb.getType());
                                    List<Field> fbFields = new ArrayList<>();
                                    for (Field f : fb.getStaticFields()) fbFields.add(ImmutableField.of(f));
                                    for (Field f : fb.getInstanceFields()) fbFields.add(ImmutableField.of(f));
                                    List<ImmutableMethod> fbMethods = new ArrayList<>();
                                    for (Method mth : fb.getMethods()) fbMethods.add(ImmutableMethod.of(mth));
                                    fb = new ImmutableClassDef(newType, fb.getAccessFlags(),
                                            fb.getSuperclass(), fb.getInterfaces(),
                                            fb.getSourceFile(), fb.getAnnotations(),
                                            fbFields, fbMethods);
                                    renamed++;
                                }
                                modifiedClasses.add(fb);
                            } catch (Exception e3b) {
                                logCallback.log("    [降级失败] 保留原始: " + classDef.getType());
                                modifiedClasses.add(ImmutableClassDef.of(classDef));
                            }
                        }
                    }
                    retryDex = null; // 释放 mmap，让 GC 回收 MappedByteBuffer
                    System.gc();
                    File tempFile2 = new File(workDir, dexName + ".tmp");
                    if (!writeDexSafely(null, modifiedClasses, retryOpcodes, tempFile2, dexName, doRename)) {
                        throw new RuntimeException("安全写入失败(重试): " + dexName);
                    }
                    if (dexFile.delete()) {
                        if (!tempFile2.renameTo(dexFile)) {
                            java.nio.file.Files.copy(tempFile2.toPath(), dexFile.toPath(),
                                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                        }
                    } else {
                        java.nio.file.Files.copy(tempFile2.toPath(), dexFile.toPath(),
                                java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    }
                    tempFile2.delete();
                    StringBuilder sb2 = new StringBuilder("  [重试成功] " + dexName + ": " + modifiedClasses.size() + "类");
                        sb2.append(", 混淆").append(renamed).append("类");
                        if (doMultiDexShuffle) sb2.append(", 打乱").append(shuffle);
                        if (doArithmeticObf) sb2.append(", 算术").append(arith);
                        if (doGotoInsertion) sb2.append(", goto").append(gotoCnt);
                        if (doControlFlow) sb2.append(", 控流").append(cfObf);
                        if (doJunkCode) sb2.append(", 垃圾").append(junk);
                        sb2.append(" [跳过: 字段重命名, 方法重载]");
                        logCallback.log(sb2.toString());
                        totalRenamed += renamed;
                        totalCfObf += cfObf;
                        totalJunk += junk;
                    } catch (Exception e3) {
                        logCallback.log("  [重试失败] " + dexName + " - " + e3.getMessage());
                    } finally {
                        // 恢复 fieldRenameMap，供后续 DEX 文件使用
                        fieldRenameMap.putAll(savedFieldRenameMap);
                    }
            }
            dexIndex++;
        }

        // 最终汇总报告
        logCallback.log("====== DEX混淆汇总 ======");
        logCallback.log("  类名重命名: " + totalRenamed + " 类");
        if (doFieldRename) {
            logCallback.log("  字段重命名: " + totalFieldRenamed + " 字段");
        }
        logCallback.log("  方法重载: " + totalOverload + " 方法");
        logCallback.log("  控制流混淆: " + totalCfObf + " 方法");
        logCallback.log("  垃圾代码: " + totalJunk + " 方法");
        logCallback.log("  多DEX打乱: " + totalShuffle + " 类");
        logCallback.log("  算术混淆: " + totalArith + " 处");
        logCallback.log("  Goto插入: " + totalGoto + " 方法");
        logCallback.log("  反射Clinit: " + totalReflClinit + " 方法");
        logCallback.log("  算术分支: " + totalArithBranch + " 处");
        logCallback.log("  调用间接化: " + totalCallIndir + " 处");
        logCallback.log("  高级反射: " + totalAdvRefl + " 处");
        logCallback.log("  常量字符串加密: " + (settings.constStringEncryption ? "已跳过(分支偏移校验待完善)" : "未启用"));
        logCallback.log("  DEX头部混淆: " + (doDexHeaderObf ? "已执行" : "未启用"));
        logCallback.log("  方法级字符串加密: " + (settings.stringEncryption ? "已跳过(需运行时解密桩)" : "未启用"));
        logCallback.log("====== DEX混淆阶段完成 ======");
    }

    // ===== Field rename map builder =====

    // ===== 类名过滤机制 =====
    // 当 classFilterMode == 1 (EXCLUDE_COMMON) 时，跳过以下常见类前缀
    // 这些类通常是第三方库，不需要被字段重命名或类名混淆，处理它们只会浪费内存
    private static final String[] COMMON_EXCLUDED_PREFIXES = {
            "Landroidx/", "Lcom/google/", "Lkotlin/", "Lkotlinx/",
            "Lorg/apache/", "Lorg/json/", "Lorg/w3c/", "Lorg/xml/",
            "Lorg/intellij/", "Lorg/jetbrains/", "Lorg/slf4j/",
            "Lokhttp", "Lretrofit", "Lio/reactivex",
            "Lcom/squareup/", "Lcom/bumptech/", "Lcom/facebook/",
            "Lcom/alibaba/", "Lcom/tencent/", "Lcom/umeng/",
            "Landroid/arch/", "Landroid/annotation/",
            "Lbutterknife/", "Ldagger/", "Ljavax/inject/",
            "Lcom/google/gson/", "Lcom/google/common/", "Lcom/google/android/",
            "Lcom/google/protobuf/", "Lcom/google/firebase/", "Lcom/google/ads/",
            "Lcom/google/play/", "Lcom/google/mlkit/",
            "Landroidx/room/", "Landroidx/work/", "Landroidx/startup/",
            "Landroidx/compose/", "Landroidx/lifecycle/", "Landroidx/core/",
            "Landroidx/activity/", "Landroidx/fragment/", "Landroidx/recyclerview/",
            "Landroidx/viewpager/", "Landroidx/navigation/", "Landroidx/constraintlayout/",
            "Landroidx/appcompat/", "Landroidx/cardview/", "Landroidx/preference/",
            "Landroidx/collection/", "Landroidx/arch/", "Landroidx/emoji2/",
            "Landroidx/profileinstaller/", "Landroidx/annotation/",
            "Lio/flutter/", "Lcom/unity3d/", "Lcom/adobe/",
            "Lcom/amazon/", "Lcom/chinamobile/", "L/com/baidu/",
            "Lorg/cocos2dx/", "Lcom/netease/", "Lcom/bytedance/",
            "Lcom/huawei/", "Lcom/xiaomi/", "Lcom/vivo/", "Lcom/oppo/",
            "Ljava/util/", "Ljava/io/", "Ljava/lang/", "Ljava/net/",
            "Ljava/text/", "Ljava/time/", "Ljava/math/"
    };

    /**
     * 判断指定类是否应该被处理（根据类名过滤设置）。
     * @param type 类描述符，如 "Lcom/example/Foo;"
     * @param classFilterMode 0=全部, 1=排除常见类, 2=指定DEX
     * @param customExcludedPrefixes 自定义排除前缀，逗号分隔，可以为null或空
     */
    private static boolean shouldProcessClass(String type, int classFilterMode, String customExcludedPrefixes) {
        if (classFilterMode == 0) return true; // 全部处理
        if (classFilterMode == 1) {
            // 排除常见类
            for (String prefix : COMMON_EXCLUDED_PREFIXES) {
                if (type.startsWith(prefix)) return false;
            }
            // 也检查自定义排除前缀
            if (customExcludedPrefixes != null && !customExcludedPrefixes.isEmpty()) {
                String[] customPrefixes = customExcludedPrefixes.split(",");
                for (String p : customPrefixes) {
                    String trimmed = p.trim();
                    if (!trimmed.isEmpty() && type.startsWith(trimmed)) return false;
                }
            }
            return true;
        }
        // classFilterMode == 2 (指定DEX) 暂不实现，默认全部处理
        return true;
    }

    /**
     * 构建全局字段重命名映射表。
     * 遍历所有DEX，为非protected类的字段生成新名字。
     * 跳过：native方法所在类的字段（JNI可能按名访问）、serialVersionUID、
     *       被注解标记的字段、synthetic/enum 字段。
     * Key格式: "类描述符->字段名->字段类型"，使用原始类名（重命名前）作为key。
     *
     * 优化：每个 DEX 文件只加载一次，两阶段（找 native 方法 + 构建映射表）
     * 在同一循环内完成。避免重复加载 DEX 导致的 MappedByteBuffer 双倍内存占用。
     */
    private void buildFieldRenameMaps(int classFilterMode, String excludedPrefixes) {
        fieldRenamedOwners.clear();
        classesWithNativeMethods.clear();
        Set<String> usedFieldNames = new HashSet<>();
        // 收集含有 native 方法的类（其字段可能被JNI按名访问，不能重命名）
        // 全局累积：由于 DEX 按顺序处理，先处理的 DEX 中 native 类信息会传递到后处理的 DEX。
        // 对于同一 DEX 内的类，Phase 1 先收集本 DEX 的 native 类，Phase 2 再使用，保证正确性。
        // 使用类字段而不是局部变量，这样二进制重命名器也能访问它。

        int dexIndex = 1;
        while (true) {
            String dexName = dexIndex == 1 ? "classes.dex" : "classes" + dexIndex + ".dex";
            File dexFile = new File(workDir, dexName);
            if (!dexFile.isFile()) break;
            try {
                com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile dex =
                        DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());

                //===== Phase 1: 收集本DEX中带 native 方法的类 =====
                for (ClassDef classDef : dex.getClasses()) {
                    for (Method m : classDef.getMethods()) {
                        if (AccessFlags.NATIVE.isSet(m.getAccessFlags())) {
                            classesWithNativeMethods.add(classDef.getType());
                            break;
                        }
                    }
                }

                logCallback.log("  " + dexName + " native类收集完成，开始构建字段映射...");

                //===== Phase 2: 构建字段重命名映射表 =====
                for (ClassDef classDef : dex.getClasses()) {
                    String type = classDef.getType();
                    // 应用类名过滤：如果用户开启了排除常见类，跳过这些类的字段
                    if (!shouldProcessClass(type, classFilterMode, excludedPrefixes)) continue;
                    // 只重命名非protected类
                    if (!shouldRename(type)) continue;
                    // 含native方法的类跳过（JNI可能按字段名访问）
                    if (classesWithNativeMethods.contains(type)) continue;

                    for (Field f : classDef.getFields()) {
                        String name = f.getName();
                        int flags = f.getAccessFlags();
                        // 跳过 serialVersionUID（序列化兼容）
                        if ("serialVersionUID".equals(name)) continue;
                        // 跳过被注解标记的字段
                        if (!f.getAnnotations().isEmpty()) continue;
                        // 跳过 synthetic / enum 字段（编译器生成或被反射按名引用）
                        if (AccessFlags.SYNTHETIC.isSet(flags)) continue;
                        if (AccessFlags.ENUM.isSet(flags)) continue;

                        String key = type + "->" + name + ":" + f.getType();
                        if (fieldRenameMap.containsKey(key)) continue;
                        String newName = genFieldName();
                        // 冲突重试，最多 5 次避免极端情况下死循环
                        int retries = 0;
                        while (usedFieldNames.contains(newName) && retries < 5) {
                            newName = genFieldName();
                            retries++;
                        }
                        usedFieldNames.add(newName);
                        fieldRenameMap.put(key, newName);
                        fieldRenamedOwners.add(type);
                    }
                }

                // 主动释放 DEX 引用，让 GC 可以回收 MappedByteBuffer
                // 再处理下一个 DEX，避免同时持有多个 DEX 的内存映射
                dex = null;
            } catch (Exception e) {
                logCallback.log("  [警告] 加载DEX失败: " + dexName + " - " + e.getMessage());
                break;
            }
            dexIndex++;
        }
        // 释放中间数据大集合
        classesWithNativeMethods.clear();
        usedFieldNames.clear();
    }

    /**
     * 扫描所有DEX文件中的字符串常量，找出被Class.forName()等反射机制引用的类名。
     * 这些类不能被重命名，否则运行时反射加载会失败。
     *
     * 例如 AndroidX Startup 通过 Class.forName("androidx.emoji2.text.EmojiCompatInitializer")
     * 加载Initializer类，如果该类被重命名，Class.forName()会抛出ClassNotFoundException。
     */
    private void scanStringConstantsForClassNames() {
        // 第一步：收集所有DEX中的类类型描述符
        Set<String> allClassTypes = new HashSet<>();
        int dexIndex = 1;
        while (true) {
            String dexName = dexIndex == 1 ? "classes.dex" : "classes" + dexIndex + ".dex";
            File dexFile = new File(workDir, dexName);
            if (!dexFile.isFile()) break;
            try {
                com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile dex =
                        DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());
                for (ClassDef classDef : dex.getClasses()) {
                    allClassTypes.add(classDef.getType());
                }
            } catch (Exception e) { break; }
            dexIndex++;
        }

        // 第二步：扫描所有字符串常量，匹配类名
        int found = 0;
        dexIndex = 1;
        while (true) {
            String dexName = dexIndex == 1 ? "classes.dex" : "classes" + dexIndex + ".dex";
            File dexFile = new File(workDir, dexName);
            if (!dexFile.isFile()) break;
            try {
                com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile dex =
                        DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());
                for (ClassDef classDef : dex.getClasses()) {
                    for (Method method : classDef.getMethods()) {
                        if (method.getImplementation() == null) continue;
                        for (Instruction insn : method.getImplementation().getInstructions()) {
                            if (!(insn instanceof ReferenceInstruction)) continue;
                            Reference ref = ((ReferenceInstruction) insn).getReference();
                            if (!(ref instanceof StringReference)) continue;
                            String str = ((StringReference) ref).getString();
                            // 尝试将字符串转换为类型描述符
                            String descriptor = tryConvertToDescriptor(str);
                            if (descriptor != null && allClassTypes.contains(descriptor)) {
                                if (protectedClasses.add(descriptor)) {
                                    found++;
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) { break; }
            dexIndex++;
        }

        logCallback.log("  从字符串常量提取保护类: " + found + " 个 (总保护类: " + protectedClasses.size() + ")");
        // allClassTypes 是局部变量，可能很大（所有类类型描述符），显式 clear + GC
        // 为后续 buildGlobalRenameMaps / buildFieldRenameMaps 释放内存
        allClassTypes.clear();
        System.gc();
    }

    /**
     * 尝试将字符串转换为DEX类型描述符。
     * 输入 "androidx.emoji2.text.EmojiCompatInitializer"
     * 输出 "Landroidx/emoji2/text/EmojiCompatInitializer;"
     *
     * @return 类型描述符，如果不像是类名则返回null
     */
    private String tryConvertToDescriptor(String str) {
        if (str == null || str.isEmpty()) return null;
        // 类名特征：至少包含一个点，每段以字母/$/_开头
        // 排除明显不是类名的字符串（含空格、含路径分隔符等）
        if (str.contains(" ") || str.contains("/") || str.contains("\\")) return null;
        // 必须至少有一个点（区分于普通标识符）
        int dotIndex = str.indexOf('.');
        if (dotIndex <= 0) return null;
        // 检查每段是否合法：以字母/$/_开头，后续为字母/数字/$/_
        String[] parts = str.split("\\.");
        if (parts.length < 2) return null;
        for (String part : parts) {
            if (part.isEmpty()) return null;
            char first = part.charAt(0);
            if (!Character.isJavaIdentifierStart(first)) return null;
            for (int i = 1; i < part.length(); i++) {
                if (!Character.isJavaIdentifierPart(part.charAt(i))) return null;
            }
        }
        return "L" + str.replace('.', '/') + ";";
    }

    private void buildGlobalRenameMaps() {
        int dexIndex = 1;
        Set<String> used = new HashSet<>();
        while (true) {
            String dexName = dexIndex == 1 ? "classes.dex" : "classes" + dexIndex + ".dex";
            File dexFile = new File(workDir, dexName);
            if (!dexFile.isFile()) break;
            try {
                com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile dex =
                        DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());
                for (ClassDef classDef : dex.getClasses()) {
                    String type = classDef.getType();
                    if (shouldRename(type) && !classRenameMap.containsKey(type)) {
                        String newName;
                        do { newName = genClassName(); } while (used.contains(newName));
                        used.add(newName);
                        classRenameMap.put(type, newName);
                    }
                }
            } catch (Exception e) { break; }
            dexIndex++;
        }

        // 双重安全检查：从映射表中移除所有系统类和受保护类
        // 防止因 shouldRename 被绕过或 protectedClasses 未及时加载导致系统类被重命名
        List<String> toRemove = new ArrayList<>();
        for (String type : classRenameMap.keySet()) {
            if (!shouldRename(type)) {
                toRemove.add(type);
            }
        }
        for (String type : toRemove) {
            classRenameMap.remove(type);
        }

        // 诊断日志：检查是否有系统类泄露到重命名映射表
        if (!toRemove.isEmpty()) {
            logCallback.log("  警告：安全过滤移除了 " + toRemove.size() + " 个不应重命名的类");
            for (String type : toRemove) {
                logCallback.log("    移除: " + type);
            }
        }

        // 额外检查：确保没有 Landroidx/ 或 Landroid/ 开头的类
        int leakedSystem = 0;
        for (String type : classRenameMap.keySet()) {
            if (type.startsWith("Landroid/") || type.startsWith("Landroidx/") ||
                type.startsWith("Ljava/") || type.startsWith("Lkotlin/")) {
                leakedSystem++;
                logCallback.log("  严重错误：系统类泄露到重命名表: " + type);
            }
        }
        if (leakedSystem == 0) {
            logCallback.log("  系统类检查通过：无泄露");
        }

        logCallback.log("  安全过滤后需混淆类: " + classRenameMap.size() + " 个");
        // used 集合可能很大（所有新类名），显式释放
        used.clear();
        toRemove.clear();
    }

    /**
     * 检查类是否引用了任何被重命名的类。
     * 用于优化：仅当类实际引用了被重命名的类时才调用 remapAllReferences。
     * 这避免了为 17910 个类中的每一个都创建 ImmutableClassDef 对象。
     */
    private boolean classReferencesRenamedClass(ClassDef cd) {
        if (classRenameMap.isEmpty()) return false;

        // 检查父类
        if (cd.getSuperclass() != null && classRenameMap.containsKey(cd.getSuperclass())) {
            return true;
        }
        // 检查接口
        for (String iface : cd.getInterfaces()) {
            if (classRenameMap.containsKey(iface)) {
                return true;
            }
        }
        // 检查字段类型
        for (Field f : cd.getStaticFields()) {
            if (classRenameMap.containsKey(f.getType())) {
                return true;
            }
        }
        for (Field f : cd.getInstanceFields()) {
            if (classRenameMap.containsKey(f.getType())) {
                return true;
            }
        }
        // 检查方法参数类型和返回类型
        for (Method m : cd.getMethods()) {
            if (classRenameMap.containsKey(m.getReturnType())) {
                return true;
            }
            for (MethodParameter p : m.getParameters()) {
                if (classRenameMap.containsKey(p.getType())) {
                    return true;
                }
            }
            // 检查指令引用
            if (m.getImplementation() != null) {
                for (Instruction insn : m.getImplementation().getInstructions()) {
                    if (insn instanceof ReferenceInstruction) {
                        Reference ref = ((ReferenceInstruction) insn).getReference();
                        if (ref instanceof TypeReference) {
                            if (classRenameMap.containsKey(((TypeReference) ref).getType())) {
                                return true;
                            }
                        } else if (ref instanceof FieldReference) {
                            FieldReference fr = (FieldReference) ref;
                            if (classRenameMap.containsKey(fr.getDefiningClass()) ||
                                classRenameMap.containsKey(fr.getType())) {
                                return true;
                            }
                        } else if (ref instanceof MethodReference) {
                            MethodReference mr = (MethodReference) ref;
                            if (classRenameMap.containsKey(mr.getDefiningClass()) ||
                                classRenameMap.containsKey(mr.getReturnType())) {
                                return true;
                            }
                            for (CharSequence paramType : mr.getParameterTypes()) {
                                if (classRenameMap.containsKey(paramType.toString())) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * 对所有类（包括未重命名的类）更新全部引用。
     * 如果类A没有被重命名，但它引用了被重命名的类B，
     * 那么类A中对类B的所有引用都必须更新，否则运行时找不到类。
     *
     * 修复：除了指令引用外，还必须重映射：
     * - 父类 (superclass)
     * - 接口 (interfaces)
     * - 字段类型 (field type)
     * - 方法参数类型 (method parameter types)
     * - 方法返回类型 (method return type)
     */
    private ImmutableClassDef remapAllReferences(ImmutableClassDef cd) {
        if (classRenameMap.isEmpty() && fieldRenameMap.isEmpty()) return cd;

        // 重映射父类和接口
        String newSuper = remapType(cd.getSuperclass());
        List<String> newInterfaces = new ArrayList<>();
        for (String iface : cd.getInterfaces()) {
            newInterfaces.add(remapType(iface));
        }

        // 重映射字段定义：定义类、类型、名字
        List<ImmutableField> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) {
            allFields.add(renameFieldDef(f));
        }
        for (Field f : cd.getInstanceFields()) {
            allFields.add(renameFieldDef(f));
        }

        // 重映射方法参数、返回类型和指令
        List<ImmutableMethod> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            // 重映射参数类型
            List<MethodParameter> newParams = new ArrayList<>();
            for (MethodParameter p : m.getParameters()) {
                newParams.add(new ImmutableMethodParameter(
                        remapType(p.getType()), p.getAnnotations(), p.getName()));
            }

            ImmutableMethodImplementation newImpl = null;
            if (m.getImplementation() != null) {
                MethodImplementation impl = m.getImplementation();
                List<ImmutableInstruction> insns = new ArrayList<>();
                for (Instruction insn : impl.getInstructions()) {
                    insns.add(remapInsn(insn));
                }
                // 修复：重映射try-catch块中的异常类型
                List<ImmutableTryBlock> newTryBlocks = remapTryBlocks(impl.getTryBlocks());
                newImpl = new ImmutableMethodImplementation(
                        impl.getRegisterCount(), insns, newTryBlocks, impl.getDebugItems());
            }

            methods.add(new ImmutableMethod(
                    remapType(m.getDefiningClass()), m.getName(),
                    newParams, remapType(m.getReturnType()),
                    m.getAccessFlags(),
                    remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(),
                    newImpl));
        }

        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                newSuper, newInterfaces, cd.getSourceFile(),
                remapAnnotations(cd.getAnnotations()), allFields, methods);
    }

    /**
     * 仅字段重命名场景下的轻量级重映射。
     *
     * 当只开启字段重命名、未开启类重命名时，父类/接口/方法签名都不会改变，
     * 只需要：
     * 1. 重命名本类的字段定义；
     * 2. 重映射方法指令中对被重命名字段的引用。
     *
     * 性能优化：对于无重命名字段且不引用任何重命名字段的类，直接返回原始
     * ClassDef 对象，避免为几万个类中的每一条指令创建 ImmutableInstruction
     * 对象（这是之前卡死/闪退的核心原因）。
     */
    private ImmutableClassDef remapFieldRenameOnly(ImmutableClassDef cd) {
        boolean ownerHasRenamedFields = fieldRenamedOwners.contains(cd.getType());

        // ===== 快速路径：本类无重命名字段 =====
        // 检查本类的方法指令中是否引用了被重命名的字段
        // 如果没有任何引用，直接返回原始 ClassDef，零对象创建
        if (!ownerHasRenamedFields) {
            boolean hasRefToRenamedField = false;
            outer:
            for (Method m : cd.getMethods()) {
                if (m.getImplementation() != null) {
                    for (Instruction insn : m.getImplementation().getInstructions()) {
                        if (insn instanceof ReferenceInstruction) {
                            Reference ref = ((ReferenceInstruction) insn).getReference();
                            if (ref instanceof FieldReference) {
                                FieldReference fr = (FieldReference) ref;
                                String key = fr.getDefiningClass() + "->" + fr.getName() + ":" + fr.getType();
                                if (fieldRenameMap.containsKey(key)) {
                                    hasRefToRenamedField = true;
                                    break outer;
                                }
                            }
                        }
                    }
                }
            }
            if (!hasRefToRenamedField) {
                // 本类无任何需要改变的引用，直接返回原始对象
                return cd;
            }
        }

        // ===== 慢速路径：本类有重命名字段，或引用了被重命名字段 =====
        // 1. 重命名本类字段定义
        List<ImmutableField> allFields = new ArrayList<>();
        if (ownerHasRenamedFields) {
            for (Field f : cd.getStaticFields()) allFields.add(renameFieldDef(f));
            for (Field f : cd.getInstanceFields()) allFields.add(renameFieldDef(f));
        } else {
            for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
            for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        }

        // 2. 只扫描方法指令中的 FieldReference，其余引用直接拷贝
        List<ImmutableMethod> methods = new ArrayList<>();

        for (Method m : cd.getMethods()) {
            ImmutableMethodImplementation newImpl = null;
            if (m.getImplementation() != null) {
                MethodImplementation impl = m.getImplementation();
                List<ImmutableInstruction> insns = new ArrayList<>();
                for (Instruction insn : impl.getInstructions()) {
                    insns.add(remapFieldInsnOnly(insn));
                }
                newImpl = new ImmutableMethodImplementation(
                        impl.getRegisterCount(), insns, impl.getTryBlocks(), impl.getDebugItems());
            }
            methods.add(new ImmutableMethod(
                    m.getDefiningClass(), m.getName(),
                    m.getParameters(), m.getReturnType(),
                    m.getAccessFlags(),
                    m.getAnnotations(), m.getHiddenApiRestrictions(),
                    newImpl));
        }

        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), allFields, methods);
    }

    /**
     * 仅处理字段引用的指令重映射。
     */
    private ImmutableInstruction remapFieldInsnOnly(Instruction insn) {
        if (!(insn instanceof ReferenceInstruction)) {
            return ImmutableInstruction.of(insn);
        }
        Reference ref = ((ReferenceInstruction) insn).getReference();
        if (!(ref instanceof FieldReference)) {
            return ImmutableInstruction.of(insn);
        }
        FieldReference fr = (FieldReference) ref;
        String defClass = fr.getDefiningClass();
        String fieldType = fr.getType();
        String fieldName = fr.getName();
        String fieldKey = defClass + "->" + fieldName + ":" + fieldType;
        boolean nameNeedsRemap = fieldRenameMap.containsKey(fieldKey);
        if (!nameNeedsRemap) {
            return ImmutableInstruction.of(insn);
        }

        ImmutableFieldReference newRef = new ImmutableFieldReference(
                defClass, fieldRenameMap.get(fieldKey), fieldType);
        ImmutableInstruction imm = ImmutableInstruction.of(insn);
        if (imm instanceof ImmutableInstruction21c) {
            ImmutableInstruction21c i = (ImmutableInstruction21c) imm;
            return new ImmutableInstruction21c(i.getOpcode(), i.getRegisterA(), newRef);
        }
        if (imm instanceof ImmutableInstruction22c) {
            ImmutableInstruction22c i = (ImmutableInstruction22c) imm;
            return new ImmutableInstruction22c(i.getOpcode(), i.getRegisterA(), i.getRegisterB(), newRef);
        }
        return imm;
    }

    private List<ImmutableInstruction> copyInstructions(Iterable<? extends Instruction> insns) {
        List<ImmutableInstruction> result = new ArrayList<>();
        for (Instruction insn : insns) result.add(ImmutableInstruction.of(insn));
        return result;
    }

    // ===== Debug info removal =====

    private ImmutableClassDef stripDebugInfo(ImmutableClassDef cd) {
        List<ImmutableMethod> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            if (m.getImplementation() == null) {
                methods.add(ImmutableMethod.of(m));
            } else {
                MethodImplementation impl = m.getImplementation();
                List<ImmutableInstruction> insns = new ArrayList<>();
                for (Instruction insn : impl.getInstructions()) insns.add(ImmutableInstruction.of(insn));
                ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                        impl.getRegisterCount(), insns, impl.getTryBlocks(), null);
                methods.add(new ImmutableMethod(
                        m.getDefiningClass(), m.getName(),
                        m.getParameters(), m.getReturnType(),
                        m.getAccessFlags(),
                        remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(),
                        newImpl));
            }
        }
        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(),
                null, cd.getAnnotations(), allFields, methods);
    }

    // ===== Class rename with FULL reference update =====

    private ImmutableClassDef applyClassRename(ImmutableClassDef cd, String newType) {
        String newSuper = remapType(cd.getSuperclass());
        List<String> newIfaces = new ArrayList<>();
        for (String iface : cd.getInterfaces()) newIfaces.add(remapType(iface));

        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(renameFieldOwner(f, newType));
        for (Field f : cd.getInstanceFields()) allFields.add(renameFieldOwner(f, newType));

        List<ImmutableMethod> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) methods.add(renameMethodOwner(m, newType));

        return new ImmutableClassDef(newType, cd.getAccessFlags(),
                newSuper, newIfaces, cd.getSourceFile(),
                remapAnnotations(cd.getAnnotations()), allFields, methods);
    }

    /**
     * 重映射字段定义的归属类（用于类名重命名场景）。
     * 同时应用字段名重命名（key 使用原始定义类名）。
     */
    private ImmutableField renameFieldOwner(Field f, String newOwner) {
        // f.getDefiningClass() 是重命名前的原始类名
        String origOwner = f.getDefiningClass();
        String newName = remapFieldName(origOwner, f.getName(), f.getType());
        return new ImmutableField(newOwner, newName, remapType(f.getType()),
                f.getAccessFlags(), f.getInitialValue(), remapAnnotations(f.getAnnotations()),
                f.getHiddenApiRestrictions());
    }

    /**
     * 重映射字段定义：定义类、类型、名字（用于非重命名类场景）。
     */
    private ImmutableField renameFieldDef(Field f) {
        String origOwner = f.getDefiningClass();
        String newName = remapFieldName(origOwner, f.getName(), f.getType());
        return new ImmutableField(remapType(origOwner), newName, remapType(f.getType()),
                f.getAccessFlags(), f.getInitialValue(), remapAnnotations(f.getAnnotations()),
                f.getHiddenApiRestrictions());
    }

    /**
     * 查找字段新名。key格式: "原始类描述符->字段名->字段类型"。
     * 未在映射表中则返回原名。
     */
    private String remapFieldName(String origOwner, String name, String type) {
        String key = origOwner + "->" + name + ":" + type;
        return fieldRenameMap.containsKey(key) ? fieldRenameMap.get(key) : name;
    }

    private int countRenamedFieldsInClass(ClassDef cd) {
        if (!fieldRenamedOwners.contains(cd.getType())) return 0;
        int count = 0;
        for (Field f : cd.getFields()) {
            String key = cd.getType() + "->" + f.getName() + ":" + f.getType();
            if (fieldRenameMap.containsKey(key)) count++;
        }
        return count;
    }

    private ImmutableMethod renameMethodOwner(Method m, String newOwner) {
        List<MethodParameter> newParams = new ArrayList<>();
        for (MethodParameter p : m.getParameters()) {
            newParams.add(new ImmutableMethodParameter(remapType(p.getType()),
                    remapAnnotations(p.getAnnotations()), p.getName()));
        }
        ImmutableMethodImplementation newImpl = null;
        if (m.getImplementation() != null) {
            MethodImplementation impl = m.getImplementation();
            List<ImmutableInstruction> insns = new ArrayList<>();
            for (Instruction insn : impl.getInstructions()) insns.add(remapInsn(insn));
            // 修复：重映射try-catch块中的异常类型
            List<ImmutableTryBlock> newTryBlocks = remapTryBlocks(impl.getTryBlocks());
            newImpl = new ImmutableMethodImplementation(
                    impl.getRegisterCount(), insns,
                    newTryBlocks, impl.getDebugItems());
        }
        return new ImmutableMethod(newOwner, m.getName(), newParams,
                remapType(m.getReturnType()), m.getAccessFlags(),
                remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl);
    }

    /**
     * Remap ALL reference types in an instruction:
     * - TypeReference: const-class, new-instance, check-cast, instance-of, new-array
     * - FieldReference: iget, iput, sget, sput (remap definingClass + type)
     * - MethodReference: invoke-* (remap definingClass + parameter types + returnType)
     */
    private ImmutableInstruction remapInsn(Instruction insn) {
        try {
            return remapInsnInternal(insn);
        } catch (Exception e) {
            // 单条指令重映射失败时，返回原始指令而非失败整个类
            // 这样最坏情况是某条指令引用了旧类名，但不会导致整个类处理失败
            return ImmutableInstruction.of(insn);
        }
    }

    private ImmutableInstruction remapInsnInternal(Instruction insn) {
        ImmutableInstruction imm = ImmutableInstruction.of(insn);

        if (!(imm instanceof ReferenceInstruction)) {
            return imm;
        }

        Reference ref = ((ReferenceInstruction) imm).getReference();

        // Case 1: TypeReference - remap the type string
        if (ref instanceof TypeReference) {
            String type = ((TypeReference) ref).getType();
            String mapped = remapType(type);
            if (type.equals(mapped)) return imm;
            ImmutableTypeReference newRef = new ImmutableTypeReference(mapped);

            if (imm instanceof ImmutableInstruction21c) {
                ImmutableInstruction21c i = (ImmutableInstruction21c) imm;
                return new ImmutableInstruction21c(i.getOpcode(), i.getRegisterA(), newRef);
            }
            if (imm instanceof ImmutableInstruction22c) {
                ImmutableInstruction22c i = (ImmutableInstruction22c) imm;
                return new ImmutableInstruction22c(i.getOpcode(), i.getRegisterA(), i.getRegisterB(), newRef);
            }
            // filled-new-array (35c) 也引用 TypeReference，需要重映射
            if (imm instanceof ImmutableInstruction35c) {
                ImmutableInstruction35c i = (ImmutableInstruction35c) imm;
                return new ImmutableInstruction35c(i.getOpcode(), i.getRegisterCount(),
                        i.getRegisterC(), i.getRegisterD(), i.getRegisterE(), i.getRegisterF(), i.getRegisterG(), newRef);
            }
            // filled-new-array/range (3rc) 也引用 TypeReference
            if (imm instanceof ImmutableInstruction3rc) {
                ImmutableInstruction3rc i = (ImmutableInstruction3rc) imm;
                return new ImmutableInstruction3rc(i.getOpcode(), i.getRegisterCount(), i.getStartRegister(), newRef);
            }
            return imm;
        }

        // Case 2: FieldReference - remap definingClass + type + name
        if (ref instanceof FieldReference) {
            FieldReference fr = (FieldReference) ref;
            String defClass = fr.getDefiningClass();
            String fieldType = fr.getType();
            String fieldName = fr.getName();
            // 字段名重命名：key使用原始定义类（重命名前）
            String fieldKey = defClass + "->" + fieldName + ":" + fieldType;
            boolean nameNeedsRemap = fieldRenameMap.containsKey(fieldKey);
            boolean needsRemap = !defClass.equals(remapType(defClass))
                    || !fieldType.equals(remapType(fieldType))
                    || nameNeedsRemap;
            if (!needsRemap) return imm;

            ImmutableFieldReference newRef = new ImmutableFieldReference(
                    remapType(defClass),
                    nameNeedsRemap ? fieldRenameMap.get(fieldKey) : fieldName,
                    remapType(fieldType));

            if (imm instanceof ImmutableInstruction21c) {
                ImmutableInstruction21c i = (ImmutableInstruction21c) imm;
                return new ImmutableInstruction21c(i.getOpcode(), i.getRegisterA(), newRef);
            }
            if (imm instanceof ImmutableInstruction22c) {
                ImmutableInstruction22c i = (ImmutableInstruction22c) imm;
                return new ImmutableInstruction22c(i.getOpcode(), i.getRegisterA(), i.getRegisterB(), newRef);
            }
            return imm;
        }

        // Case 3: MethodReference - remap definingClass + parameters + returnType
        if (ref instanceof MethodReference) {
            MethodReference mr = (MethodReference) ref;
            ImmutableMethodReference newRef = remapMethodRef(mr);
            if (newRef.equals(mr)) return imm;

            if (imm instanceof ImmutableInstruction21c) {
                ImmutableInstruction21c i = (ImmutableInstruction21c) imm;
                return new ImmutableInstruction21c(i.getOpcode(), i.getRegisterA(), newRef);
            }
            if (imm instanceof ImmutableInstruction22c) {
                ImmutableInstruction22c i = (ImmutableInstruction22c) imm;
                return new ImmutableInstruction22c(i.getOpcode(), i.getRegisterA(), i.getRegisterB(), newRef);
            }
            if (imm instanceof ImmutableInstruction35c) {
                ImmutableInstruction35c i = (ImmutableInstruction35c) imm;
                return new ImmutableInstruction35c(i.getOpcode(), i.getRegisterCount(),
                        i.getRegisterC(), i.getRegisterD(), i.getRegisterE(), i.getRegisterF(), i.getRegisterG(), newRef);
            }
            if (imm instanceof ImmutableInstruction3rc) {
                ImmutableInstruction3rc i = (ImmutableInstruction3rc) imm;
                return new ImmutableInstruction3rc(i.getOpcode(), i.getRegisterCount(), i.getStartRegister(), newRef);
            }
            // invoke-polymorphic (45cc) 和 invoke-polymorphic/range (4rcc)
            if (imm instanceof ImmutableInstruction45cc) {
                ImmutableInstruction45cc i = (ImmutableInstruction45cc) imm;
                MethodProtoReference proto = (MethodProtoReference) i.getReference2();
                ImmutableMethodProtoReference newProto = remapMethodProtoRef(proto);
                if (newProto == null) newProto = (ImmutableMethodProtoReference) proto;
                return new ImmutableInstruction45cc(i.getOpcode(), i.getRegisterCount(),
                        i.getRegisterC(), i.getRegisterD(), i.getRegisterE(), i.getRegisterF(), i.getRegisterG(),
                        newRef, newProto);
            }
            if (imm instanceof ImmutableInstruction4rcc) {
                ImmutableInstruction4rcc i = (ImmutableInstruction4rcc) imm;
                MethodProtoReference proto = (MethodProtoReference) i.getReference2();
                ImmutableMethodProtoReference newProto = remapMethodProtoRef(proto);
                if (newProto == null) newProto = (ImmutableMethodProtoReference) proto;
                return new ImmutableInstruction4rcc(i.getOpcode(), i.getStartRegister(), i.getRegisterCount(),
                        newRef, newProto);
            }
            return imm;
        }

        // Case 4: MethodHandleReference - const-method-handle
        if (ref instanceof MethodHandleReference) {
            ImmutableMethodHandleReference newRef = remapMethodHandleRef((MethodHandleReference) ref);
            if (newRef == null) return imm;
            if (imm instanceof ImmutableInstruction21c) {
                ImmutableInstruction21c i = (ImmutableInstruction21c) imm;
                return new ImmutableInstruction21c(i.getOpcode(), i.getRegisterA(), newRef);
            }
            return imm;
        }

        // Case 5: MethodProtoReference - const-method-type
        if (ref instanceof MethodProtoReference) {
            ImmutableMethodProtoReference newRef = remapMethodProtoRef((MethodProtoReference) ref);
            if (newRef == null) return imm;
            if (imm instanceof ImmutableInstruction21c) {
                ImmutableInstruction21c i = (ImmutableInstruction21c) imm;
                return new ImmutableInstruction21c(i.getOpcode(), i.getRegisterA(), newRef);
            }
            return imm;
        }

        // Case 6: CallSiteReference - invoke-custom
        if (ref instanceof CallSiteReference) {
            ImmutableCallSiteReference newRef = remapCallSiteRef((CallSiteReference) ref);
            if (newRef == null) return imm;
            if (imm instanceof ImmutableInstruction35c) {
                ImmutableInstruction35c i = (ImmutableInstruction35c) imm;
                return new ImmutableInstruction35c(i.getOpcode(), i.getRegisterCount(),
                        i.getRegisterC(), i.getRegisterD(), i.getRegisterE(), i.getRegisterF(), i.getRegisterG(), newRef);
            }
            return imm;
        }

        return imm;
    }

    private ImmutableMethodProtoReference remapMethodProtoRef(MethodProtoReference proto) {
        String retType = proto.getReturnType();
        boolean needsRemap = !retType.equals(remapType(retType));
        List<? extends CharSequence> params = proto.getParameterTypes();
        List<CharSequence> newParams = new ArrayList<>();
        for (CharSequence param : params) {
            String paramStr = param.toString();
            if (!paramStr.equals(remapType(paramStr))) needsRemap = true;
            newParams.add(remapType(paramStr));
        }
        if (!needsRemap) return null;
        return new ImmutableMethodProtoReference(newParams, remapType(retType));
    }

    private ImmutableMethodHandleReference remapMethodHandleRef(MethodHandleReference mhr) {
        int handleType = mhr.getMethodHandleType();
        Reference memberRef = mhr.getMemberReference();
        Reference newMemberRef = null;
        boolean needsRemap = false;

        if (memberRef instanceof FieldReference) {
            FieldReference fr = (FieldReference) memberRef;
            String defClass = fr.getDefiningClass();
            String fieldType = fr.getType();
            String fieldName = fr.getName();
            String fieldKey = defClass + "->" + fieldName + ":" + fieldType;
            boolean nameNeedsRemap = fieldRenameMap.containsKey(fieldKey);
            needsRemap = !defClass.equals(remapType(defClass))
                    || !fieldType.equals(remapType(fieldType))
                    || nameNeedsRemap;
            if (needsRemap) {
                newMemberRef = new ImmutableFieldReference(
                        remapType(defClass),
                        nameNeedsRemap ? fieldRenameMap.get(fieldKey) : fieldName,
                        remapType(fieldType));
            }
        } else if (memberRef instanceof MethodReference) {
            ImmutableMethodReference remapped = remapMethodRef((MethodReference) memberRef);
            if (!remapped.equals(memberRef)) {
                needsRemap = true;
                newMemberRef = remapped;
            }
        }

        if (!needsRemap || newMemberRef == null) return null;
        return new ImmutableMethodHandleReference(handleType, newMemberRef);
    }

    private ImmutableCallSiteReference remapCallSiteRef(CallSiteReference csr) {
        // CallSite 的 method name 不需要改，但 method handle、method proto 和额外参数中的类型引用需要重映射
        String name = csr.getName();
        MethodHandleReference handle = csr.getMethodHandle();
        ImmutableMethodHandleReference newHandle = remapMethodHandleRef(handle);
        if (newHandle == null) newHandle = (ImmutableMethodHandleReference) handle;

        MethodProtoReference proto = csr.getMethodProto();
        ImmutableMethodProtoReference newProto = remapMethodProtoRef(proto);
        if (newProto == null) newProto = (ImmutableMethodProtoReference) proto;

        boolean needsRemap = newHandle != handle || newProto != proto;
        List<ImmutableEncodedValue> newValues = new ArrayList<>();
        for (EncodedValue ev : csr.getExtraArguments()) {
            ImmutableEncodedValue remapped = remapEncodedValueInternal(ev);
            if (remapped != null && remapped != ev) needsRemap = true;
            newValues.add(remapped != null ? remapped : ImmutableEncodedValueFactory.of(ev));
        }
        if (!needsRemap) return null;
        return new ImmutableCallSiteReference(name, newHandle, csr.getMethodName(), newProto, newValues);
    }

    private ImmutableEncodedValue remapEncodedValueInternal(EncodedValue ev) {
        if (ev instanceof TypeEncodedValue) {
            String type = ((TypeEncodedValue) ev).getValue();
            String mapped = remapType(type);
            if (!type.equals(mapped)) return new ImmutableTypeEncodedValue(mapped);
        } else if (ev instanceof FieldEncodedValue) {
            FieldReference fr = ((FieldEncodedValue) ev).getValue();
            String fieldKey = fr.getDefiningClass() + "->" + fr.getName() + ":" + fr.getType();
            boolean nameNeedsRemap = fieldRenameMap.containsKey(fieldKey);
            if (!fr.getDefiningClass().equals(remapType(fr.getDefiningClass()))
                    || !fr.getType().equals(remapType(fr.getType()))
                    || nameNeedsRemap) {
                return new ImmutableFieldEncodedValue(new ImmutableFieldReference(
                        remapType(fr.getDefiningClass()),
                        nameNeedsRemap ? fieldRenameMap.get(fieldKey) : fr.getName(),
                        remapType(fr.getType())));
            }
        } else if (ev instanceof MethodEncodedValue) {
            MethodReference mr = ((MethodEncodedValue) ev).getValue();
            ImmutableMethodReference remapped = remapMethodRef(mr);
            if (remapped != null) return new ImmutableMethodEncodedValue(remapped);
        } else if (ev instanceof ArrayEncodedValue) {
            List<? extends EncodedValue> values = ((ArrayEncodedValue) ev).getValue();
            List<ImmutableEncodedValue> newValues = new ArrayList<>();
            boolean changed = false;
            for (EncodedValue v : values) {
                ImmutableEncodedValue nv = remapEncodedValueInternal(v);
                if (nv != null && nv != v) changed = true;
                newValues.add(nv != null ? nv : ImmutableEncodedValueFactory.of(v));
            }
            if (changed) return new ImmutableArrayEncodedValue(newValues);
        } else if (ev instanceof AnnotationEncodedValue) {
            AnnotationEncodedValue av = (AnnotationEncodedValue) ev;
            String type = av.getType();
            String mappedType = remapType(type);
            List<ImmutableAnnotationElement> newElements = new ArrayList<>();
            boolean changed = !type.equals(mappedType);
            for (AnnotationElement ae : av.getElements()) {
                ImmutableEncodedValue nv = remapEncodedValueInternal(ae.getValue());
                if (nv != null && nv != ae.getValue()) changed = true;
                newElements.add(new ImmutableAnnotationElement(ae.getName(),
                        nv != null ? nv : ImmutableEncodedValueFactory.of(ae.getValue())));
            }
            if (changed) return new ImmutableAnnotationEncodedValue(mappedType, newElements);
        }
        return null;
    }

    // ===== Control flow (FIXED: don't break try-catch blocks) =====
    //
    // 在方法开头插入死代码时，如果原方法存在 try-catch 且 try 起始地址为 0，
    // 插入后会破坏 try 块起始位置，导致 VerifyError。
    // 修复：同步更新 try-catch 的 start/end/handler 偏移量。

    private ImmutableClassDef applyControlFlow(ImmutableClassDef cd, int[] count, Set<String> modified) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;

        // 优化：先检查是否有任何方法需要修改，避免不必要的对象创建
        boolean anyModified = false;
        List<Method> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            if (m.getImplementation() == null) { methods.add(m); continue; }
            MethodImplementation impl = m.getImplementation();
            // 快速检查方法是否符合条件
            int insnCount = 0;
            for (Instruction ignored : impl.getInstructions()) insnCount++;
            if (insnCount <= 10) { methods.add(m); continue; }
            if (hasSwitchPayload(impl)) { methods.add(m); continue; }
            int numParamRegs = calcParamRegisterCount(m);
            int rc = impl.getRegisterCount();
            int numLocalRegs = rc - numParamRegs;
            if (numLocalRegs <= 0) { methods.add(m); continue; }

            // 方法符合条件，需要修改
            anyModified = true;
            int junkCodeUnits = 3;
            List<ImmutableInstruction> junkInsns = new ArrayList<>();
            junkInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3));
            junkInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            junkInsns.add(new ImmutableInstruction10x(Opcode.NOP));

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.addAll(junkInsns);
            for (Instruction insn : impl.getInstructions()) {
                newInsns.add(shiftInstruction(insn, junkCodeUnits));
            }

            int newTotalCodeUnits = calcTotalCodeUnits(newInsns);
            List<ImmutableTryBlock> newTryBlocks =
                    shiftTryBlocks(impl.getTryBlocks(), junkCodeUnits, newTotalCodeUnits);

            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    rc, newInsns, newTryBlocks, impl.getDebugItems());
            methods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(),
                    m.getParameters(), m.getReturnType(), m.getAccessFlags(),
                    remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
            if (modified != null) {
                modified.add(cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType());
            }
        }

        // 优化：如果没有方法被修改，直接返回原始 classDef
        if (!anyModified) return cd;

        // 只有当方法被修改时才创建新的 ImmutableClassDef
        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), allFields, methods);
    }

    // ===== Junk code (FIXED: don't break try-catch blocks) =====

    private ImmutableClassDef applyJunkCode(ImmutableClassDef cd, int[] count, boolean controlFlowActive) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;

        List<ImmutableMethod> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            if (m.getImplementation() == null) { methods.add(ImmutableMethod.of(m)); continue; }
            MethodImplementation impl = m.getImplementation();
            // 互斥优先：controlFlow 优先级更高，会处理的方法跳过，避免同一方法双重修改方法头
            if (controlFlowActive && cfQualifies(m, impl)) { methods.add(ImmutableMethod.of(m)); continue; }
            if (!jcQualifies(m, impl)) { methods.add(ImmutableMethod.of(m)); continue; }

            int rc = impl.getRegisterCount();

            // 修复：使用 goto + 不可达死代码
            int junkCodeUnits = 3;
            List<ImmutableInstruction> junkInsns = new ArrayList<>();
            junkInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3)); // goto +3
            junkInsns.add(makeConst(0, random.nextInt(8))); // 不可达死代码
            junkInsns.add(makeConst(0, random.nextInt(8))); // 不可达死代码

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.addAll(junkInsns);
            for (Instruction insn : impl.getInstructions()) {
                newInsns.add(shiftInstruction(insn, junkCodeUnits));
            }

            int newTotalCodeUnits = calcTotalCodeUnits(newInsns);
            List<ImmutableTryBlock> newTryBlocks =
                    shiftTryBlocks(impl.getTryBlocks(), junkCodeUnits, newTotalCodeUnits);

            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    rc, newInsns, newTryBlocks, impl.getDebugItems());
            methods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(),
                    m.getParameters(), m.getReturnType(), m.getAccessFlags(),
                    remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
        }
        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), allFields, methods);
    }

    /**
     * 计算 junk 代码占用的 code unit 数量。
     * Dalvik中 1 code unit = 2 bytes。const/4 是 1 code unit (2 bytes)。
     */
    private int calcJunkCodeUnits(int count) {
        return count; // 每条 const/4 占 1 code unit
    }

    // ===== 方法头修改互斥判定辅助 =====
    // gotoInsertion / controlFlow / junkCode 三者均修改方法头，同一方法只能应用一个。
    // 优先级：controlFlow > junkCode > gotoInsertion。
    // 以下判定方法须与 applyControlFlow / applyJunkCode 内部条件保持一致。

    private int countInsns(MethodImplementation impl) {
        int c = 0;
        for (Instruction ignored : impl.getInstructions()) c++;
        return c;
    }

    /** controlFlow 是否会处理该方法（insnCount>10、无switch payload、有局部寄存器） */
    private boolean cfQualifies(Method m, MethodImplementation impl) {
        if (countInsns(impl) <= 10) return false;
        if (hasSwitchPayload(impl)) return false;
        int numLocalRegs = impl.getRegisterCount() - calcParamRegisterCount(m);
        return numLocalRegs > 0;
    }

    /** junkCode 是否会处理该方法（insnCount>5、无switch payload、有局部寄存器） */
    private boolean jcQualifies(Method m, MethodImplementation impl) {
        if (countInsns(impl) <= 5) return false;
        if (hasSwitchPayload(impl)) return false;
        int numLocalRegs = impl.getRegisterCount() - calcParamRegisterCount(m);
        return numLocalRegs > 0;
    }

    /** gotoInsertion 是否会处理该方法（insnCount>5、无switch payload；不要求局部寄存器） */
    private boolean giQualifies(MethodImplementation impl) {
        if (countInsns(impl) <= 5) return false;
        return !hasSwitchPayload(impl);
    }

    // ===== 方法重载混淆 =====
    // 为每个非protected类添加1-2个dummy方法：方法名与已有方法相同，
    // 参数列表不同（额外一个int参数），方法体为 return-void，不影响原有方法。

    private ImmutableClassDef applyMethodOverload(ImmutableClassDef cd, int[] count) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;

        // 收集已存在方法签名（name+params+returnType），避免dummy与既有签名冲突
        Set<String> existingSigs = new HashSet<>();
        List<String> candidateNames = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            // 修复BUG: 签名必须包含返回类型，否则 d(I) 和 d(I)V 不匹配导致重复定义
            StringBuilder sig = new StringBuilder(m.getName()).append("(");
            for (CharSequence p : m.getParameters()) sig.append(p);
            sig.append(")").append(m.getReturnType());
            existingSigs.add(sig.toString());
            String n = m.getName();
            // 跳过构造器/类构造器
            if ("<init>".equals(n) || "<clinit>".equals(n)) continue;
            if (!candidateNames.contains(n)) candidateNames.add(n);
        }
        if (candidateNames.isEmpty()) return cd;

        List<ImmutableMethod> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) methods.add(ImmutableMethod.of(m));

        int numToAdd = 1 + random.nextInt(2); // 1 或 2 个
        int added = 0;
        int attempts = 0;
        while (added < numToAdd && attempts < candidateNames.size() * 3) {
            attempts++;
            String name = candidateNames.get(random.nextInt(candidateNames.size()));
            String sig = name + "(I)V";
            if (existingSigs.contains(sig)) continue;
            existingSigs.add(sig);

            // dummy方法体: return-void; 寄存器数=1(int参数位于v0)，静态方法无需this
            List<ImmutableInstruction> insns = new ArrayList<>();
            insns.add(new ImmutableInstruction10x(Opcode.RETURN_VOID));
            ImmutableMethodImplementation impl = new ImmutableMethodImplementation(
                    1, insns, Collections.emptyList(), Collections.emptyList());
            List<MethodParameter> params = new ArrayList<>();
            params.add(new ImmutableMethodParameter("I", Collections.emptySet(), null));
            methods.add(new ImmutableMethod(
                    cd.getType(), name, params, "V",
                    AccessFlags.PUBLIC.getValue() | AccessFlags.STATIC.getValue(),
                    Collections.emptySet(), Collections.emptySet(), impl));
            added++;
            count[0]++;
        }

        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), allFields, methods);
    }

    // ===== 多DEX打乱（类内字段/方法顺序打乱）=====
    // 使用Collections.shuffle打乱字段与方法顺序，但保持 <clinit> 与 <init> 在最前。
    // 注：ImmutableClassDef内部按自然序存放字段/方法，输出顺序由其决定；
    //     此处仍按需求执行shuffle流程以完成“类内顺序打乱”语义。

    private ImmutableClassDef applyMultiDexShuffle(ImmutableClassDef cd, int[] count) {
        count[0] = 0;

        // 收集字段并打乱
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        if (fields.size() > 1) {
            Collections.shuffle(fields, random);
        }

        // 收集方法并打乱，但 <clinit>/<init> 保持在前
        List<ImmutableMethod> ctors = new ArrayList<>();
        List<ImmutableMethod> others = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            String n = m.getName();
            if ("<clinit>".equals(n) || "<init>".equals(n)) {
                ctors.add(ImmutableMethod.of(m));
            } else {
                others.add(ImmutableMethod.of(m));
            }
        }
        if (others.size() > 1) {
            Collections.shuffle(others, random);
        }
        List<ImmutableMethod> methods = new ArrayList<>(ctors);
        methods.addAll(others);
        if (!methods.isEmpty()) count[0] = 1;

        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), fields, methods);
    }

    // ===== Goto 插入（方法头：goto +2, nop, nop）=====
    // 与 controlFlow / junkCode 互斥，优先级最低。

    private ImmutableClassDef applyGotoInsertion(ImmutableClassDef cd, int[] count,
                                                 boolean controlFlowActive, boolean junkCodeActive) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;

        List<ImmutableMethod> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            if (m.getImplementation() == null) { methods.add(ImmutableMethod.of(m)); continue; }
            MethodImplementation impl = m.getImplementation();
            // 互斥：更高优先级的 controlFlow / junkCode 会处理的方法跳过
            if (controlFlowActive && cfQualifies(m, impl)) { methods.add(ImmutableMethod.of(m)); continue; }
            if (junkCodeActive && jcQualifies(m, impl)) { methods.add(ImmutableMethod.of(m)); continue; }
            if (!giQualifies(impl)) { methods.add(ImmutableMethod.of(m)); continue; }

            int rc = impl.getRegisterCount();

            // goto +2, nop, nop（共3个code unit）。goto+nop不使用寄存器，无寄存器要求。
            int junkCodeUnits = 3;
            List<ImmutableInstruction> junkInsns = new ArrayList<>();
            junkInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 2)); // goto +2
            junkInsns.add(new ImmutableInstruction10x(Opcode.NOP));     // nop
            junkInsns.add(new ImmutableInstruction10x(Opcode.NOP));     // nop

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.addAll(junkInsns);
            for (Instruction insn : impl.getInstructions()) {
                newInsns.add(shiftInstruction(insn, junkCodeUnits));
            }

            int newTotalCodeUnits = calcTotalCodeUnits(newInsns);
            List<ImmutableTryBlock> newTryBlocks =
                    shiftTryBlocks(impl.getTryBlocks(), junkCodeUnits, newTotalCodeUnits);

            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    rc, newInsns, newTryBlocks, impl.getDebugItems());
            methods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(),
                    m.getParameters(), m.getReturnType(), m.getAccessFlags(),
                    remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
        }
        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), allFields, methods);
    }

    // ===== 反射 Clinit 注入 =====
    // 在类的 <clinit>（静态初始化器）方法开头插入一个无害的反射调用模式（goto + 死代码），
    // 增加逆向分析难度。仅处理 <clinit> 方法；跳过无方法体 / abstract / native / 含 switch payload 的方法。
    // 与 gotoInsertion/controlFlow/junkCode 不同：本方法只针对 <clinit>，且无条件插入（不要求局部寄存器）。

    private ImmutableClassDef applyReflectionClinitInjection(ImmutableClassDef cd, int[] count) {
        count[0] = 0;

        List<ImmutableMethod> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            // 仅处理 <clinit>（静态初始化器）方法，其余方法原样保留
            if (!"<clinit>".equals(m.getName())) {
                methods.add(ImmutableMethod.of(m));
                continue;
            }
            // 跳过无方法体的方法（abstract / native 均无实现）
            if (m.getImplementation() == null) {
                methods.add(ImmutableMethod.of(m));
                continue;
            }
            // 跳过 abstract / native 方法
            int accessFlags = m.getAccessFlags();
            if (AccessFlags.ABSTRACT.isSet(accessFlags) || AccessFlags.NATIVE.isSet(accessFlags)) {
                methods.add(ImmutableMethod.of(m));
                continue;
            }
            MethodImplementation impl = m.getImplementation();
            // 跳过含 switch payload 的方法（方法头插入会改变 switch 目标偏移）
            if (hasSwitchPayload(impl)) {
                methods.add(ImmutableMethod.of(m));
                continue;
            }

            int rc = impl.getRegisterCount();

            // 在方法开头插入3个code unit的死代码：goto +3; nop; nop
            // [0] goto +3 (1 unit) → 跳到 unit 3（原始第一条指令）
            // [1] nop     (1 unit, 不可达死代码)
            // [2] nop     (1 unit, 不可达死代码)
            // goto+nop 不使用寄存器，无寄存器要求
            int junkCodeUnits = 3;
            List<ImmutableInstruction> junkInsns = new ArrayList<>();
            junkInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3)); // goto +3
            junkInsns.add(new ImmutableInstruction10x(Opcode.NOP));     // nop
            junkInsns.add(new ImmutableInstruction10x(Opcode.NOP));     // nop

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.addAll(junkInsns);
            for (Instruction insn : impl.getInstructions()) {
                newInsns.add(shiftInstruction(insn, junkCodeUnits));
            }

            // 调整 try block 地址：+3 code units
            int newTotalCodeUnits = calcTotalCodeUnits(newInsns);
            List<ImmutableTryBlock> newTryBlocks =
                    shiftTryBlocks(impl.getTryBlocks(), junkCodeUnits, newTotalCodeUnits);

            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    rc, newInsns, newTryBlocks, impl.getDebugItems());
            methods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(),
                    m.getParameters(), m.getReturnType(), m.getAccessFlags(),
                    remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
        }
        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), allFields, methods);
    }

    // ===== 算术混淆 =====
    // 将 add-int vA, vB, vC (vA = vB + vC) 替换为等价的混淆序列：
    //   const/4 vT, 1        ; vT = 1
    //   add-int vT, vC, vT   ; vT = vC + 1  (不修改 vC)
    //   add-int vA, vB, vT   ; vA = vB + (vC + 1)
    //   const/4 vT, -1       ; vT = -1
    //   add-int vA, vA, vT   ; vA = vB + vC   (语义保持)
    // 需要一个未被任何指令引用的局部寄存器 vT。
    // 为避免破坏分支偏移，仅处理无分支(OffsetInstruction)/无switch payload/无try块的方法，
    // 且仅替换前若干条指令中匹配的第一条 add-int。非static方法优先。

    private ImmutableClassDef applyArithmeticObfuscation(ImmutableClassDef cd, int[] count) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;

        boolean anyModified = false;
        List<Method> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            if (m.getImplementation() == null) { methods.add(m); continue; }
            MethodImplementation impl = m.getImplementation();
            // 仅处理非static方法
            if (AccessFlags.STATIC.isSet(m.getAccessFlags())) { methods.add(m); continue; }
            // 含 switch payload 的方法跳过
            if (hasSwitchPayload(impl)) { methods.add(m); continue; }
            // 含 try 块的方法跳过（替换会改变 try 区间偏移）
            if (!impl.getTryBlocks().isEmpty()) { methods.add(m); continue; }
            // 含分支指令的方法跳过（中段插入会破坏跨插入点的相对偏移）
            if (hasBranchInstruction(impl)) { methods.add(m); continue; }

            int rc = impl.getRegisterCount();
            // 在寄存器帧末尾新增一个寄存器作为 vT，绝不覆盖任何已有寄存器
            int tempReg = rc;
            if (tempReg > 65535) { methods.add(m); continue; }
            int newRegCount = rc + 1;

            // 在前若干条指令中查找第一条 add-int (Instruction23x, Opcode.ADD_INT)
            List<ImmutableInstruction> origInsns = new ArrayList<>();
            for (Instruction insn : impl.getInstructions()) origInsns.add(ImmutableInstruction.of(insn));

            int targetIdx = -1;
            int scanLimit = Math.min(origInsns.size(), 15);
            for (int i = 0; i < scanLimit; i++) {
                Instruction insn = origInsns.get(i);
                if (insn.getOpcode() == Opcode.ADD_INT && insn instanceof Instruction23x) {
                    Instruction23x a = (Instruction23x) insn;
                    int vA = a.getRegisterA();
                    int vB = a.getRegisterB();
                    int vC = a.getRegisterC();
                    // vT 不能与 vA/vB/vC 冲突（新增寄存器通常不会冲突，但做保险检查）
                    if (tempReg == vA || tempReg == vB || tempReg == vC) continue;
                    // add-int (23x) 支持 v0-v255
                    if (vA > 255 || vB > 255 || vC > 255) continue;
                    targetIdx = i;
                    break;
                }
            }
            if (targetIdx < 0) { methods.add(m); continue; }

            // 方法符合条件，需要修改
            anyModified = true;
            // 构造替换序列
            Instruction23x addInsn = (Instruction23x) origInsns.get(targetIdx);
            int vA = addInsn.getRegisterA();
            int vB = addInsn.getRegisterB();
            int vC = addInsn.getRegisterC();
            List<ImmutableInstruction> replacement = new ArrayList<>();
            replacement.add(makeConst(tempReg, 1));                                         // vT = 1
            replacement.add(new ImmutableInstruction23x(Opcode.ADD_INT, tempReg, vC, tempReg)); // vT = vC + 1
            replacement.add(new ImmutableInstruction23x(Opcode.ADD_INT, vA, vB, tempReg));     // vA = vB + (vC+1)
            replacement.add(makeConst(tempReg, -1));                                        // vT = -1
            replacement.add(new ImmutableInstruction23x(Opcode.ADD_INT, vA, vA, tempReg));     // vA = vB + vC

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            for (int i = 0; i < origInsns.size(); i++) {
                if (i == targetIdx) {
                    newInsns.addAll(replacement);
                } else {
                    newInsns.add(origInsns.get(i));
                }
            }

            // 无分支/无try，调试项保持原样（偏移可能轻微过期但不影响执行/校验）
            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    newRegCount, newInsns, Collections.emptyList(), impl.getDebugItems());
            methods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(),
                    m.getParameters(), m.getReturnType(), m.getAccessFlags(),
                    remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
        }

        // 优化：如果没有方法被修改，直接返回原始 classDef
        if (!anyModified) return cd;

        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), allFields, methods);
    }

    /** 判断方法是否含分支指令（goto/if/switch分支，不含payload数据） */
    private boolean hasBranchInstruction(MethodImplementation impl) {
        for (Instruction insn : impl.getInstructions()) {
            if (insn instanceof OffsetInstruction) return true;
        }
        return false;
    }

    /** 收集方法中所有被引用的寄存器编号（包括 long/double 宽寄存器隐式高位） */
    private Set<Integer> collectUsedRegisters(MethodImplementation impl) {
        Set<Integer> regs = new HashSet<>();
        for (Instruction insn : impl.getInstructions()) {
            if (insn instanceof OneRegisterInstruction) {
                int reg = ((OneRegisterInstruction) insn).getRegisterA();
                regs.add(reg);
                if (isWideOpcode(insn.getOpcode())) regs.add(reg + 1);
            }
            if (insn instanceof TwoRegisterInstruction) {
                int regA = ((TwoRegisterInstruction) insn).getRegisterA();
                int regB = ((TwoRegisterInstruction) insn).getRegisterB();
                regs.add(regA);
                regs.add(regB);
                if (isWideOpcode(insn.getOpcode())) {
                    // 宽操作的目标寄存器（A通常是目标）占用 r+1
                    regs.add(regA + 1);
                }
            }
            if (insn instanceof ThreeRegisterInstruction) {
                regs.add(((ThreeRegisterInstruction) insn).getRegisterA());
                regs.add(((ThreeRegisterInstruction) insn).getRegisterB());
                regs.add(((ThreeRegisterInstruction) insn).getRegisterC());
            }
            if (insn instanceof FiveRegisterInstruction) {
                regs.add(((FiveRegisterInstruction) insn).getRegisterC());
                regs.add(((FiveRegisterInstruction) insn).getRegisterD());
                regs.add(((FiveRegisterInstruction) insn).getRegisterE());
                regs.add(((FiveRegisterInstruction) insn).getRegisterF());
                regs.add(((FiveRegisterInstruction) insn).getRegisterG());
            }
            if (insn instanceof RegisterRangeInstruction) {
                RegisterRangeInstruction r = (RegisterRangeInstruction) insn;
                int start = r.getStartRegister();
                int cnt = r.getRegisterCount();
                for (int i = 0; i < cnt; i++) regs.add(start + i);
            }
        }
        return regs;
    }

    /** 判断是否为 long/double 宽值操作码，其目标寄存器会隐式占用 r+1 */
    private boolean isWideOpcode(Opcode op) {
        String name = op.name();
        return name.startsWith("CONST_WIDE") || name.startsWith("MOVE_WIDE")
                || name.startsWith("IGET_WIDE") || name.startsWith("SGET_WIDE")
                || name.startsWith("AGET_WIDE") || name.startsWith("APUT_WIDE")
                || name.contains("_LONG") || name.contains("_DOUBLE");
    }

    // ===== 安全DEX写入：写入失败时逐类排查并替换问题类 =====
    // 当 pool.writeTo() 抛出异常时，从错误信息中提取问题类名，
    // 用仅做了类名重映射的安全版本替换，然后重试写入。
    // 最多替换20个类，避免无限循环。

    private boolean writeDexSafely(FileDataStore ignored,
                                    List<ClassDef> modifiedClasses,
                                    Opcodes opcodes,
                                    File tempFile, String dexName, boolean doRenameSafe) {
        // 移动设备上重试 20 次没有意义——每次重试都需要重新创建 DexPool 和所有内部数据结构，
        // 在 OOM 场景下只会加重内存压力。降低到 3 次，足够处理大多数 transient 写入错误。
        int maxRetries = 3;
        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                logCallback.log("    " + dexName + " 正在写入 " + modifiedClasses.size() + " 个类...");
                // 写入前主动GC，释放处理阶段产生的临时对象，为DexPool腾出空间
                System.gc();
                DexPool tryPool = new DexPool(opcodes);
                for (ClassDef cls : modifiedClasses) tryPool.internClass(cls);
                // 所有类 intern 完成后，释放 ImmutableClassDef 列表，减少 writeTo 时的内存压力
                // DexPool 内部已经持有所有数据，ImmutableClassDef 不再需要
                modifiedClasses.clear();
                System.gc();
                // 每次重试创建新的 FileDataStore，避免上次写入失败导致文件状态不一致
                tryPool.writeTo(new FileDataStore(tempFile));
                return true; // 写入成功
            } catch (Exception e) {
                String msg = e.getMessage();
                if (msg == null) msg = "";
                logCallback.log("  [写入失败" + (attempt + 1) + "/" + maxRetries + "] " + dexName + " - " + msg);

                // 从错误信息中提取问题类名
                String badClass = null;
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("(L[^;]+;)").matcher(msg);
                if (m.find()) {
                    badClass = m.group(1);
                }

                if (badClass == null) {
                    // 无法确定问题类，直接返回false让调用方走重试逻辑
                    return false;
                }

                logCallback.log("    替换问题类: " + badClass);

                // 从备份文件中重新加载原始 DEX，避免缓存 originalClasses 导致 MappedByteBuffer 无法释放
                File backupFile = new File(workDir, dexName + ".orig");
                ClassDef originalClassDef = null;
                try {
                    com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile retryDex =
                            DexFileFactory.loadDexFile(backupFile, opcodes);
                    for (ClassDef cd : retryDex.getClasses()) {
                        String type = cd.getType();
                        if (type.equals(badClass) || (classRenameMap.containsKey(type) && classRenameMap.get(type).equals(badClass))) {
                            originalClassDef = cd;
                            break;
                        }
                    }
                } catch (Exception ex) {
                    logCallback.log("    无法加载备份文件: " + ex.getMessage());
                    return false;
                }

                if (originalClassDef == null) {
                    logCallback.log("    未找到原始类定义: " + badClass + "，放弃");
                    return false;
                }

                // 用安全版本替换：仅做类名重映射+引用更新，不做任何代码修改
                ImmutableClassDef safeClass = ImmutableClassDef.of(originalClassDef);
                try {
                    if (doRenameSafe && classRenameMap.containsKey(safeClass.getType())) {
                        safeClass = applyClassRename(safeClass, classRenameMap.get(safeClass.getType()));
                    } else if (doRenameSafe) {
                        safeClass = remapAllReferences(safeClass);
                    }
                } catch (Exception ex) {
                    safeClass = ImmutableClassDef.of(originalClassDef);
                }

                // 在 modifiedClasses 中找到并替换
                boolean replaced = false;
                for (int i = 0; i < modifiedClasses.size(); i++) {
                    String clsType = modifiedClasses.get(i).getType();
                    if (clsType.equals(badClass) || clsType.equals(originalClassDef.getType())) {
                        modifiedClasses.set(i, safeClass);
                        replaced = true;
                        break;
                    }
                }
                if (!replaced) {
                    logCallback.log("    未在修改列表中找到: " + badClass + "，可能已被替换");
                    return false;
                }

                // 替换后系统.gc()，为下一次重试释放内存
                System.gc();
            }
        }
        return false; // 超过最大重试次数
    }

    // ===== DEX头部混淆（文件级）=====
    // 在DEX写入磁盘后，向文件末尾追加随机padding字节。
    // 不修改 magic / checksum / signature / file_size 等关键字段；
    // 追加的padding位于file_size之外，ART读取时按file_size截断，不影响加载。

    private void applyDexHeaderObfuscation(File dexFile) {
        if (dexFile == null || !dexFile.isFile()) return;
        try {
            byte[] data = java.nio.file.Files.readAllBytes(dexFile.toPath());
            if (data.length < 0x70) return;
            // 校验magic
            if (data[0] != 'd' || data[1] != 'e' || data[2] != 'x' || data[3] != '\n') return;
            // 读取 file_size 与 map_off（仅用于日志，不修改）
            int fileSize = readLeInt(data, 0x20);
            int mapOff = readLeInt(data, 0x34);

            // 在文件末尾追加随机padding（位于file_size之外，不影响校验和/签名）
            int padLen = 4 + random.nextInt(16); // 4~19 字节
            byte[] padding = new byte[padLen];
            random.nextBytes(padding);
            try (java.io.FileOutputStream fos = new java.io.FileOutputStream(dexFile, true)) {
                fos.write(padding);
            }
            logCallback.log("  DEX头部混淆: " + dexFile.getName()
                    + " 追加" + padLen + "字节padding (map_off=" + mapOff + ", file_size=" + fileSize + ")");
        } catch (Exception e) {
            logCallback.log("  DEX头部混淆失败: " + dexFile.getName() + " - " + e.getMessage());
        }
    }

    private boolean hasSwitchPayload(MethodImplementation impl) {
        if (impl == null) return false;
        // 含 try-catch 的方法跳过：方法头插桩后 try 块的 handler 偏移和分支可能不一致
        if (impl.getTryBlocks() != null && !impl.getTryBlocks().isEmpty()) return true;
        for (Instruction insn : impl.getInstructions()) {
            if (insn instanceof PackedSwitchPayload || insn instanceof SparseSwitchPayload ||
                    insn instanceof ImmutablePackedSwitchPayload || insn instanceof ImmutableSparseSwitchPayload) {
                return true;
            }
            // fill-array-data 的 payload 必须 4 字节对齐，在方法头插入代码会破坏对齐
            if (insn instanceof ArrayPayload) {
                return true;
            }
        }
        return false;
    }

    // ===== 注解重映射 =====
    // 类/字段/方法注解中的类型引用、字段引用、方法引用必须同步重映射，
    // 否则注解会指向已不存在的旧类名，导致 verifier 拒绝或运行时 ClassNotFoundException。

    private Set<ImmutableAnnotation> remapAnnotations(Set<? extends Annotation> annotations) {
        if (annotations == null || annotations.isEmpty()) return Collections.emptySet();
        Set<ImmutableAnnotation> result = new java.util.LinkedHashSet<>();
        for (Annotation ann : annotations) {
            result.add(remapAnnotation(ann));
        }
        return result;
    }

    private ImmutableAnnotation remapAnnotation(Annotation ann) {
        String newType = remapType(ann.getType());
        Set<ImmutableAnnotationElement> newElements = new java.util.LinkedHashSet<>();
        for (AnnotationElement elem : ann.getElements()) {
            newElements.add(new ImmutableAnnotationElement(elem.getName(), remapEncodedValue(elem.getValue())));
        }
        return new ImmutableAnnotation(ann.getVisibility(), newType, newElements);
    }

    private ImmutableEncodedValue remapEncodedValue(EncodedValue value) {
        if (value == null) return null;
        if (value instanceof TypeEncodedValue) {
            return new ImmutableTypeEncodedValue(remapType(((TypeEncodedValue) value).getValue()));
        }
        if (value instanceof FieldEncodedValue) {
            FieldReference fr = ((FieldEncodedValue) value).getValue();
            return new ImmutableFieldEncodedValue(remapFieldRef(fr));
        }
        if (value instanceof MethodEncodedValue) {
            MethodReference mr = ((MethodEncodedValue) value).getValue();
            return new ImmutableMethodEncodedValue(remapMethodRef(mr));
        }
        if (value instanceof EnumEncodedValue) {
            FieldReference fr = ((EnumEncodedValue) value).getValue();
            return new ImmutableEnumEncodedValue(remapFieldRef(fr));
        }
        if (value instanceof ArrayEncodedValue) {
            List<? extends EncodedValue> arr = ((ArrayEncodedValue) value).getValue();
            List<ImmutableEncodedValue> newArr = new ArrayList<>();
            for (EncodedValue v : arr) newArr.add(remapEncodedValue(v));
            return new ImmutableArrayEncodedValue(newArr);
        }
        if (value instanceof AnnotationEncodedValue) {
            AnnotationEncodedValue aev = (AnnotationEncodedValue) value;
            String newType = remapType(aev.getType());
            Set<ImmutableAnnotationElement> newElements = new java.util.LinkedHashSet<>();
            for (AnnotationElement elem : aev.getElements()) {
                newElements.add(new ImmutableAnnotationElement(elem.getName(), remapEncodedValue(elem.getValue())));
            }
            return new ImmutableAnnotationEncodedValue(newType, newElements);
        }
        return ImmutableEncodedValueFactory.of(value);
    }

    private ImmutableFieldReference remapFieldRef(FieldReference fr) {
        String defClass = remapType(fr.getDefiningClass());
        String fieldType = remapType(fr.getType());
        String fieldName = remapFieldName(fr.getDefiningClass(), fr.getName(), fr.getType());
        return new ImmutableFieldReference(defClass, fieldName, fieldType);
    }

    private ImmutableMethodReference remapMethodRef(MethodReference mr) {
        String defClass = remapType(mr.getDefiningClass());
        List<String> newParams = new ArrayList<>();
        for (CharSequence p : mr.getParameterTypes()) newParams.add(remapType(String.valueOf(p)));
        return new ImmutableMethodReference(defClass, mr.getName(), newParams, remapType(mr.getReturnType()));
    }

    /**
     * 重映射try-catch块中的异常处理器类型。
     * 当类被重命名后，catch块中的异常类型引用也必须更新。
     */
    private List<ImmutableTryBlock> remapTryBlocks(
            List<? extends com.android.tools.smali.dexlib2.iface.TryBlock<? extends com.android.tools.smali.dexlib2.iface.ExceptionHandler>> tryBlocks) {
        List<ImmutableTryBlock> result = new ArrayList<>();
        if (tryBlocks == null) return result;

        for (com.android.tools.smali.dexlib2.iface.TryBlock<? extends com.android.tools.smali.dexlib2.iface.ExceptionHandler> tb : tryBlocks) {
            List<ImmutableExceptionHandler> newHandlers = new ArrayList<>();
            for (com.android.tools.smali.dexlib2.iface.ExceptionHandler h : tb.getExceptionHandlers()) {
                String excType = h.getExceptionType();
                // catch-all handler has null exception type
                String newExcType = (excType == null) ? null : remapType(excType);
                newHandlers.add(new ImmutableExceptionHandler(newExcType, h.getHandlerCodeAddress()));
            }
            result.add(new ImmutableTryBlock(
                    tb.getStartCodeAddress(), tb.getCodeUnitCount(), newHandlers));
        }
        return result;
    }

    /**
     * 当在方法开头插入 junkCodeUnits 个 code unit 的死代码后，
     * 同步偏移所有 try-catch 的 start/end/handler 地址。
     * 同时重映射异常处理器类型。
     */
    private List<ImmutableTryBlock> shiftTryBlocks(
            List<? extends com.android.tools.smali.dexlib2.iface.TryBlock<? extends com.android.tools.smali.dexlib2.iface.ExceptionHandler>> tryBlocks,
            int junkCodeUnits,
            int newTotalCodeUnits) {

        List<ImmutableTryBlock> result = new ArrayList<>();
        if (tryBlocks == null) return result;

        for (com.android.tools.smali.dexlib2.iface.TryBlock<? extends com.android.tools.smali.dexlib2.iface.ExceptionHandler> tb : tryBlocks) {
            int newStart = tb.getStartCodeAddress() + junkCodeUnits;
            int newEnd = Math.min(newStart + tb.getCodeUnitCount(), newTotalCodeUnits);
            int newCodeUnitCount = newEnd - newStart;
            if (newCodeUnitCount <= 0) continue; // try块被完全推出方法外则丢弃

            List<ImmutableExceptionHandler> newHandlers = new ArrayList<>();
            for (com.android.tools.smali.dexlib2.iface.ExceptionHandler h : tb.getExceptionHandlers()) {
                int newHandler = h.getHandlerCodeAddress() + junkCodeUnits;
                if (newHandler >= newTotalCodeUnits) {
                    // handler超出范围，移到方法末尾最后一条指令
                    newHandler = newTotalCodeUnits - 1;
                    if (newHandler < 0) newHandler = 0;
                }
                // 修复：同时重映射异常类型
                String excType = h.getExceptionType();
                String newExcType = (excType == null) ? null : remapType(excType);
                newHandlers.add(new ImmutableExceptionHandler(newExcType, newHandler));
            }

            result.add(new ImmutableTryBlock(newStart, newCodeUnitCount, newHandlers));
        }
        return result;
    }

    /**
     * 计算指令列表的总 code unit 数。
     */
    private int calcTotalCodeUnits(List<ImmutableInstruction> insns) {
        int total = 0;
        for (ImmutableInstruction insn : insns) {
            total += insn.getCodeUnits();
        }
        return total;
    }

    /**
     * 复制指令。
     *
     * Dalvik 中 goto/if/switch 的跳转目标均是相对对应分支指令地址的偏移。
     * 当我们只在方法头插入代码时，分支指令和目标同时后移，原始相对偏移不需要改变。
     * 之前把 switch payload target 当作“相对方法开头”的绝对地址处理，会导致
     * VerifyError: invalid switch target。
     *
     * @param insn 原始指令
     * @param shift 保留参数用于兼容旧调用，不再使用
     * @return 原样复制后的不可变指令
     */
    /**
     * 平移指令中的相对跳转偏移。
     * 在方法开头插入代码后，原始指令的位置整体后移 shift 个 code unit，
     * 因此分支指令的相对目标偏移也需要同步增加 shift，才能保持语义不变。
     */
    /**
     * 在方法头部插入代码后，拷贝原有指令。
     * 由于所有指令（包括分支源和目标）都整体平移了 shift 个 code unit，
     * 分支指令的相对偏移量保持不变，无需修改。
     */
    private ImmutableInstruction shiftInstruction(Instruction insn, int shift) {
        // 所有指令整体平移，相对偏移不变，直接拷贝即可
        return ImmutableInstruction.of(insn);
    }

    /**
     * 计算方法参数占用的寄存器数量。
     * Dalvik中参数存储在最高位寄存器：
     * - 非static方法：this指针占1个寄存器 + 每个参数的类型大小
     * - static方法：仅每个参数的类型大小
     * - long/double占2个寄存器，其他类型占1个
     */
    private int calcParamRegisterCount(Method m) {
        int count = 0;
        // 非static方法有隐含的this指针
        if ((m.getAccessFlags() & 0x0008) == 0) { // ACC_STATIC = 0x0008
            count++; // this指针
        }
        for (CharSequence paramType : m.getParameters()) {
            char firstChar = paramType.charAt(0);
            if (firstChar == 'J' || firstChar == 'D') {
                count += 2; // long和double占2个寄存器
            } else {
                count += 1;
            }
        }
        return count;
    }

    /**
     * 创建 const 指令，根据寄存器索引选择正确的指令格式：
     * - v0-v15: const/4 (Instruction11n，4位寄存器)
     * - v16-v255: const/16 (Instruction21s，8位寄存器)
     * - v256+: 跳过（极罕见，不会在正常DEX中出现）
     */
    private ImmutableInstruction makeConst(int register, int value) {
        if (register < 0) {
            throw new IllegalArgumentException("register must be non-negative: " + register);
        }
        if (register <= 15 && value >= -8 && value <= 7) {
            // const/4: 4位寄存器，4位有符号值 (-8 to 7)
            return new ImmutableInstruction11n(Opcode.CONST_4, register, value);
        } else if (register <= 255 && value >= -32768 && value <= 32767) {
            // const/16: 8位寄存器，16位有符号值
            return new ImmutableInstruction21s(Opcode.CONST_16, register, value);
        } else if (register <= 65535) {
            // const: 8位寄存器，32位有符号值
            return new ImmutableInstruction31i(Opcode.CONST, register, value);
        } else {
            throw new IllegalArgumentException("register index out of range: " + register);
        }
    }

    // ===== Helpers =====

    private boolean shouldRename(String type) {
        if (type == null) return false;
        for (String p : PROTECTED_PREFIXES) if (type.startsWith(p)) return false;
        // 检查保护类（可能是精确匹配，也可能是前缀匹配，如 "Lcn/ikaile/ruoshui/client/"）
        for (String p : protectedClasses) {
            if (p.endsWith("/")) {
                // 前缀匹配
                if (type.startsWith(p)) return false;
            } else {
                // 精确匹配
                if (type.equals(p)) return false;
            }
        }
        return true;
    }

    private String remapType(String type) {
        if (type == null) return null;
        // 处理数组类型：递归剥离 '[' 前缀，重映射元素类型后再拼回
        if (type.startsWith("[")) {
            return "[" + remapType(type.substring(1));
        }
        if (classRenameMap.containsKey(type)) return classRenameMap.get(type);
        return type;
    }

    private String genClassName() {
        // 至少2段（包名+类名），避免生成默认包名（LClassName;）导致DEX写入失败
        int segs = 2 + random.nextInt(3);
        StringBuilder sb = new StringBuilder("L");
        for (int s = 0; s < segs; s++) {
            if (s > 0) sb.append("/");
            int len = 3 + random.nextInt(8);
            // 首字符必须是字母（Java类名规范），不能是数字
            sb.append(CHARS.charAt(random.nextInt(CHARS.length())));
            for (int i = 1; i < len; i++)
                sb.append(CHARS_EXT.charAt(random.nextInt(CHARS_EXT.length())));
        }
        return sb.append(";").toString();
    }

    private String genFieldName() {
        int len = 3 + random.nextInt(5);
        StringBuilder sb = new StringBuilder();
        sb.append(CHARS.charAt(random.nextInt(CHARS.length())));
        for (int i = 1; i < len; i++)
            sb.append(CHARS_EXT.charAt(random.nextInt(CHARS_EXT.length())));
        return sb.toString();
    }

    // ===== 文件级处理：DEX头部混淆与多DEX类顺序打乱 =====

    /**
     * DEX写入后修改头部padding区域，并重新计算checksum(adler32)与signature(SHA1)。
     *
     * DEX头部结构(小端序)：
     *   magic(8) + checksum(4) + signature(20) + file_size(4) + header_size(4)
     *   + endian_tag(4) + ... + map_off(4) + ...
     * header_size固定为0x70(112字节)。padding区域位于header_size之后、第一个实际
     * 数据段之前(对齐留白)。仅当存在留白时填充随机字节，不会修改
     * magic / file_size / header_size / endian_tag / map_off。
     *
     * 可在processAndWriteAll写入DEX后调用。
     */
    public void obfuscateDexHeader(File dexFile) {
        if (dexFile == null || !dexFile.isFile()) {
            return;
        }

        byte[] data;
        try {
            data = java.nio.file.Files.readAllBytes(dexFile.toPath());
        } catch (Exception e) {
            logCallback.log("  DEX头部混淆读取失败: " + dexFile.getName() + " - " + e.getMessage());
            return;
        }

        if (data.length < 0x70) {
            logCallback.log("  DEX头部混淆跳过(文件过小): " + dexFile.getName());
            return;
        }

        // 校验magic
        if (data[0] != 'd' || data[1] != 'e' || data[2] != 'x' || data[3] != '\n') {
            logCallback.log("  DEX头部混淆跳过(magic错误): " + dexFile.getName());
            return;
        }

        int headerSize = readLeInt(data, 0x24);
        int fileSize = readLeInt(data, 0x20);
        if (headerSize != 0x70) {
            // 非标准header_size，跳过避免破坏结构
            logCallback.log("  DEX头部混淆跳过(header_size非0x70): " + dexFile.getName());
            return;
        }
        if (fileSize < 0x70 || fileSize > data.length) {
            fileSize = data.length;
        }

        // 确定padding区域: [headerSize, firstSectionOff)
        // firstSectionOff = 所有 >= headerSize 的段偏移中的最小值(第一个实际数据段)
        int[] sectionOffsets = {
                readLeInt(data, 0x30), // link_off
                readLeInt(data, 0x34), // map_off
                readLeInt(data, 0x3C), // string_ids_off
                readLeInt(data, 0x44), // type_ids_off
                readLeInt(data, 0x4C), // proto_ids_off
                readLeInt(data, 0x54), // field_ids_off
                readLeInt(data, 0x5C), // method_ids_off
                readLeInt(data, 0x64), // class_defs_off
                readLeInt(data, 0x6C)  // data_off
        };
        int firstSectionOff = Integer.MAX_VALUE;
        for (int off : sectionOffsets) {
            if (off >= headerSize && off < firstSectionOff) {
                firstSectionOff = off;
            }
        }
        if (firstSectionOff == Integer.MAX_VALUE) {
            firstSectionOff = headerSize;
        }

        // 在padding区域填充随机字节
        if (firstSectionOff > headerSize) {
            int padLen = firstSectionOff - headerSize;
            byte[] noise = new byte[padLen];
            random.nextBytes(noise);
            System.arraycopy(noise, 0, data, headerSize, padLen);
            logCallback.log("  DEX头部padding混淆: " + dexFile.getName() + " 填充" + padLen + "字节");
        } else {
            logCallback.log("  DEX头部无padding留白，仅重算校验和: " + dexFile.getName());
        }

        try {
            // 重新计算signature: SHA1 over [0x20, fileSize)
            MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
            sha1.update(data, 0x20, fileSize - 0x20);
            byte[] sig = sha1.digest();
            System.arraycopy(sig, 0, data, 0x0C, 20);

            // 重新计算checksum: adler32 over [0x0C, fileSize)（包含新signature）
            Adler32 adler = new Adler32();
            adler.update(data, 0x0C, fileSize - 0x0C);
            writeLeInt(data, 0x08, (int) adler.getValue());

            // 写回文件
            try (java.io.FileOutputStream fos = new java.io.FileOutputStream(dexFile)) {
                fos.write(data, 0, fileSize);
            }
            logCallback.log("  DEX头部混淆完成: " + dexFile.getName());
        } catch (Exception e) {
            logCallback.log("  DEX头部混淆失败: " + dexFile.getName() + " - " + e.getMessage());
        }
    }

    /**
     * 打乱DEX内类的顺序，并用DexPool重新写入。
     *
     * 仅打乱class_def的排列顺序；每个类内部的 <clinit> / <init> 等方法顺序
     * 保持不变(使用ImmutableClassDef.of原样保留方法定义)。
     *
     * 可在processAndWriteAll写入DEX后调用。
     */
    public void shuffleDexClasses(File dexFile) {
        if (dexFile == null || !dexFile.isFile()) {
            return;
        }

        try {
            com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile dex =
                    DexFileFactory.loadDexFile(dexFile, Opcodes.getDefault());

            // 1. 加载所有类（每个类内部方法顺序不变）
            List<ClassDef> classList = new ArrayList<>();
            for (ClassDef classDef : dex.getClasses()) {
                classList.add(ImmutableClassDef.of(classDef));
            }
            int originalCount = classList.size();
            if (originalCount <= 1) {
                logCallback.log("  DEX类顺序打乱跳过(类数不足): " + dexFile.getName());
                return;
            }

            // 2. 打乱类列表顺序
            Collections.shuffle(classList, random);

            // 3. 用DexPool重新写入临时文件
            File tempFile = new File(workDir, dexFile.getName() + ".shuf.tmp");
            DexPool pool = new DexPool(dex.getOpcodes());
            for (ClassDef cls : classList) {
                pool.internClass(cls);
            }
            pool.writeTo(new FileDataStore(tempFile));

            // 4. 替换原文件
            if (dexFile.delete()) {
                if (!tempFile.renameTo(dexFile)) {
                    java.nio.file.Files.copy(tempFile.toPath(), dexFile.toPath(),
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    tempFile.delete();
                }
            } else {
                java.nio.file.Files.copy(tempFile.toPath(), dexFile.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                tempFile.delete();
            }
            logCallback.log("  DEX类顺序打乱完成: " + dexFile.getName() + " (" + originalCount + "类)");
        } catch (Exception e) {
            logCallback.log("  DEX类顺序打乱失败: " + dexFile.getName() + " - " + e.getMessage());
        }
    }

    /** 小端序读取32位整数 */
    private static int readLeInt(byte[] data, int offset) {
        return (data[offset] & 0xFF)
                | ((data[offset + 1] & 0xFF) << 8)
                | ((data[offset + 2] & 0xFF) << 16)
                | ((data[offset + 3] & 0xFF) << 24);
    }

    /** 小端序写入32位整数 */
    private static void writeLeInt(byte[] data, int offset, int value) {
        data[offset] = (byte) (value & 0xFF);
        data[offset + 1] = (byte) ((value >> 8) & 0xFF);
        data[offset + 2] = (byte) ((value >> 16) & 0xFF);
        data[offset + 3] = (byte) ((value >> 24) & 0xFF);
    }

    // ===== 互斥控制辅助方法 =====
    // 将类中所有方法标记为"已被代码插入功能修改"
    private void markMethodsAsModified(ImmutableClassDef cd, Set<String> modified) {
        for (Method m : cd.getMethods()) {
            if (m.getImplementation() != null) {
                modified.add(cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType());
            }
        }
    }

    // 检查方法是否已被修改
    private boolean isMethodModified(ImmutableClassDef cd, Method m, Set<String> modified) {
        String key = cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType();
        return modified.contains(key);
    }

    // applyJunkCodeEx: 跳过已被其他功能修改的方法
    private ImmutableClassDef applyJunkCodeEx(ImmutableClassDef cd, int[] count, Set<String> modified) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (isMethodModified(cd, m, modified)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (hasSwitchPayload(impl)) { newMethods.add(ImmutableMethod.of(m)); continue; }

            int regCount = impl.getRegisterCount();
            int paramRegs = calcParamRegisterCount(m);
            int freeReg = regCount - paramRegs;
            if (freeReg < 1) { newMethods.add(ImmutableMethod.of(m)); continue; }

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            for (Instruction insn : impl.getInstructions()) newInsns.add(shiftInstruction(insn, 3));
            List<ImmutableTryBlock> shiftedTB = shiftTryBlocksSimple(impl.getTryBlocks(), 3);
            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(regCount, newInsns, shiftedTB, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(), m.getAccessFlags(), remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
            modified.add(cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType());
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(), cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(), cd.getAnnotations(), fields, newMethods);
    }

    // applyArithmeticBranchEx: 跳过已被修改的方法
    private ImmutableClassDef applyArithmeticBranchEx(ImmutableClassDef cd, int[] count, Set<String> modified) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (isMethodModified(cd, m, modified)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            // 使用 hasSwitchPayload 检查（包含 try-catch、switch payload、array payload）
            if (hasSwitchPayload(impl)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            // 跳过含分支指令的方法
            if (hasBranchInstruction(impl)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if ((m.getAccessFlags() & 0x400) != 0 || (m.getAccessFlags() & 0x100) != 0) { newMethods.add(ImmutableMethod.of(m)); continue; }
            int regCount = impl.getRegisterCount();
            int paramRegs = calcParamRegisterCount(m);
            int freeReg = regCount - paramRegs;
            if (freeReg < 1) { newMethods.add(ImmutableMethod.of(m)); continue; }
            // 在寄存器帧末尾新增一个寄存器作为 vT，绝不覆盖任何已有寄存器
            int vT = regCount;
            if (vT > 65535) { newMethods.add(ImmutableMethod.of(m)); continue; }
            int newRegCount = regCount + 1;

            // const 指令长度取决于 vT 大小：<=15 用 const/4(1 unit)，否则 const/16(2 units)
            ImmutableInstruction const0 = makeConst(vT, 0);
            ImmutableInstruction const1 = makeConst(vT, 1);
            int constLen0 = const0.getCodeUnits();
            int constLen1 = const1.getCodeUnits();
            // if-eqz 长度固定为 2 units；nop 长度为 1 unit
            // 总插入长度 = const0 + if-eqz(2) + const1 + nop(1)
            int insertLen = constLen0 + 2 + constLen1 + 1;
            // if-eqz 目标偏移：跳过 if-eqz 自身(2) + const1 + nop 到达原始代码
            int ifOffset = 2 + constLen1 + 1;

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.add(const0);
            newInsns.add(new ImmutableInstruction21t(Opcode.IF_EQZ, vT, ifOffset));
            newInsns.add(const1);
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            for (Instruction insn : impl.getInstructions()) newInsns.add(shiftInstruction(insn, insertLen));
            List<ImmutableTryBlock> shiftedTB = shiftTryBlocksSimple(impl.getTryBlocks(), insertLen);
            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(newRegCount, newInsns, shiftedTB, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(), m.getAccessFlags(), remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
            modified.add(cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType());
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(), cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(), cd.getAnnotations(), fields, newMethods);
    }

    // applyCallIndirectionEx: 跳过已被修改的方法
    private ImmutableClassDef applyCallIndirectionEx(ImmutableClassDef cd, int[] count, Set<String> modified) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (isMethodModified(cd, m, modified)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            int insnCount = 0;
            for (Instruction insn : impl.getInstructions()) insnCount++;
            if (insnCount < 10) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (hasSwitchPayload(impl)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if ((m.getAccessFlags() & 0x400) != 0 || (m.getAccessFlags() & 0x100) != 0) { newMethods.add(ImmutableMethod.of(m)); continue; }

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            for (Instruction insn : impl.getInstructions()) newInsns.add(shiftInstruction(insn, 3));
            List<ImmutableTryBlock> shiftedTB = shiftTryBlocksSimple(impl.getTryBlocks(), 3);
            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(impl.getRegisterCount(), newInsns, shiftedTB, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(), m.getAccessFlags(), remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
            modified.add(cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType());
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(), cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(), cd.getAnnotations(), fields, newMethods);
    }

    // applyAdvancedReflectionEx: 跳过已被修改的方法
    private ImmutableClassDef applyAdvancedReflectionEx(ImmutableClassDef cd, int[] count, Set<String> modified) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (isMethodModified(cd, m, modified)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            int insnCount = 0;
            for (Instruction insn : impl.getInstructions()) insnCount++;
            if (insnCount < 5) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (hasSwitchPayload(impl)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if ((m.getAccessFlags() & 0x400) != 0 || (m.getAccessFlags() & 0x100) != 0) { newMethods.add(ImmutableMethod.of(m)); continue; }

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            for (Instruction insn : impl.getInstructions()) newInsns.add(shiftInstruction(insn, 3));
            List<ImmutableTryBlock> shiftedTB = shiftTryBlocksSimple(impl.getTryBlocks(), 3);
            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(impl.getRegisterCount(), newInsns, shiftedTB, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(), m.getAccessFlags(), remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
            modified.add(cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType());
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(), cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(), cd.getAnnotations(), fields, newMethods);
    }

    // applyReflectionClinitInjectionEx: 跳过已被修改的方法
    private ImmutableClassDef applyReflectionClinitInjectionEx(ImmutableClassDef cd, int[] count, Set<String> modified) {
        count[0] = 0;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (!"<clinit>".equals(m.getName())) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (isMethodModified(cd, m, modified)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (hasSwitchPayload(impl)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if ((m.getAccessFlags() & 0x400) != 0 || (m.getAccessFlags() & 0x100) != 0) { newMethods.add(ImmutableMethod.of(m)); continue; }

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            for (Instruction insn : impl.getInstructions()) newInsns.add(shiftInstruction(insn, 3));
            List<ImmutableTryBlock> shiftedTB = shiftTryBlocksSimple(impl.getTryBlocks(), 3);
            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(impl.getRegisterCount(), newInsns, shiftedTB, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(), m.getAccessFlags(), remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
            modified.add(cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType());
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(), cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(), cd.getAnnotations(), fields, newMethods);
    }

    // applyGotoInsertionEx: 跳过已被修改的方法
    private ImmutableClassDef applyGotoInsertionEx(ImmutableClassDef cd, int[] count, Set<String> modified) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (isMethodModified(cd, m, modified)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if (hasSwitchPayload(impl)) { newMethods.add(ImmutableMethod.of(m)); continue; }
            if ((m.getAccessFlags() & 0x400) != 0 || (m.getAccessFlags() & 0x100) != 0) { newMethods.add(ImmutableMethod.of(m)); continue; }

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            for (Instruction insn : impl.getInstructions()) newInsns.add(shiftInstruction(insn, 3));
            List<ImmutableTryBlock> shiftedTB = shiftTryBlocksSimple(impl.getTryBlocks(), 3);
            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(impl.getRegisterCount(), newInsns, shiftedTB, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(), m.getParameters(), m.getReturnType(), m.getAccessFlags(), remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
            modified.add(cd.getType() + "->" + m.getName() + "(" + m.getParameters() + ")" + m.getReturnType());
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(), cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(), cd.getAnnotations(), fields, newMethods);
    }

    // 通用try block偏移调整方法（2参数版本，用于Ex系列方法）
    // 在方法开头插入shift个code unit后，原始指令整体后移shift。
    // try块的start/end/handler都需要同步平移shift，但codeUnitCount保持不变。
    private List<ImmutableTryBlock> shiftTryBlocksSimple(List<? extends TryBlock<? extends ExceptionHandler>> tryBlocks, int shift) {
        List<ImmutableTryBlock> result = new ArrayList<>();
        for (TryBlock<? extends ExceptionHandler> tb : tryBlocks) {
            int newStart = tb.getStartCodeAddress() + shift;
            int newCount = tb.getCodeUnitCount();
            if (newStart < 0 || newCount <= 0) continue; // 安全检查

            List<ImmutableExceptionHandler> shiftedHandlers = new ArrayList<>();
            for (ExceptionHandler h : tb.getExceptionHandlers()) {
                String excType = h.getExceptionType();
                String newExcType = (excType == null) ? null : remapType(excType);
                int newHandlerAddr = h.getHandlerCodeAddress() + shift;
                if (newHandlerAddr < 0) newHandlerAddr = 0;
                shiftedHandlers.add(new ImmutableExceptionHandler(newExcType, newHandlerAddr));
            }
            result.add(new ImmutableTryBlock(newStart, newCount, shiftedHandlers));
        }
        return result;
    }

    // ===== 算术分支混淆 =====
    // 在方法开头插入一个假的算术条件分支，增加逆向分析难度。
    // 安全策略：只在方法开头插入（不破坏原始分支偏移），且只使用1-code-unit指令。
    private ImmutableClassDef applyArithmeticBranch(ImmutableClassDef cd, int[] count) {
        count[0] = 0;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }
            int regCount = impl.getRegisterCount();
            int paramRegs = calcParamRegisterCount(m);
            int freeReg = regCount - paramRegs;
            // 必须有至少1个空闲寄存器，且寄存器号<=15（确保const/4只占1个code unit）
            if (freeReg < 1) { newMethods.add(ImmutableMethod.of(m)); continue; }
            int vT = freeReg - 1;
            if (vT > 15) { newMethods.add(ImmutableMethod.of(m)); continue; }

            // 检查是否含switch payload
            boolean hasSwitch = false;
            for (Instruction insn : impl.getInstructions()) {
                if (insn instanceof PackedSwitchPayload || insn instanceof SparseSwitchPayload) {
                    hasSwitch = true; break;
                }
            }
            if (hasSwitch) { newMethods.add(ImmutableMethod.of(m)); continue; }

            // 跳过abstract/native方法
            if ((m.getAccessFlags() & 0x400) != 0 || (m.getAccessFlags() & 0x100) != 0) {
                newMethods.add(ImmutableMethod.of(m)); continue;
            }

            List<ImmutableInstruction> newInsns = new ArrayList<>();
            // 全部使用1-code-unit指令确保偏移计算正确：
            // [0] const/4 vT, 0     (1 unit)
            // [1] if-eqz vT, +3     (1 unit) → target = 1+3 = 4
            // [2] const/4 vT, 1     (1 unit, dead code)
            // [3] nop               (1 unit, dead code)
            // [4] original code...
            newInsns.add(new ImmutableInstruction11n(Opcode.CONST_4, vT, 0));
            newInsns.add(new ImmutableInstruction21t(Opcode.IF_EQZ, vT, 3));
            newInsns.add(new ImmutableInstruction11n(Opcode.CONST_4, vT, 1));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));

            for (Instruction insn : impl.getInstructions()) {
                newInsns.add(ImmutableInstruction.of(insn));
            }

            List<ImmutableTryBlock> newTryBlocks = remapTryBlocks(impl.getTryBlocks());
            // 调整try block地址：+4 code units
            List<ImmutableTryBlock> shiftedTryBlocks = new ArrayList<>();
            for (ImmutableTryBlock tb : newTryBlocks) {
                List<ImmutableExceptionHandler> shiftedHandlers = new ArrayList<>();
                for (ImmutableExceptionHandler h : tb.getExceptionHandlers()) {
                    shiftedHandlers.add(new ImmutableExceptionHandler(
                            h.getExceptionType(), h.getHandlerCodeAddress() + 4));
                }
                shiftedTryBlocks.add(new ImmutableTryBlock(
                        tb.getStartCodeAddress() + 4, tb.getCodeUnitCount(), shiftedHandlers));
            }

            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    regCount, newInsns, shiftedTryBlocks, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(
                    m.getDefiningClass(), m.getName(), m.getParameters(),
                    m.getReturnType(), m.getAccessFlags(), m.getAnnotations(),
                    m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), fields, newMethods);
    }

    // ===== 调用间接化 =====
    // 安全策略：在方法开头插入一个假的invoke序列（goto跳过），不修改方法中间的指令。
    // 插入: goto +3; const/4 v0, 0; const/4 v1, 0; (死代码，模拟调用模式)
    // 原始代码不受影响，因为goto直接跳到原始代码。
    private ImmutableClassDef applyCallIndirection(ImmutableClassDef cd, int[] count) {
        count[0] = 0;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }

            // 只处理指令数>10的方法
            int insnCount = 0;
            for (Instruction insn : impl.getInstructions()) insnCount++;
            if (insnCount < 10) { newMethods.add(ImmutableMethod.of(m)); continue; }

            boolean hasSwitch = false;
            for (Instruction insn : impl.getInstructions()) {
                if (insn instanceof PackedSwitchPayload || insn instanceof SparseSwitchPayload) {
                    hasSwitch = true; break;
                }
            }
            if (hasSwitch) { newMethods.add(ImmutableMethod.of(m)); continue; }

            // 跳过abstract/native方法
            if ((m.getAccessFlags() & 0x400) != 0 || (m.getAccessFlags() & 0x100) != 0) {
                newMethods.add(ImmutableMethod.of(m)); continue;
            }

            // 安全地在方法开头插入3个code unit的死代码
            // [0] goto +3     (1 unit) → 跳到unit 3（原始代码）
            // [1] nop         (1 unit, dead code)
            // [2] nop         (1 unit, dead code)
            // [3] original code...
            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            for (Instruction insn : impl.getInstructions()) {
                newInsns.add(ImmutableInstruction.of(insn));
            }

            // 调整try block地址：+3 code units
            List<ImmutableTryBlock> shiftedTryBlocks = new ArrayList<>();
            for (TryBlock<? extends ExceptionHandler> tb : impl.getTryBlocks()) {
                List<ImmutableExceptionHandler> shiftedHandlers = new ArrayList<>();
                for (ExceptionHandler h : tb.getExceptionHandlers()) {
                    String excType = h.getExceptionType();
                    String newExcType = (excType == null) ? null : remapType(excType);
                    shiftedHandlers.add(new ImmutableExceptionHandler(newExcType, h.getHandlerCodeAddress() + 3));
                }
                shiftedTryBlocks.add(new ImmutableTryBlock(
                        tb.getStartCodeAddress() + 3, tb.getCodeUnitCount(), shiftedHandlers));
            }

            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    impl.getRegisterCount(), newInsns, shiftedTryBlocks, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(
                    m.getDefiningClass(), m.getName(), m.getParameters(),
                    m.getReturnType(), m.getAccessFlags(), m.getAnnotations(),
                    m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), fields, newMethods);
    }

    // ===== 高级反射混淆 =====
    // 安全策略：在方法开头插入一个假的反射调用模式（goto跳过），不修改方法中间的指令。
    // 插入: goto +3; const/4 v0, 0; const/4 v1, 0; (死代码)
    private ImmutableClassDef applyAdvancedReflection(ImmutableClassDef cd, int[] count) {
        count[0] = 0;
        List<ImmutableMethod> newMethods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            MethodImplementation impl = m.getImplementation();
            if (impl == null) { newMethods.add(ImmutableMethod.of(m)); continue; }

            int insnCount = 0;
            for (Instruction insn : impl.getInstructions()) insnCount++;
            if (insnCount < 5) { newMethods.add(ImmutableMethod.of(m)); continue; }

            boolean hasSwitch = false;
            for (Instruction insn : impl.getInstructions()) {
                if (insn instanceof PackedSwitchPayload || insn instanceof SparseSwitchPayload) {
                    hasSwitch = true; break;
                }
            }
            if (hasSwitch) { newMethods.add(ImmutableMethod.of(m)); continue; }

            // 跳过abstract/native方法
            if ((m.getAccessFlags() & 0x400) != 0 || (m.getAccessFlags() & 0x100) != 0) {
                newMethods.add(ImmutableMethod.of(m)); continue;
            }

            // 安全地在方法开头插入3个code unit的死代码
            // [0] goto +3     (1 unit) → 跳到unit 3（原始代码）
            // [1] nop         (1 unit, dead code)
            // [2] nop         (1 unit, dead code)
            // [3] original code...
            List<ImmutableInstruction> newInsns = new ArrayList<>();
            newInsns.add(new ImmutableInstruction10t(Opcode.GOTO, 3));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            newInsns.add(new ImmutableInstruction10x(Opcode.NOP));
            for (Instruction insn : impl.getInstructions()) {
                newInsns.add(ImmutableInstruction.of(insn));
            }

            // 调整try block地址：+3 code units
            List<ImmutableTryBlock> shiftedTryBlocks = new ArrayList<>();
            for (TryBlock<? extends ExceptionHandler> tb : impl.getTryBlocks()) {
                List<ImmutableExceptionHandler> shiftedHandlers = new ArrayList<>();
                for (ExceptionHandler h : tb.getExceptionHandlers()) {
                    String excType = h.getExceptionType();
                    String newExcType = (excType == null) ? null : remapType(excType);
                    shiftedHandlers.add(new ImmutableExceptionHandler(newExcType, h.getHandlerCodeAddress() + 3));
                }
                shiftedTryBlocks.add(new ImmutableTryBlock(
                        tb.getStartCodeAddress() + 3, tb.getCodeUnitCount(), shiftedHandlers));
            }

            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    impl.getRegisterCount(), newInsns, shiftedTryBlocks, impl.getDebugItems());
            newMethods.add(new ImmutableMethod(
                    m.getDefiningClass(), m.getName(), m.getParameters(),
                    m.getReturnType(), m.getAccessFlags(), m.getAnnotations(),
                    m.getHiddenApiRestrictions(), newImpl));
            count[0]++;
        }
        if (count[0] == 0) return cd;
        List<Field> fields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) fields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) fields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), fields, newMethods);
    }

    // ===== 常量字符串加密 =====
    // 将const-string指令的字符串值加密，并在下一条插入invoke-static调用
    // StringDecryptor.decrypt(String)进行运行时解密，最后move-result-object写回同一寄存器。
    // 为防VerifyError，对含try/catch或switch的方法以及会导致分支溢出的方法跳过加密。
    private ImmutableClassDef applyConstStringEncryption(ImmutableClassDef cd, int[] count) {
        count[0] = 0;
        if (!shouldRename(cd.getType())) return cd;

        // 解密器方法引用，复用以减少对象创建
        ImmutableMethodReference decryptRef = new ImmutableMethodReference(
                "Lcom/ark/jiagu/StringDecryptor;", "decrypt",
                Collections.singletonList("Ljava/lang/String;"), "Ljava/lang/String;");

        List<ImmutableMethod> methods = new ArrayList<>();
        for (Method m : cd.getMethods()) {
            if (m.getImplementation() == null) {
                methods.add(ImmutableMethod.of(m));
                continue;
            }
            MethodImplementation impl = m.getImplementation();

            // 保守策略：跳过分支/异常处理复杂的方法，避免VerifyError
            if (hasTryBlockOrSwitch(impl)) {
                methods.add(ImmutableMethod.of(m));
                continue;
            }

            // 第一遍：记录每条指令的原始偏移，并标记需要加密的const-string
            List<Instruction> originalInsns = new ArrayList<>();
            List<Integer> originalOffsets = new ArrayList<>();
            List<Boolean> encryptFlags = new ArrayList<>();
            List<String> encryptedStrings = new ArrayList<>();
            int offset = 0;
            boolean anyEncrypted = false;
            for (Instruction insn : impl.getInstructions()) {
                originalInsns.add(insn);
                originalOffsets.add(offset);
                boolean doEncrypt = false;
                String encrypted = null;
                Opcode opcode = insn.getOpcode();
                if (opcode == Opcode.CONST_STRING || opcode == Opcode.CONST_STRING_JUMBO) {
                    ReferenceInstruction refInsn = (ReferenceInstruction) insn;
                    StringReference strRef = (StringReference) refInsn.getReference();
                    encrypted = encryptConstString(strRef.getString());
                    if (encrypted != null) {
                        doEncrypt = true;
                        anyEncrypted = true;
                    }
                }
                encryptFlags.add(doEncrypt);
                encryptedStrings.add(encrypted);
                offset += insn.getCodeUnits();
            }

            if (!anyEncrypted) {
                methods.add(ImmutableMethod.of(m));
                continue;
            }

            // 构建原始偏移 -> 新偏移映射（含最后一条指令末尾，用于try块end计算）
            ConstStringOffsetMapping mapping = buildConstStringOffsetMapping(
                    originalInsns, originalOffsets, encryptFlags, offset);

            // 检查所有分支偏移在新布局下是否仍在格式范围内；若溢出则跳过该方法
            if (!checkBranchOffsetsFit(originalInsns, originalOffsets, encryptFlags, mapping)) {
                methods.add(ImmutableMethod.of(m));
                continue;
            }

            // 第二遍：生成新指令，分支指令根据映射修正相对偏移
            List<ImmutableInstruction> newInsns = new ArrayList<>();
            for (int i = 0; i < originalInsns.size(); i++) {
                Instruction insn = originalInsns.get(i);
                int oldInsnOffset = originalOffsets.get(i);
                if (encryptFlags.get(i)) {
                    Opcode opcode = insn.getOpcode();
                    int regA = ((OneRegisterInstruction) insn).getRegisterA();
                    ImmutableStringReference newRef = new ImmutableStringReference(encryptedStrings.get(i));
                    if (opcode == Opcode.CONST_STRING) {
                        newInsns.add(new ImmutableInstruction21c(opcode, regA, newRef));
                    } else {
                        newInsns.add(new ImmutableInstruction31c(opcode, regA, newRef));
                    }
                    // 插入运行时解密调用：decrypt(encrypted) -> move-result-object regA
                    // 使用 invoke-static/range(3rc) 支持 v0~v65535，避免高寄存器超出 35c 的 4 位寄存器字段
                    newInsns.add(new ImmutableInstruction3rc(
                            Opcode.INVOKE_STATIC_RANGE, 1, regA, decryptRef));
                    newInsns.add(new ImmutableInstruction11x(Opcode.MOVE_RESULT_OBJECT, regA));
                    count[0]++;
                } else {
                    newInsns.add(shiftInstructionAtOffset(insn, oldInsnOffset, mapping));
                }
            }

            ImmutableMethodImplementation newImpl = new ImmutableMethodImplementation(
                    impl.getRegisterCount(), newInsns,
                    impl.getTryBlocks(), impl.getDebugItems());
            methods.add(new ImmutableMethod(m.getDefiningClass(), m.getName(),
                    m.getParameters(), m.getReturnType(), m.getAccessFlags(),
                    remapAnnotations(m.getAnnotations()), m.getHiddenApiRestrictions(), newImpl));
        }

        if (count[0] == 0) return cd;
        List<Field> allFields = new ArrayList<>();
        for (Field f : cd.getStaticFields()) allFields.add(ImmutableField.of(f));
        for (Field f : cd.getInstanceFields()) allFields.add(ImmutableField.of(f));
        return new ImmutableClassDef(cd.getType(), cd.getAccessFlags(),
                cd.getSuperclass(), cd.getInterfaces(), cd.getSourceFile(),
                cd.getAnnotations(), allFields, methods);
    }

    private static class ConstStringOffsetMapping {
        final Map<Integer, Integer> oldToNew = new HashMap<>();
        final Set<Integer> newInstructionStarts = new HashSet<>();
        int newTotalCodeUnits;
        ConstStringOffsetMapping() {
        }
    }

    private ConstStringOffsetMapping buildConstStringOffsetMapping(
            List<Instruction> originalInsns,
            List<Integer> originalOffsets,
            List<Boolean> encryptFlags,
            int originalTotalCodeUnits) {
        ConstStringOffsetMapping mapping = new ConstStringOffsetMapping();
        int newOffset = 0;
        for (int i = 0; i < originalInsns.size(); i++) {
            int oldOffset = originalOffsets.get(i);
            mapping.oldToNew.put(oldOffset, newOffset);
            mapping.newInstructionStarts.add(newOffset);
            int oldUnits = originalInsns.get(i).getCodeUnits();
            int extra = encryptFlags.get(i) ? 4 : 0; // invoke-static(3) + move-result-object(1)
            newOffset += oldUnits + extra;
        }
        mapping.oldToNew.put(originalTotalCodeUnits, newOffset);
        mapping.newTotalCodeUnits = newOffset;
        return mapping;
    }

    private boolean hasTryBlockOrSwitch(MethodImplementation impl) {
        if (impl.getTryBlocks() != null && !impl.getTryBlocks().isEmpty()) return true;
        for (Instruction insn : impl.getInstructions()) {
            Opcode opcode = insn.getOpcode();
            if (opcode == Opcode.PACKED_SWITCH || opcode == Opcode.SPARSE_SWITCH || opcode == Opcode.FILL_ARRAY_DATA) {
                return true;
            }
        }
        return false;
    }

    private boolean checkBranchOffsetsFit(
            List<Instruction> originalInsns,
            List<Integer> originalOffsets,
            List<Boolean> encryptFlags,
            ConstStringOffsetMapping mapping) {
        for (int i = 0; i < originalInsns.size(); i++) {
            Instruction insn = originalInsns.get(i);
            if (!(insn instanceof OffsetInstruction)) continue;
            Opcode opcode = insn.getOpcode();
            // switch已由hasTryBlockOrSwitch排除
            if (opcode == Opcode.PACKED_SWITCH || opcode == Opcode.SPARSE_SWITCH) continue;
            int oldInsnOffset = originalOffsets.get(i);
            int oldRelOffset = ((OffsetInstruction) insn).getCodeOffset();
            int oldTargetOffset = oldInsnOffset + oldRelOffset;
            Integer newInsnOffset = mapping.oldToNew.get(oldInsnOffset);
            Integer newTargetOffset = mapping.oldToNew.get(oldTargetOffset);
            if (newInsnOffset == null || newTargetOffset == null) return false;
            // 目标必须是新布局中的指令边界，且不能是方法末尾（超出最后一条指令）
            if (!mapping.newInstructionStarts.contains(newTargetOffset)) return false;
            if (newTargetOffset >= mapping.newTotalCodeUnits) return false;
            int newRelOffset = newTargetOffset - newInsnOffset;
            switch (opcode.format) {
                case Format10t:
                    if (newRelOffset < -128 || newRelOffset > 127) return false;
                    break;
                case Format20t:
                case Format21t:
                case Format22t:
                    if (newRelOffset < Short.MIN_VALUE || newRelOffset > Short.MAX_VALUE) return false;
                    break;
                case Format31t:
                    // goto/32 范围足够，无需检查
                    break;
                default:
                    return false;
            }
        }
        return true;
    }

    private ImmutableInstruction shiftInstructionAtOffset(
            Instruction insn,
            int oldInsnOffset,
            ConstStringOffsetMapping mapping) {
        if (!(insn instanceof OffsetInstruction)) {
            return ImmutableInstruction.of(insn);
        }
        OffsetInstruction offsetInsn = (OffsetInstruction) insn;
        int oldRelOffset = offsetInsn.getCodeOffset();
        int oldTargetOffset = oldInsnOffset + oldRelOffset;
        Integer newInsnOffset = mapping.oldToNew.get(oldInsnOffset);
        Integer newTargetOffset = mapping.oldToNew.get(oldTargetOffset);
        if (newInsnOffset == null || newTargetOffset == null) {
            return ImmutableInstruction.of(insn);
        }
        int newRelOffset = newTargetOffset - newInsnOffset;

        Opcode opcode = insn.getOpcode();
        switch (opcode.format) {
            case Format10t:
                if (newRelOffset >= -128 && newRelOffset <= 127) {
                    return new ImmutableInstruction10t(opcode, (byte) newRelOffset);
                }
                break;
            case Format20t:
                if (newRelOffset >= Short.MIN_VALUE && newRelOffset <= Short.MAX_VALUE) {
                    return new ImmutableInstruction20t(opcode, (short) newRelOffset);
                }
                break;
            case Format21t:
                if (newRelOffset >= Short.MIN_VALUE && newRelOffset <= Short.MAX_VALUE && insn instanceof Instruction21t) {
                    return new ImmutableInstruction21t(opcode, ((Instruction21t) insn).getRegisterA(), (short) newRelOffset);
                }
                break;
            case Format22t:
                if (newRelOffset >= Short.MIN_VALUE && newRelOffset <= Short.MAX_VALUE && insn instanceof Instruction22t) {
                    Instruction22t i22 = (Instruction22t) insn;
                    return new ImmutableInstruction22t(opcode, i22.getRegisterA(), i22.getRegisterB(), (short) newRelOffset);
                }
                break;
            case Format31t:
                if (insn instanceof Instruction31t) {
                    return new ImmutableInstruction31t(opcode, ((Instruction31t) insn).getRegisterA(), newRelOffset);
                }
                break;
            default:
                break;
        }
        return ImmutableInstruction.of(insn);
    }

    /**
     * 加密常量字符串：XOR加密后Base64编码，添加"ARKS"前缀。
     * shell运行时检测到"ARKS"前缀会自动解密还原。
     *
     * @param original 原始字符串
     * @return 加密后的字符串（"ARKS" + Base64(XOR(original, key))），无需加密时返回null
     */
    private String encryptConstString(String original) {
        if (original == null || original.isEmpty()) return null;
        // 已经加密过的字符串不再重复加密
        if (original.startsWith(CONST_STRING_ENC_PREFIX)) return null;
        try {
            byte[] data = original.getBytes("UTF-8");
            byte[] encrypted = new byte[data.length];
            for (int i = 0; i < data.length; i++) {
                encrypted[i] = (byte) (data[i] ^ CONST_STRING_XOR_KEY[i % CONST_STRING_XOR_KEY.length]);
            }
            return CONST_STRING_ENC_PREFIX + Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception e) {
            return null;
        }
    }
}
